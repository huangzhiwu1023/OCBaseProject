//
//  CountdownLabel.h
//  PLShortVideoKitDemo
//
//  Created by 黄志武 on 2018/3/13.
//  Copyright © 2018年 Pili Engineering, Qiniu Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^endCount)(int a);

@interface CountdownLabel : UILabel
//开始倒计时时间
@property (nonatomic, assign) NSInteger count;

@property (nonatomic,copy) endCount endCount;

//执行这个方法开始倒计时
- (void)startCount;

//立马结束倒计时,并重置count
- (void)endCountWithResetCount:(NSInteger)count;
@end
