//
//  YFFlieTool.h
//  jsyf_user
//
//  Created by pro on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YFUserModel.h"
#import "YFSelectMachineFilterModel.h"
#import "YFMHKeyChainTool.h"
#import "YFNewestListModel.h"
#import "YFESJListModel.h"

typedef void (^backString)(NSDictionary* ImageID);
typedef void (^fail)(NSString* error);

//小红点个数
typedef void (^redNumBlock)(NSInteger redNum);

@interface YFFlieTool : NSObject
+ (NSString *)getDocumentsFliePath;//documents目录
+ (NSString *)getCachesFliePath;//Caches目录
+ (NSString *)getTmpFliePath;//tmp目录
+ (NSString *)getUserInfoPath:(NSString *)key;//保存用户信息目录
//获取路径文件的大小
+ (double)fileSize:(NSString *)filePath;
//文件是否存在，若不存在，则创建并返回结果，若存在则返回YES
+ (BOOL)fileIsExistAtPath:(NSString *)path;
//文件夹是否存在，若不存在，则创建并返回结果，若存在则返回YES
+ (BOOL)directoryIsExistAtPath:(NSString *)path;

/** 删除文件 */
+(BOOL)deleteFile:(NSString *)filePath;

+(CGSize)getImageSizeWithURL:(id)imageURL;


//模型转字典
+(NSDictionary *)dicModel:(NSObject *)model;
//字典转模型
+(YFSelectMachineFilterSenddata *)modelFordic:(NSDictionary *)dic;
+(YFUserModelSenddata *)getUserModel;
+(void )saveUserModel:(YFUserModelSenddata *)model;
+(NSMutableArray<NewestListSendData *> *)dicToModel:(NSArray*)arr;
+(NSMutableArray<ESJListSenddata *> *)dicToEsjModel:(NSArray*)arr;

//设置资讯字体
+(void)setNewsWorld;
//时间格式
+ (NSString *)getDateStringWithTimeStr:(NSString *)str formattStr:(NSString *)formatter;
+ (NSString *)getTimeStrWithString:(NSString *)str;
//十六进制与字符串互转
+ (NSString *)convertHexStrToString:(NSString *)str;
+ (NSString *)convertStringToHexStr:(NSString *)str;

+ (NSString *)base64StringFromText:(NSString *)text;

//设置富文本,匹配所有出现的关键字
+(NSMutableAttributedString *)colorLabel:(NSString *)superStr colorString:(NSString *)colorString color:(UIColor *)color;
//设置文字大小与颜色,只匹配第一次出现的关键字
+(NSMutableAttributedString *)LabelAttributedstr1:(NSString *)str1 nameStr:(NSString *)nameStr color:(UIColor *)color size:(CGFloat)size;

//固定接口上传图片
+ (void)upLoadImageData:(NSData *)imgData type:(NSString *)typeString pathFile:(NSString *)pathFile backString:(backString)backString  fail:(fail)fail;

+ (BOOL)twoNumStr:(NSString *)num ;
+(void)changeLabelStyle:(UILabel *)label;

//获取手机的唯一标示
+ (NSString *)getIDFV;
//利用正则去掉指定字符
+ (NSString *)getZZwithString:(NSString *)string;
//时间转化
+(NSString *)stringRepToOld:(NSString *)Str rep:(NSString *)rep withString:(NSString *)withString;
//字符串替换
+(NSString *)stringRepTo:(NSString *)Str withString:(NSString *)withString;

@property(nonatomic, weak) redNumBlock rednumBlock;

- (void)getRedPointNum:(redNumBlock)redNumBlock;

//获取阿里云上传视频key
+ (void)requestAlyunKeyWithHandler:(void (^)(NSString *keyId, NSString *keySecret, NSString *token,NSString *expireTime,  NSError * error))handler;

@end
