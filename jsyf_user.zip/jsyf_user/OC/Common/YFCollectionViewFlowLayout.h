//
//  YFCollectionViewFlowLayout.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/12.
//  Copyright © 2018年 YF. All rights reserved.
//

//实现头部悬停的CollectionView
#import <UIKit/UIKit.h>

@interface YFCollectionViewFlowLayout : UICollectionViewFlowLayout
@property (nonatomic, assign) CGFloat navHeight;
@end
