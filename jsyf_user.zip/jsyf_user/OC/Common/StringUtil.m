//
//  StringUtil.m
//  meichai
//
//  Created by niuming on 15/4/28.
//  Copyright (c) 2015年 imac . All rights reserved.
//

#import "StringUtil.h"

@implementation StringUtil
//单例模式
+(StringUtil *)sharedInstance
{
    static StringUtil *sharedSingleton = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^(void) {
        sharedSingleton = [[self alloc] initialize];
    });
    return sharedSingleton;
}

-(id)initialize {
    if(self == [super init] )
    {
        //initial something here
    }
    return self;
}

-(NSString *)stringToTrim:(NSString *)oldstr{
    NSString *trimmedString = [oldstr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return trimmedString;
};

- (BOOL) isBlankString:(NSString *)string {
    if (string == nil || string == NULL || string.length<=0) {
        return YES;
    }else{
        return NO;
    }
}

-(BOOL)isEmailAddress:(NSString *)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

-(BOOL) isMobilePhone:(NSString *)mobile
{
    //手机号以13，15，17，18开头，八个 \d 数字字符 -> 以1开头的11位数字
    NSString *phoneRegex = @"^((1[0-9])|(1[0-9])|(1[0-9])|(1[0,0-9]))\\d{9}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:mobile];
}

- (BOOL)isIdentifyNumber:(NSString *)number {
    NSString *numberRegex = @"(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{2}[0-9Xx]$)";
//    NSString *numberRegex = @"^[1-9]\\d{7}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}$|^[1-9]\\d{5}[1-9]\\d{3}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}([0-9]|X)$";
     NSPredicate *numberTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",numberRegex];
    return [numberTest evaluateWithObject:number];
}

- (BOOL)validateIDCardNumber:(NSString *)value {
    value = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSInteger length =0;
    if (!value) {
        return NO;
    }else {
        length = value.length;
        if (length !=15 && length !=18) {
            return NO;
        }
        
    }
    // 省份代码
    NSArray *areasArray =@[@"11",@"12", @"13",@"14", @"15",@"21", @"22",@"23", @"31",@"32", @"33",@"34", @"35",@"36", @"37",@"41",@"42",@"43", @"44",@"45", @"46",@"50", @"51",@"52", @"53",@"54", @"61",@"62", @"63",@"64", @"65",@"71", @"81",@"82", @"91"];
    NSString *valueStart2 = [value substringToIndex:2];
    BOOL areaFlag =NO;
    for (NSString *areaCode in areasArray) {
        if ([areaCode isEqualToString:valueStart2]) {
            areaFlag =YES;
            break;
        }
    }
    if (!areaFlag) {
        return false;
    }
    NSRegularExpression *regularExpression;
    NSUInteger numberofMatch;
    int year =0;
    switch (length) {
        case 15:
            year = [value substringWithRange:NSMakeRange(6,2)].intValue +1900;
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$"
                                                                        options:NSRegularExpressionCaseInsensitive
                         error:nil];//测试出生日期的合法性
                
            }else {
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$"
                                                                        options:NSRegularExpressionCaseInsensitive
                    error:nil];//测试出生日期的合法性
            }

            numberofMatch = [regularExpression numberOfMatchesInString:value
                             options:NSMatchingReportProgress
                             
                         range:NSMakeRange(0, value.length)];
            
            //            [regularExpression release];
            
            if(numberofMatch >0) {
                return YES;
            }else {
                return NO;
            }
        case 18:
            year = [value substringWithRange:NSMakeRange(6,4)].intValue;
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$"                         options:NSRegularExpressionCaseInsensitive
                                                        error:nil];//测试出生日期的合法性
                
            }else {

                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$"                                                                         options:NSRegularExpressionCaseInsensitive
                              error:nil];//测试出生日期的合法性

            }
            numberofMatch = [regularExpression numberOfMatchesInString:value
                        options:NSMatchingReportProgress
                range:NSMakeRange(0, value.length)];
            if(numberofMatch >0) {
                int S = ([value substringWithRange:NSMakeRange(0,1)].intValue + [value substringWithRange:NSMakeRange(10,1)].intValue) *7 + ([value substringWithRange:NSMakeRange(1,1)].intValue + [value substringWithRange:NSMakeRange(11,1)].intValue) *9 + ([value substringWithRange:NSMakeRange(2,1)].intValue + [value substringWithRange:NSMakeRange(12,1)].intValue) *10 + ([value substringWithRange:NSMakeRange(3,1)].intValue + [value substringWithRange:NSMakeRange(13,1)].intValue) *5 + ([value substringWithRange:NSMakeRange(4,1)].intValue + [value substringWithRange:NSMakeRange(14,1)].intValue) *8 + ([value substringWithRange:NSMakeRange(5,1)].intValue + [value substringWithRange:NSMakeRange(15,1)].intValue) *4 + ([value substringWithRange:NSMakeRange(6,1)].intValue + [value substringWithRange:NSMakeRange(16,1)].intValue) *2 + [value substringWithRange:NSMakeRange(7,1)].intValue *1 + [value substringWithRange:NSMakeRange(8,1)].intValue *6 + [value substringWithRange:NSMakeRange(9,1)].intValue *3;
                int Y = S %11;
                NSString *M =@"F";
                NSString *JYM =@"10X98765432";
                
                M = [JYM substringWithRange:NSMakeRange(Y,1)];// 判断校验位
                if ([M isEqualToString:[value substringWithRange:NSMakeRange(17,1)]]) {
                    return YES;// 检测ID的校验位
                }else {
                    return NO;
                }
                
            }else {
                return NO;
            }
        default:
            return false;
    
    }
 
}

- (BOOL)isUserNameFormat:(NSString *)userName {
    //^[a-zA-Z] + [a-zA-Z_-]{3-19}+$   ^[A-Za-z][A-Za-z0-9_\\-]{3,19}$
    NSString *userNameRegex = @"^[A-Za-z][A-Za-z0-9_\\-]{3,19}$";
    NSPredicate *userNameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",userNameRegex];
    return [userNameTest evaluateWithObject:userName];
}


-(float) getStringHeight:(NSString *)str width:(float)width font:(UIFont*)font{
    CGSize size = [str sizeWithFont:font constrainedToSize:CGSizeMake(width,10000.0f) lineBreakMode:NSLineBreakByWordWrapping];
    return size.height;
}



-(NSString *)appendString:(NSString *)stringA andStringB:(NSString *)stringB andStringC:(NSString *)stringC andStringD:(NSString *)stringD{
    NSMutableString * result=[[NSMutableString alloc]init];
    if(stringA){
        [result appendString:stringA];
    }
    if(stringB){
        [result appendString:stringB];
    }
    if(stringC){
        [result appendString:stringC];
    }
    if(stringD){
        [result appendString:stringD];
    }
    
    return result;
}

-(NSString *)appendString:(NSArray *)stringArray{
    NSString *result = [stringArray componentsJoinedByString:@""];
    return result;
}

-(NSString *)base64String:(NSString *)plainString{
    // Create NSData object
    NSData *nsdata = [plainString dataUsingEncoding:NSUTF8StringEncoding];
    // Get NSString from NSData object in Base64
    NSString *base64Encoded = [nsdata base64EncodedStringWithOptions:0];
    // Print the Base64 encoded string
    NSLog(@"base64Encoded: %@", base64Encoded);
    
    return base64Encoded;
}

- (NSString *)textFromBase64String:(NSString *)base64 {
    if (base64 == nil) {
        return @"";
    }
    NSData *data = [[NSData alloc] initWithBase64EncodedString:base64 options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return text;
}

-(NSString*)encodeString:(NSString*)plainString{
    
    NSString * encodedString = (__bridge_transfer  NSString*) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (__bridge CFStringRef)plainString, NULL, (__bridge CFStringRef)@"!*'();:@&=+$,/?%#[]", kCFStringEncodingUTF8 );
    return encodedString;
}

-(NSString *)base64AndUrlEncodeString:(NSString*)plainString{
    NSString * str1 = [self base64String:plainString];
    NSString * str2 = [self encodeString:str1];
    return str2;
}

-(NSString *)trimZero:(NSString*)numberStr{
    NSString * s = nil;
    int offset = numberStr.length - 1;
    while (offset)
    {
        s = [numberStr substringWithRange:NSMakeRange(offset, 1)];
        if ([s isEqualToString:@"0"] || [s isEqualToString:@"."])
        {
            offset--;
        }
        else
        {
            break;
        }
    }
    NSString * outNumber = [numberStr substringToIndex:offset+1];
    NSLog(@"----result=%@", outNumber);
    return outNumber;
}

-(BOOL)isIntString:(NSString *)plainStr
{
    NSScanner* scan = [NSScanner scannerWithString:plainStr];
    int val;
    return[scan scanInt:&val] && [scan isAtEnd];
}


//字典转json字符串
- (NSString*)dictionaryToJson:(NSDictionary *)dic

{
    if (!dic) {
        return nil;
    }
    
    NSError *parseError = nil;
    NSLog(@"dicttoJson的dic == %@",dic);
   
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    NSString * str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    str = [str stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    str  = [str stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    if (parseError) {
        NSLog(@"jsonError:%@", parseError);
    }
    
    return [str urlEncode];

}


- (NSString*)jsonStringToDic:(NSDictionary *)dic

{
    if (!dic) {
        return nil;
    }
    
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    NSString * str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    str = [str stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    str  = [str stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    return str;
    
}
- (NSString *)jsonStringToArr:(NSArray *)arr

{
    if (!arr || [arr  isEqual: @[]]) {
        return nil;
    }
    
    
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:arr options:NSJSONWritingPrettyPrinted error:&parseError];
    NSString * str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    str = [str stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    str  = [str stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    return str;
}


- (NSString *)everyWordLineFeed:(NSString *)str {
    if (str.length == 0) {
        return @"";
    }
    NSString *lineStr = @"";
    for (int i = 0; i < str.length; i++) {
        lineStr = [lineStr stringByAppendingString:[str substringWithRange:NSMakeRange(i, 1)]];
        if (i < str.length -1) {
            lineStr = [NSString stringWithFormat:@"%@\n", lineStr];
        }
    }
    return lineStr;
}

@end
