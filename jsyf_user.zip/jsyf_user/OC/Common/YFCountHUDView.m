//
//  YFCountHUDView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/17.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFCountHUDView.h"

@interface YFCountHUDView()
@property(nonatomic, strong) UIView *backView;
@property(nonatomic, strong) UIImageView *iconIV;
@property(nonatomic, strong) UILabel *tipsLB;
@property(nonatomic, strong) UILabel *countLB;
@property(nonatomic, assign) NSInteger count;
@end

@implementation YFCountHUDView
- (instancetype)initWithFrame:(CGRect)frame contentFrame:(CGRect)contentFrame Image:(NSString *)image title:(NSString *)title isEndCount:(NSInteger)Count{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        self.backView = [[UIView alloc] init];
        [self addSubview:self.backView];
        [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
            make.width.equalTo(contentFrame.size.width);
            make.height.equalTo(contentFrame.size.height);
        }];
        self.backView.backgroundColor = mHexColorAlpha(0x000000, 0.8);
        self.backView.layer.masksToBounds = YES;
        self.backView.layer.cornerRadius = 10;
        self.iconIV = [[UIImageView alloc] init];
        [self.backView addSubview:self.iconIV];
        [self.iconIV mas_updateConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(30);
        }];
        self.iconIV.image = [UIImage imageNamed:image];
        self.tipsLB = [[UILabel alloc] init];
        [self.backView addSubview:self.tipsLB];
        [self.tipsLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV.mas_bottom).equalTo(20);
            make.left.equalTo(8);
            make.right.equalTo(-8);
        }];
        self.tipsLB.numberOfLines = 0;
        self.tipsLB.textAlignment = NSTextAlignmentCenter;
        self.tipsLB.textColor = [UIColor whiteColor];
        self.tipsLB.font = [UIFont systemFontOfSize:18];
        self.tipsLB.text = title;
        self.countLB = [[UILabel alloc] init];
        [self.backView addSubview:self.countLB];
        self.countLB.textAlignment = NSTextAlignmentCenter;
        self.countLB.textColor = kYellowColor;
        self.countLB.font = [UIFont systemFontOfSize:16];
        [self.countLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.tipsLB.mas_bottom).equalTo(20);
            make.left.equalTo(8);
            make.right.equalTo(-8);
        }];
        self.count = Count;
        
        if (Count > 2) {
             self.countLB.text = [NSString stringWithFormat:@"%lds后自动跳转",self.count];
             self.countLB.hidden = NO;
            [self.countLB mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.tipsLB.mas_bottom).equalTo(20);
                make.left.equalTo(8);
                make.right.equalTo(-8);
            }];
              [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timeMove:) userInfo:nil repeats:YES];
        }
        else{
            [self.iconIV mas_updateConstraints:^(MASConstraintMaker *make) {
                make.centerX.equalTo(0);
                make.top.equalTo(50);
            }];
            
            self.countLB.hidden = YES;
             [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timeMove2:) userInfo:nil repeats:YES];
        }
    }
    return self;
}

- (void)timeMove:(NSTimer *)theTimer {
    self.count -= 1;
    if (self.count > 0) {
        self.countLB.text = [NSString stringWithFormat:@"%lds后自动跳转",self.count];
    }
    else {
        !_endCount ?: _endCount(0);
        [theTimer invalidate];
        theTimer = nil;
        [self removeFromSuperview];
    }
}

- (void)timeMove2:(NSTimer *)theTimer {
    self.count -= 1;
    if (self.count > 0) {
       
    }
    else {
        !_endCount ?: _endCount(0);
        [theTimer invalidate];
        theTimer = nil;
        [self removeFromSuperview];
    }
}
@end
