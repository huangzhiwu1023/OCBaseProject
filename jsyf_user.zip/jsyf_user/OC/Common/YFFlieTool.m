//
//  YFFlieTool.m
//  jsyf_user
//
//  Created by pro on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "YFFlieTool.h"
#import "YFNewsCenterModel.h"

@implementation YFFlieTool

+ (NSString *)getDocumentsFliePath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *docDir = [paths objectAtIndex:0];
    
    return docDir;
}


+ (NSString *)getCachesFliePath {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesDir = [paths objectAtIndex:0];
    return cachesDir;
}

+ (NSString *)getTmpFliePath
{
    NSString *tmpDir = NSTemporaryDirectory();
    return tmpDir;
}

+ (NSString *)getUserInfoPath:(NSString *)key{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [paths firstObject];
    
    //获取所有信息字典
    NSString *filePath = [NSString stringWithFormat:@"%@/%@",documentPath,key];
//    NSLog(@"aa=%@",filePath);
    return filePath;
}


//获取路径文件的大小
+ (double)fileSize:(NSString *)filePath {
    
    NSFileManager *manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:filePath]) {
        return 0.f;
    }
    long long size = [manager attributesOfItemAtPath:filePath error:nil].fileSize;
    return size;
}


+ (NSString *)filesize:(NSInteger)size
{
    NSString * sizeText  = @"";
    if (size >= pow(10, 9)) { // size >= 1GB
        sizeText = [NSString stringWithFormat:@"%.2fGB", size / pow(10, 9)];
    } else if (size >= pow(10, 6)) { // 1GB > size >= 1MB
        sizeText = [NSString stringWithFormat:@"%.2fMB", size / pow(10, 6)];
    } else if (size >= pow(10, 3)) { // 1MB > size >= 1KB
        sizeText = [NSString stringWithFormat:@"%.2fKB", size / pow(10, 3)];
    } else { // 1KB > size
        sizeText = [NSString stringWithFormat:@"%zdB", size];
    }
    return sizeText;
    
}
//文件是否存在，若不存在，则创建并返回结果，若存在则返回YES
+ (BOOL)fileIsExistAtPath:(NSString *)path {
    
    NSFileManager *manager = [NSFileManager defaultManager];
    BOOL flag = [manager fileExistsAtPath:path];
    if (flag) {
        return flag;
    } else {
        //不存在
        return [manager createFileAtPath:path contents:nil attributes:nil];
    }
}
//文件夹是否存在，若不存在，则创建并返回结果，若存在则返回YES
+ (BOOL)directoryIsExistAtPath:(NSString *)path {
    
    BOOL isDir;
    NSFileManager *manager = [NSFileManager defaultManager];
    BOOL flag = [manager fileExistsAtPath:path isDirectory:&isDir];
    if (!(isDir && !flag)) {
        //文件夹不存在
        return [manager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    } else {
        return YES;
    }
}

+(CGSize)getImageSizeWithURL:(id)imageURL
{
    NSURL* URL = nil;
    if([imageURL isKindOfClass:[NSURL class]]){
        URL = imageURL;
    }
    if([imageURL isKindOfClass:[NSString class]]){
        URL = [NSURL URLWithString:imageURL];
    }
    if(URL == nil)
        return CGSizeZero;                  // url不正确返回CGSizeZero
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:URL];
    NSString* pathExtendsion = [URL.pathExtension lowercaseString];
    
    CGSize size = CGSizeZero;
    if([pathExtendsion isEqualToString:@"png"]){
        size =  [self getPNGImageSizeWithRequest:request];
    }
    else if([pathExtendsion isEqual:@"gif"])
    {
        size =  [self getGIFImageSizeWithRequest:request];
    }
    else{
        size = [self getJPGImageSizeWithRequest:request];
    }
    if(CGSizeEqualToSize(CGSizeZero, size))                    // 如果获取文件头信息失败,发送异步请求请求原图
    {
        NSData* data = [NSURLConnection sendSynchronousRequest:[NSURLRequest requestWithURL:URL] returningResponse:nil error:nil];
        UIImage* image = [UIImage imageWithData:data];
        if(image)
        {
            size = image.size;
        }
    }
    return size;
}

//  获取PNG图片的大小
+(CGSize)getPNGImageSizeWithRequest:(NSMutableURLRequest*)request
{
    [request setValue:@"bytes=16-23" forHTTPHeaderField:@"Range"];
    NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    if(data.length == 8)
    {
        int w1 = 0, w2 = 0, w3 = 0, w4 = 0;
        [data getBytes:&w1 range:NSMakeRange(0, 1)];
        [data getBytes:&w2 range:NSMakeRange(1, 1)];
        [data getBytes:&w3 range:NSMakeRange(2, 1)];
        [data getBytes:&w4 range:NSMakeRange(3, 1)];
        int w = (w1 << 24) + (w2 << 16) + (w3 << 8) + w4;
        int h1 = 0, h2 = 0, h3 = 0, h4 = 0;
        [data getBytes:&h1 range:NSMakeRange(4, 1)];
        [data getBytes:&h2 range:NSMakeRange(5, 1)];
        [data getBytes:&h3 range:NSMakeRange(6, 1)];
        [data getBytes:&h4 range:NSMakeRange(7, 1)];
        int h = (h1 << 24) + (h2 << 16) + (h3 << 8) + h4;
        return CGSizeMake(w, h);
    }
    return CGSizeZero;
}
//  获取gif图片的大小
+(CGSize)getGIFImageSizeWithRequest:(NSMutableURLRequest*)request
{
    [request setValue:@"bytes=6-9" forHTTPHeaderField:@"Range"];
    NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    if(data.length == 4)
    {
        short w1 = 0, w2 = 0;
        [data getBytes:&w1 range:NSMakeRange(0, 1)];
        [data getBytes:&w2 range:NSMakeRange(1, 1)];
        short w = w1 + (w2 << 8);
        short h1 = 0, h2 = 0;
        [data getBytes:&h1 range:NSMakeRange(2, 1)];
        [data getBytes:&h2 range:NSMakeRange(3, 1)];
        short h = h1 + (h2 << 8);
        return CGSizeMake(w, h);
    }
    return CGSizeZero;
}
//  获取jpg图片的大小
+(CGSize)getJPGImageSizeWithRequest:(NSMutableURLRequest*)request
{
    [request setValue:@"bytes=0-209" forHTTPHeaderField:@"Range"];
    NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    if ([data length] <= 0x58) {
        return CGSizeZero;
    }
    
    if ([data length] < 210) {// 肯定只有一个DQT字段
        short w1 = 0, w2 = 0;
        [data getBytes:&w1 range:NSMakeRange(0x60, 0x1)];
        [data getBytes:&w2 range:NSMakeRange(0x61, 0x1)];
        short w = (w1 << 8) + w2;
        short h1 = 0, h2 = 0;
        [data getBytes:&h1 range:NSMakeRange(0x5e, 0x1)];
        [data getBytes:&h2 range:NSMakeRange(0x5f, 0x1)];
        short h = (h1 << 8) + h2;
        return CGSizeMake(w, h);
    } else {
        short word = 0x0;
        [data getBytes:&word range:NSMakeRange(0x15, 0x1)];
        if (word == 0xdb) {
            [data getBytes:&word range:NSMakeRange(0x5a, 0x1)];
            if (word == 0xdb) {// 两个DQT字段
                short w1 = 0, w2 = 0;
                [data getBytes:&w1 range:NSMakeRange(0xa5, 0x1)];
                [data getBytes:&w2 range:NSMakeRange(0xa6, 0x1)];
                short w = (w1 << 8) + w2;
                short h1 = 0, h2 = 0;
                [data getBytes:&h1 range:NSMakeRange(0xa3, 0x1)];
                [data getBytes:&h2 range:NSMakeRange(0xa4, 0x1)];
                short h = (h1 << 8) + h2;
                return CGSizeMake(w, h);
            } else {// 一个DQT字段
                short w1 = 0, w2 = 0;
                [data getBytes:&w1 range:NSMakeRange(0x60, 0x1)];
                [data getBytes:&w2 range:NSMakeRange(0x61, 0x1)];
                short w = (w1 << 8) + w2;
                short h1 = 0, h2 = 0;
                [data getBytes:&h1 range:NSMakeRange(0x5e, 0x1)];
                [data getBytes:&h2 range:NSMakeRange(0x5f, 0x1)];
                short h = (h1 << 8) + h2;
                return CGSizeMake(w, h);
            }
        } else {
            return CGSizeZero;
        }
    }
}


+ (BOOL)deleteFile:(NSString *)filePath {
    NSFileManager *manager = [NSFileManager defaultManager];
    if([manager fileExistsAtPath:filePath]) {  //如果存在临时文件的配置文件
        NSError *error=nil;
        return [manager removeItemAtPath:filePath error:&error];
    }
    return  NO;
}
+(NSDictionary *)dicModel:(NSObject *)model {
//     [User keyValuesArrayWithObjectArray:userArray];
    NSLog(@"===%@",model.mj_keyValues);
    return model.mj_keyValues;
}


+(YFSelectMachineFilterSenddata *)modelFordic:(NSDictionary *)dic{
  return [YFSelectMachineFilterSenddata mj_objectWithKeyValues:dic];
}

+(YFUserModelSenddata *)getUserModel {
   YFUserModelSenddata* sendData = nil;
    mWZLSERIALIZE_UNARCHIVE(sendData, USERKEY, [YFFlieTool getUserInfoPath:USERKEY]);
    return sendData;
}

+ (void)saveUserModel:(YFUserModelSenddata *)model {
    mWZLSERIALIZE_ARCHIVE(model, USERKEY, [YFFlieTool getUserInfoPath:USERKEY]);
}

+(void)setNewsWorld {
//    [[SSLayouterConfig shared] setConfig:@{SSLayouterDefaultTextColor:@"#565656",SSLayouterDefaultFontSize:@"14",SSLayouterDefaultLineHeightMultiplier:@"2",SSLayouterDefaultMarginLeft:@"15",SSLayouterDefaultMarginRight:@"15"}];

}

+ (NSString *)base64StringFromText:(NSString *)text {
    
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [data base64EncodedStringWithOptions:0];
    
    return base64String;
}

+ (NSString *)getDateStringWithTimeStr:(NSString *)str formattStr:(NSString *)formatter{
    NSTimeInterval time=[str doubleValue]/1000;//传入的时间戳str如果是精确到毫秒的记得要/1000
    NSDate *detailDate=[NSDate dateWithTimeIntervalSince1970:time];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init]; //实例化一个NSDateFormatter对象
    //设定时间格式,这里可以设置成自己需要的格式
    [dateFormatter setDateFormat:formatter];
    NSString *currentDateStr = [dateFormatter stringFromDate: detailDate];
    return currentDateStr;
}

+ (NSString *)getTimeStrWithString:(NSString *)str{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];// 创建一个时间格式化对象
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"]; //设定时间的格式
    NSDate *tempDate = [dateFormatter dateFromString:str];//将字符串转换为时间对象
    NSString *timeStr = [NSString stringWithFormat:@"%ld", (long)[tempDate timeIntervalSince1970]*1000];//字符串转成时间戳,精确到毫秒*1000
    return timeStr;
}


+(NSMutableAttributedString *)colorLabel:(NSString *)superStr colorString:(NSString *)colorString color:(UIColor *)color{
    
    //1.特定文字用法
    NSMutableArray *arrayRanges = [NSMutableArray array];
    NSString *result = superStr;
    NSMutableAttributedString *attributeStr = [[NSMutableAttributedString alloc] initWithString:result];
    NSRange rang = [result rangeOfString:colorString];
    if (rang.location != NSNotFound && rang.length != 0) {
        [arrayRanges addObject:[NSNumber numberWithInteger:rang.location]];//将第一次的加入到数组中
        NSRange rang1 = {0,0};
        NSInteger location = 0;
        NSInteger length = 0;
        for (int i = 0;; i++) {
            if (0 == i) {
                //去掉这个abc字符串
                location = rang.location + rang.length;
                length = result.length - rang.location - rang.length;
                rang1 = NSMakeRange(location, length);
            }
            else {
                location = rang1.location + rang1.length;
                length = result.length - rang1.location - rang1.length;
                rang1 = NSMakeRange(location, length);
            }
            //在一个range范围内查找另一个字符串的range
            rang1 = [result rangeOfString:colorString options:NSCaseInsensitiveSearch range:rang1];
            
            if (rang1.location == NSNotFound && rang1.length == 0) {
                break;
            }
            else//添加符合条件的location进数组
                [arrayRanges addObject:[NSNumber numberWithInteger:rang1.location]];
        }
        for (NSNumber *redRange in arrayRanges) {
            [attributeStr addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(redRange.integerValue, colorString.length)];
        }
    }
    return attributeStr;
}

/**
 改变文字匹配到文字的颜色，大小
 color 颜色
 size 尺寸
 */
+(NSMutableAttributedString *)LabelAttributedstr1:(NSString *)str1 nameStr:(NSString *)nameStr color:(UIColor *)color size:(CGFloat)size{

    //1.特定文字用法
    NSString *result = str1;
    NSMutableAttributedString *attributeStr = [[NSMutableAttributedString alloc] initWithString:result];
    NSRange redRange = NSMakeRange([[attributeStr string] rangeOfString:nameStr].location, [[attributeStr string] rangeOfString:nameStr].length);
    
    [attributeStr addAttribute:NSForegroundColorAttributeName value:color range:redRange]; // 关键步骤，设置指定位置文字的颜色
    [attributeStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:size] range:redRange]; //关键步骤，设置指定位置文字的字号大小
    
    return attributeStr;
}


//将十六进制的字符串转换成NSString则可使用如下方式:
+ (NSString *)convertHexStrToString:(NSString *)str {
    if (!str || [str length] == 0) {
        return nil;
    }
    
    NSMutableData *hexData = [[NSMutableData alloc] initWithCapacity:8];
    NSRange range;
    if ([str length] % 2 == 0) {
        range = NSMakeRange(0, 2);
    } else {
        range = NSMakeRange(0, 1);
    }
    for (NSInteger i = range.location; i < [str length]; i += 2) {
        unsigned int anInt;
        NSString *hexCharStr = [str substringWithRange:range];
        NSScanner *scanner = [[NSScanner alloc] initWithString:hexCharStr];
        
        [scanner scanHexInt:&anInt];
        NSData *entity = [[NSData alloc] initWithBytes:&anInt length:1];
        [hexData appendData:entity];
        
        range.location += range.length;
        range.length = 2;
    }
    NSString *string = [[NSString alloc]initWithData:hexData encoding:NSUTF16StringEncoding];
    return string;
}

//将NSString转换成十六进制的字符串则可使用如下方式:
+ (NSString *)convertStringToHexStr:(NSString *)str {
    if (!str || [str length] == 0) {
        return @"";
    }
    NSData *data = [str dataUsingEncoding:NSUTF16StringEncoding];
    
    NSMutableString *string = [[NSMutableString alloc] initWithCapacity:[data length]];
    
    [data enumerateByteRangesUsingBlock:^(const void *bytes, NSRange byteRange, BOOL *stop) {
        unsigned char *dataBytes = (unsigned char*)bytes;
        for (NSInteger i = 0; i < byteRange.length; i++) {
            NSString *hexStr = [NSString stringWithFormat:@"%x", (dataBytes[i]) & 0xff];
            if ([hexStr length] == 2) {
                [string appendString:hexStr];
            } else {
                [string appendFormat:@"0%@", hexStr];
            }
        }
    }];
    
    return string;
}

+ (void)upLoadImageData:(NSData *)imgData type:(NSString *)typeString pathFile:(NSString *)pathFile backString:(backString)backString fail:(fail)fail{
    NSDictionary * dic = @{@"file":imgData,@"fileType":typeString, @"path":pathFile};
    [[ESNetworkManager rac_uploadImages:@[imgData] urlString:@"/OSSFile/multiFileUpload.json" params:dic targetWidth:1.0] subscribeNext:^(NSArray<NSDictionary *>* arr) {
        if(arr.count > 0) {
             backString(arr[0]);
        }else{
          
        }
       
    } error:^(NSError * _Nullable error) {
        fail(error.localizedDescription);
    }];
}


+ (BOOL)twoNumStr:(NSString *)num {
     CGFloat a = num.floatValue + 0.0004;
     CGFloat b = a * 100.0000000;
     CGFloat c = (int)(a * 100);
    if ((b / 100000) >= 10 ){//大于10000
       return NO;
    }else{//小于10000
        if ((b-c) > 0.1) {
            return NO;
        }
        return YES;
    }
    return YES;
}

//+ (instancetype)bezierPathWithRoundedRect:(CGRect)rect byRoundingCorners:(UIRectCorner)corners cornerRadii:(CGSize)cornerRadii;

+(void)changeLabelStyle:(UILabel *)label {
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:label.bounds byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft cornerRadii:CGSizeMake(14, 14)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = label.bounds;
    maskLayer.path = maskPath.CGPath;
    label.backgroundColor = [UIColor orangeColor];
    label.layer.mask = maskLayer;
}
//获取手机的唯一标示
+ (NSString *)getIDFV {
    NSString *IDFV = (NSString *)[YFMHKeyChainTool load:@"IDFV"];
    if ([IDFV isEqualToString:@""] || !IDFV) {
        IDFV = [UIDevice currentDevice].identifierForVendor.UUIDString;
        [YFMHKeyChainTool save:@"IDFV" data:IDFV];
    }
    return IDFV;
}
//利用正则去掉指定字符
+ (NSString *)getZZwithString:(NSString *)string {
    NSRegularExpression *regularExpretion = [NSRegularExpression regularExpressionWithPattern:@"-" options:0 error:nil];
    string = [regularExpretion stringByReplacingMatchesInString:string options:NSMatchingReportProgress range:NSMakeRange(0, string.length) withTemplate:@""];
    return string;
}
//时间转化
+ (NSString *)timestampTime:(float)timestamp andFormatter:(NSString *)format {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:format]; // （@"YYYY-MM-dd hh:mm:ss"）----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:timestamp / 1000];
    NSDate *currentDate = [NSDate date];
    
    NSTimeInterval timeInterval = [currentDate timeIntervalSinceDate:confromTimesp];
    
    long temp = 0;
    
    NSString *result;
    
    if (timeInterval/60 < 1) {
        
        result = [NSString stringWithFormat:@"刚刚来过"];
        
    }
    
    else if((temp = timeInterval/60) <60){
        
        result = [NSString stringWithFormat:@"%ld分钟前来过",temp];
        
    } else if((temp = temp/60) <24){
        
        result = [NSString stringWithFormat:@"%ld小时前来过",temp];
        
    } else {
        
        result = [NSString stringWithFormat:@"%@来过",[formatter stringFromDate:confromTimesp]];
        NSLog(@"**************%@", result);
        
    }
   
    return  result;
    
}


+(NSMutableArray<NewestListSendData *> *)dicToModel:(NSArray*)arr {
    return [NewestListSendData mj_objectArrayWithKeyValuesArray:arr];
}

+ (NSMutableArray<ESJListSenddata *> *)dicToEsjModel:(NSArray *)arr {
    return [ESJListSenddata mj_objectArrayWithKeyValuesArray:arr];
}


+(NSString *)stringRepToOld:(NSString *)Str rep:(NSString *)rep withString:(NSString *)withString {
    NSString*replacedStr = [Str stringByReplacingOccurrencesOfString:rep withString:withString];
    return replacedStr;
}

- (void)getRedPointNum:(redNumBlock)redNumBlock {
    __block NSInteger totalCount = 0;
    NSInteger rcNum = [[RCIMClient sharedRCIMClient] getTotalUnreadCount];
    totalCount = totalCount + rcNum;
    NSString *userId = [YFFlieTool getUserModel].userId;
    if (userId == nil) {
        userId = @"";
    }
    NSDictionary *bodyDic = @{@"customerId":userId,@"belongId":userId,@"belongType":@"0"};
    [[[ESNetworkManager getNewsCenterFirstInfo:bodyDic] map:^id(id value) {
        return [YFNewsCenterModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFNewsCenterModel *  _Nullable x) {
        totalCount = totalCount + x.data.sendData.tipsNum;
        redNumBlock(totalCount);
    } error:^(NSError * _Nullable error) {
        redNumBlock(totalCount);
    }];

}

+ (void)requestAlyunKeyWithHandler:(void (^)(NSString *, NSString *, NSString *, NSString *, NSError *))handler {
    [[[ESNetworkManager getAliyunSecretKey:nil] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        NSLog(@"%@",x);
        NSString *keyId = x[@"Access Key Id"];
        NSString *keySecret = x[@"Access Key Secret"];
        NSString *token = x[@"Security Token"];
        NSString *expireTime = x[@"Expiration"];
        handler(keyId,keySecret,token,expireTime,nil);
        
    } error:^(NSError * _Nullable error) {
        handler(@"",@"",@"",@"",error);
    }];
}

@end
