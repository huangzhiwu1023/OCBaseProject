//
//  YFCompareTool.m
//  jsyf_user
//
//  Created by 吕祥 on 2017/12/14.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "YFCompareTool.h"
#define kCompareKey @"compareList"

#define kCompareFilePath [YFFlieTool getUserInfoPath:kCompareKey]

@implementation YFCompareTool
+ (BOOL)writeInCompareModel:(ComparisonModelSenddata *)model {
    if ([YFFlieTool fileIsExistAtPath:kCompareFilePath]) {
        NSMutableArray<ComparisonModelSenddata *> *compareList = [NSMutableArray arrayWithArray:[NSKeyedUnarchiver unarchiveObjectWithFile:kCompareFilePath]];
        [compareList addObject:model];
        
      BOOL success =  [NSKeyedArchiver archiveRootObject:compareList toFile:kCompareFilePath];
        return success;
    }
    else {   //之前不存在目录
        NSMutableArray *compareList = [NSMutableArray arrayWithObject:model];
        BOOL success =  [NSKeyedArchiver archiveRootObject:compareList toFile:kCompareFilePath];
        return success;
    }
}

+ (NSArray *)getLocalCompareModelList {
    if ([YFFlieTool fileIsExistAtPath:kCompareFilePath]) {
        NSArray *compareList = [NSKeyedUnarchiver unarchiveObjectWithFile:kCompareFilePath];
    
        return compareList;
    }
    else {
        return @[];
    }
}

+ (BOOL)deleteCompareModel:(NSInteger)index {
    if ([YFFlieTool fileIsExistAtPath:kCompareFilePath]) {
        NSMutableArray<ComparisonModelSenddata *> *compareList = [NSMutableArray arrayWithArray:[NSKeyedUnarchiver unarchiveObjectWithFile:kCompareFilePath]];
        if (compareList.count > index) {
            [compareList removeObjectAtIndex:index];
        }
        else {
            
        }
        
        BOOL success =  [NSKeyedArchiver archiveRootObject:compareList toFile:kCompareFilePath];
        return success;
    }
    else {    //理论上else永远不会执行
        return NO;
    }
        
}

+ (BOOL)deleteAllCompareModel {
    if ([YFFlieTool fileIsExistAtPath:kCompareFilePath]) {
      return [YFFlieTool deleteFile:kCompareFilePath];
    }
    else {    //本来就是空的
        return YES;
    }
}
+ (BOOL)modelHaveInLocalList:(NSString *)equipmentID {
    if ([YFFlieTool fileIsExistAtPath:kCompareFilePath]) {
        NSMutableArray<ComparisonModelSenddata *> *compareList = [NSMutableArray arrayWithArray:[NSKeyedUnarchiver unarchiveObjectWithFile:kCompareFilePath]];
        for (ComparisonModelSenddata *data in compareList) {
            if ([data.equipmentId isEqualToString:equipmentID]) {
                return YES;
            }
        }
        return NO;
    }
    else {
        return NO;
    }
}
+ (BOOL)currentTypeCodeisEqualTo:(NSString *)typeCode {
    if ([YFFlieTool fileIsExistAtPath:kCompareFilePath]) {
        NSMutableArray<ComparisonModelSenddata *> *compareList = [NSMutableArray arrayWithArray:[NSKeyedUnarchiver unarchiveObjectWithFile:kCompareFilePath]];
        if (compareList.count == 0) {
            return YES;
        }
        if ([compareList.firstObject.sencondID isEqualToString:typeCode]) {
            return YES;
        }
        return NO;
    }
    else {
        return YES;
    }
}
@end
