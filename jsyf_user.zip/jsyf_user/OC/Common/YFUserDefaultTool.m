//
//  YFUserDefaultTool.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/13.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFUserDefaultTool.h"

@implementation YFUserDefaultTool
NSUserDefaults *mySettingData;

//单例模式
+ (YFUserDefaultTool *)sharedInstance {
    static YFUserDefaultTool *sharedSingleton = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^(void) {
        sharedSingleton = [[self alloc] initialize];
    });
    return sharedSingleton;
}

- (id)initialize {
    if(self == [super init]) {
        //initial something here
        mySettingData = [NSUserDefaults standardUserDefaults];
    }
    return self;
}

- (NSData *) getDataValue:(NSString *)key {
    return [mySettingData dataForKey:key];
}
- (NSString *)getStringValue:(NSString *)key {
    return [mySettingData stringForKey:key];
};

- (void)setdataValue:(NSString *)key andValue: (NSData *)value {
    [mySettingData setObject:value forKey:key];
    [mySettingData synchronize];
}
- (void)setStringValue:(NSString *)key andValue:(NSString *)value {
    [mySettingData setObject:value forKey:key];
    [mySettingData synchronize];
};

- (BOOL)getBoolValue:(NSString *)key {
    return [mySettingData boolForKey:key];
};

- (void)setBoolValue:(NSString *)key andValue:(BOOL)value {
    [mySettingData setBool:value forKey:key];
    [mySettingData synchronize];
};

- (void)setDefaultValue:(NSString *)key andValue:(id)value {
    //NSDictionary *defaultValues = [NSDictionary dictionaryWithObjectsAndKeys: @YES, @"isFirstIn",nil];
    NSDictionary *defaultValues = [NSDictionary dictionaryWithObjectsAndKeys: value, key, nil];
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaultValues];
};

-(void)deleteValue:(NSString *)key{
    [mySettingData removeObjectForKey:key];
    [mySettingData synchronize];
};

- (NSObject *)getObject:(NSString *)key {
    return [mySettingData objectForKey:key];
};

- (void)setObject:(NSString *)key andValue:(NSObject *)value {
    [mySettingData setObject:value forKey:key];
    [mySettingData synchronize];
};
@end
