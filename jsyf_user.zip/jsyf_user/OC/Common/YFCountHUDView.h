//
//  YFCountHUDView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/17.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^hudEndCount)(int a);

@interface YFCountHUDView : UIView
- (instancetype)initWithFrame:(CGRect)frame contentFrame:(CGRect)contentFrame Image:(NSString *)image title:(NSString *)title isEndCount:(NSInteger)Count;

@property (nonatomic,copy) hudEndCount endCount;

@end
