//
//  ProgressView.m
//  XzbTest
//
//  Created by xzb on 2017/5/25.
//  Copyright © 2017年 xzb. All rights reserved.
//

#import "ProgressView.h"

static const CGFloat kLineWidth = 3.0f;

#define kColor_Top [UIColor colorWithRed:34/255.0 green:44/255.0 blue:87/255.0 alpha:1]
#define kColor_Bottom [UIColor colorWithRed:223/255.0 green:157/255.0 blue:16/255.0 alpha:1]
#define kColor_Background [UIColor colorWithRed:225/255.0 green:224/255.0 blue:233/255.0 alpha:1]


@interface ProgressView ()

@end
@implementation ProgressView
- (void)drawRect:(CGRect)rect{
    CGContextRef ctx = UIGraphicsGetCurrentContext();//获取上下文
    CGPoint center = CGPointMake(self.bounds.size.height/2, self.bounds.size.height/2);  //设置圆心位置
    CGFloat radius = self.bounds.size.height/2.0-2.75f;  //设置半径
    CGFloat startA = - M_PI_2;  //圆起点位置
    CGFloat endA = -M_PI_2 + M_PI * 2 * _progress;  //圆终点位置
    NSLog(@"==%lf",self.progress);
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:startA endAngle:endA clockwise:YES];
    
    CGContextSetLineWidth(ctx, kLineWidth); //设置线条宽度
    [mHexColor(0xF48F4A) setStroke]; //设置描边颜色
    CGContextAddPath(ctx, path.CGPath); //把路径添加到上下文
    CGContextStrokePath(ctx);  //渲染
}
- (void)ogress:(float)progress{
    self.progress = progress;
    [self setNeedsDisplay];
}



@end
