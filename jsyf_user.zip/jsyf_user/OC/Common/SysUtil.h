/**
 SysUtil, Created by niuming 2016-8-4
 */

//static long timestampGap=0;

@interface SysUtil : NSObject{
}

+(SysUtil *)sharedInstance;
+(long)getServerTimestamp;
+(void)setServerTimestamp:(long)ts;

+(long)getLocalTimestamp;
+(NSString *)getLocalTimeString;

/**
 时间戳转指定格式时间 yyyy-MM-dd
 */
+(NSString *)getTimeWithTimeStamp:(long) timestamp;
/**
 时间戳转指定格式时间 format时间格式 
 */
+ (NSString *)getAppointTimeWithTimeStamp:(long)timestamp formatString:(NSString *)format;

/**
 时间戳转指定格式时间 MM-dd
 */
+(NSString *)getMonthAndDayTimeWithTimeStamp:(long) timestamp;

/**
 时间戳转指定格式时间 MM/dd
 */
+(NSString *)getSlashMonthAndDayTimeWithTimeStamp:(long) timestamp;

/**
    时间戳转指定格式时间 yyyy/MM/dd
 */
+(NSString *)getSlashTimeWithTimeStamp:(long) timestamp;


+(void)setCurrentViewController:(UIViewController *)currentVC;
+(UIViewController *)getCurrentViewController;

+(void)showMessage:(UIViewController *)owner andMsg:(NSString *)msg andYOffset:(CGFloat)offset;
+(void)showMessageWithWindowMsg:(NSString *)msg andYOffset:(CGFloat)offset;
+(void)openProgressRound:(UIViewController *)owner andText:(NSString *)text andYOffset:(CGFloat)offset;
+(void)openWindowProgressRound:(UIViewController *)owner andText:(NSString *)text andYOffset:(CGFloat)offset;
+(void)closeProgressRound;


//指定时间格式转换为时间戳
+(long)timeSwitchTimestamp:(NSString *)formatTime andFormatter:(NSString *)format;

/** 时间格式相互转换,hh与HH的区别:分别表示12小时制,24小时制
 @param formatTime 当前格式的时间 eg:1991:02:04 15:23:45
 @param  oldFormatter  eg :@"YYYY:MM:dd HH:mm:ss"
 @parma format 输出的时间格式 eg:@"YYYY-MM-dd HH:mm"
 */
+(NSString *)timeFormatterSwitchTimesFormatter:(NSString *)formatTime OldFormatter:(NSString *)oldFormatter andReturnFormatter:(NSString *)format;

//json字符串->dic
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;

//json字符串->array
+ (NSArray *)stringToJSON:(NSString *)jsonStr;

+(NSString *) utf8ToUnicode:(NSString *)string;

//eg:2017-09-15 周五
+ (NSString *)getSignLocalTimeStr;

//拨打电话功能
+ (void)doCallWithNumber:(NSString *)number tapView:(UIView *)sender onView:(UIView *)view;

+ (NSString *)getNewsCenterTimeWithTimeStamp:(long)timestamp;

+ (NSString *)getForumTimeWithTimeStamp:(long)timestamp;
/**
 个人主页头部的时间显示
 */
+ (NSString *)getPersonalHeaderTimeWithTimeStamp:(long)timestamp;
@end

