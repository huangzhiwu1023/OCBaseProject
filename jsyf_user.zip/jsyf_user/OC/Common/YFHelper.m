//
//  YFHelper.m
//  jsyf_user
//
//  Created by wangyadong on 2018/11/16.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFHelper.h"

@implementation YFHelper

+(NSString *)templateid{
    return @"223097";
}
+(NSString *)thirdWeChatLoginNotificationKey{
    return @"ThirdWeChatLoginNotificationKey";
}

+(NSString *)wexinBaseURL{
    return @"https://api.weixin.qq.com/sns";
}

+(NSString *)wechatAppID{
    return @"wx46c028e1edb3bf3b";
}
+(NSString *)wechatAppSecret{
    return @"a80bd88c0a37852609894ea5918abb60";
}
+(NSString *)wxScopeUserinfo{
    return @"snsapi_userinfo";//这个值是微信规定的
}
+(NSString *)wxAuthReqState{
    return @"YF_WXState";//这个值是自己定义
}

+(CGFloat)labelheightWithWidth:(CGFloat)width font:(UIFont*)font text:(NSString*)content{
    if (content.length<=0) {
        return 0;
    }
    UILabel *lb = [[UILabel alloc] initWithFrame:CGRectMake(0, 0,width, 1)];
    lb.font = font;
    lb.numberOfLines = 0;
    lb.text = content;
    [lb sizeToFit];
    return lb.bounds.size.height;
}
+(NSString *)notice_RefreshESJDetail{
    return @"refreshESJDetail";
}
+(NSString*)notice_PublishVideoSuccess{
    return @"PublishVideoSuccess";
}

@end
