//
//  YFMHKeyChainTool.h
//  jsyf_user
//
//  Created by 程辉 on 2018/8/8.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFMHKeyChainTool : NSObject

+ (void)save:(NSString *)service data:(id)data;
+ (id)load:(NSString *)service;
+ (void)deleteKeyData:(NSString *)service;

@end
