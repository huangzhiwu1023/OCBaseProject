//
//  CountdownLabel.m
//  PLShortVideoKitDemo
//
//  Created by 黄志武 on 2018/3/13.
//  Copyright © 2018年 Pili Engineering, Qiniu Inc. All rights reserved.
//

#import "CountdownLabel.h"

@interface CountdownLabel()
@property (nonatomic, strong) NSTimer *timer;

@end


@implementation CountdownLabel

//开始倒计时
- (void)startCount{
    [self initTimer];
}

- (void)endCountWithResetCount:(NSInteger)count {
    [_timer invalidate];
    _timer = nil;
    self.count = count;
    [self removeFromSuperview];
}

- (void)initTimer{
    //如果没有设置，则默认为3
    if (self.count == 0){
        self.count = 3;
    }
    [_timer invalidate];
    _timer = nil;
    [self countDown];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(countDown) userInfo:nil repeats:YES];
}

- (void)countDown{
    if (_count > 0){
        self.text = [NSString stringWithFormat:@"%ld",_count];
        CAKeyframeAnimation *anima2 = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
        //字体变化大小
//        NSValue *value1 = [NSNumber numberWithFloat:4.0f];
        NSValue *value2 = [NSNumber numberWithFloat:3.0f];
        NSValue *value3 = [NSNumber numberWithFloat:2.0f];
        NSValue *value4 = [NSNumber numberWithFloat:0.7f];
        NSValue *value5 = [NSNumber numberWithFloat:1.0f];
        anima2.values = @[value2,value3,value4,value5];
        anima2.duration = 0.6;
        [self.layer addAnimation:anima2 forKey:@"scalsTime"];
        _count -= 1;
      
    }else {
        !_endCount ?: _endCount(0);
        _timer.fireDate = [NSDate distantFuture];
        [_timer invalidate];
        _timer = nil;
        [self removeFromSuperview];
    }
}

@end
