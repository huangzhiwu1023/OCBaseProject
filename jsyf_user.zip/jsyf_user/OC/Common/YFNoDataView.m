//
//  YFNoDataView.m
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/23.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "YFNoDataView.h"
#import "Masonry.h"

@interface YFNoDataView ()
@property (nonatomic, strong) UILabel *detailTextLabel;
@end

@implementation YFNoDataView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = mHexColor(0xF6F6F6);
        [self addSubviews];
        [self refreshBtn];
    }
    return self;
}

- (void)addSubviews {
    self.noDataIV = ({
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView;
    });
    self.noDataIV.clipsToBounds = YES;
    [self addSubview:self.noDataIV];
    
    self.titleLabel = ({
        UILabel *label = [[UILabel alloc] init];
        label.textColor = mHexColor(0xA5B8BE);
        label.font = [UIFont systemFontOfSize:14];
        label.textAlignment = NSTextAlignmentCenter;
        label.numberOfLines = 0;
        label;
    });
    [self addSubview:self.titleLabel];
    
    self.detailTextLabel = ({
        UILabel *label = [[UILabel alloc] init];
        label.textColor = mHexColor(0xa5b8be);
        label.font = [UIFont systemFontOfSize:12];
        label.numberOfLines = 0;
        label;
    });
    [self addSubview:self.detailTextLabel];
    
    self.bottomButton = ({
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.font = [UIFont systemFontOfSize:15];
        button.layer.cornerRadius = 22;
        button.layer.masksToBounds = YES;
        [button setBackgroundImage:[UIImage imageNamed:@"ws_nodata_btn_orange_n"] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:@"ws_nodata_btn_orange_p"] forState:UIControlStateHighlighted];
        [button setTitle:@"" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        button;
    });
    [self addSubview:self.bottomButton];
    
    [self confignConstraints];
    
    [self confignViewByType:YFNoDataViewTypeNone];
}

- (void)confignConstraints {
    [self.noDataIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(0);
        make.centerY.equalTo(-44);
        make.width.equalTo(336*m6Scale);
        make.height.equalTo(240*m6Scale);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.noDataIV.mas_bottom).offset(17);
        make.left.equalTo(8);
        make.right.equalTo(-8);
    }];
    
    [self.detailTextLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(17);
        make.centerX.equalTo(self.noDataIV);
    }];
    
    [self.bottomButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(30);
        make.centerX.equalTo(self.noDataIV);
        make.size.mas_equalTo(CGSizeMake(200, 44));
    }];
}

- (void)confignViewByType:(YFNoDataViewType)viewType {
    switch (viewType) {
        case YFNoDataViewTypeNone:
            self.titleLabel.text = @"空空如也~";
            [self.titleLabel setTextColor:kDarkWordColor];
            self.noDataIV.image = [UIImage imageNamed:@"空状态图片"];
            break;
            
        case YFNoDataViewTypeSearch:
            self.titleLabel.text = @"未搜索到相关数据~";
            [self.titleLabel setTextColor:kDarkWordColor];
            self.noDataIV.image = [UIImage imageNamed:@"空状态图片"];
            break;
        case YFNoDataViewTypeNoDate:
            self.titleLabel.text = @"空空如也~";
            [self.titleLabel setTextColor:kDarkWordColor];
            self.noDataIV.image = [UIImage imageNamed:@"空状态图片"];
            break;
            
        case YFNoDataViewTypeNoShop: {
            self.titleLabel.hidden = YES;
            [self.noDataIV mas_updateConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(-64);
                make.centerX.equalTo(0);
                make.width.equalTo(108);
                make.height.equalTo(108);
            }];
            self.noDataIV.image = [UIImage imageNamed:@"空状态图片"];
            [self insertSubview:self.borderView belowSubview:self.noDataIV];
            [self.borderView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.center.equalTo(self.noDataIV);
                make.width.height.equalTo(128);
            }];
            self.borderView.clipsToBounds = YES;
            self.borderView.layer.cornerRadius = 2;
            self.borderView.layer.borderColor = mHexColor(0xE0E0E0).CGColor;
            self.borderView.layer.borderWidth = 0.5;
            self.goWebBtn.hidden = NO;
        }
            break;
            
        case YFNoDataViewTypeInCell: {
            self.titleLabel.text = @"空空如也~";
            [self.noDataIV mas_updateConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(-30);
                make.centerX.equalTo(0);
                make.width.equalTo(125);
                make.height.equalTo(90);
            }];
            self.noDataIV.image = [UIImage imageNamed:@"空状态图片"];
            self.backgroundColor = kBottomBgColor;
        }
            break;
      
        default:
            break;
    }
}

- (void)setViewType:(YFNoDataViewType)viewType {
    _viewType = viewType;
    [self confignViewByType:viewType];
}

- (void)setTitle:(NSString *)title {
    _title = title;
    self.titleLabel.text = title;
}

- (void)setNoDataImage:(UIImage *)noDataImage {
    _noDataImage = noDataImage;
    self.noDataIV.image = noDataImage;
}

- (void)setDetailText:(NSString *)detailText {
    _detailText = detailText;
    self.detailTextLabel.text = detailText;
}

- (UIButton *)refreshBtn {
    if (!_refreshBtn) {
        _refreshBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_refreshBtn];
        [_refreshBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(self.titleLabel.mas_bottom).equalTo(25);
            make.width.equalTo(150);
            make.height.equalTo(30);
        }];
        [_refreshBtn setTitle:@"重新加载" forState:UIControlStateNormal];
        _refreshBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_refreshBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
        _refreshBtn.hidden = YES;
    }
    return _refreshBtn;
}

- (UIButton *)goWebBtn {
    if (!_goWebBtn) {
        _goWebBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_goWebBtn];
        [_goWebBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(self.noDataIV.mas_bottom).equalTo(30);
            make.width.equalTo(104);
            make.height.equalTo(36);
        }];
        [_goWebBtn setTitle:@"GO ! 官网" forState:UIControlStateNormal];
        _goWebBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [_goWebBtn setTitleColor:mHexColorAlpha(0x000000, 0.87) forState:UIControlStateNormal];
        _goWebBtn.backgroundColor = kYellowColor;
        _goWebBtn.hidden = YES;
        
        _goWebBtn.layer.shadowColor = mHexColorAlpha(0x333333, 0.5).CGColor;
        _goWebBtn.layer.shadowOffset = CGSizeMake(0.5, 0.5);
        _goWebBtn.layer.shadowOpacity = 0.5;
        _goWebBtn.layer.shadowRadius = 1.0;
        
        UILabel *tipsLB = [[UILabel alloc] init];
        [self addSubview:tipsLB];
        [tipsLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(20);
            make.right.equalTo(-20);
            make.top.equalTo(_goWebBtn.mas_bottom).equalTo(24);
            make.height.equalTo(45);
        }];
        tipsLB.numberOfLines = 0;
        tipsLB.textColor = mHexColor(0x9A9A9A);
        tipsLB.textAlignment = NSTextAlignmentCenter;
        tipsLB.font = [UIFont systemFontOfSize:14];
        tipsLB.text = @"真不巧,您的区域暂无品牌经销商入驻。\n请前往官网,获得更多帮助~";
    }
    return _goWebBtn;
}

- (UIView *)borderView {
    if (!_borderView) {
        _borderView = [UIView new];
    }
    return _borderView;
}
@end
