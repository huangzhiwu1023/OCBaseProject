//
//  YFUserDefaultTool.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/13.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFUserDefaultTool : NSObject
+(YFUserDefaultTool *)sharedInstance;

-(NSString *)getStringValue:(NSString *)key;
-(void)setStringValue:(NSString *)key andValue:(NSString *)value;

-(BOOL)getBoolValue:(NSString *)key;
-(void)setBoolValue:(NSString *)key andValue:(BOOL)value;

-(void)setDefaultValue:(NSString *)key andValue:(id)value;

-(void)deleteValue:(NSString *)key;


-(NSData *) getDataValue:(NSString *)key;
-(void)setdataValue:(NSString *)key andValue: (NSData *)value;

-(NSObject *)getObject:(NSString *)key;
-(void)setObject:(NSString *)key andValue:(NSObject *)value;
@end
