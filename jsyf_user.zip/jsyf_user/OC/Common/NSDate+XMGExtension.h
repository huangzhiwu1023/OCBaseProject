//
//

#import <Foundation/Foundation.h>

@interface NSDate (XMGExtension)

//两个时间的差值
- (NSDateComponents *)deltaFrom:(NSDate *)from;

//是否为今年
- (BOOL)isThisYear;

//是否为今天
- (BOOL)isToday;

//是否为昨天
- (BOOL)isYesterDay;

//是否为两天前
- (BOOL)isTowDayBefore;
//是否为三天前
- (BOOL)isThreeDayBefore;
//是否为七天前
- (BOOL)isSevenDayBefore;
//是否是超过一个月
- (BOOL)isMonthBefore;
@end
