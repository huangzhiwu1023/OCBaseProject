//
//  NSString+Space.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/5/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "NSString+Space.h"

@implementation NSString (Space)

/*
 *  设置行间距和字间距
 *
 *  @param lineSpace 行间距
 *  @param kern      字间距
 *
 *  @return 富文本
*/
- (NSAttributedString*)getAttributedStringWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern font:(UIFont *)font{
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    //调整行间距
    paragraphStyle.lineSpacing= lineSpace;
    NSDictionary*attriDict =@{NSFontAttributeName:font,NSParagraphStyleAttributeName:paragraphStyle,NSKernAttributeName:@(kern)};
    NSMutableAttributedString* attributedString = [[NSMutableAttributedString alloc] initWithString:self attributes:attriDict];
    return attributedString;
}

- (NSAttributedString *)getAttributedStringForESJWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern {
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    //缩进
    paragraphStyle.headIndent = 10;
    //首行缩进为0
    paragraphStyle.firstLineHeadIndent = 0;
    //调整行间距
    paragraphStyle.lineSpacing= lineSpace;
    NSDictionary*attriDict =@{NSParagraphStyleAttributeName:paragraphStyle,NSKernAttributeName:@(kern)};
    NSMutableAttributedString* attributedString = [[NSMutableAttributedString alloc] initWithString:self attributes:attriDict];
    return attributedString;
}

- (NSAttributedString *)getLocationAttributedStringWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern font:(UIFont *)font {
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.alignment = NSTextAlignmentCenter;
    //调整行间距
    paragraphStyle.lineSpacing= lineSpace;
    NSDictionary*attriDict =@{NSFontAttributeName:font,NSParagraphStyleAttributeName:paragraphStyle,NSKernAttributeName:@(kern)};
    NSMutableAttributedString* attributedString = [[NSMutableAttributedString alloc] initWithString:self attributes:attriDict];
    return attributedString;
}

/*
 *  获取富文本的高度
 *
 *  @param string    文字
 *  @param lineSpace 行间距
 *  @param font      字体大小
 *  @param width     文本宽度
 *
 *  @return size
 */
- (CGSize)getAttributionHeightWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern font:(UIFont *)font width:(CGFloat)width {
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.lineSpacing = lineSpace;
    
    NSDictionary *dict = @{NSFontAttributeName:font, NSParagraphStyleAttributeName:paragraphStyle,NSKernAttributeName:@(kern)};
    
    CGSize size = [self boundingRectWithSize:CGSizeMake(width, MAXFLOAT)
                                       options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                    attributes:dict
                                       context:nil].size;
    return size;
}

@end
