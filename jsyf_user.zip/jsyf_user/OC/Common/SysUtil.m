/**
 SysUtil, Created by niuming 2016-8-4
 */

#import "SysUtil.h"
#import "MBProgressHUD.h"
#import "NSDate+XMGExtension.h"


@interface SysUtil() {
    
}
-(id)initialize;
@end

static MBProgressHUD *HUD;
static long timestampGap=0;  //本地时间与服务器时间差值
static UIViewController *currentViewController;

//static ESUserBasicBean *userBasicBean;

//内购数组
static NSArray *productArr;

@implementation SysUtil

-(id)initialize
{
    if(self == [super init] )
    {
        //initial something here
    }
    return self;
}

+(SysUtil *)sharedInstance
{
    static SysUtil *sharedSingleton = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^(void) {
        sharedSingleton = [[self alloc] initialize];
    });
    return sharedSingleton;
}

+(long)getServerTimestamp {
    return timestampGap+[self getLocalTimestamp];
}

+(void)setServerTimestamp:(long)ts {
    timestampGap=ts-[self getLocalTimestamp];
}

+(long)getLocalTimestamp{
    //标准时间
    NSDate *now = [NSDate date];
    //北京时间的时间戳
    NSString *tsStr = [NSString stringWithFormat:@"%ld", (long)[now timeIntervalSince1970]];
    return [tsStr longLongValue];
}

+(NSString *)getLocalTimeString{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSDate *dateNow = [NSDate date];
    return [formatter stringFromDate:dateNow];
}

+ (NSString *)getTimeWithTimeStamp:(long)timestamp {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    timestamp = timestamp / 1000;
    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:timestamp];;
    return [formatter stringFromDate:date];
}


+ (NSString *)getAppointTimeWithTimeStamp:(long)timestamp formatString:(NSString *)format {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:format];
    timestamp = timestamp / 1000;
    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:timestamp];;
    return [formatter stringFromDate:date];
}

+ (NSString *)getMonthAndDayTimeWithTimeStamp:(long)timestamp {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"MM-dd"];
    timestamp = timestamp / 1000;
    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:timestamp];;
    return [formatter stringFromDate:date];
}

+ (NSString *)getSlashMonthAndDayTimeWithTimeStamp:(long)timestamp {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"MM/dd"];
    timestamp = timestamp / 1000;
    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:timestamp];;
    return [formatter stringFromDate:date];
}

+ (NSString *)getSlashTimeWithTimeStamp:(long)timestamp {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"yyyy/MM/dd"];
    timestamp = timestamp / 1000;
    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:timestamp];;
    return [formatter stringFromDate:date];
}
+(void)setCurrentViewController:(UIViewController *)currentVC{
    currentViewController=currentVC;
};

+(UIViewController *)getCurrentViewController{
    return currentViewController;
};

+(void)showMessage:(UIViewController *)owner andMsg:(NSString *)msg andYOffset:(CGFloat)offset
{
    if(msg.length==0)
    {
        return;
    }
    if (owner.view == nil) {
        return;
    }
    [HUD removeFromSuperview];
    HUD = nil;
    HUD = [[MBProgressHUD alloc] initWithView:owner.view];
    [owner.view addSubview:HUD];
    HUD.label.text = msg;
    HUD.mode = MBProgressHUDModeText;
    
    //指定距离中心点的X轴和Y轴的偏移量，如果不指定则在屏幕中间显示
    [HUD setOffset:CGPointMake(0, offset)];
    [HUD showAnimated:YES];
    [HUD hideAnimated:YES afterDelay:2];
}

+(void)showMessageWithWindowMsg:(NSString *)msg andYOffset:(CGFloat)offset
{
    if(msg.length==0)
    {
        return;
    }
    [HUD removeFromSuperview];
    HUD = nil;
    HUD = [[MBProgressHUD alloc] initWithView:[UIApplication sharedApplication].keyWindow];
    [[UIApplication sharedApplication].keyWindow addSubview:HUD];
    HUD.label.text = msg;
    HUD.mode = MBProgressHUDModeText;
    
    //指定距离中心点的X轴和Y轴的偏移量，如果不指定则在屏幕中间显示
    [HUD setOffset:CGPointMake(0, offset)];
    //HUD.xOffset = 100.0f;
    
    [HUD showAnimated:YES];
    [HUD hideAnimated:YES afterDelay:2];
}

+(void)openProgressRound:(UIViewController *)owner andText:(NSString *)text andYOffset:(CGFloat)offset{
    //初始化进度框，置于当前的View当中
    if (HUD) {
//        HUD.hidden = YES;
        [HUD removeFromSuperview];
        HUD =nil;
    }
    if([owner.view viewWithTag:10124])
    {
        return;
    }
    HUD = [[MBProgressHUD alloc] initWithView:owner.view];
    HUD.tag =10124;
    [owner.view addSubview:HUD];
//    currentViewController = owner;
    //设置对话框文字
    HUD.label.text = text;
    
    //指定距离中心点的X轴和Y轴的偏移量，如果不指定则在屏幕中间显示
     [HUD setOffset:CGPointMake(0, offset)];
    //HUD.xOffset = 100.0f;
    
    [HUD showAnimated:YES];
};
+(void)openWindowProgressRound:(UIViewController *)owner andText:(NSString *)text andYOffset:(CGFloat)offset{
    //初始化进度框，置于当前的View当中
    if (HUD) {
        //        HUD.hidden = YES;
        [HUD removeFromSuperview];
        HUD =nil;
    }
    if([owner.view viewWithTag:10124])
    {
        return;
    }
    HUD = [[MBProgressHUD alloc] initWithView:[UIApplication sharedApplication].keyWindow];
    HUD.tag =10124;
    [[UIApplication sharedApplication].keyWindow addSubview:HUD];
    //    currentViewController = owner;
    //设置对话框文字
    HUD.label.text = text;
    
    //指定距离中心点的X轴和Y轴的偏移量，如果不指定则在屏幕中间显示
     [HUD setOffset:CGPointMake(0, offset)];
    //HUD.xOffset = 100.0f;
    
    [HUD showAnimated:YES];
};

+ (void)closeProgressRound{
    [HUD removeFromSuperview];
    HUD = nil;
}



#pragma mark - 将某个时间转化成 时间戳

+(long)timeSwitchTimestamp:(NSString *)formatTime andFormatter:(NSString *)format{
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:format]; //(@"YYYY-MM-dd HH:mm:ss") ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    [formatter setTimeZone:timeZone];
    NSDate* date = [formatter dateFromString:formatTime]; //------------将字符串按formatter转成nsdate
    
    //时间转时间戳的方法:
    
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue];
    
    NSLog(@"将某个时间转化成 时间戳&&&&&&&timeSp:%ld",(long)timeSp); //时间戳的值
    
    return timeSp;
    
}

+(NSString *)timeFormatterSwitchTimesFormatter:(NSString *)formatTime OldFormatter:(NSString *)oldFormatter andReturnFormatter:(NSString *)format {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:oldFormatter]; //(@"YYYY-MM-dd HH:mm:ss") ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    
    [formatter setTimeZone:timeZone];
    
    NSDate* date = [formatter dateFromString:formatTime]; //------------将字符串按formatter转成nsdate
    //时间转时间戳的方法:
    
    NSDateFormatter *outformat = [[NSDateFormatter alloc]init];
    [outformat setDateFormat:format];
    NSString *outputTime = [outformat stringFromDate:date];
    if (outputTime == nil) {
        outputTime = @"";
    }
    return outputTime;
}




//josn字符串->dic
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        return nil;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                         
                                                        options:NSJSONReadingMutableContainers
                         
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}
//json字符串->array
+ (NSArray *)stringToJSON:(NSString *)jsonStr {
    if (jsonStr) {
        id tmp = [NSJSONSerialization JSONObjectWithData:[jsonStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments | NSJSONReadingMutableLeaves | NSJSONReadingMutableContainers error:nil];
        
        if (tmp) {
            if ([tmp isKindOfClass:[NSArray class]]) {
                
                return tmp;
                
            } else if([tmp isKindOfClass:[NSString class]]
                      || [tmp isKindOfClass:[NSDictionary class]]) {
                
                return [NSArray arrayWithObject:tmp];
                
            } else {
                return nil;
            }
        } else {
            return nil;
        }
        
    } else {
        return nil;
    }
}

+(NSString *) utf8ToUnicode:(NSString *)string{
    
    NSUInteger length = [string length];
    NSMutableString *s = [NSMutableString stringWithCapacity:0];
    for (int i = 0;i < length; i++){
        unichar _char = [string characterAtIndex:i];
        //判断是否为英文和数字
        if (_char <= '9' && _char >='0'){
            [s appendFormat:@"%@",[string substringWithRange:NSMakeRange(i,1)]];
        }else if(_char >='a' && _char <= 'z'){
            [s appendFormat:@"%@",[string substringWithRange:NSMakeRange(i,1)]];
        }else if(_char >='A' && _char <= 'Z')
        {
            [s appendFormat:@"%@",[string substringWithRange:NSMakeRange(i,1)]];
        }else{
            [s appendFormat:@"\\u%x",[string characterAtIndex:i]];
        }
    }
    return s;
}

+ (NSString *)getSignLocalTimeStr {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    //    timestamp = timestamp / 1000;
    NSDate *date = [NSDate date];
    NSString *timeStr = [formatter stringFromDate:date];
    
    NSArray *weekdays = [NSArray arrayWithObjects: [NSNull null],@"周日",@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",nil];
    
    NSCalendar *calendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    [calendar setTimeZone: timeZone];
    
    NSCalendarUnit calendarUnit =NSCalendarUnitWeekday;
    
    NSDateComponents *theComponents = [calendar components:calendarUnit fromDate:date];
    
    NSString *weekStr = [weekdays objectAtIndex:theComponents.weekday];
    return [NSString stringWithFormat:@"%@ %@",timeStr,weekStr];
}

+ (void)doCallWithNumber:(NSString *)number tapView:(UIView *)sender onView:(UIView *)view {
    if (number.length == 0) {
        return;
    }
    sender.userInteractionEnabled = NO;
    UIWebView *callWebview =[[UIWebView alloc] init];
    NSString *telStr = [@"tel://" stringByAppendingString:number];
    NSURL *telURL =[NSURL URLWithString:telStr];// 貌似tel:// 或者 tel: 都行
    [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
    //记得添加到view上
    [view addSubview:callWebview];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        sender.userInteractionEnabled = YES;
    });
}

+ (NSString *)getNewsCenterTimeWithTimeStamp:(long)timestamp {
    NSString *tempTime = [SysUtil getAppointTimeWithTimeStamp:timestamp formatString:@"yyyy-MM-dd HH:mm:ss"];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    //设置日期格式(y:年,M:月,d:天,H:小时(24)h(12),m(分),s(秒))
    fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    //发帖时间
    NSDate *create = [fmt dateFromString:tempTime];

    
    NSDate *currentDate = [NSDate date];
     NSDateComponents *cmps = [currentDate deltaFrom:create];
    if (cmps.year == 0) {
        //当前时间
        if (cmps.month == 0 && cmps.day == 0 && cmps.hour == 0 && cmps.minute <= 10) { //时间差距小于等于10分钟
            return @"刚刚";
        }
        else {
            //大于10分钟
            fmt.dateFormat = @"MM-dd HH:mm";
            return [fmt stringFromDate:create];
        }
    } else {
        //不是今年的
        fmt.dateFormat = @"yy-MM-dd HH:mm";
        return [fmt stringFromDate:create];
    }
}

+ (NSString *)getForumTimeWithTimeStamp:(long)timestamp {
    NSString *tempTime = [SysUtil getAppointTimeWithTimeStamp:timestamp formatString:@"yyyy-MM-dd HH:mm:ss"];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    //设置日期格式(y:年,M:月,d:天,H:小时(24)h(12),m(分),s(秒))
    fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    //发帖时间
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    NSDate *create2 = [fmt dateFromString:tempTime];
    NSInteger interval = [timeZone secondsFromGMTForDate:create2];
    NSDate *create = [create2 dateByAddingTimeInterval:interval];
    
    NSDate *currentDate2 = [NSDate date];
    NSInteger currentInterval = [timeZone secondsFromGMTForDate:currentDate2];
    NSDate *currentDate = [currentDate2 dateByAddingTimeInterval:currentInterval];
    NSDateComponents *cmps = [currentDate deltaFrom:create];
    if (cmps.year == 0) {
        if (cmps.day == 0) {
            if (cmps.hour == 0) {
                if (cmps.minute == 0) {
                    return @"刚刚";
                }
                else {
                    return [NSString stringWithFormat:@"%ld分钟前",cmps.minute];
                }
            }
            else {
                 return [NSString stringWithFormat:@"%ld小时前",cmps.hour];
            }
        }//months
        else if (cmps.month > 0) {  //大于1个月
            return @"一个多月前";
        }
        else {  //1个月内
            return [NSString stringWithFormat:@"%ld天前",cmps.day];
        }
    }
    else {
        //不是今年的
        fmt.dateFormat = @"yyyy-MM-dd";
        return [fmt stringFromDate:create2];
    }
}

+ (NSString *)getPersonalHeaderTimeWithTimeStamp:(long)timestamp {
    NSString *tempTime = [SysUtil getAppointTimeWithTimeStamp:timestamp formatString:@"yyyy-MM-dd HH:mm:ss"];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    //设置日期格式(y:年,M:月,d:天,H:小时(24)h(12),m(分),s(秒))
    fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    //发帖时间
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+0800"];
    NSDate *create2 = [fmt dateFromString:tempTime];
    NSInteger interval = [timeZone secondsFromGMTForDate:create2];
    NSDate *create = [create2 dateByAddingTimeInterval:interval];
    
    NSDate *currentDate2 = [NSDate date];
    NSInteger currentInterval = [timeZone secondsFromGMTForDate:currentDate2];
    NSDate *currentDate = [currentDate2 dateByAddingTimeInterval:currentInterval];
    NSDateComponents *cmps = [currentDate deltaFrom:create];
    if (cmps.year == 0) {
        if (cmps.day == 0) {
            if (cmps.hour == 0) {
                if (cmps.minute == 0) {
//                    return @"刚刚";
                    return [NSString stringWithFormat:@"1分钟前来过"];
                }
                else {
                    return [NSString stringWithFormat:@"%ld分钟前来过",cmps.minute];
                }
            }
            else {
                return [NSString stringWithFormat:@"%ld小时前来过",cmps.hour];
            }
        }//months
        else if (cmps.month > 0) {  //大于1个月
//            return @"一个多月前";
            return [NSString stringWithFormat:@"%ld个多月前来过", cmps.month];
        }
        else {  //1个月内
            return [NSString stringWithFormat:@"%ld天前来过",cmps.day];
        }
    }
    else {
        //不是今年的
//        fmt.dateFormat = @"yyyy-MM-dd";
//        return [fmt stringFromDate:create];
        return @"1年前来过";
    }
}
@end
