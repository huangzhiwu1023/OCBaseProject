//
//  NSString+Space.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/5/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Space)
//设置行间距和字间距 不带缩进
- (NSAttributedString*)getAttributedStringWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern font:(UIFont *)font;

//开通二手机业务页面富文本,带缩进
- (NSAttributedString*)getAttributedStringForESJWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern;
//设置行间距和字间距 居中显示
- (NSAttributedString*)getLocationAttributedStringWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern font:(UIFont *)font;

//获取富文本的Size
- (CGSize)getAttributionHeightWithLineSpace:(CGFloat)lineSpace kern:(CGFloat)kern font:(UIFont *)font width:(CGFloat)width;

@end
