//
//  UIViewController+YFCommon.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/26.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "UIViewController+YFCommon.h"

@implementation UIViewController (YFCommon)
- (void)setInsetNoneWithScrollView:(UIScrollView *)scrollView {
    if (@available(iOS 11.0, *)) {
        scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;  //UIScrollView也适用
    }else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.edgesForExtendedLayout = UIRectEdgeNone;
}
@end
