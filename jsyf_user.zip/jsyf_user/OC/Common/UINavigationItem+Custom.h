//
//  UINavigationItem+Custom.h
//  XMMuseum
//
//  Created by 何振东 on 14/7/24.
//  Copyright (c) 2014年 XM. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  定制ViewController返回item的内容
 *  warning: 自动挂载，勿删
 */
@interface UINavigationItem (Custom)

@end
