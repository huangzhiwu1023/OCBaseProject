//
//  YFHelper.h
//  jsyf_user
//
//  Created by wangyadong on 2018/11/16.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YFHelper : NSObject


///短信模板id
+(NSString *)templateid;
///微信回调通知key
+(NSString *)thirdWeChatLoginNotificationKey;
///微信请求用户信息的url
+(NSString*)wexinBaseURL;
///微信appid
+(NSString*)wechatAppID;
///微信appSecrect
+(NSString*)wechatAppSecret;

///微信SendAuthReq.scope，用户信息权限
+(NSString*)wxScopeUserinfo;
///微信SendAuthReq.state本身用来标识其请求的唯一性
+(NSString*)wxAuthReqState;

/**
 固定lable的宽，获取lable的高

 @param width 固定宽
 @param font 字体
 @param content 显示text
 @return 高
 */
+(CGFloat)labelheightWithWidth:(CGFloat)width font:(UIFont*)font text:(NSString*)content;

/**
 登录成功后刷新二手机详情,
全局搜索替换的
 @return key
 */
+(NSString*)notice_RefreshESJDetail;
///发布视频成功
+(NSString*)notice_PublishVideoSuccess;

@end

NS_ASSUME_NONNULL_END
