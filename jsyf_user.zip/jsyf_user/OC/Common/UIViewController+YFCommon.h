//
//  UIViewController+YFCommon.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/26.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (YFCommon)
- (void)setInsetNoneWithScrollView:(UIScrollView *)scrollView;
@end
