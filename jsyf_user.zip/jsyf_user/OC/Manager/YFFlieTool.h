//
//  YFFlieTool.h
//  jsyf_user
//
//  Created by pro on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFFlieTool : NSObject
+ (NSString *)getDocumentsFliePath;//documents目录
+ (NSString *)getCachesFliePath;//Caches目录
+ (NSString *)getTmpFliePath;//tmp目录
//获取路径文件的大小
+ (double)fileSize:(NSString *)filePath;
//文件是否存在，若不存在，则创建并返回结果，若存在则返回YES
+ (BOOL)fileIsExistAtPath:(NSString *)path;
//文件夹是否存在，若不存在，则创建并返回结果，若存在则返回YES
+ (BOOL)directoryIsExistAtPath:(NSString *)path;
@end
