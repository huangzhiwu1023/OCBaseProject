//
//  AppConfig.h
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import <Foundation/Foundation.h>

#define N_HostSiteMain [[YFAppMacroOC share] getHostSiteMain]
#define ESHHostMain [[YFAppMacroOC share] getESHHostMain]
#define WebMain [[YFAppMacroOC share] getMWebMain]
#define YFWebMain [[YFAppMacroOC share] getYFWebMain]

// 占位图片
#define kPlaceholderImage     [UIImage imageNamed:@"占位图"]
#define kPlaceholderHeadImage [UIImage imageNamed:@"user_default"]  //评论头像
#define kPlaceHolderCycleImage [UIImage imageNamed:@"占位图"]  //轮播图占位
//详情占位
#define kEquipmentPlaceHolder [UIImage imageNamed:@"机型占位图New"]
#define kShopPlaceHolder [UIImage imageNamed:@"机型占位图New"]

//第三方key

// 苹方斜体
#define kFont_PF_Ultralight(fontSize) [UIFont fontWithName:@"PingFangSC-Ultralight" size:fontSize]
// 苹方常规
#define kFont_PF_Regular(fontSize) [UIFont fontWithName:@"PingFangSC-Regular" size:fontSize]
// 苹方粗体
#define kFont_PF_Semibold(fontSize) [UIFont fontWithName:@"PingFangSC-Semibold" size:fontSize]
#define kFont_PF_Thin(fontSize) [UIFont fontWithName:@"PingFangSC-Thin" size:fontSize]
#define kFont_PF_Light(fontSize) [UIFont fontWithName:@"PingFangSC-Light" size:fontSize]
#define kFont_PF_Medium(fontSize) [UIFont fontWithName:@"PingFangSC-Medium" size:fontSize]


///MARK:APP基本色=========
#define kNaviLineColor    mHexColor(0xF0F0F0)  //navi和tabbar分割线颜色
#define kBottomBgColor    mHexColor(0xF5F5F5) //灰色的底色
#define kLineColor        mHexColor(0xEBEBEB)  //灰色的线
#define kBuleWordColor    mHexColor(0x2196F3)  //蓝色的字
#define kBlackWordColor   mHexColor(0x222222) //黑色的字
#define kDarkWordColor    mHexColor(0x757575)  //深灰色的字
#define kLightWordColor   mHexColor(0xCBCBCB)  //浅灰色的字
#define kYellowColor      mHexColor(0xFFC107)
#define kRedColor         mHexColor(0xF44336)
#define kButtonLineColor  mHexColor(0xE0E0E0)  //按钮间隔线颜色 eg.设备丨吨位
#define kSliderColor mHexColor(0xF48F4A)   //分段滑块黄
#define k333Color  mHexColor(0x333333)
#define k666Color  mHexColor(0x666666)
#define k999Color  mHexColor(0x999999)
#define kOrangeColor mHexColor(0xF48F4A)  //主色调橘黄


//mark: app 基本字体大小
#define kFont12 [UIFont systemFontOfSize:12]
#define kFont13 [UIFont systemFontOfSize:13]
#define kFont14 [UIFont systemFontOfSize:14]
#define kFont15 [UIFont systemFontOfSize:15]
#define KFont16 [UIFont systemFontOfSize:16]
#define kFont_system(fontSize) [UIFont systemFontOfSize:fontSize]
#define kFont_boldsys(fontSize) [UIFont boldSystemFontOfSize:fontSize]

#define RandColor RGBColor(arc4random_uniform(255), arc4random_uniform(255), arc4random_uniform(255))
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define HexColorInt32_t(rgbValue) \
[UIColor colorWithRed:((float)((0x##rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((0x##rgbValue & 0x00FF00) >> 8))/255.0 blue:((float)(0x##rgbValue & 0x0000FF))/255.0  alpha:1]

/////////////////////////// 懒加载 /////////////////////////////
#define ELazyMutableArray(_array) \
return !(_array) ? (_array) = [NSMutableArray array] : (_array);


#pragma mark OSS相关key
#define AccessKey @""
#define SecretKey @""
#define endPointOSS @"oss-cn-shanghai.aliyuncs.com"
#define testBucket @""

#pragma mark 用户信息保存key
#define USERKEY @"userInfo"
#define kUserPermissions @"kUserPermissions"//底部权限
#define kSellerIDs @"kSellerIDs"//销售下属ID集合
#define kRequest_error @"网络错误,请稍后重试"

