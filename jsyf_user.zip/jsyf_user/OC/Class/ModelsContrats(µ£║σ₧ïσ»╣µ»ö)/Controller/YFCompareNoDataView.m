//
//  YFCompareNoDataView.m
//  jsyf_user
//
//  Created by 吕祥 on 2017/12/19.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "YFCompareNoDataView.h"
@interface YFCompareNoDataView()
@property(nonatomic, strong) UIImageView *noDataIV;
@property(nonatomic, strong) UILabel *noDataLB;
@property(nonatomic, strong) UIButton *addBtn;
@end

@implementation YFCompareNoDataView
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        [self noDataIV];
        [self noDataLB];
        [self addBtn];
    }
    return self;
}

- (UIImageView *)noDataIV {
    if (!_noDataIV) {
        _noDataIV = [[UIImageView alloc] init];
        [self addSubview:_noDataIV];
        [_noDataIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.centerY.equalTo(self.mas_centerY).equalTo(-44);
            
        }];
        _noDataIV.image = [UIImage imageNamed:@"空状态图片"];
//        _noDataIV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _noDataIV;
}

- (UILabel *)noDataLB {
    if (!_noDataLB) {
        _noDataLB = [[UILabel alloc] init];
        [self addSubview:_noDataLB];
        [_noDataLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(20);
            make.right.equalTo(-20);
            make.top.equalTo(self.noDataIV.mas_bottom).equalTo(30);
            make.height.equalTo(15);
        }];
        _noDataLB.textAlignment = NSTextAlignmentCenter;
        _noDataLB.font = [UIFont systemFontOfSize:14];
        _noDataLB.textColor = kDarkWordColor;
        _noDataLB.text = @"机型库还空着呐! 添加机型对比吧";
    }
    return _noDataLB;
}

- (UIButton *)addBtn {
    if (!_addBtn) {
        _addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_addBtn];
        [_addBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(0);
            make.height.equalTo(50);
        }];
        
        [_addBtn setImage:[UIImage imageNamed:@"compare"] forState:UIControlStateNormal];
        [_addBtn setTitle:@"添加机型" forState:UIControlStateNormal];
        _addBtn.backgroundColor = kYellowColor;
        [_addBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
        
        _addBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -6, 0, 6);
        _addBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, -6);
        mWeakSelf
        [_addBtn tapHandle:^NSString *{
            if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(didTapAddBtn:)]) {
                [weakSelf.delegate didTapAddBtn:self];
            }
            return @"添加机型";
        }];
    }
    return _addBtn;
}

@end
