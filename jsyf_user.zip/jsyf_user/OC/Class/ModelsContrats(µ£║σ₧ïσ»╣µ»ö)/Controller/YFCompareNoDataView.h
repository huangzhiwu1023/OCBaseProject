//
//  YFCompareNoDataView.h
//  jsyf_user
//
//  Created by 吕祥 on 2017/12/19.
//  Copyright © 2017年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YFCompareNoDataView;
@protocol CompareNoDataDelegate <NSObject>
@optional
- (void)didTapAddBtn:(YFCompareNoDataView *)noDataView;
@end

@interface YFCompareNoDataView : UIView
@property(nonatomic,weak)id<CompareNoDataDelegate> delegate;
@end
