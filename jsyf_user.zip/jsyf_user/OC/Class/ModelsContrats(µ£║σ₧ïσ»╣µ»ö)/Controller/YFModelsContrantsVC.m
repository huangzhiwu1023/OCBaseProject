//
//  YFModelsContrantsVC.m
//  UITableViewLInkageDemo
//
//  Created by Eleven on 2017/7/3.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import "YFModelsContrantsVC.h"
#import "CompareCell.h"
#import "CompareHeaderView.h"
#import "CompareSectionHeaderView.h"

#import "CompareTableView.h"

#import "YFComparisonBrandsModel.h"
#import "YFComparisonModelModel.h"
#import "YFCompareBrandModelSelectView.h"
#import "YFCompareParamModel.h"

#import "PersonalCenterController.h"
#import "YFEquipmentListModel.h"

#import "YFCompareNoDataView.h"
#import "LPActionSheet.h"

#import "YFCompareGroupModel.h"

#import "UINavigationController+FDFullscreenPopGesture.h"

#import "YFComapreSencondModel.h"
#import "YFNewCompareParamModel.h"

#import "YFCompareBrandSelectView.h"
#import "YFNewBrandListModel.h"

#define kMaxNum 6

static inline UIEdgeInsets sgm_safeAreaInset(UIView *view) {
    if (@available(iOS 11.0, *)) {
        return view.safeAreaInsets;
    }
    return UIEdgeInsetsZero;
}


typedef NS_ENUM(NSInteger, ParameterCompareType) {
    ParameterCompareTypeAdd, // 添加车型
    ParameterCompareTypeDelete // 删除车型
};

static NSString * const BrandCellIdentifier = @"BrandCell";
static CGFloat const kItemWidth = 100;  //94->
static CGFloat const kHeaderHeight = 60;  //66->

@interface YFModelsContrantsVC () <UITableViewDelegate, UITableViewDataSource,CompareNoDataDelegate>

/** 参数名称列表 */
@property (nonatomic, strong) CompareTableView *backgroundTableView;
@property (nonatomic, strong) UITableView *emptyTableView;
@property (nonatomic, strong) CompareHiddenHeader *hiddenHeader;
@property (nonatomic, strong) CompareHiddenHeader *hiddenHeaderLast;

@property (nonatomic, strong) CompareAddHeader *addHeader;
@property (nonatomic, strong) UIScrollView *scrollView;
/** 头部名称视图 */
@property (nonatomic, strong) UIScrollView *littleScrollView;
@property (nonatomic, assign) NSInteger count;
@property (nonatomic, strong) NSMutableArray<UITableView *> *tableViewArr;
@property (nonatomic, strong) NSMutableArray<UIView *> *headerArr;
@property (nonatomic, strong) NSMutableArray *nameArr;
@property (nonatomic, strong) NSMutableArray *sectionArr;
@property (nonatomic, strong) NSMutableArray *rowArr;
@property (nonatomic, strong) NSMutableArray *idArr;

//
@property(nonatomic, strong) NSMutableArray<NewBrandListBrandlist *> *brandList;
@property(nonatomic, strong) NSMutableArray<ComparisonModelSenddata *> *modelList;
@property(nonatomic, strong) NSString *brandID;
@property(nonatomic, strong) NSString *brandName;
@property(nonatomic, strong) NSString *brandLogo;
@property(nonatomic, strong) NSString *modelID;
@property(nonatomic, strong) NSString *modelName;
@property(nonatomic, strong) NSString *typeID;
@property(nonatomic, strong) NSString *typeName; //挖掘机/装载机
//设备分类
@property(nonatomic, strong) NSString *secondID;
@property(nonatomic, strong) NSArray<EquipmentListSenddata *> *typeList;

@property(nonatomic, strong) NSMutableArray<ComparisonModelSenddata *> *localModelList;
@property(nonatomic, strong) dispatch_group_t group;
@property(nonatomic, strong) NSMutableArray<CompareGroupSenddata *> *dataList;

@property(nonatomic, strong) NSArray<YFNewCompareParamSenddata *> *paramList;
//无数据的view
@property(nonatomic, strong) YFCompareNoDataView *noDataView;

@property(nonatomic, assign) UIEdgeInsets safeAreaInsets;

@property(nonatomic, strong) UIView *selectView;

@property(nonatomic, assign) CGFloat naviZero;

@property(nonatomic, assign) CGFloat distanceLeft;
//在竖屏时判断,保存 (横屏时判断不准)
@property(nonatomic, assign) BOOL isIphoneX;

@property(nonatomic, strong) UITableView *placeTableView;
@end

@implementation YFModelsContrantsVC

#pragma mark - life cycle
- (void)viewSafeAreaInsetsDidChange {
    [super viewSafeAreaInsetsDidChange];
    self.safeAreaInsets = sgm_safeAreaInset(self.view);
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.navigationController.navigationBar.translucent = YES;
    self.naviZero = NaviHeight;
    self.distanceLeft = 0.0;
    self.isIphoneX = IS_IPHONE_X;
    self.title = @"机型比较";
    self.view.backgroundColor = [UIColor whiteColor];
    [self _initUI];
    
    self.localModelList = [YFCompareTool getLocalCompareModelList].mutableCopy;
    if (self.localModelList.count == 0) {
        self.noDataView.hidden = NO;
    }
    else {
        self.noDataView.hidden = YES;
        self.typeName = self.localModelList.firstObject.typeName;
        [self _loadParameterDataWithCout:self.localModelList.count];
    }
    self.typeID = self.localModelList.firstObject.typeCode;
    self.secondID = self.localModelList.firstObject.sencondID;
    
    [self requestTypeListDataPre];
    [self requestBrandListPre];
    //修复初次左滑无效的bug
    self.scrollView.contentOffset = CGPointMake(0.5, 0);
    
}

- (void)viewDidAppear:(BOOL)animated {
    self.navigationController.fd_fullscreenPopGestureRecognizer.enabled = NO;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//
    //这句代码放在这里从其他页面侧滑进入该页面时会导致程序卡死self.navigationController.fd_fullscreenPopGestureRecognizer.enabled = NO;
    if (IS_IPHONE_X) {
        kAppDelegate.allowRotate = YES;
    }
    else {
        kAppDelegate.allowRotate = YES;
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    self.navigationController.fd_fullscreenPopGestureRecognizer.enabled = YES;
    kAppDelegate.allowRotate = NO;
    NSNumber *orientationUnknown = [NSNumber numberWithInt:UIInterfaceOrientationUnknown];
    [[UIDevice currentDevice] setValue:orientationUnknown forKey:@"orientation"];
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.scrollView.frame = CGRectMake(kItemWidth, self.naviZero+kHeaderHeight, kScreenWidth - kItemWidth, self.backgroundTableView.contentSize.height);
    CGSize contentSize = self.scrollView.contentSize;
    contentSize.height = self.backgroundTableView.contentSize.height;
    self.scrollView.contentSize = contentSize;
    
}

#pragma mark - private methods
- (void)_initUI {
    [self.view addSubview:self.hiddenHeader];
    [self.view addSubview:self.scrollView];
    [self.view addSubview:self.backgroundTableView];
    
    [self.scrollView addSubview:self.emptyTableView];
    [self.tableViewArr addObject:self.emptyTableView];
    [self.view addSubview:self.littleScrollView];
    [self.littleScrollView addSubview:self.addHeader];
    [self.headerArr addObject:self.addHeader];
    //添加一个空白
//    [self.littleScrollView addSubview:self.hiddenHeaderLast];
//    [self.headerArr addObject:self.hiddenHeaderLast];
//    
    self.scrollView.contentSize = CGSizeMake(4 * kItemWidth, 0);
}


///调用旋转的时候出发的方法
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    CGFloat mkScreenWidth = size.width;
    CGFloat mkScreenHeight = size.height;
    if (self.isIphoneX && (mkScreenWidth > mkScreenHeight)) {
        self.distanceLeft = 44;
    }
    else {
        self.distanceLeft = 0;
    }
    
    if (mkScreenWidth > mkScreenHeight) {
        self.navigationController.navigationBarHidden = YES;
        self.naviZero = 20;
    }
    else {
        self.navigationController.navigationBarHidden = NO;
        self.naviZero = NaviHeight;
    }
    
//    self.hiddenHeader.frame = CGRectMake(0, self.naviZero, kItemWidth, kHeaderHeight);
    [self.hiddenHeader mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.distanceLeft);
        make.top.equalTo(self.naviZero);
    }];
    self.littleScrollView.frame = CGRectMake(self.distanceLeft + kItemWidth, self.naviZero, mkScreenWidth - kItemWidth, kHeaderHeight);
   
    [self layoutWithDataWithOritentionChange];

    self.backgroundTableView.frame = CGRectMake(self.distanceLeft +0, self.naviZero + kHeaderHeight, mkScreenWidth, mkScreenHeight - kHeaderHeight - self.naviZero);
    
    self.scrollView.frame = CGRectMake(self.distanceLeft +kItemWidth, self.naviZero + kHeaderHeight, mkScreenWidth - kItemWidth, self.backgroundTableView.contentSize.height);
    
    CGSize contentSize = self.scrollView.contentSize;
    contentSize.height = self.backgroundTableView.contentSize.height;
    self.scrollView.contentSize = contentSize;
    self.selectView.frame = CGRectMake(0, 0, mkScreenWidth, mkScreenHeight);
    [self.selectView layoutIfNeeded];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"viewTrans" object:nil];
    
}
/**
 *  具体参数列表
 */
- (UITableView *)_creatTableView {
    UITableView *tableView = [[UITableView alloc] init];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.rowHeight = 35;
    tableView.showsVerticalScrollIndicator = NO;
    tableView.bounces = NO;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    return tableView;
}

//占位TableView
- (UITableView *)placeTableView {
    if (!_placeTableView) {
        _placeTableView = [[UITableView alloc] init];
        _placeTableView.delegate = self;
        _placeTableView.dataSource = self;
        _placeTableView.rowHeight = 35;
        _placeTableView.showsVerticalScrollIndicator = NO;
        _placeTableView.bounces = NO;
        _placeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _placeTableView.backgroundColor = [UIColor clearColor];
        [_placeTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];
    }
    return _placeTableView;
}

/**
 *  头部视图
 */
- (CompareRightHeader *)_creatHeaderView {
    CompareRightHeader *rightHeader = [CompareRightHeader creatView];
    rightHeader.frame = CGRectMake(kItemWidth, 0, kItemWidth, kHeaderHeight);
    rightHeader.deleteBlock = ^(UIButton *button) {
//        取消: 0, 确认: -1, 其他: 1.2.3...
        [LPActionSheet showActionSheetWithTitle:@"" cancelButtonTitle:@"取消" destructiveButtonTitle:@"删除" otherButtonTitles:nil handler:^(LPActionSheet *actionSheet, NSInteger index) {
            NSLog(@"%ld",index);
            if (index == -1) {
                [self _deleteModels:button];
            }
        }];
        
//        [self _deleteModels:button];
    };
    return rightHeader;
}

/**
 *  重新布局列表视图
 *
 *  @param arr   列表集合
 *  @param index 开始位置
 *  @param type  添加或删除
 */
- (void)_layoutWithArr:(NSMutableArray *)arr fromIndex:(NSInteger)index type:(ParameterCompareType)type {
    
    if (type == ParameterCompareTypeDelete) {
        UIView *view = arr[index];
        [view removeFromSuperview];
        [arr removeObjectAtIndex:index];
    }
    for (NSInteger i = index; i < arr.count; i ++) {
        UIView *header = arr[i];
        CGRect frame = header.frame;
        if (type == ParameterCompareTypeAdd) {
            frame.origin.x += kItemWidth;
            frame.size.width = kItemWidth;;
            header.frame = frame;
        
        } else {
            frame.origin.x -= kItemWidth;
            header.frame = frame;
        }
    }
    NSInteger sum;
    if (self.count + 1 < 5) {
        sum = 4;
    } else {
        sum = self.count + 1;
    }
    self.scrollView.contentSize = CGSizeMake(kItemWidth * sum, 0);
    self.littleScrollView.contentSize = CGSizeMake(kItemWidth * sum, 0);
    //添加的按钮是否显示
    if (self.localModelList.count >= kMaxNum) {
        self.addHeader.hidden = YES;
    }
    else {
        self.addHeader.hidden = NO;
    }
}

#pragma mark - load Data
- (void)_loadParameterDataWithCout:(NSInteger)count {
    if (count >= 1) {  //
        NSMutableArray *tmpArr = [NSMutableArray array];
        for (ComparisonModelSenddata *data in self.localModelList) {
            if (data.equipmentId == nil) {
                data.equipmentId = @"";
            }
            NSDictionary *tmpDic = @{@"equipmentId" : data.equipmentId};
            [tmpArr addObject:tmpDic];
        }
        [self.view showBusyHUD];
        NSDictionary *bodyDic = @{@"equipmentIdList" : tmpArr};
        
        [[[ESNetworkManager getNewCompareParam:bodyDic] map:^id(id value) {
            YFNewCompareParamModel *model = [YFNewCompareParamModel mj_objectWithKeyValues:value];
            NSArray<YFNewCompareParamSenddata *> *arr =  [YFNewCompareParamSenddata mj_objectArrayWithKeyValuesArray:model.data.sendData];
            
            for (YFNewCompareParamSenddata* model2 in arr) {
                  NSArray *arr3 =  [YFNewCompareParamList mj_objectArrayWithKeyValuesArray:model2.list];
                model2.list = arr3;
            }
            return arr;
          
        }] subscribeNext:^(NSArray<YFNewCompareParamSenddata *> *  _Nullable arr) {
            self.noDataView.hidden = YES;
            [self.view hideBusyHUD];
            self.paramList = arr;
    
            [self layoutWithDataWithCount:self.paramList.firstObject.list.count];
        } error:^(NSError * _Nullable error) {
            self.noDataView.hidden = NO;
            [self.view hideBusyHUD];
            [self.view showWarning:error.localizedDescription];
        }];
    }
}

- (void)layoutWithDataWithCount:(NSInteger)count {
    if (self.localModelList.count > 0) {
        self.noDataView.hidden = YES;
    }
    else {
        self.noDataView.hidden = NO;
    }
//    NSInteger sumNumber = self.paramList.firstObject.list.count;
    [self.nameArr removeAllObjects];
    [self.idArr removeAllObjects];
    for (NSInteger i = 0; i < self.paramList.firstObject.list.count; i ++) {
        [self.nameArr addObject:self.paramList.firstObject.list[i].firstObject.brandAndModel];
        [self.idArr addObject:[NSString stringWithFormat:@"%zi",i]];
    }
    
    [self.backgroundTableView reloadData];
    
    [self.emptyTableView reloadData];
    
    if (self.tableViewArr.count > 1) {
        for (NSInteger i = self.headerArr.count - 2; i >= 0; i --) {
            _count --;
            CompareRightHeader *rightHeader = (CompareRightHeader *)self.headerArr[i];
            NSInteger index = [self.headerArr indexOfObject:rightHeader];
            [self _layoutWithArr:self.headerArr fromIndex:index type:ParameterCompareTypeDelete];
            [self _layoutWithArr:self.tableViewArr fromIndex:index type:ParameterCompareTypeDelete];
        }
    }
    self.placeTableView.frame = CGRectMake(self.distanceLeft, 0, mScreenWidth, kScreenHeight - self.naviZero - kHeaderHeight);
    [self.scrollView addSubview:self.placeTableView];
    for (NSInteger i = 0; i < self.idArr.count; i ++) {
        [self _addModels];
    }
    for (UITableView *tableView in self.tableViewArr) {
        [tableView reloadData];
    }
    
    for (NSInteger i = 0; i < self.nameArr.count; i ++) {
        CompareRightHeader *header = (CompareRightHeader *)self.headerArr[i];
        header.modelNameLabel.text = self.nameArr[i];
    }
    
}


- (void)layoutWithDataWithOritentionChange {
    [self.backgroundTableView reloadData];
    [self.emptyTableView reloadData];
    
    if (self.tableViewArr.count > 1) {
        for (NSInteger i = self.headerArr.count - 2; i >= 0; i --) {
            _count --;
            CompareRightHeader *rightHeader = (CompareRightHeader *)self.headerArr[i];
            NSInteger index = [self.headerArr indexOfObject:rightHeader];
            [self _layoutWithArr:self.headerArr fromIndex:index type:ParameterCompareTypeDelete];
            [self _layoutWithArr:self.tableViewArr fromIndex:index type:ParameterCompareTypeDelete];
        }
    }
    self.placeTableView.frame = CGRectMake(self.distanceLeft, 0, mScreenWidth, kScreenHeight - self.naviZero - kHeaderHeight);
    [self.scrollView addSubview:self.placeTableView];
    for (NSInteger i = 0; i < self.idArr.count; i ++) {
        [self _addModels];
    }
    for (UITableView *tableView in self.tableViewArr) {
        [tableView reloadData];
    }
    
    for (NSInteger i = 0; i < self.nameArr.count; i ++) {
        CompareRightHeader *header = (CompareRightHeader *)self.headerArr[i];
        header.modelNameLabel.text = self.nameArr[i];
    }
}

#pragma mark - <UITableViewDelegate, UITableViewDataSource>
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.paramList.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == self.paramList.count - 1) {
        return self.paramList[section].list.firstObject.count + 2;
    }
    else {
        return self.paramList[section].list.firstObject.count;
        
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.placeTableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
        cell.selectionStyle = 0;
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    if (tableView == _backgroundTableView) {
        CompareLeftCell *leftCell = [CompareLeftCell cellWithTableView:tableView];
        leftCell.backgroundColor = [UIColor clearColor];
        leftCell.titleLabel.textColor = mHexColor(0x999999);
        if (indexPath.section == self.paramList.count - 1 && indexPath.row == self.paramList[indexPath.section].list.firstObject.count) {
            leftCell.titleLabel.text = @"更多信息";
            return leftCell;
        }
        else if (indexPath.section == self.paramList.count - 1 && indexPath.row == self.paramList[indexPath.section].list.firstObject.count + 1) {
            leftCell.titleLabel.text = @"设备评价";
            return leftCell;
        }
        else {
            leftCell.titleLabel.text = self.paramList[indexPath.section].list.firstObject[indexPath.row].paramName;
            if ([self.paramList[indexPath.section].list.firstObject[indexPath.row].paramLabelValueContrastFlag isEqualToString:@"0"]) {
//                leftCell.titleLabel.textColor = mHexColor(0x0D47A1);
            }
            else {
                
            }
            return leftCell;
        }
    } else if (tableView == _emptyTableView) {
        CompareRightCell *rightCell = [CompareRightCell cellWithTableView:tableView];
        return rightCell;
    } else {
        NSInteger rightTableViewIndex = [self.tableViewArr indexOfObject:tableView];
        mWeakSelf
        if (indexPath.section == self.paramList.count - 1 && indexPath.row == self.paramList[indexPath.section].list.firstObject.count) {
            CompareBottomCell *bottomCell = [CompareBottomCell cellWithTableView:tableView];
            bottomCell.titleLabel.text = @"查看详情";
            [bottomCell.titleLabel tapHandle:^NSString *{
                PersonalCenterController *centerVC = [[PersonalCenterController alloc] init];
                centerVC.detailStyle = 1;
                centerVC.selectIndex = 1;
                centerVC.equipmentID = weakSelf.localModelList[rightTableViewIndex].equipmentId;
                centerVC.parameterStr = weakSelf.localModelList[rightTableViewIndex].equipmentSku;
                centerVC.typeCode = weakSelf.localModelList[rightTableViewIndex].typeCode;
                centerVC.equipmentName = weakSelf.paramList.firstObject.list[rightTableViewIndex].firstObject.brandAndModel;
                centerVC.typeName = weakSelf.typeName;
                [weakSelf.navigationController pushViewController:centerVC animated:YES];
                return @"机型对比查看全部参数";
            }];
            return bottomCell;
        }
        else if (indexPath.section == self.paramList.count - 1 && indexPath.row == self.paramList[indexPath.section].list.firstObject.count + 1) {
            CompareBottomCell *bottomCell = [CompareBottomCell cellWithTableView:tableView];
            bottomCell.titleLabel.text = @"查看全部评价";
            [bottomCell.titleLabel tapHandle:^NSString *{
                PersonalCenterController *centerVC = [[PersonalCenterController alloc] init];
                centerVC.detailStyle = 1;
                centerVC.selectIndex = 3;
                centerVC.equipmentID = weakSelf.localModelList[rightTableViewIndex].equipmentId;
                centerVC.parameterStr = weakSelf.localModelList[rightTableViewIndex].equipmentSku;
                centerVC.typeCode = weakSelf.localModelList[rightTableViewIndex].typeCode;
                centerVC.equipmentName = weakSelf.paramList.firstObject.list[rightTableViewIndex].firstObject.brandAndModel;
                centerVC.typeName = weakSelf.typeName;
                [centerVC addWriteCommentBtn];
                [weakSelf.navigationController pushViewController:centerVC animated:YES];
                return @"机型对比查看全部评价";
            }];
            return bottomCell;
        }
        else {
            CompareRightCell *rightCell = [CompareRightCell cellWithTableView:tableView];
            rightCell.titleLabel.textColor = mHexColor(0x1E2124);
            if (indexPath.row < self.paramList[indexPath.section].list[rightTableViewIndex].count) {
                rightCell.titleLabel.text = self.paramList[indexPath.section].list[rightTableViewIndex][indexPath.row].valueContent;
                if (self.paramList[indexPath.section].list[rightTableViewIndex][indexPath.row].valueContent.length == 0) {
                    rightCell.titleLabel.text = @"-";
                }
                if ([self.paramList[indexPath.section].list[rightTableViewIndex][indexPath.row].paramLabelValueContrastFlag isEqualToString:@"0"]) {
//                    rightCell.titleLabel.textColor = mHexColor(0x0D47A1);
                }
                
            }
            else {
                rightCell.titleLabel.text = @"-";
            }
            return rightCell;
        }
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (tableView == self.placeTableView) {
        UIView *headV = [[UIView alloc] init];
        headV.backgroundColor = [UIColor clearColor];
        return headV;
    }
    CompareSectionHeaderView *sectionHeader = [CompareSectionHeaderView creatView];
    sectionHeader.titleLabel.text = self.paramList[section].name;
    return sectionHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.littleScrollView) {
        if (self.scrollView.contentOffset.x != self.littleScrollView.contentOffset.x) {
            self.scrollView.contentOffset = CGPointMake(self.littleScrollView.contentOffset.x, 0);
        }
    } else if (scrollView == self.scrollView) {
        if (self.littleScrollView.contentOffset.x != self.scrollView.contentOffset.x) {
            self.littleScrollView.contentOffset = CGPointMake(self.scrollView.contentOffset.x, 0);
        }
    } else if ([scrollView isKindOfClass:[UITableView class]]) {
        if (scrollView == self.backgroundTableView) {
            for (UITableView *right in self.tableViewArr) {
                right.contentOffset = CGPointMake(0, self.backgroundTableView.contentOffset.y);
            }
        } else {
            UITableView *scrollTableView = (UITableView *)scrollView;
            self.backgroundTableView.contentOffset = CGPointMake(0, scrollTableView.contentOffset.y);
            for (NSInteger i = 0; i < self.tableViewArr.count; i ++) {
                if (self.tableViewArr[i] != scrollTableView) {
                    self.tableViewArr[i].contentOffset = CGPointMake(0, scrollTableView.contentOffset.y);
                }
            }
        }
    }
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(0, scrollView.contentOffset.y, 94, CGRectGetHeight(self.backgroundTableView.frame))];
    self.backgroundTableView.path = path;
}

#pragma mark - event response
- (void) _addModels {
    UITableView *tableView = [self _creatTableView];
    tableView.frame = CGRectMake(self.distanceLeft + kItemWidth * self.count, 0, kItemWidth, kScreenHeight - self.naviZero - kHeaderHeight);
    
    [self.scrollView addSubview:tableView];
    [self.tableViewArr insertObject:tableView atIndex:self.tableViewArr.count - 1];
    
    [tableView reloadData];
    
    CompareRightHeader *header = [self _creatHeaderView];
    header.frame = CGRectMake(kItemWidth * self.count, 0, kItemWidth, kHeaderHeight);
    [self.littleScrollView addSubview:header];
    [self.headerArr insertObject:header atIndex:self.headerArr.count - 1];
    
    _count ++;
    [self _layoutWithArr:self.headerArr fromIndex:self.headerArr.count - 1 type:ParameterCompareTypeAdd];
    [self _layoutWithArr:self.tableViewArr fromIndex:self.tableViewArr.count - 1 type:ParameterCompareTypeAdd];
}

- (void)_deleteModels:(UIButton *)button {
    _count --;
    CompareRightHeader *rightHeader = (CompareRightHeader *)button.superview;
    NSInteger index = [self.headerArr indexOfObject:rightHeader];
    [YFCompareTool deleteCompareModel:index];
    if (self.localModelList.count > index) {
        [self.localModelList removeObjectAtIndex:index];
    }
    if (self.localModelList.count > 0) {
        self.noDataView.hidden = YES;
    }
    else {
        self.noDataView.hidden = NO;
    }
    [self _layoutWithArr:self.headerArr fromIndex:index type:ParameterCompareTypeDelete];
    [self _layoutWithArr:self.tableViewArr fromIndex:index type:ParameterCompareTypeDelete];
    // 删除相应的ID
    [self.idArr removeObjectAtIndex:index];
    [self.nameArr removeObjectAtIndex:index];

    
}

#pragma mark - getter
- (CompareTableView *)backgroundTableView {
    if (!_backgroundTableView) {
        _backgroundTableView = [[CompareTableView alloc] initWithFrame:CGRectMake(self.distanceLeft +0, self.naviZero + kHeaderHeight, kScreenWidth, kScreenHeight - self.naviZero - kHeaderHeight)];
        _backgroundTableView.delegate = self;
        _backgroundTableView.dataSource = self;
        _backgroundTableView.rowHeight = 35;
        _backgroundTableView.showsVerticalScrollIndicator = NO;
        _backgroundTableView.bounces = NO;
        _backgroundTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _backgroundTableView.scrollEnabled = YES;
        _backgroundTableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_backgroundTableView];
    }
    return _backgroundTableView;
}

- (UITableView *)emptyTableView {
    if (!_emptyTableView) {
        _emptyTableView = [self _creatTableView];
        _emptyTableView.frame = CGRectMake(self.distanceLeft +0, 0, kItemWidth, self.backgroundTableView.contentSize.height);
        _emptyTableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_emptyTableView];
    }
    return _emptyTableView;
}

- (CompareHiddenHeader *)hiddenHeader {
    if (!_hiddenHeader) {
        _hiddenHeader = [CompareHiddenHeader creatView];
        _hiddenHeader.hidden = NO;
        _hiddenHeader.frame = CGRectMake(self.distanceLeft +0, self.naviZero, kItemWidth, kHeaderHeight);
        [self.view addSubview:_hiddenHeader];
        [_hiddenHeader mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.distanceLeft);
            make.top.equalTo(self.naviZero);
            make.width.equalTo(kItemWidth);
            make.height.equalTo(kHeaderHeight);
        }];
    }
    return _hiddenHeader;
}


- (CompareHiddenHeader *)hiddenHeaderLast {
    if (!_hiddenHeaderLast) {
        _hiddenHeaderLast = [CompareHiddenHeader creatView];
        _hiddenHeaderLast.hidden = NO;
        _hiddenHeaderLast.frame = CGRectMake(self.distanceLeft +0, self.naviZero, kItemWidth, kHeaderHeight);
        [self.view addSubview:_hiddenHeaderLast];
        [_hiddenHeaderLast mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.distanceLeft);
            make.top.equalTo(self.naviZero);
            make.width.equalTo(kItemWidth);
            make.height.equalTo(kHeaderHeight);
        }];
    }
    return _hiddenHeaderLast;
}

- (CompareAddHeader *)addHeader {
    if (!_addHeader) {
        _addHeader = [CompareAddHeader creatView];
        _addHeader.hidden = NO;
        _addHeader.frame = CGRectMake(0, 0, kItemWidth, kHeaderHeight);
        
        __weak __typeof(self) weakSelf = self;
        _addHeader.addBlock = ^() {
            
//         UIImage *image =  [weakSelf captureCurrentView:weakSelf.view];
//            [weakSelf saveImageToPhotos:image];
//            return ;
            __strong __typeof(weakSelf) strongSelf = weakSelf;
            //如果为空的话,先弹出机型选择框
            if (self.localModelList.count == 0) {
                [strongSelf.brandList removeAllObjects];
                [strongSelf requestTypeListData];
            }
            else {
                //弹出品牌列表选择
//                strongSelf.typeID = strongSelf.localModelList.firstObject.typeCode;
                [strongSelf requestComparisonBrand];
            }
        };
    }
    return _addHeader;
}

- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.backgroundColor = [UIColor whiteColor];
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.bounces = NO;
        _scrollView.delegate = self;
    }
    return _scrollView;
}

- (UIScrollView *)littleScrollView {
    if (!_littleScrollView) {
        _littleScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(self.distanceLeft +kItemWidth, self.naviZero, kScreenWidth - kItemWidth, kHeaderHeight)];
        _littleScrollView.backgroundColor = mRGB(245, 245, 245);
        _littleScrollView.showsHorizontalScrollIndicator = NO;
        _littleScrollView.bounces = NO;
        _littleScrollView.delegate = self;
    }
    return _littleScrollView;
}

- (NSMutableArray<UITableView *> *)tableViewArr { ELazyMutableArray(_tableViewArr); }
- (NSMutableArray<UIView *> *)headerArr { ELazyMutableArray(_headerArr); }
- (NSMutableArray *)nameArr { ELazyMutableArray(_nameArr); }
- (NSMutableArray *)sectionArr { ELazyMutableArray(_sectionArr); }
- (NSMutableArray *)rowArr { ELazyMutableArray(_rowArr); }
- (NSMutableArray *)idArr { ELazyMutableArray(_idArr); }

//提前请求设备类型
- (void)requestTypeListDataPre {
//    NSDictionary *bodyDic = @{@"paramCode" : @"EQUIPMENT"};
    [[[ESNetworkManager getEquipType:nil] map:^id(id value) {
        return [YFEquipmentListModel mj_objectWithKeyValues:value];
        
    }] subscribeNext:^(YFEquipmentListModel *  _Nullable x) {
        self.typeList = x.data.sendData;
    } error:^(NSError * _Nullable error) {
        
    }];
}
//请求设备类型
- (void)requestTypeListData {
    if (self.typeList.count != 0) {
        YFCompareBrandModelSelectView *selectView = [[YFCompareBrandModelSelectView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight) dataList:self.typeList type:2];
        self.selectView = selectView;
        selectView.selectBrandBlock = ^(NSString *code, NSString *name,NSString *brandLogo) {
            //请求model数据
            self.typeID = code;
            self.typeName = name;
            [self.brandList removeAllObjects];
//            [self requestSencondData];
            [self requestComparisonBrand];
        };
        [kAppDelegate.window addSubview:selectView];
    }
    else {
        [self.view showBusyHUD];
        [[[ESNetworkManager getEquipType:nil] map:^id(id value) {
            return [YFEquipmentListModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFEquipmentListModel *  _Nullable x) {
            [self.view hideBusyHUD];
            self.typeList = x.data.sendData;
            YFCompareBrandModelSelectView *selectView = [[YFCompareBrandModelSelectView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight) dataList:self.typeList type:2];
            self.selectView = selectView;
            selectView.selectBrandBlock = ^(NSString *code, NSString *name,NSString *brandLogo) {
                //请求model数据
                self.typeID = code;
                self.typeName = name;
                [self.brandList removeAllObjects];
//                [self requestSencondData];
                [self requestComparisonBrand];
            };
            [kAppDelegate.window addSubview:selectView];
        } error:^(NSError * _Nullable error) {
            [self.view hideBusyHUD];
            [self.view showWarning:error.localizedDescription];
        }];
    }
}
//请求二级分类
- (void)requestSencondData {
    NSDictionary *bodyDic = @{@"equipmentParamTypeParamCode":self.typeID};
    [[[ESNetworkManager getEquipSencondList:bodyDic] map:^id(id value) {
        return [YFComapreSencondModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFComapreSencondModel *  _Nullable x) {
        NSArray<YFCompareSencondSendData *> *sencondList = [NSArray arrayWithArray:x.data.sendData];
        if (sencondList.count == 1) {
            self.secondID = sencondList.firstObject.equipmentParamTypeParamCodeTwo;
            self.typeName = sencondList.firstObject.equipmentParamTypeParamNameTwo;
            [self requestComparisonBrand];
            return;
        }
        YFCompareBrandModelSelectView *selectView = [[YFCompareBrandModelSelectView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight) dataList:sencondList type:3];
        
        self.selectView = selectView;
        selectView.selectBrandBlock = ^(NSString *code, NSString *name, NSString *brandLogo) {
            self.secondID = code;
            self.typeName = name;
            [self requestComparisonBrand];
        };
        [kAppDelegate.window addSubview:selectView];
    } error:^(NSError * _Nullable error) {
        
     }];
}

//初次进入已有机型存在,提前请求品牌
- (void)requestBrandListPre {
    if (self.localModelList.count != 0) {
        NSDictionary *bodyDic = @{@"equipmentFirstTypeCode":self.typeID};
       
        [[[ESNetworkManager getBrandListAndHot:bodyDic] map:^id(id value) {
            return [YFNewBrandListModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFNewBrandListModel *  _Nullable x) {
            [self.brandList removeAllObjects];
            [self.brandList addObjectsFromArray:x.data.sendData.aliasNameList];
        } error:^(NSError * _Nullable error) {
           
        }];
    }
}
//获取品牌
- (void)requestComparisonBrand {
    [self.brandList removeAllObjects];
    [self.view showBusyHUD];
    NSDictionary *bodyDic = @{@"equipmentFirstTypeCode":self.typeID};
    [[[ESNetworkManager getBrandListAndHot:bodyDic] map:^id(id value) {
        return [YFNewBrandListModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFNewBrandListModel *  _Nullable x) {
        [self.view hideBusyHUD];
        [self.brandList addObjectsFromArray:x.data.sendData.aliasNameList];
        YFCompareBrandSelectView *selectView = [[YFCompareBrandSelectView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight) dataList:self.brandList hotList:x.data.sendData.hotList];
        self.selectView = selectView;
        selectView.newselectBlock = ^(NSString *code, NSString *name) {
            self.brandID = code;
            self.brandName = name;
            [self requestModelListData];
        };
        [kAppDelegate.window addSubview:selectView];
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
}

//获取型号
- (void)requestModelListData {
    NSDictionary *bodyDic = @{@"equipmentParamTypeParamCode": self.typeID,@"brandId":self.brandID};
    [self.view showBusyHUD];
    [[[ESNetworkManager getComparisonModel:bodyDic] map:^id(id value) {
        return [YFComparisonModelModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFComparisonModelModel *  _Nullable x) {
        [self.view hideBusyHUD];
        [self.modelList removeAllObjects];
        [self.modelList addObjectsFromArray:x.data.sendData];
        //遍历去除已经添加过的机型
        NSArray<ComparisonModelSenddata *> *localList = [YFCompareTool getLocalCompareModelList];
        
        for (int i = 0; i < self.modelList.count; i++) {
            for (ComparisonModelSenddata *data in localList) {
                if ([self.modelList[i].equipmentId isEqualToString:data.equipmentId]) {
                    [self.modelList removeObjectAtIndex:i];
                    i--;
                    break;
                }
            }
        }
        YFCompareBrandModelSelectView *selectView = [[YFCompareBrandModelSelectView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight) dataList:self.modelList type:1];
        self.selectView = selectView;
        selectView.selectModelBlock = ^(ComparisonModelSenddata *model) {
            model.brandLogo = self.brandLogo;
            self.modelID = model.equipmentId;
            self.modelName = model.modelName;
            model.typeName = self.typeName;
            model.sencondID = self.secondID;
            model.typeCode = self.typeID;
            //将此机型存入本地
            BOOL success = [YFCompareTool writeInCompareModel:model];
            if (success) {
                [self.localModelList addObject:model];
                [self _loadParameterDataWithCout:1];
            }
            else {
                [self.view showWarning:@"加入失败"];
            }
        };
        [kAppDelegate.window addSubview:selectView];
        
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
    
    
}

- (NSMutableArray<ComparisonModelSenddata *> *)modelList {
    if (!_modelList) {
        _modelList = [NSMutableArray array];
    }
    return _modelList;
}

- (NSMutableArray<ComparisonModelSenddata *> *)localModelList {
    if (!_localModelList) {
        _localModelList = [NSMutableArray array];
    }
    return _localModelList;
}
- (NSString *)brandID {
    if (!_brandID) {
        _brandID = @"";
    }
    return _brandID;
}
- (NSString *)secondID {
    if (!_secondID) {
        _secondID = @"";
    }
    return _secondID;
}

- (NSString *)typeID {
    if (!_typeID) {
        _typeID = @"";
    }
    return _typeID;
    
}

- (dispatch_group_t)group {
    if (_group == nil) {
        _group = dispatch_group_create();
    }
    return _group;
}
- (NSMutableArray<NewBrandListBrandlist *> *)brandList {
    if (!_brandList) {
        _brandList = [NSMutableArray array];
    }
    return _brandList;
}
- (NSMutableArray<CompareGroupSenddata *> *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}

- (YFCompareNoDataView *)noDataView {
    if (!_noDataView) {
        _noDataView = [[YFCompareNoDataView alloc] initWithFrame:CGRectZero];
        [self.view addSubview:_noDataView];
        [self.view bringSubviewToFront:_noDataView];
        [_noDataView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        _noDataView.delegate = self;
    }
    return _noDataView;
}
#pragma mark -- NoDataViewDelegate
- (void)didTapAddBtn:(YFCompareNoDataView *)noDataView {
    [self requestTypeListData];
}

//设置样式
- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}

//设置是否隐藏
- (BOOL)prefersStatusBarHidden {
    //    [super prefersStatusBarHidden];
    return NO;
}

//设置隐藏动画
- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationNone;
}

- (void)dealloc {
    [ESNetworkManager cancelAllRequest];
}



#pragma mark -------- 截屏 --------
- (UIImage *)captureCurrentView:(UIView *)view {
    CGSize frame = self.scrollView.contentSize;
    UIGraphicsBeginImageContext(frame);
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    [self.scrollView.layer renderInContext:contextRef];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (UIImage *)captureScrollView{
    UIImage* image = nil;
    UIGraphicsBeginImageContextWithOptions(self.scrollView.contentSize, YES, 0.0);
    {
        CGPoint savedContentOffset = self.scrollView.contentOffset;
        CGRect savedFrame = self.scrollView.frame;
        self.scrollView.contentOffset = CGPointZero;
        self.scrollView.frame = CGRectMake(0, 0, self.scrollView.contentSize.width, self.scrollView.contentSize.height);
        
        [self.scrollView.layer renderInContext: UIGraphicsGetCurrentContext()];
        image = UIGraphicsGetImageFromCurrentImageContext();
        
        self.scrollView.contentOffset = savedContentOffset;
        self.scrollView.frame = savedFrame;
    }
    UIGraphicsEndImageContext();
    
    if (image != nil) {
        return image;
    }
    return nil;
}

- (void)saveImageToPhotos:(UIImage *)image {
    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:),nil);
}
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error == nil) {
        NSLog(@"保存成功");
    } else {
        NSLog(@"失败");
    }
}


@end
