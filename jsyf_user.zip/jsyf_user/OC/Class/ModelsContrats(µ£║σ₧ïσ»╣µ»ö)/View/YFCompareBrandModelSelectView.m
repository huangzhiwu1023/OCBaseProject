//
//  YFCompareBrandModelSelectView.m
//  jsyf_user
//
//  Created by 吕祥 on 2017/12/13.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "YFCompareBrandModelSelectView.h"
#import "YFComparisonBrandsModel.h"
#import "YFBrandSelectCell.h"
#import "YFEquipmentListModel.h"
#import "YFComapreSencondModel.h"

@interface YFCompareBrandModelSelectView()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;

@property(nonatomic, strong) NSArray *dataList;
@property(nonatomic, assign) NSInteger type;
@property(nonatomic, strong) NSArray<ComparisonBrandsSenddataBrandlist *> *brandList;
@property(nonatomic, strong) NSArray<ComparisonModelSenddata *> *modelList;
@property(nonatomic, strong) NSArray<EquipmentListSenddata *> *typeList;
@property(nonatomic, strong) NSArray<YFCompareSencondSendData *> *secondList;
//弹出框的高度
@property(nonatomic, assign) CGFloat viewHeight;
@end

@implementation YFCompareBrandModelSelectView
- (instancetype)initWithFrame:(CGRect)frame dataList:(NSArray *)dataList type:(NSInteger)type{
    if (self = [super initWithFrame:frame]) {
        self.dataList = dataList;
        self.viewHeight = 44 * self.dataList.count + 40;
        if (self.viewHeight <= 40) {
            self.viewHeight = 84;
        }
        self.type = type;
        if (self.type == 1) {
            self.modelList = dataList;
        }
        else if (self.type == 2) {
            self.typeList = dataList;
        }
        else if (self.type == 3) {
            self.secondList = dataList;
        }
        else{
            self.brandList = dataList;
        }
        
        [self show];
        [self contentView];
        self.backgroundColor = [UIColor clearColor];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapView:)];
        [self.bgView addGestureRecognizer:tap];
    }
    return self;
}
- (void)tapView:(UITapGestureRecognizer *)ges {
    [self closeView:self];
}

- (void)layoutSubviews {
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (orientation == UIInterfaceOrientationPortrait) {
        [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        CGFloat h = self.viewHeight;
        if (self.viewHeight > mScreenHeight-300) {
            h = mScreenHeight - 300;
        }
        [self.contentView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(40);
            make.right.equalTo(-40);
//            make.top.equalTo(150);
//            make.bottom.equalTo(-150);
            make.centerY.equalTo(0);
            make.height.equalTo(h);
        }];
    }
    else {
        [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);

        }];

        CGFloat h = self.viewHeight;
        if (self.viewHeight > mScreenHeight-80) {
            h = mScreenHeight - 80;
        }
            [self.contentView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(150);
            make.right.equalTo(-150);
                make.centerY.equalTo(0);
                make.height.equalTo(h);
//            make.top.equalTo(40);
//            make.bottom.equalTo(-40);
            }];
//        }
    }

}


- (void)show{
    self.bgView.alpha = 0;
    [self layoutIfNeeded];
    [UIView animateWithDuration:0.3 animations:^{
        self.bgView.alpha = 0.5;
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        
    }];
}

- (void)closeView:(YFCompareBrandModelSelectView *)view {
    __block UIView *lview = view;
    [UIView animateWithDuration:0.3 animations:^{
        view.bgView.alpha = 0;
        [view layoutIfNeeded];
    } completion:^(BOOL finished) {
        [view removeFromSuperview];
        lview = nil;
    }];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //0 品牌  1 型号  2 设备类型  3 设备分类
    if (self.type == 1) {  //型号
        !_selectModelBlock ?: _selectModelBlock(self.modelList[indexPath.row]);
    }
    else if (self.type == 2) {  //设备类型
        !_selectBrandBlock ?: _selectBrandBlock(self.typeList[indexPath.row].equipmentParamTypeParamCode,self.typeList[indexPath.row].equipmentParamTypeParamName,@"");
    }
    else if (self.type == 3) {
        !_selectBrandBlock ?: _selectBrandBlock(self.secondList[indexPath.row].equipmentParamTypeParamCodeTwo,self.secondList[indexPath.row].equipmentParamTypeParamNameTwo,@"");
    }
    else {  //品牌
        !_selectBrandBlock ?: _selectBrandBlock(self.brandList[indexPath.row].brandId,self.brandList[indexPath.row].chineseName,@"");
    }
    [self closeView:self];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    cell.textLabel.font = kFont14;
    cell.textLabel.textColor = kBlackWordColor;
    if (self.type == 1) {
        cell.textLabel.text = self.modelList[indexPath.row].modelName;
//        cell.textLabel.text = @"11111";
    }
    else if (self.type == 2) {
        cell.textLabel.text = self.typeList[indexPath.row].equipmentParamTypeParamName;
        
    }
    else if (self.type == 3) {
        cell.textLabel.text = self.secondList[indexPath.row].equipmentParamTypeParamNameTwo;
    }
    else {
        cell.textLabel.text = self.brandList[indexPath.row].chineseName;
    }
    
    return cell;
}

- (UIView *)bgView {
    if (!_bgView) {
        _bgView = [[UIView alloc] init];
        _bgView.backgroundColor = [UIColor blackColor];
        [self addSubview:_bgView];
        [_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
    }
    return _bgView;
}
- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.backgroundColor = [UIColor whiteColor];
        CGFloat h = self.viewHeight;
        if (self.viewHeight > mScreenHeight-300) {
            h = mScreenHeight - 300;
        }
        [self addSubview:_contentView];
        [_contentView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(40);
            make.right.equalTo(-40);
//            make.top.equalTo(150);
//            make.bottom.equalTo(-150);
            make.centerY.equalTo(0);
            make.height.equalTo(h);
        }];
        _contentView.layer.cornerRadius = 4;
        _contentView.layer.masksToBounds = YES;
        
        UIView *titleBgView = [[UIView alloc] init];
        [_contentView addSubview:titleBgView];
        [titleBgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.top.equalTo(0);
            make.height.equalTo(40);
            make.right.equalTo(0);
        }];
        titleBgView.backgroundColor = mHexColor(0xF48F4A);
        
        UILabel *titleLB = [[UILabel alloc] init];
        [titleBgView addSubview:titleLB];
        [titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(15);
            make.top.equalTo(0);
            make.height.equalTo(40);
            make.right.equalTo(-20);
        }];
        titleLB.font = [UIFont boldSystemFontOfSize:16];
        if (self.type == 0) {
            titleLB.text = @"品牌";
        }
        else if (self.type == 1) {
            titleLB.text = @"型号";
        }
        else if (self.type == 2) {
            titleLB.text = @"设备类型";
        }
        else if (self.type == 3) {
             titleLB.text = @"设备分类";
        }
        else {
            titleLB.text = @"选项";
        }
        
        titleLB.textColor = [UIColor whiteColor];
//        UIView *topLine = [[UIView alloc] init];
//        [_contentView addSubview:topLine];
//        [topLine mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(titleLB.mas_bottom);
//            make.left.right.equalTo(0);
//            make.height.equalTo(0.5);
//        }];
//        topLine.backgroundColor = kLineColor;
        
        [self tableView];
        
    }
    return _contentView;
}
#pragma mark -- UITableView Delegate/DataSource
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        [self.contentView addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.right.equalTo(0);
            make.top.equalTo(40);
            make.bottom.equalTo(-10);
        }];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];
        _tableView.rowHeight = 44;
        _tableView.separatorStyle = 0;
        _tableView.tableFooterView = [UIView new];
    }
    return _tableView;
}



@end
