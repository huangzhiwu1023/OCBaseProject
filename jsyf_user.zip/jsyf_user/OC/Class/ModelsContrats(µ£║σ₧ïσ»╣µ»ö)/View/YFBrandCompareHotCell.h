//
//  YFBrandCompareHotCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/6/22.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YFNewBrandListModel.h"
#import "YFSelectMachineFilterModel.h"

typedef void(^BrandCompareHotBlock)(NewBrandListHot *model);

@interface YFBrandCompareHotCell : UITableViewCell
@property(nonatomic, strong) NSArray<NewBrandListHot *> *hotList;

@property(nonatomic, copy) BrandCompareHotBlock compareHotBlock;

@end
