//
//  YFCompareBrandSelectView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/17.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^brandBlock)(NSString *code,NSString *name);

@interface YFCompareBrandSelectView : UIView


- (instancetype)initWithFrame:(CGRect)frame dataList:(NSArray *)dataList hotList:(NSArray *)hotList;

@property(nonatomic, copy) brandBlock newselectBlock;
@property(nonatomic, strong) UIView *bgView;
@property(nonatomic, strong) UIView *contentView;

@end
