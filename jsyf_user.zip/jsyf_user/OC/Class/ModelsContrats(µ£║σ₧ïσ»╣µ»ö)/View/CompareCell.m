//
//  CompareCell.m
//  UITableViewLInkageDemo
//
//  Created by Eleven on 2017/7/3.
//  Copyright © 2016年 Hawk. All rights reserved.
//

#import "CompareCell.h"

@implementation CompareLeftCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString * ID = @"CompareLeftCell";
    CompareLeftCell * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CompareCell" owner:nil options:nil] objectAtIndex:0];
    }
    cell.titleLabel.textAlignment = NSTextAlignmentLeft;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleLabel.textColor = kDarkWordColor;
    return cell;
}

@end

@implementation CompareRightCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString * ID = @"CompareRightCell";
    CompareRightCell * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CompareCell" owner:nil options:nil] objectAtIndex:1];
    }
    cell.titleLabel.textAlignment = NSTextAlignmentLeft;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleLabel.textColor = kBlackWordColor;
    return cell;
}

@end

@implementation CompareBottomCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString * ID = @"CompareBottomCell";
    CompareBottomCell * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CompareCell" owner:nil options:nil] objectAtIndex:2];
    }
    cell.titleLabel.textColor = kBuleWordColor;
    cell.titleLabel.textAlignment = NSTextAlignmentLeft;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

@end
