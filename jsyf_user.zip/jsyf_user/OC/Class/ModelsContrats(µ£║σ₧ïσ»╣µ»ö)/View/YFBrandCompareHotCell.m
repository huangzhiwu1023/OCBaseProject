//
//  YFBrandCompareHotCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/6/22.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFBrandCompareHotCell.h"
#import "YFHotEquipmentCell.h"
#import "YFAllBrandCell.h"
#import "YFBrandCenterVC.h"

@interface YFBrandCompareHotCell()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic, strong) UICollectionView *collectionView;

@end

@implementation YFBrandCompareHotCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self collectionView];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadView) name:@"viewTrans" object:nil];
    }
    return self;
}

- (void)reloadView {
    [self.collectionView reloadData];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (mScreenHeight > mScreenWidth) {
         return CGSizeMake((mScreenWidth - 3 - 80-25) / 4.0, (mScreenWidth - 3 - 80-25) / 4.0);
    }
    else {
        return CGSizeMake((mScreenWidth -3 -300-25)/4.0 , (mScreenWidth -3 -300-25)/4.0);
    }
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.hotList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NewBrandListHot *hotModel = self.hotList[indexPath.row];
    YFAllBrandCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFAllBrandCell" forIndexPath:indexPath];
    [cell.brandIV sd_setImageWithURL:hotModel.brandAppLogoUrl.lx_URL placeholderImage:kPlaceholderImage];
    cell.brandLB.text = hotModel.brandChineseName;
    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NewBrandListHot *hotModel = self.hotList[indexPath.row];
    !_compareHotBlock ?: _compareHotBlock(hotModel);
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 3 - 80) / 4.0, (mScreenWidth - 3 - 80) / 4.0);
        layout.minimumLineSpacing = 1;
        layout.minimumInteritemSpacing = 1;
        layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.contentView addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.right.equalTo(0);
//            make.width.equalTo(mScreenWidth-80);
            make.top.bottom.equalTo(0);
        }];
        _collectionView.scrollEnabled = NO;
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = kBottomBgColor;
        [_collectionView registerClass:[YFHotEquipmentCell class] forCellWithReuseIdentifier:@"YFHotEquipmentCell"];
        [_collectionView registerClass:[YFAllBrandCell class] forCellWithReuseIdentifier:@"YFAllBrandCell"];
    }
    return _collectionView;
}

- (void)setHotList:(NSArray<NewBrandListHot *> *)hotList {
    _hotList = hotList;
    [self.collectionView reloadData];
}

@end
