//
//  YFCompareBrandModelSelectView.h
//  jsyf_user
//
//  Created by 吕祥 on 2017/12/13.
//  Copyright © 2017年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YFComparisonModelModel.h"

typedef void(^selectCompareBlock)(NSString *code,NSString *name,NSString *brandLogo);

typedef void(^selectModelBlock)(ComparisonModelSenddata *model);

@interface YFCompareBrandModelSelectView : UIView

//0 品牌  1 型号  2 设备类型  3 设备分类
- (instancetype)initWithFrame:(CGRect)frame dataList:(NSArray *)dataList type:(NSInteger)type;

@property(nonatomic, copy) selectCompareBlock selectBrandBlock;
@property(nonatomic, copy) selectModelBlock selectModelBlock;
@property(nonatomic, strong) UIView *bgView;
@property(nonatomic, strong) UIView *contentView;


@end
