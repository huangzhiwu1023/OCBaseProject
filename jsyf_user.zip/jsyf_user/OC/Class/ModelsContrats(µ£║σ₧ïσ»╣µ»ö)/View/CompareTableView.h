//
//  CompareTableView.h
//  UITableViewLInkageDemo
//
//  Created by Eleven on 2017/8/13.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompareTableView : UITableView

@property (nonatomic, strong) UIBezierPath *path;

@end
