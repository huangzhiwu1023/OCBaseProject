//
//  YFCompareBrandSelectView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/17.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFCompareBrandSelectView.h"
#import "YFBrandListCell.h"
#import "YFBrandCompareHotCell.h"
#import "ZTLetterIndex.h"
#import "YFNewBrandListModel.h"

@interface YFCompareBrandSelectView()<UITableViewDelegate,UITableViewDataSource,ZTLetterIndexDelegate>
@property(nonatomic, strong) UITableView *tableView;


@property(nonatomic, strong) ZTLetterIndex *letterIndex;
@property(nonatomic, strong) NSMutableArray *letterArray;
@property(nonatomic, assign) BOOL isClick;

@property(nonatomic, strong) NSArray<NewBrandListBrandlist *> *dataList;
@property(nonatomic, strong) NSArray<NewBrandListHot *> *hotList;


@property(nonatomic, assign) NSInteger totalCount;

@property(nonatomic, assign) CGFloat height;
@end

@implementation YFCompareBrandSelectView
- (instancetype)initWithFrame:(CGRect)frame dataList:(NSArray *)dataList hotList:(NSArray *)hotList{
    if (self = [super initWithFrame:frame]) {
        self.dataList = dataList;
        self.hotList = hotList;
        self.backgroundColor = [UIColor clearColor];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapView:)];
        [self.bgView addGestureRecognizer:tap];
        
        self.isClick = NO;
        self.letterArray = [NSMutableArray array];
        self.totalCount = 0;
        
        NSMutableArray<NewBrandListBrandlist *> *tmpArr = [NSMutableArray array];
        tmpArr = self.dataList.mutableCopy;
        for (int i = 0; i < tmpArr.count; i++) {
            if (tmpArr[i].brandList.count == 0) {
                [tmpArr removeObjectAtIndex:i];
                i--;
            }
        }
        self.dataList =  tmpArr.copy;
//        if (self.hotList.count > 0) {
            [self.letterArray addObject:@"热"];
//        }
    
        for (NewBrandListBrandlist *data in self.dataList) {
            if (data.brandList.count != 0) {
                [self.letterArray addObject:data.brandAliasName];
                self.totalCount += data.brandList.count;
            }
        }
        
        self.height = 50 + 48 * self.totalCount + self.letterArray.count * 25;
        if (self.height >= mScreenHeight - 40 - 40) {
            self.height = mScreenHeight - 40 - 40;
        }
        [self show];
        [self contentView];
        [self letterIndex];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadView) name:@"viewTrans" object:nil];
        
    }
    return self;
}

- (void)reloadView {
    [self.tableView reloadData];
}

- (void)tapView:(UITapGestureRecognizer *)ges {
    [self closeView:self];
}

- (void)layoutSubviews {
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (orientation == UIDeviceOrientationPortrait) {
        self.height = 50 + 48 * self.totalCount + self.letterArray.count * 25;
        if (self.height >= mScreenHeight - 40 - 40) {
            self.height = mScreenHeight - 40 - 40;
        }
        [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        [self.contentView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(40);
            make.right.equalTo(-40);
//            make.top.equalTo(200);
//            make.bottom.equalTo(-200);
            make.centerY.equalTo(0);
            make.height.equalTo(self.height);
            
        }];
    }
    else {
        self.height = 50 + 48 * self.totalCount + self.letterArray.count * 25;
        if (self.height >= mScreenHeight - 30 - 30) {
            self.height = mScreenHeight - 30 - 30;
        }
        [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
            
        }];
        [self.contentView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(150);
            make.right.equalTo(-150);
//            make.top.equalTo(40);
//            make.bottom.equalTo(-40);
            make.centerY.equalTo(0);
            make.height.equalTo(self.height);
        }];
    }
}


- (void)show{
    self.bgView.alpha = 0;
    [self layoutIfNeeded];
    [UIView animateWithDuration:0.3 animations:^{
        self.bgView.alpha = 0.5;
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        
    }];
}

- (void)closeView:(YFCompareBrandSelectView *)view {
    __block UIView *lview = view;
    [UIView animateWithDuration:0.3 animations:^{
        view.bgView.alpha = 0;
        [view layoutIfNeeded];
    } completion:^(BOOL finished) {
        [view removeFromSuperview];
        lview = nil;
    }];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NewBrandListBrandlistModel *model = self.dataList[indexPath.section-1].brandList[indexPath.row];
    !_newselectBlock ?: _newselectBlock(model.brandId,model.brandChineseName);
    [self closeView:self];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataList.count + 1;
//    return self.dataList.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }
    else {
        return self.dataList[section - 1].brandList.count;
    }
//    return self.dataList[section].brandList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFBrandCompareHotCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFBrandCompareHotCell" forIndexPath:indexPath];
        cell.hotList = self.hotList;
        cell.compareHotBlock = ^(NewBrandListHot *model) {
            !_newselectBlock ?: _newselectBlock(model.brandId,model.brandChineseName);
            [self closeView:self];
        };
        return cell;
    } else {
        YFBrandListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFBrandListCell" forIndexPath:indexPath];
        [cell.brandIcon sd_setImageWithURL:self.dataList[indexPath.section-1].brandList[indexPath.row].brandAppLogoUrl.lx_URL placeholderImage:kPlaceholderImage];
        cell.brandName.text = self.dataList[indexPath.section-1].brandList[indexPath.row].brandChineseName;
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        NSInteger lines = self.hotList.count / 4;
        if (self.hotList.count % 4) {
            lines += 1;
        }
        if (self.hotList.count == 0) {
            return 0;
        }
        else {
            if (mScreenWidth > mScreenHeight) {
                return (mScreenWidth - 3 - 300-25) / 4 * lines + lines - 1;
            } else {
                return (mScreenWidth - 3 - 80-25) / 4 * lines + lines - 1;
                
            }
        }
    }
    return 48;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView * headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH, 40)];
    headView.backgroundColor = kBottomBgColor;
    UILabel *nameLB = [[UILabel alloc] init];
    [headView addSubview:nameLB];
    [nameLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(15);
        make.right.equalTo(0);
        make.top.bottom.equalTo(0);
    }];
    nameLB.font = [UIFont boldSystemFontOfSize:13];
    nameLB.textColor = kBlackWordColor;
    if (section == 0) {
        nameLB.text = @"热门";
    }else {
        nameLB.text = self.dataList[section-1].brandAliasName;
    }
    return headView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01f;
}

- (UIView *)bgView {
    if (!_bgView) {
        _bgView = [[UIView alloc] init];
        _bgView.backgroundColor = [UIColor blackColor];
        [self addSubview:_bgView];
        [_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        
    }
    return _bgView;
}
- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.backgroundColor = [UIColor whiteColor];
        [self addSubview:_contentView];
        
        [_contentView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(40);
            make.right.equalTo(-40);
            make.centerY.equalTo(0);
            make.height.equalTo(self.height);
        }];
        _contentView.layer.cornerRadius = 4;
        _contentView.layer.masksToBounds = YES;
        
        UIView *titleBgView = [[UIView alloc] init];
        [_contentView addSubview:titleBgView];
        [titleBgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.top.equalTo(0);
            make.height.equalTo(40);
            make.right.equalTo(0);
        }];
        titleBgView.backgroundColor = mHexColor(0xF48F4A);
        
        UILabel *titleLB = [[UILabel alloc] init];
        [_contentView addSubview:titleLB];
        [titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(15);
            make.top.equalTo(0);
            make.height.equalTo(40);
            make.right.equalTo(-20);
        }];
        titleLB.font = [UIFont boldSystemFontOfSize:16];
        titleLB.text = @"品牌";
        titleLB.textColor = [UIColor whiteColor];
//        UIView *topLine = [[UIView alloc] init];
//        [_contentView addSubview:topLine];
//        [topLine mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(titleLB.mas_bottom);
//            make.left.right.equalTo(0);
//            make.height.equalTo(0.5);
//        }];
//        topLine.backgroundColor = kLineColor;
        
        [self tableView];
        
    }
    return _contentView;
}
#pragma mark -- UITableView Delegate/DataSource
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        [self.contentView addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.right.equalTo(-25);
            make.top.equalTo(40);
            make.bottom.equalTo(-10);
        }];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        [_tableView registerClass:[YFBrandListCell class] forCellReuseIdentifier:@"YFBrandListCell"];
        [_tableView registerClass:[YFBrandCompareHotCell class] forCellReuseIdentifier:@"YFBrandCompareHotCell"];
//        _tableView.rowHeight = 48;
        _tableView.separatorStyle = 0;
        _tableView.tableFooterView = [UIView new];
    }
    return _tableView;
}

#pragma Mark============索引============
- (ZTLetterIndex *)letterIndex {
    if (!_letterIndex) {
        _letterIndex = [[ZTLetterIndex alloc] initWithFrame:CGRectMake(self.bounds.size.width-20, (self.bounds.size.height - 16*25 - 40)/2, 16, 16*25 + 40 + 8)];
        _letterIndex.sliderColor = mHexColor(0xF48F4A);
        _letterIndex.textColor = kBlackWordColor;
        _letterIndex.selectedTextColor = [UIColor whiteColor];
        _letterIndex.dataArray = _letterArray; //在其他用于展示的属性赋值之后赋值
        _letterIndex.delegate = self;
        [self.contentView addSubview:_letterIndex];
        [_letterIndex mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-4);
            make.centerY.equalTo(0);
            make.width.equalTo(16);
            make.height.equalTo(16*self.letterArray.count + 4 *self.letterArray.count +56);
        }];
    }
    return _letterIndex;
}

#pragma mark - ZTLetterIndexDelegate
- (void)ZTLetterIndex:(ZTLetterIndex *)indexView didSelectedItemWithIndex:(NSInteger)index {
    _isClick = YES;
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:index] atScrollPosition:UITableViewScrollPositionTop animated:NO];
}

- (void)ZTLetterIndex:(ZTLetterIndex *)indexView beginChangeItemWithIndex:(NSInteger)index {
   
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:index] atScrollPosition:UITableViewScrollPositionTop animated:NO];
}

- (void)ZTLetterIndex:(ZTLetterIndex *)indexView endChangeItemWithIndex:(NSInteger)index {
    
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:index] atScrollPosition:UITableViewScrollPositionTop animated:NO];
}

- (void)ZTLetterIndex:(ZTLetterIndex *)indexView isChangingItemWithIndex:(NSInteger)index {
    
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:index] atScrollPosition:UITableViewScrollPositionTop animated:NO];
}

#pragma mark -UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (_isClick) {
        return;
    }
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:scrollView.contentOffset];
    NSInteger selectIndex = 0;
    selectIndex = indexPath.section;
//    if (selectIndex <= 0) {
//        selectIndex = 0;
//    }
//    if (selectIndex >= self.letterArray.count) {
//        selectIndex = self.letterArray.count - 1;
//    }
    [_letterIndex selectIndex:selectIndex];
}
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    _isClick = NO;
}
@end
