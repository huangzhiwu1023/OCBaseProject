//
//  SectionHeaderView.h
//  UITableViewLInkageDemo
//
//  Created by Eleven on 2017/7/3.
//  Copyright © 2016年 Hawk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompareSectionHeaderView : UIView

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

+ (instancetype)creatView;

@end
