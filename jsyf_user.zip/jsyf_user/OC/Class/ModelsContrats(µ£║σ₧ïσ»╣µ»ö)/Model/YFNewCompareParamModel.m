//
//  YFNewCompareParamModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/2/11.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFNewCompareParamModel.h"

@implementation YFNewCompareParamModel

@end



@implementation YFNewCompareParamE

@end


@implementation YFNewCompareParamData

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"sendData" : [YFNewCompareParamSenddata class]};
}

@end


@implementation YFNewCompareParamSenddata
+ (NSDictionary *)mj_objectClassInArray{
    return @{@"list" : [NSArray<YFNewCompareParamList *> class]};
}
@end

@implementation YFNewCompareParamList

@end
