//
//  YFNewCompareParamModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/2/11.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class YFNewCompareParamE,YFNewCompareParamData,YFNewCompareParamSenddata,YFNewCompareParamList;
@interface YFNewCompareParamModel : NSObject

@property (nonatomic, strong) YFNewCompareParamE *e;

@property (nonatomic, strong) YFNewCompareParamData *data;

@end

@interface YFNewCompareParamE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface YFNewCompareParamData : NSObject

@property (nonatomic, strong) NSArray<YFNewCompareParamSenddata *> *sendData;

@end

@interface YFNewCompareParamSenddata : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *code;

@property (nonatomic, strong) NSArray<NSArray<YFNewCompareParamList *> *> *list;

@end

@interface YFNewCompareParamList : NSObject
@property(nonatomic, strong) NSString *brandAndModel;
@property(nonatomic, strong) NSString *equipmentId;
@property(nonatomic, strong) NSString *paramLabelValueContrastFlag;
@property(nonatomic, strong) NSString *paramLabelValueEquipmentTypeCode;
@property(nonatomic, strong) NSString *paramLabelValueId;
@property(nonatomic, strong) NSString *paramLabelValueParamCode;
@property(nonatomic, strong) NSString *paramLabelValueParentId;
@property(nonatomic, strong) NSString *paramLabelValueSort;
@property(nonatomic, strong) NSString *paramName;
@property(nonatomic, strong) NSString *thumbnails;
@property(nonatomic, strong) NSString *valueContent;
@end
