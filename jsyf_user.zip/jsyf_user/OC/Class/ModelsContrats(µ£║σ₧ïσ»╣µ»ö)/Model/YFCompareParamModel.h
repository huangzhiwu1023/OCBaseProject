//
//  YFCompareParamModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2017/12/14.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CompareParamE,CompareParamData,CompareParamSenddata,CompareParamObject,CompareParamParam,CompareParamNameandcontentlist,CompareParamMenu;
@interface YFCompareParamModel : NSObject

@property (nonatomic, strong) CompareParamE *e;

@property (nonatomic, strong) CompareParamData *data;

@end
@interface CompareParamE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface CompareParamData : NSObject

@property (nonatomic, strong) CompareParamSenddata *sendData;

@end

@interface CompareParamSenddata : NSObject

@property (nonatomic, strong) NSArray<CompareParamMenu *> *menu;

@property (nonatomic, strong) CompareParamObject *object;

@property (nonatomic, strong) NSArray<CompareParamNameandcontentlist *> *nameAndContentList;

@property (nonatomic, copy) NSString *thumbnails;

@end

@interface CompareParamObject : NSObject

@property (nonatomic, strong) NSArray<CompareParamParam *> *param;

@property (nonatomic, assign) NSInteger equipmentSequenceId;

@property (nonatomic, copy) NSString *brandAndModel;

@property (nonatomic, copy) NSString *equipmentId;

@property (nonatomic, copy) NSString *typeCode;

@end

@interface CompareParamParam : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *value;

@end

@interface CompareParamNameandcontentlist : NSObject

@property (nonatomic, copy) NSString *paramLabelId;

@property (nonatomic, copy) NSString *valueName;

@property (nonatomic, copy) NSString *valueContent;

@end

@interface CompareParamMenu : NSObject

@property (nonatomic, copy) NSString *paramLabelId;

@property (nonatomic, copy) NSString *valueName;

@end

