//
//  YFCompareGroupModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/1/3.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CompareGroupE,CompareGroupData,CompareGroupSenddata,CompareGroupEquipment,CompareGroupParam,CompareGroupNameandcontentlist;
@interface YFCompareGroupModel : NSObject

@property (nonatomic, strong) CompareGroupE *e;

@property (nonatomic, strong) CompareGroupData *data;

@end
@interface CompareGroupE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface CompareGroupData : NSObject

@property (nonatomic, strong) CompareGroupSenddata *sendData;

@end

@interface CompareGroupSenddata : NSObject
@property (nonatomic, strong) CompareGroupEquipment *equipment;
@property (nonatomic, strong) NSArray<CompareGroupParam *> *param;


@end

@interface CompareGroupParam : NSObject
@property(nonatomic, strong) NSString *componentName;
@property(nonatomic, strong) NSArray<CompareGroupNameandcontentlist *> *nameAndContentList;
@end

@interface CompareGroupEquipment : NSObject
@property(nonatomic, strong) NSString *brandAndModel;
@property(nonatomic, strong) NSString *equipmentId;
@property(nonatomic, strong) NSString *thumbnails;
@property(nonatomic, strong) NSString *typeCode;
@end

@interface CompareGroupNameandcontentlist : NSObject

@property (nonatomic, copy) NSString *paramLabelId;

@property (nonatomic, copy) NSString *valueName;

@property (nonatomic, copy) NSString *valueContent;

@end

