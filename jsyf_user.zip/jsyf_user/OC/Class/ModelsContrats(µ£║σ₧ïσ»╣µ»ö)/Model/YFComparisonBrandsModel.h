//
//  YFComparisonBrandsModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2017/12/13.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ComparisonBrandsE,ComparisonBrandsData,ComparisonBrandsSenddata,ComparisonBrandsSenddataBrandlist;
@interface YFComparisonBrandsModel : NSObject

@property (nonatomic, strong) ComparisonBrandsE *e;

@property (nonatomic, strong) ComparisonBrandsData *data;

@end
@interface ComparisonBrandsE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface ComparisonBrandsData : NSObject

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, strong) ComparisonBrandsSenddata *sendData;

@property(nonatomic, strong) NSString *paramNameSecond;

@end

@interface ComparisonBrandsSenddata : NSObject

@property (nonatomic, copy) NSString *englishName;

@property (nonatomic, copy) NSString *brandAppLogUrl;
//id -> idField
@property (nonatomic, copy) NSString *idField;

@property (nonatomic, copy) NSString *brandName;

@property(nonatomic, strong) NSArray<ComparisonBrandsSenddataBrandlist *> *brandsList;

@end

@interface ComparisonBrandsSenddataBrandlist : NSObject
@property(nonatomic, strong) NSString *brandId;
@property(nonatomic, strong) NSString *chineseName;
@property(nonatomic, strong) NSString *nameSpell;
@property(nonatomic, strong) NSString *paramNameSecond;
@end
