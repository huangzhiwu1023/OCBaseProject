//
//  YFCompareGroupModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/1/3.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFCompareGroupModel.h"

@implementation YFCompareGroupModel

@end
@implementation CompareGroupE

@end


@implementation CompareGroupData

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"sendData" : [CompareGroupSenddata class]};
}

@end


@implementation CompareGroupSenddata

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"param" : [CompareGroupParam class]};
}


- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}

@end

@implementation CompareGroupParam

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"nameAndContentList" : [CompareGroupNameandcontentlist class]};
}
@end

@implementation CompareGroupEquipment
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end
@implementation CompareGroupNameandcontentlist

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


