//
//  YFComparisonBrandsModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2017/12/13.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import "YFComparisonBrandsModel.h"


@implementation YFComparisonBrandsModel

@end
@implementation ComparisonBrandsE

MJExtensionCodingImplementation
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation ComparisonBrandsData

@end


@implementation ComparisonBrandsSenddata

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"brandsList" : [ComparisonBrandsSenddataBrandlist class]};
}

@end

@implementation ComparisonBrandsSenddataBrandlist

@end

