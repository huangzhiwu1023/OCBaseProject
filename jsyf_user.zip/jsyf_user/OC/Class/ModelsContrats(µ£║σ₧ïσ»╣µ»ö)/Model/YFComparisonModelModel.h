//
//  YFComparisonModelModel.h
//
//  Created by 吕祥 on 2017/12/14.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ComparisonModelE,ComparisonModelData,ComparisonModelSenddata;
@interface YFComparisonModelModel : NSObject

@property (nonatomic, strong) ComparisonModelE *e;

@property (nonatomic, strong) ComparisonModelData *data;

@end
@interface ComparisonModelE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface ComparisonModelData : NSObject

@property (nonatomic, strong) NSArray<ComparisonModelSenddata *> *sendData;

@end

@interface ComparisonModelSenddata : NSObject<NSCoding>

//@property (nonatomic, copy) NSString *brandId;

//@property (nonatomic, copy) NSString *modelName;

//@property (nonatomic, copy) NSString *equipmentId;

@property (nonatomic, copy) NSString *typeCode;
//品牌logo  add 非接口所有
@property(nonatomic, strong) NSString *brandLogo;
//lvx add
@property(nonatomic, strong) NSString *typeName;
//lvx add   保存到本地
@property(nonatomic, strong) NSString *sencondID;
//lvx add  保存到本地
@property(nonatomic, strong) NSString *secondName;

//New
@property (nonatomic, copy) NSString *equipmentId;
@property (nonatomic, copy) NSString *equipmentSku;
@property (nonatomic, copy) NSString *modelName;

@end

