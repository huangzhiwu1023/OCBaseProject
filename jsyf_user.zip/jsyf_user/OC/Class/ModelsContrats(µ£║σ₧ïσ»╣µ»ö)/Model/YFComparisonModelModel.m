//
//  YFComparisonModelModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2017/12/14.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import "YFComparisonModelModel.h"
#define USING_ENCODE_KIT            1

@implementation YFComparisonModelModel

@end
@implementation ComparisonModelE

@end


@implementation ComparisonModelData

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"sendData" : [ComparisonModelSenddata class]};
}

@end


@implementation ComparisonModelSenddata


MJExtensionCodingImplementation
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}



@end


