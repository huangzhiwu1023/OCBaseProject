//
//  YFCompareParamModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2017/12/14.
//  Copyright © 2017年 Hawk. All rights reserved.
//

#import "YFCompareParamModel.h"

@implementation YFCompareParamModel

@end
@implementation CompareParamE

@end


@implementation CompareParamData
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation CompareParamSenddata

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"nameAndContentList" : [CompareParamNameandcontentlist class], @"menu" : [CompareParamMenu class]};
}
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation CompareParamObject

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"param" : [CompareParamParam class]};
}
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation CompareParamParam
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation CompareParamNameandcontentlist
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation CompareParamMenu


- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


