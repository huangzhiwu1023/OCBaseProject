//
//  YFUserVideoModel.h
//  jsyf_user
//
//  Created by 黄志武 on 2018/4/9.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>
@class DiscussList;
@interface YFUserVideoModel : NSObject
@property (nonatomic, strong) NSString * columnCode;
@property (nonatomic, strong) NSString * coverPicture;
@property (nonatomic, strong) NSString * coverPictureUrl;
@property (nonatomic, strong) NSString * createdBy;
@property (nonatomic, assign) NSInteger createdTime;
@property (nonatomic, strong) NSString * customerImgUrl;
@property (nonatomic, strong) NSString * customerNickName;
@property (nonatomic, assign) NSInteger discussCount;
@property (nonatomic, strong) NSArray<DiscussList *> * discussList;
@property (nonatomic, assign) NSInteger likeNumber;
@property (nonatomic, strong) NSString * modifyBy;
@property (nonatomic, strong) NSString * modifyByName;
@property (nonatomic, assign) long long modifyTime;
@property (nonatomic, assign) NSInteger playNumber;
@property (nonatomic, assign) NSInteger sort;
@property (nonatomic, strong) NSString * statusFlag;
@property (nonatomic, strong) NSString * videoContent;
@property (nonatomic, strong) NSString * videoId;
@property (nonatomic, strong) NSString * videoTitle;
@property (nonatomic, strong) NSString * videoType;
@property (nonatomic, strong) NSString * videoUrl;
//点赞标记  1 未点赞  0 已点赞
@property(nonatomic, strong) NSString *praiseFlag;
//@property(nonatomic, assign) NSInteger sequenceId;
@end


@interface DiscussList : NSObject

@property (nonatomic, strong) NSString * atticCommentId;
@property (nonatomic, strong) NSString * commentCountnet;
@property (nonatomic, assign) NSInteger commentFloor;
@property (nonatomic, strong) NSString * commentTypeCode;
@property (nonatomic, strong) NSString * customerId;
@property (nonatomic, strong) NSString * customerImgUrl;
@property (nonatomic, strong) NSString * customerNickName;
@property (nonatomic, strong) NSString * delFlag;
@property (nonatomic, strong) NSString * delTime;
@property (nonatomic, strong) NSString * equipmentSource;
@property (nonatomic, assign) NSInteger fabulousNumber;
@property (nonatomic, strong) NSString * idField;
@property (nonatomic, strong) NSString * modifyTime;
@property (nonatomic, strong) NSString * parentId;
@property (nonatomic, strong) NSString * publishIp;
@property (nonatomic, strong) NSString * publishTime;
@property (nonatomic, strong) NSString * relevanceId;
@property (nonatomic, strong) NSString * replayId;
@property (nonatomic, assign) NSInteger sort;
@property (nonatomic, strong) NSString * statusFlag;

@end
