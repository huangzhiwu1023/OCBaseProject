//
//  YFVideoCommentModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/4/11.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class YFVideoComentE,YFVideoComentData,YFVideoComentSenddata,YFVideoComentChildrenlist;
@interface YFVideoCommentModel : NSObject

@property (nonatomic, strong) YFVideoComentE *e;

@property (nonatomic, strong) YFVideoComentData *data;

@end
@interface YFVideoComentE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface YFVideoComentData : NSObject

@property (nonatomic, assign) NSInteger count;
@property (nonatomic, assign) NSInteger totalCount;

@property (nonatomic, strong) NSArray<YFVideoComentSenddata *> *sendData;

@end

@interface YFVideoComentSenddata : NSObject

@property (nonatomic, copy) NSString *modifyTime;

@property (nonatomic, copy) NSString *commentCountnet;

@property (nonatomic, copy) NSString *relevanceId;//帖子序列id

@property (nonatomic, copy) NSString *customerNickName;

@property (nonatomic, assign) NSInteger isLoadMoreFlag;

@property (nonatomic, assign) NSInteger sort;

@property (nonatomic, copy) NSString *delTime;

@property (nonatomic, copy) NSString *publishIp;

@property (nonatomic, copy) NSString *customerId;

@property (nonatomic, copy) NSString *atticCommentId;
//id ->idField
@property (nonatomic, copy) NSString *idField;//评论id

@property (nonatomic, assign) NSInteger fabulousNumber;

@property (nonatomic, assign) NSInteger commentFloor;

@property (nonatomic, copy) NSString *customerImgUrl;

@property (nonatomic, assign) NSInteger answerCount;

@property (nonatomic, copy) NSString *parentId;//上级id

@property (nonatomic, strong) NSArray<YFVideoComentChildrenlist *> *childrenList;

@property (nonatomic, copy) NSString *publishTime;

@property (nonatomic, copy) NSString *statusFlag;

@property (nonatomic, copy) NSString *commentTypeCode;

@property (nonatomic, copy) NSString *replayId;

@property (nonatomic, copy) NSString *equipmentSource;

@property(nonatomic, strong) NSString *delFlag;

@property(nonatomic, strong) NSString *shieldFlag;

@end

@interface YFVideoComentChildrenlist : NSObject

@property (nonatomic, copy) NSString *modifyTime;

@property (nonatomic, copy) NSString *commentCountnet;

@property (nonatomic, copy) NSString *relevanceId;

@property (nonatomic, copy) NSString *customerNickName;

@property (nonatomic, assign) NSInteger sort;

@property (nonatomic, copy) NSString *delTime;

@property (nonatomic, copy) NSString *publishIp;

@property (nonatomic, copy) NSString *customerId;

@property (nonatomic, copy) NSString *atticCommentId;
//id ->idField
@property (nonatomic, copy) NSString *idField;

@property (nonatomic, assign) NSInteger fabulousNumber;

@property (nonatomic, assign) NSInteger commentFloor;

@property (nonatomic, copy) NSString *customerImgUrl;

@property (nonatomic, copy) NSString *parentId;

@property (nonatomic, copy) NSString *publishTime;

@property (nonatomic, copy) NSString *statusFlag;

@property (nonatomic, copy) NSString *commentTypeCode;

@property (nonatomic, copy) NSString *replayId;

@property (nonatomic, copy) NSString *equipmentSource;

@property(nonatomic, strong) NSString *delFlag;

@property(nonatomic, strong) NSString *shieldFlag;

@end

