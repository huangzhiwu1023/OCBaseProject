//
//  YFVideoCommentModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/4/11.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFVideoCommentModel.h"

@implementation YFVideoCommentModel

@end
@implementation YFVideoComentE

@end


@implementation YFVideoComentData

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"sendData" : [YFVideoComentSenddata class]};
}

@end


@implementation YFVideoComentSenddata

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"childrenList" : [YFVideoComentChildrenlist class]};
}

+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"idField": @"id"};
}

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation YFVideoComentChildrenlist
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"idField": @"id"};
}

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


