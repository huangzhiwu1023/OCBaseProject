//
//  YFVideoListRootModel.h
//  jsyf_user
//
//  Created by 黄志武 on 2018/4/9.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFVideoListRootModel : NSObject
@property (nonatomic, strong) NSString * createdBy;
@property (nonatomic, assign) NSInteger createdTime;
@property (nonatomic, strong) NSString * descriptionField;
@property (nonatomic, assign) NSInteger disc;
@property (nonatomic, strong) NSString * isDel;
@property (nonatomic, strong) NSString * modifyBy;
@property (nonatomic, strong) NSString * modifyTime;
@property (nonatomic, strong) NSString * paramCode;
@property (nonatomic, strong) NSString * paramId;
@property (nonatomic, strong) NSString * paramName;
@property (nonatomic, strong) NSString * parentId;
@property (nonatomic, strong) NSString * status;

@end
