//
//  YFVideoListRootModel.m
//  jsyf_user
//
//  Created by 黄志武 on 2018/4/9.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFVideoListRootModel.h"

@implementation YFVideoListRootModel
MJExtensionCodingImplementation
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end
