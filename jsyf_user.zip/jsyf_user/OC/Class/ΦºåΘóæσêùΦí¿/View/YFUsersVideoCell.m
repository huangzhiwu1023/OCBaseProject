//
//  YFUsersVideoCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFUsersVideoCell.h"


@implementation YFCycleCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        self.contentLB = [[UILabel alloc] init];
        [self.contentView addSubview:self.contentLB];
        [self.contentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        self.contentLB.textColor = [UIColor whiteColor];
        self.contentLB.font = [UIFont systemFontOfSize:10];
    }
    return self;
}
@end

@implementation YFUsersVideoCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self picIV];
        [self headIV];
        [self nameLB];
        [self commentCountLB];
        [self commentIcon];
        [self playCountLB];
        [self playIcon];
        [self titleLB];
        [self cycleView];
    }
    return self;
}

- (UIImageView *)picIV {
    if (!_picIV) {
        _picIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_picIV];
        [_picIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        _picIV.clipsToBounds = YES;
        _picIV.contentMode = UIViewContentModeScaleAspectFill;
        _picIV.clipsToBounds = YES;
        _picIV.layer.cornerRadius = 2;
    }
    return _picIV;
}

- (UIImageView *)headIV {
    if (!_headIV) {
        _headIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_headIV];
        [_headIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(8);
            make.bottom.equalTo(-8);
            make.width.height.equalTo(22);
        }];
        _headIV.clipsToBounds = YES;
        _headIV.layer.cornerRadius = 11;
        _headIV.contentMode = UIViewContentModeScaleAspectFill;
    }
    return _headIV;
}


- (UILabel *)nameLB {
    if (!_nameLB) {
        _nameLB = [[UILabel alloc] init];
        [self.contentView addSubview:_nameLB];
        [_nameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.headIV.mas_right).equalTo(4);
            make.right.equalTo(self.playIcon.mas_left).equalTo(-2);
            make.centerY.equalTo(self.headIV);
        }];
        _nameLB.font = [UIFont systemFontOfSize:10];
        _nameLB.textColor = mHexColor(0xFFFFFF);
    }
    return _nameLB;
}

- (UILabel *)commentCountLB {
    if (!_commentCountLB) {
        _commentCountLB = [[UILabel alloc] init];
        [self.contentView addSubview:_commentCountLB];
        [_commentCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-2);
            make.centerY.equalTo(self.nameLB);
            make.width.equalTo(25);
        }];
        _commentCountLB.font = [UIFont systemFontOfSize:9];
        _commentCountLB.textColor = mHexColor(0xFFFFFF);
    }
    return _commentCountLB;
}

- (UIImageView *)commentIcon {
    if (!_commentIcon) {
        _commentIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"回复人数小"]];
        [self.contentView addSubview:_commentIcon];
        [_commentIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.commentCountLB.mas_left).equalTo(-4);
            make.centerY.equalTo(self.commentCountLB);
            make.width.height.equalTo(11);
        }];
         _commentIcon.contentMode = UIViewContentModeCenter;
    }
    return _commentIcon;
}

- (UILabel *)playCountLB {
    if (!_playCountLB) {
        _playCountLB = [[UILabel alloc] init];
        [self.contentView addSubview:_playCountLB];
        [_playCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.commentIcon.mas_left).equalTo(-2);
            make.centerY.equalTo(self.commentCountLB);
            make.width.equalTo(25);
            
        }];
        _playCountLB.font = [UIFont systemFontOfSize:9];
        _playCountLB.textColor = mHexColor(0xFFFFFF);
    }
    return _playCountLB;
}

- (UIImageView *)playIcon {
    if (!_playIcon) {
        _playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放数量小"]];
        [self.contentView addSubview:_playIcon];
        [_playIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.playCountLB.mas_left).equalTo(-4);
            make.centerY.equalTo(self.commentCountLB);
            make.width.height.equalTo(11);
        }];
        _playIcon.contentMode = UIViewContentModeCenter;
    }
    return _playIcon;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(8);
            make.bottom.equalTo(self.headIV.mas_top).equalTo(-8);
            make.right.equalTo(-20);
        }];
        _titleLB.textColor = mHexColor(0xFFFFFF);
        _titleLB.font = [UIFont systemFontOfSize:11];
    }
    return _titleLB;
}
- (KBCycleScrollView *)cycleView {
    if (!_cycleView) {

        _cycleView = [KBCycleScrollView cycleScrollViewWithFrame:CGRectZero shouldInfiniteLoop:YES count:0];
        [self.contentView addSubview:_cycleView];
        [_cycleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.titleLB.mas_top).equalTo(-6);
            make.left.equalTo(8);
            make.right.equalTo(-8);
            make.height.equalTo(16);
        }];
        _cycleView.delegate = self;
        _cycleView.autoScrollTimeInterval = 2;
        _cycleView.scrollDirection = UICollectionViewScrollDirectionVertical;
        _cycleView.infiniteLoop = YES;
        _cycleView.itemSize = CGSizeMake(mScreenWidth - 16, 16);
        _cycleView.backgroundColor = [UIColor clearColor];
        [_cycleView registerCellClass:[YFCycleCell class] identifier:@"YFCycleCell"];
    }
    return _cycleView;
}

- (UICollectionViewCell *)cycleScrollView:(KBCycleScrollView *)cycleScrollView index:(NSInteger)index collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    YFCycleCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFCycleCell" forIndexPath:indexPath];
    DiscussList *model = self.discussList[index];
    
    cell.contentLB.text = [NSString stringWithFormat:@"%@:%@",model.customerNickName,model.commentCountnet];
    return cell;
    
}

- (NSMutableArray *)discussList{
    if (!_discussList) {
        _discussList = [NSMutableArray array];
    }
    return _discussList;
}

@end
