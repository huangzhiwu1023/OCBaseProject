//
//  YFCommonVideoCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFCommonVideoCell.h"

@implementation YFFirstVideoCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self picIV];
        [self titleLB];
//        [self commentCountLB];
//        [self commentIcon];
        [self playCountLB];
        [self playIcon];
    }
    return self;
}

- (UIImageView *)picIV {
    if (!_picIV) {
        _picIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_picIV];
        [_picIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.equalTo(0);
            make.bottom.equalTo(0);
        }];
        _picIV.clipsToBounds = YES;
        _picIV.contentMode = UIViewContentModeScaleAspectFill;
        
        UIImageView *play = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放按钮大"]];
        [_picIV addSubview:play];
        [play mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
        }];
    }
    return _picIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(8);
            make.bottom.equalTo(self.picIV.mas_bottom).equalTo(-8);
            make.right.equalTo(self.playIcon.mas_left).equalTo(-10);
        }];
        _titleLB.textColor = mHexColor(0xFFFFFF);
        _titleLB.font = [UIFont systemFontOfSize:14];
    }
    return _titleLB;
}

//- (UILabel *)commentCountLB {
//    if (!_commentCountLB) {
//        _commentCountLB = [[UILabel alloc] init];
//        [self.contentView addSubview:_commentCountLB];
//        [_commentCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(-2);
//            make.centerY.equalTo(self.titleLB);
//            make.width.equalTo(30);
//        }];
//        _commentCountLB.font = [UIFont systemFontOfSize:12];
//        _commentCountLB.textColor = mHexColor(0xFFFFFF);
//    }
//    return _commentCountLB;
//}
//
//- (UIImageView *)commentIcon {
//    if (!_commentIcon) {
//        _commentIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"回复人数大"]];
//        [self.contentView addSubview:_commentIcon];
//        [_commentIcon mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(self.commentCountLB.mas_left).equalTo(-3);
//            make.centerY.equalTo(self.commentCountLB);
//            make.width.height.equalTo(15);
//        }];
//        _commentIcon.contentMode = UIViewContentModeCenter;
//    }
//    return _commentIcon;
//}

- (UILabel *)playCountLB {
    if (!_playCountLB) {
        _playCountLB = [[UILabel alloc] init];
        [self.contentView addSubview:_playCountLB];
        [_playCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(self.commentIcon.mas_left).equalTo(-2);
            make.right.equalTo(-2);
//            make.centerY.equalTo(self.commentCountLB);
            make.centerY.equalTo(self.titleLB);
            make.width.equalTo(30);
        }];
        _playCountLB.font = [UIFont systemFontOfSize:12];
        _playCountLB.textColor = mHexColor(0xFFFFFFF);
    }
    return _playCountLB;
}

- (UIImageView *)playIcon {
    if (!_playIcon) {
        _playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放数量大"]];
        [self.contentView addSubview:_playIcon];
        [_playIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.playCountLB.mas_left).equalTo(-3);
            make.centerY.equalTo(self.playCountLB);
            make.width.height.equalTo(15);
        }];
       _playIcon.contentMode = UIViewContentModeCenter;
    }
    return _playIcon;
}

@end


@implementation YFCommonVideoCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor clearColor];
        [self picIV];
        [self titleLB];
//        [self commentCountLB];
//        [self commentIcon];
        [self playCountLB];
        [self playIcon];
        
        self.contentView.layer.cornerRadius = 2;
        self.contentView.layer.masksToBounds = YES;
        //阴影
//        self.layer.shadowColor = mHexColorAlpha(0x333333, 0.5).CGColor;
//        self.layer.shadowOffset = CGSizeMake(0.5, 0.5);
//        self.layer.shadowOpacity = 0.5;
//        self.layer.shadowRadius = 1.0;
        
        
    }
    return self;
}

- (UIImageView *)bgView {
    if (!_bgView) {
        _bgView = [UIImageView new];
        _bgView.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:_bgView];
        [_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        //阴影图片
        _bgView.image = [UIImage imageNamed:@"视频列表页面阴影"];
        
    }
    return _bgView;
}

- (UIImageView *)picIV {
    if (!_picIV) {
        _picIV = [[UIImageView alloc] init];
        [self.bgView addSubview:_picIV];
        [_picIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.equalTo(0);
            make.bottom.equalTo(-45);
        }];
        _picIV.clipsToBounds = YES;
        _picIV.contentMode = UIViewContentModeScaleAspectFill;
        
        UIImageView *play = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放按钮小"]];
        [_picIV addSubview:play];
        [play mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
        }];
    }
    return _picIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
       
        _titleLB = [[UILabel alloc] init];
        [self.bgView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(8);
            make.top.equalTo(self.picIV.mas_bottom).equalTo(6);
            make.right.equalTo(-8);
            make.height.equalTo(12);
        }];
        _titleLB.textColor = mHexColor(0x222222);
        _titleLB.font = [UIFont systemFontOfSize:12];
    }
    return _titleLB;
}

//- (UILabel *)commentCountLB {
//    if (!_commentCountLB) {
//        _commentCountLB = [[UILabel alloc] init];
//        [self.bgView addSubview:_commentCountLB];
//        [_commentCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(-2);
//            make.top.equalTo(self.titleLB.mas_bottom).equalTo(8);
//            make.width.equalTo(25);
//            make.height.equalTo(10);
//        }];
//        _commentCountLB.font = [UIFont systemFontOfSize:10];
//        _commentCountLB.textColor = mHexColor(0x757575);
//    }
//    return _commentCountLB;
//}
//
//- (UIImageView *)commentIcon {
//    if (!_commentIcon) {
//        _commentIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"回复灰"]];
//        [self.bgView addSubview:_commentIcon];
//        [_commentIcon mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(self.commentCountLB.mas_left).equalTo(-3);
//            make.centerY.equalTo(self.commentCountLB);
//            make.width.height.equalTo(11);
//        }];
//        _commentIcon.contentMode = UIViewContentModeCenter;
//    }
//    return _commentIcon;
//}

- (UILabel *)playCountLB {
    if (!_playCountLB) {
        _playCountLB = [[UILabel alloc] init];
        [self.bgView addSubview:_playCountLB];
        [_playCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(self.commentIcon.mas_left).equalTo(-2);
            make.right.equalTo(-2);
//            make.centerY.equalTo(self.commentCountLB);
            make.top.equalTo(self.titleLB.mas_bottom).equalTo(8);
            make.width.equalTo(25);
            make.height.equalTo(10);
        }];
        _playCountLB.font = [UIFont systemFontOfSize:10];
        _playCountLB.textColor = mHexColor(0x757575);
    }
    return _playCountLB;
}

- (UIImageView *)playIcon {
    if (!_playIcon) {
        _playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放灰"]];
        [self.bgView addSubview:_playIcon];
        [_playIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.playCountLB.mas_left).equalTo(-3);
            make.centerY.equalTo(self.playCountLB);
            make.width.height.equalTo(11);
        }];
        _playIcon.contentMode = UIViewContentModeCenter;
    }
    return _playIcon;
}



@end
