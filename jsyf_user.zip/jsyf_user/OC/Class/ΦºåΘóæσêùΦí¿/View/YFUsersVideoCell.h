//
//  YFUsersVideoCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YFUserVideoModel.h"

@interface YFCycleCell:UICollectionViewCell
@property(nonatomic, strong) UILabel *contentLB;
@end

@interface YFUsersVideoCell : UICollectionViewCell<KBCycleScrollViewDataSource,KBCycleScrollViewDelegate>
@property(nonatomic, strong) UIImageView *picIV;
@property(nonatomic, strong) UIImageView *headIV;
@property(nonatomic, strong) UILabel *nameLB;
@property(nonatomic, strong) UIImageView *playIcon;
@property(nonatomic, strong) UILabel *playCountLB;
@property(nonatomic, strong) UIImageView *commentIcon;
@property(nonatomic, strong) UILabel *commentCountLB;
@property(nonatomic, strong) UILabel *titleLB;
@property(nonatomic, strong) KBCycleScrollView *cycleView;
@property(nonatomic, strong) NSMutableArray *discussList;
@end
