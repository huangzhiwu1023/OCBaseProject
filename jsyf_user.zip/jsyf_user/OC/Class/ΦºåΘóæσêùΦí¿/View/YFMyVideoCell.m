//
//  YFMyVideoCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/19.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFMyVideoCell.h"

@implementation YFMyVideoCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self picIV];
        [self titleLB];
        [self commentCountLB];
        [self commentIcon];
        [self playCountLB];
        [self playIcon];
    }
    return self;
}

- (UIImageView *)picIV {
    if (!_picIV) {
        _picIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_picIV];
        [_picIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.equalTo(0);
            make.bottom.equalTo(0);
        }];
        _picIV.clipsToBounds = YES;
        _picIV.contentMode = UIViewContentModeScaleAspectFill;
        
        _picIV.layer.cornerRadius = 2;
        _picIV.clipsToBounds = YES;
        
        UIImageView *play = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放按钮大"]];
        [_picIV addSubview:play];
        [play mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
        }];
    }
    return _picIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(8);
            make.bottom.equalTo(self.picIV.mas_bottom).equalTo(-8);
            make.right.equalTo(self.playIcon.mas_left).equalTo(-10);
        }];
        _titleLB.textColor = mHexColor(0xFFFFFF);
        _titleLB.font = [UIFont systemFontOfSize:14];
    }
    return _titleLB;
}

- (UILabel *)commentCountLB {
    if (!_commentCountLB) {
        _commentCountLB = [[UILabel alloc] init];
        [self.contentView addSubview:_commentCountLB];
        [_commentCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-2);
            make.centerY.equalTo(self.titleLB);
            make.width.equalTo(30);
        }];
        _commentCountLB.font = [UIFont systemFontOfSize:12];
        _commentCountLB.textColor = mHexColor(0xFFFFFF);
    }
    return _commentCountLB;
}

- (UIImageView *)commentIcon {
    if (!_commentIcon) {
        _commentIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"回复人数大"]];
        [self.contentView addSubview:_commentIcon];
        [_commentIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.commentCountLB.mas_left).equalTo(-3);
            make.centerY.equalTo(self.commentCountLB);
            make.width.height.equalTo(15);
        }];
        _commentIcon.contentMode = UIViewContentModeCenter;
    }
    return _commentIcon;
}

- (UILabel *)playCountLB {
    if (!_playCountLB) {
        _playCountLB = [[UILabel alloc] init];
        [self.contentView addSubview:_playCountLB];
        [_playCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
        
            make.right.equalTo(self.commentIcon.mas_left).equalTo(-2);
            make.centerY.equalTo(self.commentCountLB);
            make.width.equalTo(30);
        }];
        _playCountLB.font = [UIFont systemFontOfSize:12];
        _playCountLB.textColor = mHexColor(0xFFFFFFF);
    }
    return _playCountLB;
}

- (UIImageView *)playIcon {
    if (!_playIcon) {
        _playIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放数量大"]];
        [self.contentView addSubview:_playIcon];
        [_playIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.playCountLB.mas_left).equalTo(-3);
            make.centerY.equalTo(self.commentCountLB);
            make.width.height.equalTo(15);
        }];
        _playIcon.contentMode = UIViewContentModeCenter;
    }
    return _playIcon;
}


@end
