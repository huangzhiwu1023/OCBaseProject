//
//  YFShortVideoCollectionCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/8.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFShortVideoCollectionCell.h"

@implementation YFShortVideoCollectionCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self coverIV];
        [self playIV];
        [self titleLB];
        [self lookLB];
        [self timeLB];
    }
    return self;
}

- (void)setModel:(YFUserVideoModel *)model {
    _model = model;
    [self.coverIV sd_setImageWithURL:model.coverPictureUrl.lx_URL placeholderImage:kPlaceholderImage];
    self.titleLB.text = model.videoTitle;
    self.lookLB.text = [NSString stringWithFormat:@"浏览数 %ld",model.playNumber];
    self.timeLB.text = [SysUtil getAppointTimeWithTimeStamp:model.modifyTime formatString:@"MM-dd"];
}

- (UIImageView *)coverIV {
    if (!_coverIV) {
        _coverIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_coverIV];
        [_coverIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.bottom.equalTo(-45);
        }];
        _coverIV.contentMode = UIViewContentModeScaleAspectFill;
        _coverIV.clipsToBounds = YES;
    }
    return _coverIV;
}

- (UIImageView *)playIV {
    if (!_playIV) {
        _playIV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"home_video"]];
        [self.coverIV addSubview:_playIV];
        [_playIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.bottom.equalTo(-10);
        }];
    }
    return _playIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(0);
            make.top.equalTo(self.coverIV.mas_bottom).equalTo(6);
            make.height.equalTo(13);
        }];
        _titleLB.font = kFont_system(13);
        _titleLB.textColor = k333Color;
    }
    return _titleLB;
}

- (UILabel *)lookLB {
    if (!_lookLB) {
        _lookLB = [[UILabel alloc] init];
        [self.contentView addSubview:_lookLB];
        [_lookLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.top.equalTo(self.titleLB.mas_bottom).equalTo(6);
            make.right.equalTo(self.mas_centerX);
            make.height.equalTo(12);
        }];
        _lookLB.font = kFont_system(12);
        _lookLB.textColor = k999Color;
    }
    return _lookLB;
}

- (UILabel *)timeLB {
    if (!_timeLB) {
        _timeLB = [[UILabel alloc] init];
        [self.contentView addSubview:_timeLB];
        [_timeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.mas_centerX);
            make.right.equalTo(0);
            make.centerY.equalTo(self.lookLB);
            
        }];
        _timeLB.textAlignment = NSTextAlignmentRight;
        _timeLB.font = kFont_system(12);
        _timeLB.textColor = k999Color;
    }
    return _timeLB;
}
@end
