//
//  YFShortVideoCollectionCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/8.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#

NS_ASSUME_NONNULL_BEGIN

@interface YFShortVideoCollectionCell : UICollectionViewCell
@property(nonatomic, strong) UIImageView *coverIV;
@property(nonatomic, strong) UIImageView *playIV;
@property(nonatomic, strong) UILabel *titleLB;
@property(nonatomic, strong) UILabel *lookLB;
@property(nonatomic, strong) UILabel *timeLB;

@property(nonatomic, strong) YFUserVideoModel *model;
@end

NS_ASSUME_NONNULL_END
