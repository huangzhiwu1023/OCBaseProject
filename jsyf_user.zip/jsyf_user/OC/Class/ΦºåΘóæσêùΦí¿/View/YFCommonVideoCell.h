//
//  YFCommonVideoCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFFirstVideoCell : UICollectionViewCell
@property(nonatomic, strong) UIImageView *picIV;
@property(nonatomic, strong) UILabel *titleLB;
@property(nonatomic, strong) UIImageView *playIcon;
@property(nonatomic, strong) UILabel *playCountLB;
@property(nonatomic, strong) UIImageView *commentIcon;
@property(nonatomic, strong) UILabel *commentCountLB;

@end

@interface YFCommonVideoCell : UICollectionViewCell
@property(nonatomic, strong) UIImageView *picIV;
@property(nonatomic, strong) UILabel *titleLB;
@property(nonatomic, strong) UIImageView *playIcon;
@property(nonatomic, strong) UILabel *playCountLB;
@property(nonatomic, strong) UIImageView *commentIcon;
@property(nonatomic, strong) UILabel *commentCountLB;

@property(nonatomic, strong) UIImageView *bgView;
@end
