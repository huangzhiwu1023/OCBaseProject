//
//  YFPlayerCommentView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/4.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFPlayerCommentView : UIView
- (instancetype)initWithFrame:(CGRect)frame withVideoID:(NSString *)videoID isForum:(BOOL)isForum isStore:(BOOL)isStore;
@property(nonatomic, strong) NSString *videoID;
@property(nonatomic, assign) BOOL isForum;
@property(nonatomic, assign) BOOL isStore;
@end
