
#import <UIKit/UIKit.h>

#import "YFUserVideoModel.h"
typedef void(^deleteSuccessBlock)(void);

@interface YFPlayVC : UIViewController
@property (nonatomic , assign) BOOL whenBackIsNeedhiddenBottomBar;
@property (nonatomic , strong) NSString* videoUrl;
@property (nonatomic , strong) NSString* vPictureUrl;
@property (nonatomic , strong) YFUserVideoModel *model;
//是否可以删除
@property(nonatomic, assign) BOOL isDelete;

@property(nonatomic, copy) deleteSuccessBlock deleteSuccess;

@end
