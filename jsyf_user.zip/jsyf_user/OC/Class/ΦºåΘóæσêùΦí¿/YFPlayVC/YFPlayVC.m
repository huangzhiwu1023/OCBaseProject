//

#import "YFPlayVC.h"
#import "WMPlayer.h"
#import "SDImageCache.h"
#import "SDImageCache.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"
#import <CommonCrypto/CommonCryptor.h>
#import <Security/SecRandom.h>
#import "UIImageView+WebCache.h"
#import <AVFoundation/AVFoundation.h>
#import "YFPlayerCommentView.h"
#import "LPActionSheet.h"

#define iphone6Scale(x) (([UIScreen mainScreen].bounds.size.width)/375.00 * x)

#define MAX_STARWORDS_LENGTH 50

#define ScreenHeight [UIScreen mainScreen].bounds.size.height

#define ScreenWidth [UIScreen mainScreen].bounds.size.width
//评论字数限制
#define maxNum 140


@interface YFPlayVC ()<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate> {
}
@property (nonatomic,strong) UITableView* mainTableView;
@property (nonatomic,strong) WMPlayer* wmPlayer;


@property (nonatomic,strong) UIView* commentsTextFieldBar;

@property (nonatomic,strong) UITextView* commentsTextField;

@property (nonatomic,strong) UIButton* sendCommentsBtn;

@property (nonatomic,strong) UIVisualEffectView *visualEffectView;

@property (nonatomic,strong) NSMutableArray* commentsMutableAry;

@property (nonatomic, strong) UIImageView* iconImgeView;


@property (nonatomic, strong) UIImageView* zhanImgView;

@property(nonatomic, strong) UIButton *coverBtn;


@property (nonatomic, strong) UILabel *shareLabel,*zhanLabel,*commentLabel;

@property (nonatomic, assign) BOOL isZhan;

@property(nonatomic, strong) UIView *headerView;

@property(nonatomic, strong) UIImageView *playIV;
@property(nonatomic, strong) UIView *maskView;
@end

@implementation YFPlayVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    if (_wmPlayer.state == WMPlayerStatePlaying) {
        [_wmPlayer pause];
        self.playIV.hidden = NO;
    }
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
//    [_wmPlayer play];  //调两次就是暂停
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    _commentsMutableAry = [NSMutableArray array];
    [self createTableView];
    [self createBottomInfoView];
    [self createCustomNavBar];
    [self palyAddOne];
    //创建输入框
    [self createCommentsTextFieldBar];
    
    [self.view setNeedsLayout]; //更新视图
    [self.view layoutIfNeeded];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finishPlayer) name:WMPlayerFinishedPlayNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickOneWMPlayer) name:WMPlayerSingleTapNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrameNotification:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHideNotification:) name:UIKeyboardWillHideNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showkeyboard) name:@"showKeyboard" object:nil];
    [self.mainTableView reloadData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(commentVideoSuccess) name:@"commentVideoSuccess" object:nil];
}


- (void)createTableView{
    _mainTableView = [[UITableView alloc] init];
    _mainTableView.showsVerticalScrollIndicator = NO;
    _mainTableView.delegate = self;
    _mainTableView.dataSource = self;
    _mainTableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    _mainTableView.scrollEnabled = NO;
    [self.view addSubview:_mainTableView];
    [_mainTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self.view);
        make.bottom.equalTo(self.view)/*.offset(-44)*/;
    }];
    // 为了让tableView自适应高度设置如下两个属性
    _mainTableView.estimatedRowHeight = 30;
    _mainTableView.rowHeight = UITableViewAutomaticDimension;
    self.headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    _mainTableView.tableHeaderView = self.headerView;
    self.headerView.backgroundColor = [UIColor blackColor];


    UIImageView* wmPlayerBgImgView = [[UIImageView alloc] init];
    wmPlayerBgImgView.contentMode = UIViewContentModeScaleAspectFit;
    [wmPlayerBgImgView setClipsToBounds:YES];
    [self.headerView addSubview:wmPlayerBgImgView];
    [wmPlayerBgImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.equalTo(self.headerView);
    }];
    [wmPlayerBgImgView sd_setImageWithURL:[NSURL URLWithString: self.vPictureUrl] placeholderImage:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"usericon02" ofType:@"png"]]];

    _wmPlayer  = [[WMPlayer alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) videoURLStr:self.videoUrl];
    [self.headerView addSubview:_wmPlayer];
    _wmPlayer.closeBtn.hidden = YES;
    _wmPlayer.bottomView.hidden = YES;
    _wmPlayer.fullScreenBtn.hidden = YES;
//    _wmPlayer.backgroundColor = [UIColor clearColor];
    [_wmPlayer play];
    
}
- (void)createCustomNavBar{
    UIButton* backBtn = [[UIButton alloc] init];
    [backBtn setImage:[UIImage imageNamed:@"小视频返回"] forState:UIControlStateNormal];
    [self.view addSubview:backBtn];
//    backBtn.imageEdgeInsets = UIEdgeInsetsMake(5, 5, 5, 5);
    [backBtn addTarget:self action:@selector(clickBackBtn) forControlEvents:UIControlEventTouchUpInside];
    [backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(30);
        make.left.equalTo(self.view).offset(16);
        make.width.height.equalTo(@(40));
    }];
    
    UIButton *deleteBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:deleteBtn];
    [deleteBtn setImage:[UIImage imageNamed:@"删除视频按钮"] forState:UIControlStateNormal];
    [deleteBtn addTarget:self action:@selector(clickDeleteBtn:) forControlEvents:UIControlEventTouchUpInside];
    [deleteBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(30);
        make.right.equalTo(self.view).offset(-16);
        make.width.height.equalTo(@(40));
    }];
    deleteBtn.hidden = !(self.isDelete);
    
    
    self.playIV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"播放页播放按钮"]];
    [self.view addSubview:self.playIV];
    [self.playIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(0);
    }];
    self.playIV.hidden = YES;
}

- (void)createBottomInfoView {
  
    UIView* headerViewBottomBar = [[UIView alloc] init];
    headerViewBottomBar.backgroundColor = [UIColor clearColor];
    [self.headerView addSubview:headerViewBottomBar];
    [headerViewBottomBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.equalTo(self.headerView);
        make.height.equalTo(@(iphone6Scale(46)));
    }];
    
    
    UIImageView* commentImgView = [[UIImageView alloc] init];
    commentImgView.image = [UIImage imageNamed:@"播放页回复图标"];
    commentImgView.userInteractionEnabled = YES;
    [headerViewBottomBar addSubview:commentImgView];
    [commentImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(headerViewBottomBar);
//        make.centerX.equalTo(headerViewBottomBar);
        make.left.equalTo(headerViewBottomBar.mas_centerX);
        make.width.height.equalTo(@(iphone6Scale(22)));
    }];
//    commentImgView.contentMode = UIViewContentModeCenter;
    UITapGestureRecognizer* tapGesturecommentImg = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickcommentImgView)];
    [commentImgView addGestureRecognizer:tapGesturecommentImg];
   
    
//    _shareLabel = [[UILabel alloc] init];
//    _shareLabel.textColor = [UIColor whiteColor];
//    _shareLabel.textAlignment = NSTextAlignmentRight;
//    _shareLabel.font = [UIFont systemFontOfSize:11];
//    _shareLabel.text = [NSString stringWithFormat:@"%ld",self.model.discussCount];;
//    [headerViewBottomBar addSubview:_shareLabel];
//    [_shareLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.right.equalTo(headerViewBottomBar).offset(-20);
//        make.centerY.equalTo(commentImgView);
//    }];
    
    UIImageView* shareImgView = [[UIImageView alloc] init];
    shareImgView.image = [UIImage imageNamed:@"播放页分享图标"];
    shareImgView.userInteractionEnabled = YES;
    [headerViewBottomBar addSubview:shareImgView];
    [shareImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(commentImgView);
//        make.right.equalTo(_shareLabel.mas_left).offset(-6);
        make.right.equalTo(-16);
        make.width.height.equalTo(@(iphone6Scale(22)));
    }];
    UITapGestureRecognizer* tapGestureShareImg = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickShare3rdBtn)];
    [shareImgView addGestureRecognizer:tapGestureShareImg];
    
    
    _zhanImgView = [[UIImageView alloc] init];
    _zhanImgView.image = [UIImage imageNamed:@"播放页点赞图标"];
    if (self.model.praiseFlag) {
        _zhanImgView.image = [UIImage imageNamed:@"已点赞"];
    }
    _zhanImgView.userInteractionEnabled = YES;
    [headerViewBottomBar addSubview:_zhanImgView];
    [_zhanImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(commentImgView);
        make.centerX.equalTo(headerViewBottomBar).offset(ScreenWidth/4-8);
        make.width.height.equalTo(@(iphone6Scale(22)));
    }];
    _isZhan = NO;
    UITapGestureRecognizer* tapGestureZhanImg = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickZhanBtn)];
    [_zhanImgView addGestureRecognizer:tapGestureZhanImg];
    
    //做点赞动画的小星星
    _coverBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [headerViewBottomBar insertSubview:_coverBtn belowSubview:_zhanImgView];
    [_coverBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(commentImgView);
        make.centerX.equalTo(headerViewBottomBar).offset(ScreenWidth/4-8);
        make.width.height.equalTo(@(iphone6Scale(22)));
    }];
    _coverBtn.alpha = 0;
    [_coverBtn setImage:[UIImage imageNamed:@"已点赞"] forState:UIControlStateSelected];
    [_coverBtn setImage:[UIImage imageNamed:@"已点赞"] forState:UIControlStateNormal];
    
    
    _commentLabel = [[UILabel alloc] init];
    _commentLabel.textColor = [UIColor whiteColor];
    _commentLabel.textAlignment = NSTextAlignmentLeft;
    _commentLabel.font = [UIFont systemFontOfSize:11];
    _commentLabel.text = [NSString stringWithFormat:@"%ld",self.model.discussCount];
    [headerViewBottomBar addSubview:_commentLabel];
    [_commentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(commentImgView);
        make.left.equalTo(commentImgView.mas_right).offset(6);
        make.right.equalTo(_zhanImgView.mas_left).equalTo(-6);
    }];
    
    _zhanLabel = [[UILabel alloc] init];
    _zhanLabel.textColor = [UIColor whiteColor];
    _zhanLabel.textAlignment = NSTextAlignmentLeft;
    _zhanLabel.font = [UIFont systemFontOfSize:11];
    _zhanLabel.text = [NSString stringWithFormat:@"%ld",self.model.likeNumber];
    [headerViewBottomBar addSubview:_zhanLabel];
    [_zhanLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_zhanImgView.mas_right).offset(2);
        make.centerY.equalTo(commentImgView);
        make.right.equalTo(shareImgView.mas_left).equalTo(-6);
    }];
    
    UIView* writeBgView = [[UIView alloc] init];
    writeBgView.backgroundColor = [UIColor whiteColor];
    writeBgView.alpha = 0.4;
    [headerViewBottomBar addSubview:writeBgView];
    [writeBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(headerViewBottomBar);
        make.height.equalTo(@(30));
        make.width.equalTo(@(ScreenWidth/2 - 32 -12));
        make.left.equalTo(headerViewBottomBar).offset(16);
        
    }];
    writeBgView.layer.masksToBounds = true;
    writeBgView.layer.cornerRadius = 15;
    
    UITapGestureRecognizer* tapGesture2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickSendComment)];
    [writeBgView addGestureRecognizer:tapGesture2];
    
    UILabel* writeComment = [[UILabel alloc] init];
    writeComment.backgroundColor = [UIColor clearColor];
    writeComment.textColor = [UIColor whiteColor];
    writeComment.textAlignment = NSTextAlignmentLeft;
    writeComment.font = [UIFont systemFontOfSize:14];
    writeComment.text = @"发表评论...";
    [headerViewBottomBar addSubview:writeComment];
    [writeComment mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(commentImgView);
        make.left.equalTo(writeBgView).offset(10);
    }];
    
    UILabel *desLB = [[UILabel alloc] init];
    [self.view addSubview:desLB];
    desLB.numberOfLines = 0;
    desLB.textColor = [UIColor whiteColor];
    desLB.font = [UIFont systemFontOfSize:12];
    [desLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(headerViewBottomBar.mas_top).equalTo(-24);
        make.left.equalTo(16);
        make.right.equalTo(-80);
    }];
    desLB.text = self.model.videoContent;
    
    UILabel *titleLB = [[UILabel alloc] init];
    [self.view addSubview:titleLB];
    titleLB.textColor = [UIColor whiteColor];
    titleLB.font = [UIFont boldSystemFontOfSize:14];
    [titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(desLB.mas_top).equalTo(-12);
        make.left.equalTo(16);
        make.right.equalTo(-80);
    }];
    titleLB.text = self.model.videoTitle;;
    
    UIImageView *headIV = [[UIImageView alloc] init];
    [self.view addSubview:headIV];
    headIV.contentMode = UIViewContentModeScaleAspectFill;
    headIV.layer.cornerRadius = 22;
    headIV.clipsToBounds = YES;
    [headIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(16);
        make.bottom.equalTo(titleLB.mas_top).equalTo(-12);
        make.width.height.equalTo(44);
    }];
   [headIV sd_setImageWithURL:[NSURL URLWithString:self.model.customerImgUrl] placeholderImage:[UIImage imageNamed:@"user_default"]];
    
    UILabel *nameLB = [[UILabel alloc] init];
    [self.view addSubview:nameLB];
    nameLB.textColor = [UIColor whiteColor];
    nameLB.font = [UIFont boldSystemFontOfSize:16];
    [nameLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(headIV.mas_right).equalTo(8);
        make.centerY.equalTo(headIV);
        make.right.equalTo(-80);
    }];
    nameLB.text = self.model.customerNickName;
    
}

-(void)createCommentsTextFieldBar{
    _commentsTextFieldBar = [[UIView alloc] init];
    _commentsTextFieldBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_commentsTextFieldBar];
    [_commentsTextFieldBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.view);
        make.height.equalTo(@(53));
        make.bottom.equalTo(self.view).offset(53);
    }];
    
    _sendCommentsBtn = [[UIButton alloc] init];
    [_sendCommentsBtn setTitle:@"发送" forState:UIControlStateNormal];
    [_sendCommentsBtn setTitleColor:mHexColor(0x333333) forState:UIControlStateNormal];
    [_sendCommentsBtn setBackgroundColor:kYellowColor];
    [_sendCommentsBtn.titleLabel setFont:[UIFont systemFontOfSize:14]];
    [_sendCommentsBtn addTarget:self action:@selector(clicksendCommentsBtn:) forControlEvents:UIControlEventTouchUpInside];
    [_commentsTextFieldBar addSubview:_sendCommentsBtn];
    _sendCommentsBtn.enabled = YES;
    [_sendCommentsBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_commentsTextFieldBar).offset(-20);
        make.centerY.equalTo(0);
        make.height.equalTo(26);
        make.width.equalTo(@(46));
    }];
    _sendCommentsBtn.layer.masksToBounds = true;
    _sendCommentsBtn.layer.cornerRadius = 2;
    
    
    _commentsTextField = [[UITextView alloc] init];
    _commentsTextField.returnKeyType = UIReturnKeyDone;
    //    _commentsTextField.borderStyle = UITextBorderStyleNone;
    //    _commentsTextField.returnKeyType = UIReturnKeySend;
    _commentsTextField.backgroundColor = [UIColor clearColor];
    _commentsTextField.font = [UIFont systemFontOfSize:14];
//    _commentsTextField.placeholder = @"写评论...";
    [self setupTextView];
    _commentsTextField.delegate = self;
    [_commentsTextFieldBar addSubview:_commentsTextField];
    [_commentsTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(_commentsTextFieldBar).offset(10);
        make.bottom.equalTo(_commentsTextFieldBar).offset(-10);
        make.right.equalTo(_sendCommentsBtn.mas_left).offset(-15);
    }];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];//选中后的反显颜色即刻消失
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    // 若为UITableViewCellContentView（即点击了tableViewCell），则不截获Touch事件
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        return NO;
    }
    
    return  YES;
}



//键盘弹出
- (void)keyboardWillChangeFrameNotification:(NSNotification *)notification {
    // 获取键盘基本信息（动画时长与键盘高度）
    NSDictionary *userInfo = [notification userInfo];
    if (!userInfo) {
        return;
    }
    
    CGSize kbSize = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;//得到鍵盤的高度
    CGFloat keyboardDuration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    // 修改下边距约束
    
    [_commentsTextFieldBar mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view).offset(-kbSize.height);
    }];
    
    // 更新约束
    [UIView animateWithDuration:keyboardDuration animations:^{
        [self.view layoutIfNeeded];
    }];
    
}

- (void)keyboardWillHideNotification:(NSNotification *)notification {
    // 获得键盘动画时长
    NSDictionary *userInfo   = [notification userInfo];
    if (!userInfo) {
        return;
    }
    CGFloat keyboardDuration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    CGFloat barHeight = _commentsTextFieldBar.frame.size.height;
    // 修改为以前的约束（距下边距0）
    [_commentsTextFieldBar mas_updateConstraints:^(MASConstraintMaker *make) {
        if (_mainTableView.contentOffset.y > barHeight) {
            make.bottom.equalTo(self.view).offset(0);
        }
        else
        {
            make.bottom.equalTo(self.view).offset(barHeight - _mainTableView.contentOffset.y);
        }
        
    }];
    
    // 更新约束
    [UIView animateWithDuration:keyboardDuration animations:^{
        [self.view layoutIfNeeded];
    }];
//    _commentsTextField.placeholder = @"写评论...";
}

//pragma mark - UITextView代理
-(void)textViewDidChange:(UITextView *)textView {
    // 1.计算textView的高度
    CGFloat textViewH = 0;
    CGFloat minHeight = 33; // textView最小的高度
    CGFloat maxHeight = 36; // textView最大的高度
    // 获取contentSize 的高度
    CGFloat contentHeight = textView.contentSize.height;
    
    if (contentHeight <= minHeight) {
        textViewH = minHeight;
//        [textView setContentInset:UIEdgeInsetsZero];
    } else if (contentHeight > maxHeight) {
        textViewH = maxHeight;
//        [textView setContentInset:UIEdgeInsetsMake(-5, 0, -3.5, 0)];
    } else {
        textViewH = contentHeight;
//        [textView setContentInset:UIEdgeInsetsMake(-4.5, 0, -4.5, 0)];
    }
    [self.commentsTextFieldBar mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(textViewH + 20);
    }];
    // 更新约束
    [UIView animateWithDuration:0.25 animations:^{
        [self.view layoutIfNeeded];
    }];

    //字数限制
    NSInteger value=textView.text.length;
    //高亮不进入统计 避免未输入的中文在拼音状态被统计入总长度限制
    value -= [textView textInRange:[textView markedTextRange]].length;
    if (value<=maxNum) {
    } else {
        //截断长度限制以后的字符 避免截断字符
        NSString *tempStr = [textView.text substringWithRange:[textView.text rangeOfComposedCharacterSequencesForRange:NSMakeRange(0, maxNum)]];
        textView.text=tempStr;
    }
    
    
}



- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([@"\n" isEqualToString:text] == YES) {
        [textView resignFirstResponder];
        return NO;
    }
    UITextRange *selectedRange = [textView markedTextRange];
    //获取高亮部分
    UITextPosition *pos = [textView positionFromPosition:selectedRange.start offset:0];
    //获取高亮部分内容
    //NSString * selectedtext = [textView textInRange:selectedRange];
    //如果有高亮且当前字数开始位置小于最大限制时允许输入
    if (selectedRange && pos) {
        NSInteger startOffset = [textView offsetFromPosition:textView.beginningOfDocument toPosition:selectedRange.start];
        NSInteger endOffset = [textView offsetFromPosition:textView.beginningOfDocument toPosition:selectedRange.end];
        NSRange offsetRange = NSMakeRange(startOffset, endOffset - startOffset);
        
        if (offsetRange.location < maxNum) {
            return YES;
        }
        else {
            return NO;
        }
    }
    
    NSString *comcatstr = [textView.text stringByReplacingCharactersInRange:range withString:text];
    NSInteger caninputlen = maxNum - comcatstr.length;
    if (caninputlen >= 0) {
        return YES;
    }
    else {
        NSInteger len = text.length + caninputlen;
        //防止当text.length + caninputlen < 0时，使得rg.length为一个非法最大正数出错
        NSRange rg = {0,MAX(len,0)};
        NSLog(@"rg==%ld", rg.length);
        if (rg.length > 0) {
            NSString *s = @"";
            //判断是否只普通的字符或asc码(对于中文和表情返回NO)
            BOOL asc = [text canBeConvertedToEncoding:NSASCIIStringEncoding];
            if (asc) {
                s = [text substringWithRange:rg];//因为是ascii码直接取就可以了不会错
            }
            else {
                __block NSInteger idx = 0;
                __block NSString  *trimString = @"";//截取出的字串
                //使用字符串遍历，这个方法能准确知道每个emoji是占一个unicode还是两个
                [text enumerateSubstringsInRange:NSMakeRange(0, [text length])
                                         options:NSStringEnumerationByComposedCharacterSequences
                                      usingBlock: ^(NSString* substring, NSRange substringRange, NSRange enclosingRange, BOOL* stop) {
                                          
                                          NSInteger steplen = substring.length;
                                          
                                          if (idx >= rg.length) {
                                              *stop = YES; //取出所需要就break，提高效率
                                              
                                              return ;
                                          }
                                          
                                          trimString = [trimString stringByAppendingString:substring];
                                          
                                          //                                          idx++;
                                          idx = idx + steplen;//这里变化了，使用了字串占的长度来作为步长
                                      }];
                
                s = trimString;
            }
            //rang是指从当前光标处进行替换处理(注意如果执行此句后面返回的是YES会触发didchange事件)
            [textView setText:[textView.text stringByReplacingCharactersInRange:range withString:s]];
            //既然是超出部分截取了，哪一定是最大限制了。
        }
        return NO;
    }
}
//删除视频
- (void)clickDeleteBtn:(UIButton *)sender {
    UIAlertController * alertC =  [UIAlertController alertControllerWithTitle:@"友情提示" message:@"确认删除?" preferredStyle:1];
    UIAlertAction * confimAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        sender.enabled = NO;
        //调用删除接口
        NSDictionary *bodyDic = @{@"videoId" : self.model.videoId};
        [[[ESNetworkManager deleteVideo:bodyDic] map:^id(id value) {
            return value;
        }] subscribeNext:^(id  _Nullable x) {
            sender.enabled = YES;
            !_deleteSuccess ?: _deleteSuccess();
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshFriendVideo" object:nil];
            [self.navigationController popViewControllerAnimated:YES];
        } error:^(NSError * _Nullable error) {
            sender.enabled = YES;
            [self.view showWarning:error.localizedDescription];
        }];
    }];
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alertC addAction:confimAction];
    [alertC addAction:cancelAction];
    [self presentViewController:alertC animated:YES completion:nil];
}

- (void)clickBackBtn {
    [self releaseWMPlayer];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) finishPlayer {
    [_wmPlayer play];
}

- (void)clickOneWMPlayer {
//    WMPlayerStateFailed,     // 播放失败
//    WMPlayerStateBuffering,  // 缓冲中
//    WMPlayerStatePlaying,    // 播放中
//    WMPlayerStateStopped,    // 停止播放
//    WMPlayerStatePause       //暂停播放
    [_wmPlayer play];

    if (_wmPlayer.state == WMPlayerStatePlaying) {
        self.playIV.hidden = YES;
    }
    else {
        self.playIV.hidden = NO;
    }
    
}

-(void)releaseWMPlayer{
    [_wmPlayer.player.currentItem cancelPendingSeeks];
    [_wmPlayer.player.currentItem.asset cancelLoading];
    [_wmPlayer pause];
    
    //移除观察者
    [_wmPlayer.currentItem removeObserver:_wmPlayer forKeyPath:@"status"];
    [_wmPlayer removeFromSuperview];
    [_wmPlayer.playerLayer removeFromSuperlayer];
    [_wmPlayer.player replaceCurrentItemWithPlayerItem:nil];
    _wmPlayer.player = nil;
    _wmPlayer.currentItem = nil;
    //释放定时器，否侧不会调用WMPlayer中的dealloc方法
    [_wmPlayer.autoDismissTimer invalidate];
    _wmPlayer.autoDismissTimer = nil;
    [_wmPlayer.durationTimer invalidate];
    _wmPlayer.durationTimer = nil;
    _wmPlayer.playOrPauseBtn = nil;
    _wmPlayer.playerLayer = nil;
    _wmPlayer = nil;
}
- (void)clickSendComment {
    //点击写评论
    [self showkeyboard];
}


- (void)clickcommentImgView {
    //评论
    YFPlayerCommentView *commentView = [[YFPlayerCommentView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight) withVideoID:self.model.videoId isForum:NO isStore:NO];
    [self.view addSubview:commentView];
}


- (void)clickZhanBtn {
    YFUserModelSenddata *userModel = [YFFlieTool getUserModel];
    if (userModel == nil) {
        [self showAlert];
        return;
    }
    if ([self.model.createdBy isEqualToString:userModel.userId]) {
        [[ESAlert alloc]mAlertWithTitle:@"提示" message:@"您不可以给自己点赞" :@"确定"];
        return;
    }
    //点赞
    _zhanImgView.userInteractionEnabled = NO;
    NSDictionary *bodyDic = @{@"videoId" : self.model.videoId,@"customerId": userModel.userId ,@"flag":self.model.praiseFlag};
    [[[ESNetworkManager zanVideoWithDic:bodyDic] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        if ([self.model.praiseFlag isEqualToString:@"1"]
            ) {   //点赞
            self.model.likeNumber += 1;
            self.model.praiseFlag = @"0";
            self.zhanLabel.text = [NSString stringWithFormat:@"%ld",self.model.likeNumber];
            _zhanImgView.image = [UIImage imageNamed:@"已点赞"];
            //动画
            _coverBtn.alpha = 1;
            [UIView animateWithDuration:1.0f animations:^{
                _coverBtn.frame = CGRectMake(80, CGRectGetMinY(_zhanImgView.frame) - 50, iphone6Scale(40), iphone6Scale(40));
                CAKeyframeAnimation *anima = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation"];
                NSValue *value1 = [NSNumber numberWithFloat:-M_PI/180*5];
                NSValue *value2 = [NSNumber numberWithFloat:M_PI/180*5];
                NSValue *value3 = [NSNumber numberWithFloat:-M_PI/180*5];
                anima.values = @[value1,value2,value3];
                anima.repeatCount = MAXFLOAT;
                [_coverBtn.layer addAnimation:anima forKey:nil];
                _coverBtn.alpha = 0;
                _coverBtn.centerX = _zhanImgView.centerX;
            } completion:^(BOOL finished) {
                _coverBtn.frame = _zhanImgView.frame;
                _zhanImgView.userInteractionEnabled = YES;
            }];
        }
        else {  //取消点赞
            _zhanImgView.userInteractionEnabled = YES;
            self.model.likeNumber -= 1;
            self.model.praiseFlag = @"1";
            self.zhanLabel.text = [NSString stringWithFormat:@"%ld",self.model.likeNumber];
            _zhanImgView.image = [UIImage imageNamed:@"播放页点赞图标"];
        }
        
       
    } error:^(NSError * _Nullable error) {
        _zhanImgView.userInteractionEnabled = YES;
        [self.view showWarning:error.localizedDescription];
    }];
    
    
    
}

- (void)clickShare3rdBtn {
    NSString *shareUrl = [NSString stringWithFormat:@"%@/share/video?id=%@&sf=share",WebMain,self.model.videoId];
    
    NSString *title = self.model.videoTitle;
    NSString *content = @"让买卖工程机械更容易";
    NSString *videoImg = self.model.coverPictureUrl;
    //分享
    [[YFShareView shareview] showInViewWithView:self.view type:5 shareImageURL:videoImg shareContent:content shareTitle:title shareUrl:shareUrl isAd:false contentShareType:SSDKContentTypeVideo];
    [YFShareView shareview].reportAction = ^{
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)( 0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                  [[ESAlert API] mAlertWithTitle:@"提示" message:@"亲，您的举报我们已经受理，感谢您的监督！我们将及时处理。" :@"好" ];
                });
//        [LPActionSheet showActionSheetWithTitle:@"举报" cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:@[@"1",@"2",@"3",@"4"] handler:^(LPActionSheet *actionSheet, NSInteger index) {
//            //被点击按钮标识,取消: 0, 删除: -1, 其他: 1.2.3
//        }];
    };
    
}

- (void)commentVideoSuccess {
    self.model.discussCount += 1;
    self.commentLabel.text= @(self.model.discussCount).stringValue;
}

- (void)clicksendCommentsBtn:(UIButton *)sender {
    //点击发送评论
    if (self.commentsTextField.text.trim.length == 0) {
        [self.view showWarning:@"评论内容不能为空"];
        return;
    }
    YFUserModelSenddata *userModel = [YFFlieTool getUserModel];
    if (userModel.userId.length == 0) {
        [self showAlert];
        return;
    }
   
    NSDictionary *bodyDic = @{@"relevanceId":self.model.videoId,@"customerId" :userModel.userId,@"commentContent":self.commentsTextField.text,@"parentId":@"",@"commentTypeCode":@"DISCUSS_CODE_VIDEO"};
    [[[ESNetworkManager sendVideoComment:bodyDic] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        [self hidekeyboard];
        self.commentsTextField.text = @"";
        [self.view showWarning:@"评论成功"];
        self.model.discussCount += 1;
        self.commentLabel.text= @(self.model.discussCount).stringValue;
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
    }];
}

//播放加1
-(void)palyAddOne {
    
    [[[ESNetworkManager addVideoPlayNum:self.model.videoId] map:^id(id dic) {
        return dic;
    }] subscribeNext:^(id  _Nullable arr) {
//        self.model.playNumber += 1;
    } error:^(NSError * _Nullable error) {
        
    }];
}



- (void)dealloc {
    [self releaseWMPlayer];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}



-(void)showkeyboard {
    [self.view addSubview:self.maskView];
    [self.view bringSubviewToFront:self.commentsTextFieldBar];
    [_commentsTextField becomeFirstResponder];
}

- (void)hidekeyboard {
    [self.maskView removeFromSuperview];
    [_commentsTextField resignFirstResponder];
}

- (UIView *)maskView {
    if (!_maskView) {
        _maskView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight)];
        [self.view addSubview:_maskView];
        _maskView.backgroundColor = [UIColor clearColor];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidekeyboard)];
        [_maskView addGestureRecognizer:tap];
    }
    return _maskView;
}

//为textview添加placeHoder
- (void)setupTextView {
    UILabel *placeHolderLabelTwo = [[UILabel alloc] init];
    placeHolderLabelTwo.text = @"写评论...";
    placeHolderLabelTwo.numberOfLines = 0;
    placeHolderLabelTwo.textColor = mHexColorAlpha(0x000000, 0.54);
    [placeHolderLabelTwo sizeToFit];
    [self.commentsTextField addSubview:placeHolderLabelTwo];
    //    placeHolderLabelOne.font = [UIFont systemFontOfSize:14.f];
    placeHolderLabelTwo.font = self.commentsTextField.font;
    
    [self.commentsTextField setValue:placeHolderLabelTwo forKey:@"_placeholderLabel"];
}
- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (void)showAlert {
    UIAlertController * alertC =  [UIAlertController alertControllerWithTitle:@"友情提示" message:@"立即登录?" preferredStyle:1];
    UIAlertAction * confimAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        YFLoginVC *loginVC = [[YFLoginVC alloc] init];
        [self.navigationController pushViewController:loginVC animated:YES];
    }];
    UIAlertAction * cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alertC addAction:confimAction];
    [alertC addAction:cancelAction];
    [self presentViewController:alertC animated:YES completion:nil];
}

@end
