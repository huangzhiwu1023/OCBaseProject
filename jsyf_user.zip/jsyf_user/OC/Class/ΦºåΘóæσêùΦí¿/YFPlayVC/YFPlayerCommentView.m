//
//  YFPlayerCommentView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/4.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFPlayerCommentView.h"
#import "YFVideoCommentModel.h"
#import "YFPersonalHomeVC.h"


@interface YFPlayerCommentView()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) NSMutableArray<YFVideoComentSenddata *> *commentList;
//@property(nonatomic, strong) YFNoDataView  *emptyView;
@property(nonatomic, assign) NSInteger page;
@property(nonatomic, strong) UIView *backView;

@property(nonatomic, strong) UIButton *cancelBtn;

@property(nonatomic, strong) YFNoDataView *emptyView;

@property(nonatomic, strong) UIView *tableHeaderView;
@property(nonatomic, strong) UILabel *headerLB;
@property(nonatomic, assign) NSInteger commentCount;

@property(nonatomic, strong) NSString *commentTypeCode;
@end

@implementation YFPlayerCommentView
- (instancetype)initWithFrame:(CGRect)frame withVideoID:(NSString *)videoID isForum:(BOOL)isForum isStore:(BOOL)isStore{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        [self backView];
        [self cancelBtn];
        [self tableView];
        [self setUI];
        self.videoID = videoID;
        self.isForum = isForum;
        self.isStore = isStore;
        if (self.isForum) {
            self.commentTypeCode = @"DISCUSS_CODE_POST";
        }
        else if (self.isStore) {
            self.commentTypeCode = @"DISCUSS_CODE_STORE_VIDEO";
        }
        else {
            self.commentTypeCode = @"DISCUSS_CODE_VIDEO";
        }
        [self getCommentList];
       
     }
    return self;
}



- (void)setUI {
    //通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData:) name:@"commentVideoSuccess" object:nil];
    mWeakSelf
    [self.tableView addBackFooterRefresh:^{
        [weakSelf getCommentListMore];
    }];
    self.page = 1;
}



//数据更新
- (void)refreshData:(NSNotification *)noti {
    [self.tableView.mj_footer resetNoMoreData];
    NSDictionary *tmpDic = @{@"relevanceId" : self.videoID,@"commentTypeCode" :  self.commentTypeCode};
    NSDictionary *bodyDic = @{@"jsonParam" : tmpDic,@"page":@"1",@"rows":@"100"};
    if (self.isForum) {
        [[[ESNetworkManager getForumVideoCommentList:bodyDic] map:^id(id value) {
            return [YFVideoCommentModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFVideoCommentModel *  _Nullable x) {
            self.page = 1;
            [self.commentList removeAllObjects];
            [self.commentList addObjectsFromArray:x.data.sendData];
            [self.tableView reloadData];
            if (self.commentList.count == 0) {
                self.emptyView.hidden = NO;
                self.tableView.bounces = NO;
            }
            else {
                self.emptyView.hidden = YES;
                self.tableView.bounces = YES;
            }
            self.commentCount = x.data.totalCount;
            self.headerLB.text = [NSString stringWithFormat:@"共%ld条评论",self.commentCount];
        } error:^(NSError * _Nullable error) {
            [self.backView showWarning:error.localizedDescription];
        }];
    }
    else {
        [[[ESNetworkManager getVideoCommentList:bodyDic] map:^id(id value) {
            return [YFVideoCommentModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFVideoCommentModel *  _Nullable x) {
            self.page = 1;
            [self.commentList removeAllObjects];
            [self.commentList addObjectsFromArray:x.data.sendData];
            [self.tableView reloadData];
            if (self.commentList.count == 0) {
                self.emptyView.hidden = NO;
                self.tableView.bounces = NO;
            }
            else {
                self.emptyView.hidden = YES;
                self.tableView.bounces = YES;
            }
            self.commentCount = x.data.totalCount;
            self.headerLB.text = [NSString stringWithFormat:@"共%ld条评论",self.commentCount];
        } error:^(NSError * _Nullable error) {
            [self.backView showWarning:error.localizedDescription];
        }];
    }
    
    
}

//评论列表
- (void)getCommentList {
    [self.tableView.mj_footer resetNoMoreData];
    NSDictionary *tmpDic = @{@"relevanceId" : self.videoID,@"commentTypeCode" :  self.commentTypeCode};
    NSDictionary *bodyDic = @{@"jsonParam" : tmpDic,@"page":@"1",@"rows":@"100"};
    [self.backView showBusyHUD];
    if (self.isForum) {
        [[[ESNetworkManager getForumVideoCommentList:bodyDic] map:^id(id value) {
            return [YFVideoCommentModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFVideoCommentModel *  _Nullable x) {
            [self.backView hideBusyHUD];
            self.page = 1;
            [self.commentList removeAllObjects];
            [self.commentList addObjectsFromArray:x.data.sendData];
            [self.tableView reloadData];
            if (self.commentList.count == 0) {
                self.emptyView.hidden = NO;
                self.tableView.bounces = NO;
            }
            else {
                self.emptyView.hidden = YES;
                self.tableView.bounces = YES;
            }
            self.commentCount = x.data.totalCount;
            self.headerLB.text = [NSString stringWithFormat:@"共%ld条评论",self.commentCount];
        } error:^(NSError * _Nullable error) {
            [self.backView hideBusyHUD];
            [self.backView showWarning:error.localizedDescription];
            //        self.emptyView.hidden = NO;
        }];
    } else {
        [[[ESNetworkManager getVideoCommentList:bodyDic] map:^id(id value) {
            return [YFVideoCommentModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFVideoCommentModel *  _Nullable x) {
            [self.backView hideBusyHUD];
            self.page = 1;
            [self.commentList removeAllObjects];
            [self.commentList addObjectsFromArray:x.data.sendData];
            [self.tableView reloadData];
            if (self.commentList.count == 0) {
                self.emptyView.hidden = NO;
                self.tableView.bounces = NO;
            }
            else {
                self.emptyView.hidden = YES;
                self.tableView.bounces = YES;
            }
            self.commentCount = x.data.totalCount;
            self.headerLB.text = [NSString stringWithFormat:@"共%ld条评论",self.commentCount];
        } error:^(NSError * _Nullable error) {
            [self.backView hideBusyHUD];
            [self.backView showWarning:error.localizedDescription];
            //        self.emptyView.hidden = NO;
        }];
    }
}

//加载更多评论列表
- (void)getCommentListMore {
    NSDictionary *tmpDic = @{@"relevanceId" : self.videoID,@"commentTypeCode" :  self.commentTypeCode};
    NSDictionary *bodyDic = @{@"jsonParam" : tmpDic,@"page":@(self.page+1).stringValue,@"rows":@"100"};
    if (self.isForum) {
        [[[ESNetworkManager getForumVideoCommentList:bodyDic] map:^id(id value) {
            return [YFVideoCommentModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFVideoCommentModel *  _Nullable x) {
            [self.tableView endFooterRefresh];
            if (x.data.sendData.count == 0) {
                [self.tableView endFooterRefreshWithNoMoreData];
            }
            self.page += 1;
            [self.commentList addObjectsFromArray:x.data.sendData];
            [self.tableView reloadData];
        } error:^(NSError * _Nullable error) {
            [self.tableView endFooterRefresh];
            [self.backView showWarning:error.localizedDescription];
        }];
    }
    else {
        [[[ESNetworkManager getVideoCommentList:bodyDic] map:^id(id value) {
            return [YFVideoCommentModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFVideoCommentModel *  _Nullable x) {
            [self.tableView endFooterRefresh];
            if (x.data.sendData.count == 0) {
                [self.tableView endFooterRefreshWithNoMoreData];
            }
            self.page += 1;
            [self.commentList addObjectsFromArray:x.data.sendData];
            [self.tableView reloadData];
        } error:^(NSError * _Nullable error) {
            [self.tableView endFooterRefresh];
            [self.backView showWarning:error.localizedDescription];
        }];
    }
    
}

#pragma mark -------- tableviewDelegate/Datasource --------
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.commentList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFEquipmentCommentCell" forIndexPath:indexPath];
    
    YFVideoComentSenddata * model = self.commentList[indexPath.row];
    if (self.isForum && [model.customerId isEqualToString:[YFFlieTool getUserModel].userId]) {
         cell.isDelete = YES;
    }
    else {
         cell.isDelete = NO;
    }
    
    
    [cell configVideoCommentCellDataWithModel:model :self.isForum];
    self.tableView.rowHeight = cell.cellH;
    
    mWeakSelf
    [cell.headerIV tapHandle:^NSString *{
        YFPersonalHomeVC *vc = [[YFPersonalHomeVC alloc] init];
        vc.parameterStr = model.customerId;
        [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        return @"";
    }];
    [cell.commentImage tapHandle:^NSString *{
        if (weakSelf.isForum) {
            if ([model.customerId isEqualToString:[YFFlieTool getUserModel].userId]) {
                //删除
                [self deleteForumComment:indexPath.row];
            }
            else {
                YFForumVideoChildCommentVC *vc = [[YFForumVideoChildCommentVC alloc] init];
                vc.articleId = self.videoID;
                vc.videoModel = model;
                [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
            }
            
        }
        else {
            YFVideoChildCommentVC *vc = [[YFVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            vc.videoModel = model;
            vc.commentTypeCode = self.commentTypeCode;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        return @"";
    }];
    
    [cell.contentLabel tapHandle:^NSString *{
        if (weakSelf.isForum) {
            YFForumVideoChildCommentVC *vc = [[YFForumVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            vc.videoModel = model;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        else {
            YFVideoChildCommentVC *vc = [[YFVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            vc.videoModel = model;
            vc.commentTypeCode = self.commentTypeCode;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        return @"";
    }];
    
    
    [cell.commentOneLabel tapHandle:^NSString *{
        if (weakSelf.isForum) {
            YFForumVideoChildCommentVC *vc = [[YFForumVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            vc.videoModel = model;
            YFVideoComentChildrenlist *modelo =  model.childrenList[0];
            vc.repyName = modelo.customerNickName;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        else {
            YFVideoChildCommentVC *vc = [[YFVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            vc.videoModel = model;
            YFVideoComentChildrenlist *modelo =  model.childrenList[0];
            vc.repyName = modelo.customerNickName;
            vc.commentTypeCode = self.commentTypeCode;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
       
        return @"";
    }];
    
    [cell.commentTwoLabel tapHandle:^NSString *{
        if (weakSelf.isForum) {
            YFForumVideoChildCommentVC *vc = [[YFForumVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            YFVideoComentChildrenlist *modelo =  model.childrenList[1];
            vc.repyName = modelo.customerNickName;
            vc.videoModel = model;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        else {
            YFVideoChildCommentVC *vc = [[YFVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            YFVideoComentChildrenlist *modelo =  model.childrenList[1];;
            vc.repyName = modelo.customerNickName;
            vc.videoModel = model;
            vc.commentTypeCode = self.commentTypeCode;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        return @"";
    }];
    
    [cell.commentMoreLabel tapHandle:^NSString *{
        if (weakSelf.isForum) {
            YFForumVideoChildCommentVC *vc = [[YFForumVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            vc.videoModel = model;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        else {
            YFVideoChildCommentVC *vc = [[YFVideoChildCommentVC alloc] init];
            vc.articleId = self.videoID;
            vc.videoModel = model;
            vc.commentTypeCode = self.commentTypeCode;
            [weakSelf.viewController.navigationController pushViewController:vc animated:YES];
        }
        
        return @"";
    }];
    
    return cell;
}

//删除论坛视频评论
- (void)deleteForumComment:(NSInteger)indexRow {
    [LPActionSheet showActionSheetWithTitle:@"确认删除该评论?" cancelButtonTitle:@"取消" destructiveButtonTitle:@"确认" otherButtonTitles:nil handler:^(LPActionSheet *actionSheet, NSInteger index) {
        if (index == -1) {
            //删除接口
            [self.viewController.view showBusyHUD];
            NSString *userId = [YFFlieTool getUserModel].userId;
            if (userId == nil) {
                userId = @"";
            }
            NSDictionary *bodyDic = @{@"commentId" : self.commentList[indexRow].idField,@"customerId":userId};
            [[[ESNetworkManager deleteForumComment:bodyDic] map:^id(id value) {
                return value;
            }] subscribeNext:^(id  _Nullable x) {
                [self.viewController.view hideBusyHUD];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"deleteCommentSuccess" object:@(self.commentList[indexRow].childrenList.count + 1).stringValue];
                self.commentCount -= (self.commentList[indexRow].childrenList.count + 1);
                self.headerLB.text = [NSString stringWithFormat:@"共%ld条评论",self.commentCount];
                [self.commentList removeObjectAtIndex:indexRow];
                [self.tableView reloadData];
                if (self.commentList.count == 0) {
                    self.emptyView.hidden = NO;
                }
                else {
                    self.emptyView.hidden = YES;
                }
            } error:^(NSError * _Nullable error) {
                [self.viewController.view hideBusyHUD];
                [self.viewController.view showWarning:error.localizedDescription];
            }];
        }
    }];
}


- (UIView *)backView {
    if (!_backView) {
        _backView = [[UIView alloc] initWithFrame:CGRectMake(0, mScreenHeight, mScreenWidth, mScreenHeight * 0.65)];
        [self addSubview:_backView];
        _backView.backgroundColor = mHexColor(0xFFFFFF);
//        self.cancelBtn.enabled = NO;
        [UIView animateWithDuration:0.25 animations:^{
            _backView.frame = CGRectMake(0, mScreenHeight - mScreenHeight*0.65, mScreenWidth, mScreenHeight * 0.65);
        } completion:^(BOOL finished) {
//            self.cancelBtn.enabled = YES;
        }];
    }
    return _backView;
}

- (UIButton *)cancelBtn {
    if (!_cancelBtn) {
        _cancelBtn = [UIButton new];
        [self addSubview:_cancelBtn];
        [_cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.equalTo(0);
            make.bottom.equalTo(self.backView.mas_top).equalTo(-2);
        }];
        [_cancelBtn addTarget:self action:@selector(cancelBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cancelBtn;
}

- (void)cancelBtnClick:(UIButton *)sender {
    [UIView animateWithDuration:0.25 animations:^{
        _backView.frame = CGRectMake(0, mScreenHeight, mScreenWidth, mScreenHeight * 0.65);
    } completion:^(BOOL finished) {
        [_backView removeFromSuperview];
        [self removeFromSuperview];
    }];
}

- (void)closeBtnClicked:(UIButton *)sender {
    [self cancelBtnClick:sender];
}

#pragma mark -------- lazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight*0.65) style:UITableViewStylePlain];
        [self.backView addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        //        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorColor = kLineColor;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _tableView.backgroundColor = kBottomBgColor;
        [_tableView registerClass:[YFCommentCell class] forCellReuseIdentifier:@"YFEquipmentCommentCell"];
        _tableView.tableFooterView = [UIView new];
        _tableView.tableHeaderView = self.tableHeaderView;
    }
    return _tableView;
}
- (UIView *)tableHeaderView {
    if (!_tableHeaderView) {
        _tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, 44)];
        UIImageView *icon = [[UIImageView alloc] init];
        [_tableHeaderView addSubview:icon];
        [icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(8);
            make.centerY.equalTo(0);
        }];
        icon.image = [UIImage imageNamed:@"commentIcon"];
        
        self.headerLB = [[UILabel alloc] init];
        [_tableHeaderView addSubview:_headerLB];
        [_headerLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(icon.mas_right).equalTo(10);
            make.centerY.equalTo(0);
//            make.right.equalTo(-60);
            make.width.equalTo(150);
        }];
        _headerLB.font = [UIFont systemFontOfSize:15];
        _headerLB.textColor = mHexColor(0x333333);
        _headerLB.text = @"共0条评论";
        
        UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_tableHeaderView addSubview:closeBtn];
        [closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-16);
            make.centerY.equalTo(0);
            make.height.equalTo(40);
            make.width.equalTo(30);
        }];
        closeBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [closeBtn setImage:[UIImage imageNamed:@"commentClose"] forState:UIControlStateNormal];
        [closeBtn addTarget:self action:@selector(closeBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        UIView *lineView = [[UIView alloc] init];
        [_tableHeaderView addSubview:lineView];
        [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.right.equalTo(0);
            make.height.equalTo(0.5);
        }];
        lineView.backgroundColor = kLineColor;
    }
    return _tableHeaderView;
}

- (NSMutableArray<YFVideoComentSenddata *> *)commentList {
    if (!_commentList) {
        _commentList = [NSMutableArray array];
    }
    return _commentList;
}
- (NSString *)videoID {
    if (!_videoID) {
        _videoID = @"";
    }
    return _videoID;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectZero];
        [self.backView addSubview:_emptyView];
        [_emptyView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(44);
            make.left.right.bottom.equalTo(0);
//            make.edges.equalTo(0);
        }];
        [self.backView bringSubviewToFront:_emptyView];
        
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.refreshBtn.hidden = NO;
        [_emptyView.refreshBtn setTitle:@"发表评论" forState:UIControlStateNormal];
        [_emptyView.refreshBtn addTarget:self action:@selector(refreshBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        _emptyView.hidden = YES;
    }
    return _emptyView;
}

- (void)refreshBtnClicked:(UIButton *)sender {
    [UIView animateWithDuration:0.25 animations:^{
        _backView.frame = CGRectMake(0, mScreenHeight, mScreenWidth, mScreenHeight * 0.65);
    } completion:^(BOOL finished) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"showKeyboard" object:nil];
        [_backView removeFromSuperview];
        [self removeFromSuperview];
        
    }];
}
@end
