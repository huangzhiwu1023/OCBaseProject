//
//  YFVideoListRootVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFVideoListRootVC.h"
#import "YFUserVideoVC.h"
#import "YFCommonVideoVC.h"
#import "YFVideoListRootModel.h"
#import "YFNewestListVC.h"


@interface YFVideoListRootVC ()<VTMagicViewDelegate,VTMagicViewDataSource>
@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong)  NSMutableArray *menuList;
@property (nonatomic, strong)  NSMutableArray *menuCodeList;
@property(nonatomic, assign) BOOL needRefresh;
@end

@implementation YFVideoListRootVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"视频";
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = kBottomBgColor;
    [self magicController];
    [self.menuList addObjectsFromArray:@[@"小视频",@"采访",@"产品",@"品牌"]] ;

    [self.menuCodeList addObjectsFromArray:@[@"FRIENDS_VIDEO",@"USED_VIDEO",@"OTHER_VIDEO",@""]];
    [self.magicController.magicView reloadData];
    [self getMenu];
}

- (void)viewWillAppear:(BOOL)animated {
    if (self.needRefresh) {
        [self getMenu];
    }
}

-(void)getMenu{
  [[[ESNetworkManager getVideoMenu] map:^id(id dic) {
        return [YFVideoListRootModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
        self.needRefresh = NO;
        [self.menuList removeAllObjects];
        [self.menuCodeList removeAllObjects];
        for (YFVideoListRootModel *model in arr) {
            if([model.paramCode isEqualToString:@"FRIENDS_VIDEO"]) {
                [self.menuCodeList insertObject:model.paramCode atIndex:0];
                 [self.menuList insertObject:model.paramName atIndex:0];
            }else{
                [self.menuList addObject:model.paramName];
                [self.menuCodeList addObject:model.paramCode];
            }
            
        }
        [self.magicController.magicView reloadData];
    } error:^(NSError * _Nullable error) {
        self.needRefresh = YES;
    } completed:^{
        
    }];

}


#pragma mark - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    return _menuList;
}


- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex {
    static NSString *itemIdentifier = @"itemIdentifier";
    WSMenuItem *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (menuItem == nil) {
        menuItem = [WSMenuItem buttonWithType:UIButtonTypeCustom];
    }
    [menuItem setTitleColor:k666Color forState:UIControlStateNormal];
    [menuItem setTitleColor:kSliderColor forState:UIControlStateSelected];
    menuItem.titleLabel.font = [UIFont systemFontOfSize:14];
    menuItem.dotHidden = YES;
    return menuItem;
    
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex {
    if (pageIndex == 0) {
//        static NSString *gridId = @"relate.identifier";
//        YFUserVideoVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
//        if (childVC == nil) {
//            childVC = [[YFUserVideoVC alloc] init];
//        }
//        childVC.paramCode = self.menuCodeList[pageIndex];
//        return childVC;
        
        static NSString *gridId = @"relate.identifier";
        YFNewestListVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
        if (childVC == nil) {
            childVC = [[YFNewestListVC alloc] init];
        }
        childVC.labelId = self.labelId;
        childVC.labelName = self.labelName;
        childVC.isAllVideo = YES;
        return childVC;
        
    }
    else {
   NSString *gridId2 =  [NSString stringWithFormat:@"relate.identifier%ld",pageIndex+1];
        YFCommonVideoVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId2];
        if (childVC == nil) {
            childVC = [[YFCommonVideoVC alloc] init];
        }
        childVC.paramCode = self.menuCodeList[pageIndex];
        return childVC;
    }
   
}

#pragma mark - accessor methods
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        _magicController.view.translatesAutoresizingMaskIntoConstraints = NO;
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = kSliderColor;
        _magicController.magicView.switchStyle = 1;
        _magicController.magicView.layoutStyle = 0;
        _magicController.magicView.navigationHeight = 44;
        _magicController.magicView.sliderExtension = 10.f;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
        _magicController.magicView.needPreloading = YES;
        _magicController.magicView.itemScale = 1.1;
        
        [self addChildViewController:_magicController];
        [self.view addSubview:_magicController.view];
        [_magicController.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.view).offset(0);
            make.left.mas_equalTo(self.view).offset(0);
            make.bottom.mas_equalTo(self.view).offset(0);
            make.right.mas_equalTo(self.view).offset(0);
        }];
    }
    return _magicController;
}


- (CGFloat)magicView:(VTMagicView *)magicView itemWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/4;
}

- (CGFloat)magicView:(VTMagicView *)magicView sliderWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/4;
}


//init
- (NSMutableArray *)menuList{
    if (!_menuList) {
        _menuList = [NSMutableArray array];
    }
    return _menuList;
}

- (NSMutableArray *)menuCodeList{
    if (!_menuCodeList) {
        _menuCodeList = [NSMutableArray array];
    }
    return _menuCodeList;
}

@end
