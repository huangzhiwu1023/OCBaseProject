//
//  YFShortVideoListVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/8.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFShortVideoListVC.h"
#import "YFShortVideoCollectionCell.h"

@interface YFShortVideoListVC ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong)  NSMutableArray *dataArr;
@property (nonatomic,assign) NSInteger page;
@property (nonatomic, strong) YFNoDataView *emptyView;
@end

@implementation YFShortVideoListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kBottomBgColor;
    [self setInsetNoneWithScrollView:self.collectionView];
    [self collectionView];
    self.page = 1;
    mWeakSelf
    [self.collectionView addHeaderRefresh:^{
        [weakSelf.collectionView endFooterRefresh];
        [weakSelf.collectionView.mj_footer resetNoMoreData];
        [weakSelf getRefreshData];
    }];
    //    [self.collectionView beginHeaderRefresh];
    [self getRefreshData];
    [self.collectionView addBackFooterRefresh:^{
        [weakSelf.collectionView endHeaderRefresh];
        [weakSelf getMoreData];
    }];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getRefreshData) name:@"refreshFriendVideo" object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    if( [self.dataArr count] > 0 ) {
        [self.collectionView reloadData];
    }
}

//获取数据
-(void)getRefreshData {
    NSString *userID = [YFFlieTool getUserModel].userId;
    if (userID == nil) {
        userID = @"";
    }
    NSDictionary *bodyDic = @{
                              @"jsonParam":@{
                                      @"columnCode":self.paramCode,
                                      @"customerId":userID
                                      },
                              @"page":@1,
                              @"rows":@20
                              };
    
    [[[ESNetworkManager getVideoList:bodyDic] map:^id(id dic) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
        [self.dataArr removeAllObjects];
        [self.dataArr addObjectsFromArray: arr];
        self.page = 1;
        [self.collectionView endHeaderRefresh];
        [self.collectionView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endHeaderRefresh];
    }];
    
}

- (void)getMoreData {
    NSString *userID = [YFFlieTool getUserModel].userId;
    if (userID == nil) {
        userID = @"";
    }
    NSDictionary *bodyDic = @{
                              @"jsonParam":@{
                                      @"columnCode":self.paramCode,
                                      @"customerId":userID
                                      },
                              @"page":@(self.page+1),
                              @"rows":@20
                              };
    
    [[[ESNetworkManager getVideoList:bodyDic] map:^id(id dic) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
        
        [self.dataArr addObjectsFromArray: arr];
        [self.collectionView reloadData];
        [self.collectionView endFooterRefresh];
        if([arr count] > 0){  self.page += 1;}
        if ([arr count] == 0) {
            [self.collectionView endFooterRefreshWithNoMoreData];
        }
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endFooterRefresh];
    }];
    
}



//collectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    YFShortVideoCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFShortVideoCollectionCell" forIndexPath:indexPath];
   
    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    //新全屏滑动播放器  隐藏
    YFFullScrollPlayerVC *vc = [[YFFullScrollPlayerVC alloc] init];
    vc.dataList = self.dataArr.mutableCopy;
    vc.showIndex = indexPath;
    vc.paramCode = self.paramCode;
    vc.page = self.page;
    [self.navigationController pushViewController:vc animated:YES];
    
    
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 44) / 2.0, (mScreenWidth - 44) / 2.0 * 0.59 + 45);
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 12;
        layout.sectionInset = UIEdgeInsetsMake(16, 16, 16, 0);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.top.equalTo(6);
            make.bottom.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView registerClass:[YFShortVideoCollectionCell class] forCellWithReuseIdentifier:@"YFShortVideoCollectionCell"];
    }
    return _collectionView;
}
- (NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-44)];
        [self.view addSubview:_emptyView];
        [_emptyView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(0);
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.bottom.equalTo(0);
        }];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
        
    }
    return _emptyView;
}
@end
