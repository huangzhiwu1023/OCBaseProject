//
//  YFMyVideoListVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFMyVideoListVC.h"
#import "YFMyVideoCell.h"

@interface YFMyVideoListVC ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property(nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong)  NSMutableArray *dataArr;
@property (nonatomic,assign) NSInteger page;
@end

@implementation YFMyVideoListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的小视频";
    if (@available(iOS 11.0, *)) {
        self.collectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;//UIScrollView也适用
    }else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self collectionView];
    
    self.page = 1;
    mWeakSelf
    [self.collectionView addHeaderRefresh:^{
        [weakSelf.collectionView endFooterRefresh];
        [weakSelf.collectionView.mj_footer resetNoMoreData];
        [weakSelf getRefreshData];
    }];
    
//    [self.collectionView beginHeaderRefresh];
    [self getRefreshData];
    [self.collectionView addBackFooterRefresh:^{
        [weakSelf.collectionView endHeaderRefresh];
        [weakSelf getMoreData];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.collectionView reloadData];
}

//获取数据
-(void)getRefreshData {
    
    if(self.usedId.length > 0) {
    
    NSDictionary *dic = @{
                          @"jsonParam":@{
                                  @"createdBy":self.usedId,
                                  @"columnCode":@"FRIENDS_VIDEO"
                                  },
                          @"page":@1,
                          @"rows":@20
                          };
    
    [[[ESNetworkManager getVideoList:dic] map:^id(id dic) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
        [self.collectionView endHeaderRefresh];
        [self.dataArr removeAllObjects];
        [self.dataArr addObjectsFromArray: arr];
        self.page = 1;
        [self.collectionView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endHeaderRefresh];
    } completed:^{
        [self.collectionView endHeaderRefresh];
    }];}else{
        [self.collectionView endHeaderRefresh];}
    
}


-(void)getMoreData {
    if(self.usedId.length > 0) {
    NSDictionary *dic = @{
                          @"jsonParam":@{
                                 @"createdBy":self.usedId
                                  },
                          @"page":@(self.page+1),
                          @"rows":@20
                          };
    
    [[[ESNetworkManager getVideoList:dic] map:^id(id dic) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
    
        [self.dataArr addObjectsFromArray: arr];
        [self.collectionView reloadData];
        [self.collectionView endFooterRefresh];
        if([arr count] > 0){  self.page += 1;}
        if ([arr count] == 0) {
            [self.collectionView endFooterRefreshWithNoMoreData];
        }
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endFooterRefresh];
    }];}else{
        [self.collectionView endHeaderRefresh];}
    
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
   
    YFMyVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFMyVideoCell" forIndexPath:indexPath];
     YFUserVideoModel *model = self.dataArr[indexPath.row];
    cell.commentCountLB.text = [@(model.discussCount).stringValue numStringToConvertTenthousand];
    cell.playCountLB.text = [@(model.playNumber).stringValue numStringToConvertTenthousand];
    cell.titleLB.text = model.videoTitle;
    [cell.picIV sd_setImageWithURL:[NSURL URLWithString:model.coverPictureUrl] placeholderImage:kEquipmentPlaceHolder];
    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    YFUserVideoModel *model = self.dataArr[indexPath.row];
    model.playNumber += 1;
    if ([model.videoType isEqualToString: @"1"] ) {
        YFWebVC *webVC = [[YFWebVC alloc] init];
        webVC.urlString = model.videoUrl;
        [self.navigationController pushViewController:webVC animated:YES];
    }else{
        YFPlayVC *playVC = [[YFPlayVC alloc] init];
        playVC.videoUrl = model.videoUrl;
        playVC.vPictureUrl = model.coverPictureUrl;
        playVC.model = model;
        playVC.isDelete = YES;
        playVC.deleteSuccess = ^{
            [self.dataArr removeObject:model];
            [self.collectionView reloadData];
        };
        [self.navigationController pushViewController:playVC animated:YES];
    }
}


- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 12) / 2.0, (mScreenWidth - 12) / 2.0 * 1.333);
        layout.minimumLineSpacing = 4;
        layout.minimumInteritemSpacing = 4;
        layout.sectionInset = UIEdgeInsetsMake(4, 4, 0, 4);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.top.bottom.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = kBottomBgColor;
        [_collectionView registerClass:[YFMyVideoCell class] forCellWithReuseIdentifier:@"YFMyVideoCell"];
    }
    return _collectionView;
}

- (NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}
@end
