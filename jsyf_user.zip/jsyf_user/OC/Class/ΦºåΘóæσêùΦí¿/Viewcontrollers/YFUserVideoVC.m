//
//  YFUserVideoVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFUserVideoVC.h"
#import "YFUsersVideoCell.h"
#import "RTRootNavigationController.h"
#import "YFPlayVC.h"
#import "YFVideoNavigationController.h"
#import "YFUserVideoModel.h"

#import <AssetsLibrary/AssetsLibrary.h>

#import "AliyunRootViewController.h"
#import "AliyunRecordViewController.h"
#import "AliyunMediator.h"
#import "AliyunVideoUIConfig.h"
#import "AliyunVideoBase.h"
#import "AliyunVideoRecordParam.h"
#import "AliyunVideoCropParam.h"
#import "YFFullScrollPlayerVC.h"


@interface YFUserVideoVC ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property(nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong)  NSMutableArray *dataArr;
@property (nonatomic,assign) NSInteger page;

@property (nonatomic, strong) AliyunVideoRecordParam *quVideo;

@property (assign, nonatomic) BOOL isPhotoToRecord;
@end

@implementation YFUserVideoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setInsetNoneWithScrollView:self.collectionView];
    [self collectionView];
    [self addActionBtn]; //拍视频按钮
    //阿里小视频配置
    [self setupParam];
    [self setupSDKBaseVersionUI];
    
    self.page = 1;
    mWeakSelf
    [self.collectionView addHeaderRefresh:^{
        [weakSelf.collectionView endFooterRefresh];
        [weakSelf.collectionView.mj_footer resetNoMoreData];
        [weakSelf getRefreshData];
    }];
//    [self.collectionView beginHeaderRefresh];
    [self getRefreshData];
    [self.collectionView addBackFooterRefresh:^{
        [weakSelf.collectionView endHeaderRefresh];
        [weakSelf getMoreData];
    }];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getRefreshData) name:@"refreshFriendVideo" object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    if( [self.dataArr count] > 0 ) {
        [self.collectionView reloadData];
    }
//    [self getRefreshData];
}

//获取数据
-(void)getRefreshData {
    NSString *userID = [YFFlieTool getUserModel].userId;
    if (userID == nil) {
        userID = @"";
    }
    NSDictionary *bodyDic = @{
        @"jsonParam":@{
            @"columnCode":self.paramCode,
            @"customerId":userID
        },
        @"page":@1,
        @"rows":@20
    };
    
    [[[ESNetworkManager getVideoList:bodyDic] map:^id(id dic) {
    return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
        [self.dataArr removeAllObjects];
        [self.dataArr addObjectsFromArray: arr];
        self.page = 1;
        [self.collectionView endHeaderRefresh];
        [self.collectionView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endHeaderRefresh];
    }];
    
}

- (void)getMoreData {
    NSString *userID = [YFFlieTool getUserModel].userId;
    if (userID == nil) {
        userID = @"";
    }
    NSDictionary *bodyDic = @{
                          @"jsonParam":@{
                                  @"columnCode":self.paramCode,
                                  @"customerId":userID
                                  },
                          @"page":@(self.page+1),
                          @"rows":@20
                          };
    
    [[[ESNetworkManager getVideoList:bodyDic] map:^id(id dic) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
    
        [self.dataArr addObjectsFromArray: arr];
        [self.collectionView reloadData];
        [self.collectionView endFooterRefresh];
        if([arr count] > 0){  self.page += 1;}
        if ([arr count] == 0) {
            [self.collectionView endFooterRefreshWithNoMoreData];
        }
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endFooterRefresh];
    }];
    
}

//添加拍视频按钮
- (void)addActionBtn {
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:addBtn];
    [self.view bringSubviewToFront:addBtn];
    [addBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(-12);
        make.width.height.equalTo(48);
        make.bottom.equalTo(-60);
    }];
    [addBtn setImage:[UIImage imageNamed:@"拍摄视频"] forState:UIControlStateNormal];
    [addBtn addTarget:self action:@selector(addBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
}
//去拍视频页
- (void)addBtnClicked:(UIButton *)sender {
    YFUserModelSenddata* model = [YFFlieTool getUserModel];
    if (model) {
//      新视频录制
        [self toRecordViewControllerWithMediaConfig:_quVideo];
        return;
    } else {
      
        YFLoginVC * loginVC = [[YFLoginVC alloc] init];
        loginVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:loginVC animated:YES];
    }
   
    
   
}


//collectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    YFUsersVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFUsersVideoCell" forIndexPath:indexPath];
    if (self.dataArr.count > 0) {
        YFUserVideoModel *model = self.dataArr[indexPath.row];
        [cell.headIV sd_setImageWithURL:[NSURL URLWithString:model.customerImgUrl] placeholderImage:[UIImage imageNamed:@"user_default"]];
        cell.nameLB.text = model.customerNickName;
        cell.commentCountLB.text = [@(model.discussCount).stringValue numStringToConvertTenthousand];
        cell.playCountLB.text = [@(model.playNumber).stringValue numStringToConvertTenthousand];
        cell.titleLB.text = model.videoTitle;
        [cell.picIV sd_setImageWithURL:[NSURL URLWithString:model.coverPictureUrl] placeholderImage:kEquipmentPlaceHolder];
    
        [cell.discussList removeAllObjects];
        [cell.discussList addObjectsFromArray:model.discussList];
        cell.cycleView.count = cell.discussList.count;
    }

    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    //新全屏滑动播放器  隐藏
    YFFullScrollPlayerVC *vc = [[YFFullScrollPlayerVC alloc] init];
    vc.dataList = self.dataArr.mutableCopy;
    vc.showIndex = indexPath;
    vc.paramCode = self.paramCode;
    vc.page = self.page;
    [self.navigationController pushViewController:vc animated:YES];
    return;
    
    YFUserVideoModel *model = self.dataArr[indexPath.row];
    model.playNumber =  model.playNumber + 1;
    [self.dataArr removeObjectAtIndex:indexPath.row];
    [self.dataArr insertObject:model atIndex:indexPath.row];
    
    if ([model.videoType isEqualToString: @"1"] ) {
        YFWebVC *webVC = [[YFWebVC alloc] init];
        webVC.urlString = model.videoUrl;
        [self.navigationController pushViewController:webVC animated:YES];
    }else{
        YFPlayVC *playVC = [[YFPlayVC alloc] init];
        playVC.videoUrl = model.videoUrl;//@"rtmp://live.hkstv.hk.lxdns.com/live/hks"
        playVC.vPictureUrl = model.coverPictureUrl;
        playVC.model = model;
        [self.navigationController pushViewController:playVC animated:YES];
    }
    
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 12) / 2.0, (mScreenWidth - 12) / 2.0 * 1.333);
        layout.minimumLineSpacing = 4;
        layout.minimumInteritemSpacing = 4;
        layout.sectionInset = UIEdgeInsetsMake(4, 4, 0, 4);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.top.bottom.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = kBottomBgColor;
        [_collectionView registerClass:[YFUsersVideoCell class] forCellWithReuseIdentifier:@"YFUsersVideoCell"];
    }
    return _collectionView;
}
- (NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}



#pragma mark -------- rootDelegate --------
#pragma mark - RecordParamViewControllerDelegate
- (void)toRecordViewControllerWithMediaConfig:(id)config {
    UIViewController *recordViewController = [[AliyunVideoBase shared] createRecordViewControllerWithRecordParam:(AliyunVideoRecordParam*)_quVideo];
    [AliyunVideoBase shared].delegate = (id)self;
    [self.navigationController pushViewController:recordViewController animated:YES];
}

- (void)setupParam {
    _quVideo = [[AliyunVideoRecordParam alloc] init];
    _quVideo.ratio = AliyunVideoVideoRatio9To16;
    _quVideo.size = AliyunVideoVideoSize540P;
    _quVideo.minDuration = 2;
    _quVideo.maxDuration = 15;
    _quVideo.position = AliyunCameraPositionFront;
    _quVideo.beautifyStatus = YES;
    _quVideo.beautifyValue = 100;
    _quVideo.torchMode = AliyunCameraTorchModeOff;
    _quVideo.outputPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/record_save.mp4"];
}

- (void)setupSDKBaseVersionUI {
    AliyunVideoUIConfig *config = [[AliyunVideoUIConfig alloc] init];
    
    config.backgroundColor = mRGB(35, 42, 66);
    config.timelineBackgroundCollor = mRGB(35, 42, 66);
    config.timelineDeleteColor = [UIColor redColor];
    config.timelineTintColor = mRGB(239, 75, 129);
    config.durationLabelTextColor = [UIColor redColor];
    config.cutTopLineColor = [UIColor redColor];
    config.cutBottomLineColor = [UIColor redColor];
    config.noneFilterText = @"无滤镜";
    config.hiddenDurationLabel = YES;
    config.hiddenFlashButton = NO;
    config.hiddenBeautyButton = NO;
    config.hiddenCameraButton = NO;
    config.hiddenImportButton = NO;
    config.hiddenDeleteButton = NO;
    config.hiddenFinishButton = NO;
    config.recordOnePart = NO;
    config.filterArray = @[@"炽黄",@"粉桃",@"海蓝",@"红润",@"灰白",@"经典",@"麦茶",@"浓烈",@"柔柔",@"闪耀",@"鲜果",@"雪梨",@"阳光",@"优雅",@"朝阳",@"波普",@"光圈",@"海盐",@"黑白",@"胶片",@"焦黄",@"蓝调",@"迷糊",@"思念",@"素描",@"鱼眼",@"马赛克",@"模糊"];
    config.imageBundleName = @"QPSDK";
    config.filterBundleName = @"FilterResource";
    config.recordType = AliyunVideoRecordTypeCombination;
    config.showCameraButton = YES;
    
    [[AliyunVideoBase shared] registerWithAliyunIConfig:config];
}

#pragma mark - ConfigureViewControllerdelegate

- (void)configureDidFinishWithMedia:(AliyunMediaConfig *)mediaConfig {
#if SDK_VERSION != SDK_VERSION_BASE
    [AliyunIConfig config].showCameraButton = YES;
#endif
    UIViewController *vc = [[AliyunMediator shared] cropModule];
    [vc setValue:mediaConfig forKey:@"cutInfo"];
    [vc setValue:self forKey:@"delegate"];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - PhotoViewControllerDelgate
- (void)recodBtnClick:(UIViewController *)vc {
#if SDK_VERSION != SDK_VERSION_BASE
    [AliyunIConfig config].hiddenImportButton = YES;
#endif
    self.isPhotoToRecord = YES;
    UIViewController *recordVC = [[AliyunMediator shared] recordViewController];
    [recordVC setValue:self forKey:@"delegate"];
    [recordVC setValue:[vc valueForKey:@"cutInfo"] forKey:@"quVideo"];
    [recordVC setValue:@(NO) forKey:@"isSkipEditVC"];
    [self.navigationController pushViewController:recordVC animated:YES];
}

- (void)videoBase:(AliyunVideoBase *)base cutCompeleteWithCropViewController:(UIViewController *)cropVC image:(UIImage *)image {
    //裁剪图片
    if (image) {
        UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
    }
}

- (void)cropFinished:(UIViewController *)cropViewController videoPath:(NSString *)videoPath sourcePath:(NSString *)sourcePath {
    
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    [library writeVideoAtPathToSavedPhotosAlbum:[NSURL fileURLWithPath:videoPath] completionBlock:^(NSURL *assetURL, NSError *error) {
        if (error) {
            NSLog(@"裁剪完成，保存到相册失败");
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"裁剪完成" message:@"已保存到手机相册" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
        });
    }];
}

- (void)cropFinished:(UIViewController *)cropViewController mediaType:(kPhotoMediaType)type photo:(UIImage *)photo videoPath:(NSString *)videoPath {
    if (type == kPhotoMediaTypePhoto) {
        UIImageWriteToSavedPhotosAlbum(photo, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
    }
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if(error != NULL){
        NSLog(@"裁剪完成，保存到相册失败");
        return;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.navigationController popViewControllerAnimated:YES];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"裁剪完成" message:@"已保存到手机相册" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alert show];
    });
}

- (void)backBtnClick:(UIViewController *)vc {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - RecordViewControllerDelegate
- (void)exitRecord {
    if (self.isPhotoToRecord) {
        self.isPhotoToRecord = NO;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)recoderFinish:(UIViewController *)vc videopath:(NSString *)videoPath {
    
    if (self.isPhotoToRecord) {
        self.isPhotoToRecord = NO;
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        [library writeVideoAtPathToSavedPhotosAlbum:[NSURL fileURLWithPath:videoPath] completionBlock:^(NSURL *assetURL, NSError *error) {
            if (error) {
                NSLog(@"录制完成，保存到相册失败");
                return;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.navigationController popViewControllerAnimated:YES];
            });
        }];
        return;
    }
    UIViewController *editVC = [[AliyunMediator shared] editViewController];
    // 录制进编辑不合成视频
    //    NSString *outputPath = [[vc valueForKey:@"recorder"] valueForKey:@"taskPath"];
    //    [editVC setValue:outputPath forKey:@"videoPath"];
    // 录制进编辑合成视频
    [editVC setValue:videoPath forKey:@"videoPath"];
    [editVC setValue:[vc valueForKey:@"quVideo"] forKey:@"config"];
    [self.navigationController pushViewController:editVC animated:YES];
}

- (void)recordViewShowLibrary:(UIViewController *)vc {
#if SDK_VERSION != SDK_VERSION_BASE
    [AliyunIConfig config].showCameraButton = NO;
#endif
    UIViewController *compositionVC = [[AliyunMediator shared] compositionViewController];
    AliyunMediaConfig *mediaConfig = [[AliyunMediaConfig alloc] init];
    mediaConfig.fps = 25;
    mediaConfig.gop = 5;
    mediaConfig.videoQuality = 1;
    mediaConfig.cutMode = AliyunMediaCutModeScaleAspectFill;
    mediaConfig.encodeMode = AliyunEncodeModeHardH264;
    mediaConfig.outputSize = CGSizeMake(540, 720);
    mediaConfig.videoOnly = YES;
    [compositionVC setValue:mediaConfig forKey:@"compositionConfig"];
    [self.navigationController pushViewController:compositionVC animated:YES];
}

#pragma mark - AliyunVideoBaseDelegate
#if (SDK_VERSION == SDK_VERSION_BASE || SDK_VERSION == SDK_VERSION_STANDARD)
-(void)videoBaseRecordVideoExit {
    NSLog(@"退出录制");
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)videoBase:(AliyunVideoBase *)base recordCompeleteWithRecordViewController:(UIViewController *)recordVC videoPath:(NSString *)videoPath {
    
    UIViewController *editVC = [[AliyunMediator shared] editViewController];
    // 录制进编辑不合成视频
    //    NSString *outputPath = [[vc valueForKey:@"recorder"] valueForKey:@"taskPath"];
    //    [editVC setValue:outputPath forKey:@"videoPath"];
    // 录制进编辑合成视频
    [editVC setValue:videoPath forKey:@"videoPath"];
    [editVC setValue:[recordVC valueForKey:@"quVideo"] forKey:@"config"];
    [self.navigationController pushViewController:editVC animated:YES];
    return;
    NSLog(@"录制完成  %@", videoPath);
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    [library writeVideoAtPathToSavedPhotosAlbum:[NSURL fileURLWithPath:videoPath]
                                completionBlock:^(NSURL *assetURL, NSError *error) {
                                    
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        [recordVC.navigationController popViewControllerAnimated:YES];
                                    });
                                }];
}

- (AliyunVideoCropParam *)videoBaseRecordViewShowLibrary:(UIViewController *)recordVC {
    
    NSLog(@"录制页跳转Library");
    // 可以更新相册页配置
    AliyunVideoCropParam *mediaInfo = [[AliyunVideoCropParam alloc] init];
    mediaInfo.minDuration = 2.0;
    mediaInfo.maxDuration = 10.0*60;
    mediaInfo.fps = 25;
    mediaInfo.gop = 5;
    mediaInfo.videoQuality = 1;
    mediaInfo.size = AliyunVideoVideoSize540P;
    mediaInfo.ratio = AliyunVideoVideoRatio3To4;
    mediaInfo.cutMode = AliyunVideoCutModeScaleAspectFill;
    mediaInfo.videoOnly = YES;
    mediaInfo.outputPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cut_save.mp4"];
    return mediaInfo;
    
}

// 裁剪
- (void)videoBase:(AliyunVideoBase *)base cutCompeleteWithCropViewController:(UIViewController *)cropVC videoPath:(NSString *)videoPath {
    
    NSLog(@"裁剪完成  %@", videoPath);
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    [library writeVideoAtPathToSavedPhotosAlbum:[NSURL fileURLWithPath:videoPath]
                                completionBlock:^(NSURL *assetURL, NSError *error) {
                                    
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        
                                        AliyunMediaConfig *quVideo =[[AliyunMediaConfig alloc] init];
                                        quVideo.outputSize = CGSizeMake(540, 960);
                                        quVideo.minDuration = 2;
                                        quVideo.maxDuration = 15;
                                        //                                        quVideo.outputPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/record_save.mp4"]; [cropVC.navigationController popViewControllerAnimated:YES];
                                        
                                        UIViewController *editVC = [[AliyunMediator shared] editViewController];
                                        // 录制进编辑合成视频
                                        [editVC setValue:videoPath forKey:@"videoPath"];
                                        [editVC setValue:quVideo forKey:@"config"];
                                        [self.navigationController pushViewController:editVC animated:YES];
                                    });
                                }];
    
}

- (AliyunVideoRecordParam *)videoBasePhotoViewShowRecord:(UIViewController *)photoVC {
    
    NSLog(@"跳转录制页");
    return nil;
}

- (void)videoBasePhotoExitWithPhotoViewController:(UIViewController *)photoVC {
    
    NSLog(@"退出相册页");
    [photoVC.navigationController popViewControllerAnimated:YES];
}
#endif

@end


