//
//  YFVideoNavigationController.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/10.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFVideoNavigationController.h"

@interface YFVideoNavigationController ()

@end

@implementation YFVideoNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.childViewControllers.count > 0) {
        UIButton *backBtn = [[UIButton alloc] init];
        backBtn.frame = CGRectMake(0, 0, 40, 44);
        [backBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        backBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
        [backBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
        [backBtn setImage:[UIImage imageNamed:@"head_nav_back"] forState:UIControlStateNormal];
        backBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 10);
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
            //隐藏tabBar
        //这句suoer的push要放在后面,让viewController可以覆盖上面设置的leftBarButtonItem
        viewController.hidesBottomBarWhenPushed = YES;
    }
    
    
    [super pushViewController:viewController animated:animated];
}


- (void)back {
    //停止所有操作
    //    [SVProgressHUD dismiss];
    [ESNetworkManager cancelAllRequest];
    [self popViewControllerAnimated:YES];
}

@end
