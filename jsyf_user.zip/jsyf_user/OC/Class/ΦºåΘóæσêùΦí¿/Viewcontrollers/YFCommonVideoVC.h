//
//  YFCommonVideoVC.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFCommonVideoVC : UIViewController
@property (nonatomic, strong) NSString * paramCode;
@end
