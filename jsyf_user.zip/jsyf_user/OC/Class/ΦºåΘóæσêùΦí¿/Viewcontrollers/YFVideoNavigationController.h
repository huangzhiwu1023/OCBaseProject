//
//  YFVideoNavigationController.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/10.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "RTRootNavigationController.h"

@interface YFVideoNavigationController : RTRootNavigationController

@end
