//
//  YFCommonVideoVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFCommonVideoVC.h"
#import "YFCommonVideoCell.h"
#import "YFUserVideoModel.h"
#import "YFFullScrollPlayerVC.h"

@interface YFCommonVideoVC ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong)  NSMutableArray *dataArr;
@property (nonatomic,assign) NSInteger page;
@end

@implementation YFCommonVideoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setInsetNoneWithScrollView:self.collectionView];
    [self collectionView];
    self.page = 1;
    mWeakSelf
    [self.collectionView addHeaderRefresh:^{
        [weakSelf.collectionView endFooterRefresh];
        [weakSelf.collectionView.mj_footer resetNoMoreData];
        [weakSelf getRefreshData];
    }];
//    [self.collectionView beginHeaderRefresh];
    [self getRefreshData];
    [self.collectionView addBackFooterRefresh:^{
        [weakSelf.collectionView endHeaderRefresh];
        [weakSelf getMoreData];
    }];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if( [self.dataArr count] > 0 ) {
        [self.collectionView reloadData];
    }
//    [self getRefreshData];
}

//获取数据

-(void)getRefreshData {
    NSString *userID = [YFFlieTool getUserModel].userId;
    if (userID == nil) {
        userID = @"";
    }
    NSDictionary *dic = @{
                          @"jsonParam":@{
                                  @"columnCode":self.paramCode,
                                  @"customerId":userID
                                  },
                          @"page":@1,
                          @"rows":@21
                          };
    
    [[[ESNetworkManager getVideoList:dic] map:^id(id dic) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
        [self.collectionView endHeaderRefresh];
        [self.dataArr removeAllObjects];
        [self.dataArr addObjectsFromArray: arr];
        [self.collectionView reloadData];
        self.page = 1;
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
         [self.collectionView endHeaderRefresh];
    }];
    
}

-(void)getMoreData {
    NSString *userID = [YFFlieTool getUserModel].userId;
    if (userID == nil) {
        userID = @"";
    }
    NSDictionary *dic = @{
                          @"jsonParam":@{
                                  @"columnCode":self.paramCode,
                                  @"customerId":userID
                                  },
                          @"page":@(self.page+1),
                          @"rows":@20
                          };
    
    [[[ESNetworkManager getVideoList:dic] map:^id(id dic) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:dic[@"data"][@"sendData"]];
    }] subscribeNext:^(id  _Nullable arr) {
        [self.dataArr addObjectsFromArray: arr];
        [self.collectionView reloadData];
        if([arr count] > 0){  self.page += 1;}
        [self.collectionView endFooterRefresh];
        if ([arr count] == 0) {
            [self.collectionView endFooterRefreshWithNoMoreData];
        }
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
         [self.collectionView endFooterRefresh];
    } completed:^{
        [self.collectionView endFooterRefresh];
    }];
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return self.dataArr.count ? 1 : 0;
    }
    else {
        return self.dataArr.count -1;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFFirstVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFFirstVideoCell" forIndexPath:indexPath];
         YFUserVideoModel *model = self.dataArr[0];
        cell.commentCountLB.text = [@(model.discussCount).stringValue numStringToConvertTenthousand];
        cell.playCountLB.text = [@(model.playNumber).stringValue numStringToConvertTenthousand];
        cell.titleLB.text = model.videoTitle;
           [cell.picIV sd_setImageWithURL:[NSURL URLWithString:model.coverPictureUrl] placeholderImage:kEquipmentPlaceHolder];
        return cell;
    }
    else {
        YFCommonVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFCommonVideoCell" forIndexPath:indexPath];
        YFUserVideoModel *model = self.dataArr[indexPath.row+1];
        cell.commentCountLB.text = [@(model.discussCount).stringValue numStringToConvertTenthousand];
        cell.playCountLB.text = [@(model.playNumber).stringValue numStringToConvertTenthousand];
        cell.titleLB.text = model.videoTitle;
        [cell.picIV sd_setImageWithURL:[NSURL URLWithString:model.coverPictureUrl] placeholderImage:kEquipmentPlaceHolder];
        return cell;
    }
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    long a = indexPath.row;
    
    if (indexPath.section == 0) {
        a = 0;
    }else{
        a = indexPath.row + 1;
    }
    YFFullScrollPlayerVC *vc = [[YFFullScrollPlayerVC alloc] init];
    vc.dataList = self.dataArr;
    vc.showIndex = [NSIndexPath indexPathForRow:a inSection:0];
    vc.paramCode = self.paramCode;
    vc.page = self.page;
    [self.navigationController pushViewController:vc animated:YES];
    
//    if ([model.videoType isEqualToString: @"1"] ) {
//        YFWebVC *webVC = [[YFWebVC alloc] init];
//        webVC.urlString = model.videoUrl;
//        [self.navigationController pushViewController:webVC animated:YES];
//    }else{
//        YFPlayVC *playVC = [[YFPlayVC alloc] init];
//        playVC.videoUrl = model.videoUrl;
//        playVC.vPictureUrl = model.coverPictureUrl;
//        playVC.model = model;
//        [self.navigationController pushViewController:playVC animated:YES];
//    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return CGSizeMake(mScreenWidth, mScreenWidth * 0.464);
    }
    else {
        return CGSizeMake((mScreenWidth - 12) / 2.0, (mScreenWidth - 12) / 2.0);
    }
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    if (section == 0) {
        return 0;
    }
    else {
        return 4;
    }
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    if (section == 0) {
        return 0;
    }
    else{
        return 4;
    }
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    if (section == 0) {
        return UIEdgeInsetsMake(0, 0, 0, 0);
    }
    else {
        return UIEdgeInsetsMake(4, 4, 0, 4);
    }
}
- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 12) / 2.0, (mScreenWidth - 12) / 2.0 + 42);
        layout.minimumLineSpacing = 4;
        layout.minimumInteritemSpacing = 4;
        layout.sectionInset = UIEdgeInsetsMake(0, 4, 0, 4);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.top.bottom.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = kBottomBgColor;
        [_collectionView registerClass:[YFCommonVideoCell class] forCellWithReuseIdentifier:@"YFCommonVideoCell"];
        [_collectionView registerClass:[YFFirstVideoCell class] forCellWithReuseIdentifier:@"YFFirstVideoCell"];
    }
    return _collectionView;
}

- (NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

- (NSString *)paramCode {
    if (!_paramCode) {
        _paramCode = @"";
    }
    return _paramCode;
}

@end




