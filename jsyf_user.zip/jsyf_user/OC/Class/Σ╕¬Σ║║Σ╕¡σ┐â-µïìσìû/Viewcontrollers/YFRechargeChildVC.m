//
//  YFRechargeChildVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/31.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFRechargeChildVC.h"
#import "YFRechargeCell.h"
#import "YFRechargeListModel.h"

@interface YFRechargeChildVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) UIView *tableHeadView;
@property(nonatomic, strong) NSMutableArray<YFRechargeListpageList *> *listData;
@property(nonatomic, assign) NSInteger page;
@property(nonatomic, strong) YFNoDataView *emptyView;
@end

@implementation YFRechargeChildVC

- (void)viewDidLoad {
    [super viewDidLoad];
    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;  //UIScrollView也适用
    }else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = kBottomBgColor;
    self.page = 1;
    mWeakSelf
    [self.tableView addHeaderRefresh:^{
        [weakSelf.tableView.mj_footer resetNoMoreData];
        [weakSelf.tableView endFooterRefresh];
        [[[ESNetworkManager getRechargeListWithMemberId:[[ESToolAPI BtnAPI] getESHid] State:weakSelf.stateStr PageIndex:@"1" pageSize:@"20"] map:^id(id value) {
            return [YFRechargeListModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFRechargeListModel *  _Nullable x) {
            [weakSelf.tableView endHeaderRefresh];
            weakSelf.page = 2;
            [weakSelf.listData removeAllObjects];
            [weakSelf.listData addObjectsFromArray:x.data.pageList];
            [weakSelf.tableView reloadData];
            if (x.data.pageList.count == 0) {
                weakSelf.emptyView.hidden = NO;
            }
            else {
                weakSelf.emptyView.hidden = YES;
            }
        } error:^(NSError * _Nullable error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.view showWarning:error.localizedDescription];
        }];
    }];
    [self.tableView addBackFooterRefresh:^{
        [weakSelf.tableView endHeaderRefresh];
        [[[ESNetworkManager getRechargeListWithMemberId:[[ESToolAPI BtnAPI] getESHid] State:weakSelf.stateStr PageIndex:@(weakSelf.page).stringValue pageSize:@"20"] map:^id(id value) {
            return [YFRechargeListModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFRechargeListModel *  _Nullable x) {
            [weakSelf.tableView endFooterRefresh];
            if (x.data.pageList.count == 0) {
                [weakSelf.tableView endFooterRefreshWithNoMoreData];
            }
            weakSelf.page += 1;
            [weakSelf.listData addObjectsFromArray:x.data.pageList];
            [weakSelf.tableView reloadData];
            if (weakSelf.listData.count != 0) {
                weakSelf.emptyView.hidden = YES;
            }
        } error:^(NSError * _Nullable error) {
            [weakSelf.tableView endFooterRefresh];
            [weakSelf.view showWarning:error.localizedDescription];
        }];
    }];
    //发起网络请求
    [self requestData];
}

- (void)requestData {
    [self.view showBusyHUD];
    NSLog(@"stateStr = %@",self.stateStr);
    [[[ESNetworkManager getRechargeListWithMemberId:[[ESToolAPI BtnAPI] getESHid] State:self.stateStr PageIndex:@"1" pageSize:@"20"] map:^id(id value) {
        return [YFRechargeListModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFRechargeListModel *  _Nullable x) {
        [self.view hideBusyHUD];
        self.page = 2;
        [self.listData removeAllObjects];
        [self.listData addObjectsFromArray:x.data.pageList];
        [self.tableView reloadData];
        if (x.data.pageList.count == 0) {
            self.emptyView.hidden = NO;
        }
        else {
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        self.emptyView.hidden = NO;
        [self.view showWarning:error.localizedDescription];
    }];
}

//- (void)refreshAction {
//    NSLog(@"str = %@",_stateStr);
//}

#pragma mark -------- tableViewDelegate/tableviewDelegate --------
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.listData.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFRechargeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFRechargeCell" forIndexPath:indexPath];
    cell.model = self.listData[indexPath.row];
    return cell;
}


#pragma mark -------- LazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight - NaviHeight - 90*m6Scale) style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.separatorColor = kLineColor;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _tableView.sectionFooterHeight = 0;
        _tableView.tableHeaderView = self.tableHeadView;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        _tableView.rowHeight = 141;
        //注册cell
        [_tableView registerClass:[YFRechargeCell class] forCellReuseIdentifier:@"YFRechargeCell"];
    }
    return _tableView;
}

- (UIView *)tableHeadView {
    if (!_tableHeadView) {
        _tableHeadView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, 4)];
        _tableHeadView.backgroundColor = kBottomBgColor;
    }
    return _tableHeadView;
    
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth,mScreenHeight - NaviHeight - 90*m6Scale)];
        [self.view addSubview:_emptyView];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
    }
    return _emptyView;
}
- (NSString *)stateStr {
    if (!_stateStr) {
        _stateStr = @"";
    }
    return _stateStr;
}
- (NSMutableArray<YFRechargeListpageList *> *)listData {
    if (!_listData) {
        _listData = [NSMutableArray array];
    }
    return _listData;
}

@end
