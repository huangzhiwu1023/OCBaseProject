//
//  YFReturnRecordVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/3/5.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFReturnRecordVC.h"
#import "YFReturnChildVC.h"
#import "YFEnumStateModel.h"
@interface YFReturnRecordVC ()<VTMagicViewDelegate,VTMagicViewDataSource>
@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong)  NSArray *menuList;
@property(nonatomic, strong) NSArray<YFEnumStateRefundStatus *> *headList;
@end

@implementation YFReturnRecordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"返还记录";
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = kBottomBgColor;
    [self magicController];
    _menuList = @[@"全部",@"审核中",@"审核不通过",@"退款成功",@"取消申请"];
    [self.magicController.magicView reloadData];
    [self getEnumState];
}

//获取枚举状态
- (void)getEnumState {
    [[[ESNetworkManager getEnumState] map:^id(id value) {
        return [YFEnumStateModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFEnumStateModel *  _Nullable x) {
        self.headList = x.data.RefundStatus;
        NSMutableArray *tmpArr = [NSMutableArray array];
        [tmpArr addObject:@"全部"];
        for (YFEnumStateState *state in self.headList) {
            [tmpArr addObject:state.Text];
        }
        _menuList = tmpArr.copy;
        [self.magicController.magicView reloadData];
    } error:^(NSError * _Nullable error) {
        //        [self.view showWarning:error.localizedDescription];
    }];
}


#pragma mark - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    return _menuList;
}


- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex {
    static NSString *itemIdentifier = @"itemIdentifier";
    WSMenuItem *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (menuItem == nil) {
        menuItem = [WSMenuItem buttonWithType:UIButtonTypeCustom];
    }
    [menuItem setTitleColor:k666Color forState:UIControlStateNormal];
    [menuItem setTitleColor:kSliderColor forState:UIControlStateSelected];
    menuItem.titleLabel.font = [UIFont systemFontOfSize:14];
    menuItem.dotHidden = YES;
    return menuItem;
    
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex {
//    static NSString *gridId = @"relate.identifier";
//    YFReturnChildVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
//    if (!childVC) {
      YFReturnChildVC *childVC = [[YFReturnChildVC alloc] init];
//    }
    
    if (pageIndex == 0) {
        childVC.stateStr = @"";
    }
    else {
        if (self.headList.count > pageIndex - 1) {
            childVC.stateStr = self.headList[pageIndex - 1].Value;
        }
        else {
//            childVC.stateStr = @(pageIndex).stringValue;
        }
    }
    
    return childVC;
}

#pragma mark - accessor methods
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        _magicController.view.translatesAutoresizingMaskIntoConstraints = NO;
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = kSliderColor;
        _magicController.magicView.switchStyle = 1;
        _magicController.magicView.layoutStyle = 0;
        _magicController.magicView.navigationHeight = 90*m6Scale;
        _magicController.magicView.sliderExtension = 10.f;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
        _magicController.magicView.itemScale = 1.1;
        
        
        [self addChildViewController:_magicController];
        [self.view addSubview:_magicController.view];
        [_magicController.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.view).offset(0);
            make.left.mas_equalTo(self.view).offset(0);
            make.bottom.mas_equalTo(self.view).offset(0);
            make.right.mas_equalTo(self.view).offset(0);
        }];
    }
    return _magicController;
}


- (CGFloat)magicView:(VTMagicView *)magicView itemWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/5;
}

- (CGFloat)magicView:(VTMagicView *)magicView sliderWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/5;
}


@end
