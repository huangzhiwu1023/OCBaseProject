//
//  YFHeadListVC.m
//  jsyf_user
//
//  Created by 黄志武 on 2018/11/29.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFHeadListVC.h"
#import "YFHeadListCell.h"

@interface YFHeadListVC() <UICollectionViewDelegate,UICollectionViewDataSource>

@property(nonatomic,strong)UICollectionView *collectionView;

@property(nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation YFHeadListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.collectionView];
    [self setUI];
    [self getData];
    [self addTap];
}

#pragma mark- 布局更新UI
-(void)setUI{
    self.title = @"头像库";
       [self setEdgesForExtendedLayout:UIRectEdgeNone];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(20);
         make.top.equalTo(10);
         make.right.bottom.equalTo(-20);
    }];
}

#pragma mark- 获取数据
-(void)getData {
    mWeakSelf
    [[[ESNetworkManager getHeadImages] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        NSLog(@"返回的数据===%@", x);
        weakSelf.dataSource = x[@"data"][@"sendData"][@"urlList"];
        [self.collectionView reloadData];
     
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [weakSelf.view showWarning:error.localizedDescription];
    }];
}

#pragma mark- 事件处理
-(void)addTap {
    
}

#pragma mark- 代理UICollectionViewDataSource
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return self.dataSource.count / 5 + MIN(1, self.dataSource.count % 5) ;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 5;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
   YFHeadListCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
  
    NSString* img =  self.dataSource[indexPath.row];
    [cell.headImg sd_setImageWithURL:img.lx_URL placeholderImage:[UIImage imageNamed:@""]];
    cell.headImg.layer.cornerRadius = (mScreenWidth-40)/10.0-5;
    cell.headImg.layer.borderColor = kLineColor.CGColor;
    cell.headImg.layer.borderWidth = 0.5;
    cell.headImg.clipsToBounds = true;
    return cell;
}
#pragma mark- 代理UICollectionViewDelegate
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
   
    NSString* img =  self.dataSource[indexPath.row];
    self.imgUrlBlock(img);
     [self.navigationController popViewControllerAnimated:true];
}

#pragma mark- 初始化
-(UICollectionView *)collectionView{
    if (!_collectionView){
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        flowLayout.minimumLineSpacing = 0;
        flowLayout.minimumInteritemSpacing = 0;
        flowLayout.itemSize = CGSizeMake((mScreenWidth-40)/5.0, (mScreenWidth-40)/5.0);
        flowLayout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
        
        _collectionView = [[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:flowLayout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView registerClass:[YFHeadListCell class] forCellWithReuseIdentifier:@"cell"];
    }
    return _collectionView;
}

@end
