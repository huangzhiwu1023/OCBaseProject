//
//  YFMineVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/30.
//  Copyright © 2018年 YF. All rights reserved.
//
#import "YFMineVC.h"
#import "YFMineUserCell.h"
#import "YFMineTopicCell.h"
#import "YFMineNormalCell.h"
#import "YFOpenBusinessCell.h"

#import "YFRealnameSystemVC.h"
#import "FeedBackViewController.h"
#import "YFMyMoneyVC.h"
#import "SettingViewController.h"
#import "HezuoViewController.h"
#import "AboutMeViewController.h"
#import "UserInfoViewController.h"
#import "YFMyVideoListVC.h"
#import "YFLoginVC.h"

#import "YFApplyJobRootVC.h"
#import "YFRequestJobRootVC.h"

#import "YFESJListVC.h"
#import "YFESJManagerRootVC.h"
#import "YFESJDredgeVC.h"

#import "YFInvitationAndVideoVC.h"
#import "YFMyFansAndFollowsVC.h"
#import "YFNewsCenterVC.h"

@interface YFMineVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, assign) BOOL isLogin;
@property(nonatomic, strong) NSArray *titleList;
@property(nonatomic, strong) NSArray *imgList;
@property(nonatomic, strong) YFUserModelSenddata *userModel;
@property(nonatomic, strong) NSString *type;
@property(nonatomic, strong) NSString *number;

@property (nonatomic, strong) NSString *fansNum;//粉丝数
@property (nonatomic, strong) NSString *focusNum;//关注数
@property (nonatomic, strong) NSString *invitationNum;//帖子数

@property(nonatomic, strong) UIView *redPoint;

@end

@implementation YFMineVC
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的";
    [self addNaviRightBtn];
    [self addNaviLeftBtn];
    self.view.backgroundColor = kBottomBgColor;
    [self setInsetNoneWithScrollView:self.tableView];
    self.userModel = [YFFlieTool getUserModel];
    if (self.userModel) {
        self.isLogin = YES;
        [self requestAttendAndInvitationData];
    } else {
        self.isLogin = NO;
    }
    self.number = @"0";

}

//添加导航右按钮
- (void)addNaviRightBtn {
    UIButton *rightBtn = [[UIButton alloc] init];
    rightBtn.frame = CGRectMake(0, 0, 45, 44);
    [rightBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
    rightBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [rightBtn addTarget:self action:@selector(rightBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
}

//添加导航左按钮
- (void)addNaviLeftBtn {
    UIButton *leftBtn = [[UIButton alloc] init];
    leftBtn.frame = CGRectMake(0, 0, 45, 44);
    [leftBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
    leftBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [leftBtn addTarget:self action:@selector(leftBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [leftBtn setImage:[UIImage imageNamed:@"message_icon"] forState:UIControlStateNormal];
    self.redPoint = [[UIView alloc] initWithFrame:CGRectMake(20, 10, 6, 6)];
    [leftBtn addSubview:self.redPoint];
    self.redPoint.backgroundColor = kRedColor;
    self.redPoint.clipsToBounds = YES;
    self.redPoint.layer.cornerRadius = 3;
    self.redPoint.hidden = YES;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
}

//消息中心
- (void)leftBtnClick:(UIButton *)sender {
    if ([YFFlieTool getUserModel] == nil) {
        YFLoginVC *vc = [[YFLoginVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if ([[RCIM sharedRCIM] getConnectionStatus] != ConnectionStatus_Connected) {
        YFLoginVC *vc = [[YFLoginVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else {
        YFNewsCenterVC *vc = [[YFNewsCenterVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}
//分享操作
- (void)rightBtnClick:(UIButton *)sender {

    NSString *str = [NSString stringWithFormat:@"%@/download",WebMain];
    [[YFShareView shareview] showInViewWithView:self.view type:0 shareImageURL:@"" shareContent:@"感谢您把app分享给更多人, 快喊朋友来下载，世界因同用一个app而精彩" shareTitle:@"灜沣工程机械" shareUrl:str isAd:false contentShareType:SSDKContentTypeAuto];
    [YFShareView shareview].isShareSuccess = ^(NSString * msg){

    };
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self modelFor];
    self.userModel = [YFFlieTool getUserModel];
    if (self.userModel) {
        self.isLogin = YES;
         [[ESToolAPI BtnAPI] getESHInfos];
    } else {
        self.isLogin = NO;
    }
    if (self.isLogin) {
        [self requestAttendAndInvitationData];
        if (self.userModel.usedBusinessFlag == 1){
               self.titleList = @[@"我发布的设备",@"我的询价",@"我的招聘",@"我的求职",@"收藏夹",@"最近浏览",@"设置",@"意见反馈",@"我要合作",@"关于"];

            self.imgList = @[@"设备",@"询价",@"个人中心-招聘",@"个人中心-求职",@"收藏",@"lastbrowse",@"setting",@"feed_back",@"partner",@"about_us"];
        }else{
            self.titleList = @[@"我的询价",@"我的招聘",@"我的求职",@"收藏夹",@"最近浏览",@"设置",@"意见反馈",@"我要合作",@"关于"];
            self.imgList = @[@"询价",@"个人中心-招聘",@"个人中心-求职",@"收藏",@"lastbrowse",@"setting",@"feed_back",@"partner",@"about_us"];
        }
//
        [self requestDataRefresh];
    }
    else {
        self.titleList = @[@"设置",@"我要合作",@"关于"];
        self.imgList = @[@"setting",@"partner",@"about_us"];

    }
    [self.tableView reloadData];
    
    //是否展示小红点
    /*  暂时不判断小红点
    if (self.userModel == nil) {
        self.redPoint.hidden = YES;
    }
    else {
        [[[YFFlieTool alloc] init] getRedPointNum:^(NSInteger redNum) {
            if (redNum > 0) {
                self.redPoint.hidden = NO;
            }
            else {
                self.redPoint.hidden = YES;
            }
        }];
    }
     */
}

//获取小红点个数
- (void)modelFor {
    [[ESNetworkManager getNumeber] subscribeNext:^(id  _Nullable x) {
        NSString * str = x[@"data"][@"sendData"][@"inquiry"][@"receivedNotCount"];
        NSLog(@"%@",str);
        self.number =  [NSString stringWithFormat:@"%@",str];//String(format:"%@",str);
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        
    }];
}


- (void)requestDataRefresh {
    
    if (self.userModel.username== nil) {
        self.userModel.username = @"";
    }
    if (self.userModel.loginSecretKey == nil) {
        self.userModel.loginSecretKey = @"";
    }
    NSString * password =  [[NSUserDefaults standardUserDefaults] objectForKey:@"password"];
    if (password == nil) {
        password  = @"";
    }
    
    if (self.userModel.username.length != 0 && self.userModel.loginSecretKey.length != 0)
    {
        NSDictionary * bodyDic = @{@"phoneNumber":self.userModel.username,@"LOGIN_SECRET_KEY":self.userModel.loginSecretKey};
        
        [[[ESNetworkManager validateLoginKeyWithParam:bodyDic] map:^id(id value) {
            return [YFUserModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFUserModel *  _Nullable x) {
            x.data.sendData.loginSecretKey = self.userModel.loginSecretKey;
            [YFFlieTool saveUserModel:x.data.sendData];
            self.userModel = x.data.sendData;
            [JPUSHService setAlias:x.data.sendData.userId completion:nil seq:0];
            [self.tableView reloadData];
        } error:^(NSError * _Nullable error) {
//            if (error.code==1 ) {
                [self.view showWarning:error.localizedDescription];
                [YFFlieTool saveUserModel:nil];
               // [KeychainTool deleteKeychainValue:USERNAME];
                [KeychainTool deleteKeychainValue:PASSWORD];
            [[RCIM sharedRCIM] disconnect];
            [JPUSHService deleteAlias:nil seq:0];

                self.isLogin = NO;
                self.titleList = @[@"设置",@"我要合作",@"关于"];
                self.imgList = @[@"setting",@"partner",@"about_us"];
//            }
            [self.tableView reloadData];
            
        } completed:^{
          
        }];
    }else  if (self.userModel.username.length != 0 && password.length != 0)
    {
        NSDictionary * bodyDic = @{@"username":self.userModel.username,@"password":password};
        [[[ESNetworkManager userLoginwithParam:bodyDic] map:^id(id value) {
            return [YFUserModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFUserModel *  _Nullable x) {
            [YFFlieTool saveUserModel:x.data.sendData];
            self.userModel = x.data.sendData;
            [JPUSHService setAlias:x.data.sendData.userId completion:^(NSInteger iResCode, NSString *iAlias, NSInteger seq) {
                
            } seq:0];
            
            [self.tableView reloadData];
        } error:^(NSError * _Nullable error) {
//            if (error.code==1 ) {
                [self.view showWarning:error.localizedDescription];
                [YFFlieTool saveUserModel:nil];
               // [KeychainTool deleteKeychainValue:USERNAME];
                [KeychainTool deleteKeychainValue:PASSWORD];
            [[RCIM sharedRCIM] disconnect];
            [JPUSHService deleteAlias:nil seq:0];
                self.isLogin = NO;
                self.titleList = @[@"设置",@"我要合作",@"关于"];
                self.imgList = @[@"setting",@"partner",@"about_us"];
//            }
            [self.tableView reloadData];
        } completed:^{
        }];
    } else {
        [YFFlieTool saveUserModel:nil];
        self.isLogin = NO;
        self.titleList = @[@"设置",@"我要合作",@"关于"];
        self.imgList = @[@"setting",@"partner",@"about_us"];
        [self.tableView reloadData];
        
    }

}

#pragma mark -------- tableViewDelegate/Datasource --------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.isLogin && self.userModel.usedBusinessFlag == 0) {
        return 4;
    }
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.isLogin && self.userModel.usedBusinessFlag == 0) {
        if (section == 3) {
            return self.titleList.count;
        }
        else {
            return 1;
        }
    }
    else {
        if (section == 2) {
            return self.titleList.count;
        }
        else {
            return 1;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFMineUserCell *userCell = [tableView dequeueReusableCellWithIdentifier:@"YFMineUserCell" forIndexPath:indexPath];
        if (self.isLogin) {
            userCell.infoView.hidden = NO;
            userCell.infoView.invitNumlabel.text = _invitationNum;
            userCell.infoView.fansNumLabel.text = _fansNum;
            userCell.infoView.attNumLabel.text = _focusNum;
            [userCell fullCellWithModel:self.userModel];
            userCell.type = self.userModel.auditStatus;
            
            [userCell.infoView.attention_btn tapHandle:^NSString *{
                YFMyFansAndFollowsVC *vc = [[YFMyFansAndFollowsVC alloc] init];
                vc.joinFans = @"follow";
                vc.title_Str = @"我的关注";
                [self.navigationController pushViewController:vc animated:YES];
                return @"关注";
            }];
            
            [userCell.infoView.fans_btn tapHandle:^NSString *{
                YFMyFansAndFollowsVC *vc = [[YFMyFansAndFollowsVC alloc] init];
                vc.joinFans = @"fans";
                vc.title_Str = @"我的粉丝";
                [self.navigationController pushViewController:vc animated:YES];
                return @"粉丝";
            }];
            
            [userCell.infoView.invitation_btn tapHandle:^NSString *{
                YFInvitationAndVideoVC *vc = [[YFInvitationAndVideoVC alloc] init];
                [self.navigationController pushViewController:vc animated:NO];
                return @"帖子";
            }];
            
        }
        else {
            [userCell fullCellWithModel:nil];
            userCell.infoView.hidden = YES;
        }
        return userCell;
    }
    else if (indexPath.section == 1) {
        if (self.isLogin && self.userModel.usedBusinessFlag == 0) {
            YFOpenBusinessCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFOpenBusinessCell" forIndexPath:indexPath];
            return cell;
        } else {
           return [self setBuyAndsellCellWith:tableView index:indexPath];
        }
        
    }
    else if (indexPath.section == 2) {
        if (self.isLogin && self.userModel.usedBusinessFlag == 0) {
            return [self setBuyAndsellCellWith:tableView index:indexPath];
        } else {
            YFMineNormalCell *normalCell = [tableView dequeueReusableCellWithIdentifier:@"YFMineNormalCell" forIndexPath:indexPath];
                  normalCell.hotL.hidden = YES;
            normalCell.titleLB.text = self.titleList[indexPath.row];
            if ([normalCell.titleLB.text isEqualToString:@"我的询价"]) {
                normalCell.hotL.hidden = [self.number isEqualToString:@"0"];
              
                normalCell.hotL.text  =  self.number;
            }
            normalCell.iconIV.image = [UIImage imageNamed:self.imgList[indexPath.row]];
            return normalCell;
        }
    }
    else {
        YFMineNormalCell *normalCell = [tableView dequeueReusableCellWithIdentifier:@"YFMineNormalCell" forIndexPath:indexPath];
        normalCell.titleLB.text = self.titleList[indexPath.row];
        normalCell.iconIV.image = [UIImage imageNamed:self.imgList[indexPath.row]];
        normalCell.hotL.hidden = YES;
        if ([normalCell.titleLB.text isEqualToString:@"我的询价"]) {
            normalCell.hotL.hidden = [self.number isEqualToString:@"0"];
            normalCell.hotL.text  = self.number;
        }
        return normalCell;
    }
}

- (YFMineTopicCell *)setBuyAndsellCellWith:(UITableView *)tableView index:(NSIndexPath *)indexPath {
    YFMineTopicCell *topicCell = [tableView dequeueReusableCellWithIdentifier:@"YFMineTopicCell" forIndexPath:indexPath];
    mWeakSelf
    [topicCell.myMoneyView tapHandle:^NSString *{
        NSString *memberID = [[ESToolAPI BtnAPI] getESHid];
        if  (memberID.length == 0 || [YFFlieTool getUserModel] == nil) {
            YFLoginVC *loginVC = [[YFLoginVC alloc] init];
            [weakSelf.navigationController pushViewController:loginVC animated:YES];
        }
        else {
            YFMyMoneyVC *vc = [[YFMyMoneyVC alloc] init];
            vc.hidesBottomBarWhenPushed = YES;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }
        return @"我的资金";
    }];
    
    [topicCell.orderView  tapHandle:^NSString *{
        NSString *memberID = [[ESToolAPI BtnAPI] getESHid];
        if  (memberID.length == 0 || [YFFlieTool getUserModel] == nil) {
            YFLoginVC *loginVC = [[YFLoginVC alloc] init];
            [weakSelf.navigationController pushViewController:loginVC animated:YES];
        }
        else {
            YFAuctionOrderViewController *vc = [[YFAuctionOrderViewController alloc] init];
            vc.hidesBottomBarWhenPushed = YES;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }
        
        return @"拍卖订单";
    }];
    
    [topicCell.followedView  tapHandle:^NSString *{
        NSString *memberID = [[ESToolAPI BtnAPI] getESHid];
        if  (memberID.length == 0 || [YFFlieTool getUserModel] == nil) {
            YFLoginVC *loginVC = [[YFLoginVC alloc] init];
            [weakSelf.navigationController pushViewController:loginVC animated:YES];
        }
        else {
            YFMineEquipAttentionVC *vc = [[YFMineEquipAttentionVC  alloc] init];
            vc.hidesBottomBarWhenPushed = YES;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }
        return @"我的关注";
    }];
    
    [topicCell.equipmentView tapHandle:^NSString *{
        
        if ([YFFlieTool getUserModel] == nil) {
            YFLoginVC *vc = [[YFLoginVC alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }else {
        
//        ESHDailyAuctionAppointmentGuideViewController *guideViewController = [[ESHDailyAuctionAppointmentGuideViewController alloc] init];
//        guideViewController.title = @" 预约拍卖";
//        guideViewController.hidesBottomBarWhenPushed = YES;
//        [self.navigationController pushViewController:guideViewController animated:YES];
            }
        return  @"预约拍卖";
        }];
        
    return topicCell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    if (self.isLogin && self.userModel.usedBusinessFlag == 0) {
        if (indexPath.section == 0) {
            return 158;
        }
        else if (indexPath.section == 1) {
            return mScreenWidth * 0.3;
        }
        else if (indexPath.section == 2) {
            return (mScreenWidth - 4)/3.0 * 3.0/4.0 + 38;
//            return (mScreenWidth - 6)/4.0 * 3.0/4.0 + 38;
        }
        else {
            return 48;
        }
    }
    else {
        if (indexPath.section == 0) {
            if (self.isLogin == NO) {
                return 100;
            } else {
               return 158;
            }
        }
        else if (indexPath.section == 1) {
            return (mScreenWidth - 4)/3.0 * 3.0/4.0 + 38;
//            return (mScreenWidth - 6)/4.0 * 3.0/4.0 + 38;
        }
        else {
            return 48;
        }
    }
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headV = [[UIView alloc] init];
    headV.backgroundColor = kBottomBgColor;
    return headV;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 8;
    }
    else {
        return 4;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}
//selectRow
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (self.isLogin) {
            UserInfoViewController * userInfoVC= [[UserInfoViewController alloc] init];
            userInfoVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:userInfoVC animated:YES]; 
        }
        else {
            YFLoginVC * loginVC = [[YFLoginVC alloc] init];
            loginVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:loginVC animated:YES];
        }
        
    }
    else if(indexPath.section == 1) {
        if (self.isLogin && self.userModel.usedBusinessFlag == 0) {
            //跳转认证页面
            YFESJDredgeVC *vc = [[YFESJDredgeVC alloc] init];
            vc.userModel = self.userModel;
            [self.navigationController pushViewController:vc animated:YES];
        }
        else {  //do nothing  此时是拍卖相关cell
        }
    }
    else if (indexPath.section == 2) {
        if (self.isLogin && self.userModel.usedBusinessFlag == 0) {
            //do nothing 此时是拍卖相关cell
        } else {
            NSString *title = self.titleList[indexPath.row];
            [self didSelectRowWithTitle:title];
        }
    }
    else {
        NSString *title = self.titleList[indexPath.row];
        [self didSelectRowWithTitle:title];
    }
}

- (void)didSelectRowWithTitle:(NSString *)title {
    if ([title isEqualToString:@"我发布的设备"]) {
        YFESJManagerRootVC *vc = [[YFESJManagerRootVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    if([title isEqualToString:@"最近浏览"]) {
        YFRecentLookRootVC *vc = [[YFRecentLookRootVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if([title isEqualToString:@"分享"]) {
        [self rightBtnClick:nil];
    }
    else if([title isEqualToString:@"我的视频"]) { //废弃
        YFMyVideoListVC * vc = [[YFMyVideoListVC alloc] init];
        vc.hidesBottomBarWhenPushed = YES;
        vc.usedId = self.userModel.userId;
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if([title isEqualToString:@"我的求职"]) {
        YFRequestJobRootVC *jobvc = [[YFRequestJobRootVC alloc] init];
        [self.navigationController pushViewController:jobvc animated:YES];
    }
    else if([title isEqualToString:@"我的招聘"]) {
        YFApplyJobRootVC * jjvc = [[YFApplyJobRootVC alloc] init];
        [self.navigationController pushViewController:jjvc animated:YES];
    }
    else if([title isEqualToString:@"设置"]) {
        SettingViewController * settingVC = [[SettingViewController alloc] initWithIsLogin:self.isLogin];
        settingVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:settingVC animated:YES];
    }
    else if([title isEqualToString:@"意见反馈"]) {
        FeedBackViewController * feedBackVc = [[FeedBackViewController alloc] initWithNibName:@"FeedBackViewController" bundle:nil];
        feedBackVc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:feedBackVc animated:YES];
    }
    else if([title isEqualToString:@"我要合作"]) {
        HezuoViewController * hezuoVC = [[HezuoViewController alloc] init];
        [self.navigationController pushViewController:hezuoVC animated:YES];
    }
    else if([title isEqualToString:@"关于"]) {
        AboutMeViewController * aboutMeVC = [[AboutMeViewController alloc] init];
        [self.navigationController pushViewController:aboutMeVC animated:YES];
    }
    else if([title isEqualToString:@"我的询价"]) {
        YFMyAskPriceVC * vc = [[YFMyAskPriceVC alloc] init];
        if (self.userModel.usedBusinessFlag == 1) {}else{
            vc.arr = @[@"我发出的询价"];
        }
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if([title isEqualToString:@"收藏夹"]) {
        YFCollectVC * vc = [[YFCollectVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}

#pragma mark -------- LazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight - NaviHeight - TABBARHEIGHT) style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.separatorColor = kLineColor;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        //注册cell
        [_tableView registerClass:[YFMineUserCell class] forCellReuseIdentifier:@"YFMineUserCell"];
        [_tableView registerClass:[YFMineTopicCell class] forCellReuseIdentifier:@"YFMineTopicCell"];
        [_tableView registerClass:[YFMineNormalCell class] forCellReuseIdentifier:@"YFMineNormalCell"];
        [_tableView registerClass:[YFOpenBusinessCell class] forCellReuseIdentifier:@"YFOpenBusinessCell"];
        
    }
    return _tableView;
}
//获取关注数，粉丝数和帖子数
- (void)requestAttendAndInvitationData {
    
    [[ESNetworkManager findFocusCountAndFansCount] subscribeNext:^(id  _Nullable x) {
        self.fansNum = x[@"data"][@"sendData"][@"fansCount"];
        self.focusNum = x[@"data"][@"sendData"][@"focusCount"];
        self.invitationNum = x[@"data"][@"sendData"][@"forumCount"];
        NSLog(@"拿到的数据===%@===%@==%@", _fansNum, _focusNum, _invitationNum);
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
    }];
   
}

@end
