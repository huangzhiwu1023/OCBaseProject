//
//  YFHeadListVC.h
//  jsyf_user
//
//  Created by 黄志武 on 2018/11/29.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef void (^imgUrlBlock)(NSString *imgUrl);

@interface YFHeadListVC : UIViewController


@property(nonatomic, copy) imgUrlBlock imgUrlBlock;

@end

NS_ASSUME_NONNULL_END
