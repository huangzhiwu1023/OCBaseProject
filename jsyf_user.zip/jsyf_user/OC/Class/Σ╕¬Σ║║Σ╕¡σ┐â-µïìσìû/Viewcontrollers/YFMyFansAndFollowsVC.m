//
//  YFMyFansAndFollowsVC.m
//  jsyf_user
//
//  Created by 程辉 on 2018/8/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFMyFansAndFollowsVC.h"
#import <WebKit/WebKit.h>
#import "YFPersonalHomeVC.h"


@interface YFMyFansAndFollowsVC ()<WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate>

@property (nonatomic, strong) WKWebView *webView;

@end

@implementation YFMyFansAndFollowsVC
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    [_webView.configuration.userContentController addScriptMessageHandler:self name:@"jump2UserDetail"];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [_webView.configuration.userContentController removeScriptMessageHandlerForName:@"jump2UserDetail"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.title_Str;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    
    // 设置偏好设置
    config.preferences = [[WKPreferences alloc] init];
    // 默认为0
    config.preferences.minimumFontSize = 10;
    // 默认认为YES
    config.preferences.javaScriptEnabled = YES;
    // 在iOS上默认为NO，表示不能自动通过窗口打开
    config.preferences.javaScriptCanOpenWindowsAutomatically = NO;
    
    // web内容处理池
    config.processPool = [[WKProcessPool alloc] init];
    
    // 通过JS与webview内容交互
    config.userContentController = [[WKUserContentController alloc] init];
    // 我们可以在WKScriptMessageHandler代理中接收到
    [self.view showBusyHUD];
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds
                                      configuration:config];
    
//    [config.userContentController addScriptMessageHandler:self name:@"jump2UserDetail"];
    
    NSString *str;
    if (_isReplay) {
        str = [NSString stringWithFormat:@"%@/user/certified?rz=%@&type=0", WebMain, _joinFans];
    } else {
       str = [NSString stringWithFormat:@"%@/%@/%@", WebMain,[YFFlieTool getUserModel].userId,_joinFans];
    }
    NSURL *path = [NSURL URLWithString:str];

    [self.webView evaluateJavaScript:[[ESToolAPI BtnAPI] getUrl] completionHandler:^(NSString* data, NSError * _Nullable error) {
        NSLog(@"%@",data);
        
    }];
    
 
    [self.webView loadRequest:[NSURLRequest requestWithURL:path]];
    [self.view addSubview:self.webView];
    
    // 导航代理
    self.webView.navigationDelegate = self;
    // 与webview UI交互代理
    self.webView.UIDelegate = self;
    
    // 添加KVO监听
    [self.webView addObserver:self
                   forKeyPath:@"loading"
                      options:NSKeyValueObservingOptionNew
                      context:nil];
    [self.webView addObserver:self
                   forKeyPath:@"estimatedProgress"
                      options:NSKeyValueObservingOptionNew
                      context:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateJSRefresh:) name:@"updateJSRefresh" object:nil];
}
- (void)updateJSRefresh:(NSNotification *)notification {
    NSString *js = [NSString stringWithFormat:@"refreshInfo()"];
    [self.webView evaluateJavaScript:js completionHandler:^(id _Nullable data, NSError * _Nullable error) {
        NSLog(@"手动调用JS代码==%@=%@",data,error);
    }];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_webView removeObserver:self forKeyPath:@"loading"];
    [_webView removeObserver:self forKeyPath:@"estimatedProgress"];
}

#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController
      didReceiveScriptMessage:(WKScriptMessage *)message {
    NSDictionary *dic = (NSDictionary *)message.body;
    NSLog(@"html包含的字典==%@===%@", dic, message.name);

    if ([message.name isEqualToString:@"jump2UserDetail"]) {
        NSDictionary *dict = (NSDictionary *)message.body;
        YFPersonalHomeVC *vc = [[YFPersonalHomeVC alloc] init];
        vc.parameterStr = dict[@"x"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }
}

#pragma mark - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary<NSString *,id> *)change
                       context:(void *)context {
    if ([keyPath isEqualToString:@"loading"]) {
        NSLog(@"loading");
        [self.view hideBusyHUD];
    } else if ([keyPath isEqualToString:@"title"]) {
        self.title = self.webView.title;
    } else if ([keyPath isEqualToString:@"estimatedProgress"]) {
        NSLog(@"progress: %f", self.webView.estimatedProgress);
    }
}


@end
