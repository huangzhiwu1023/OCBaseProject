//
//  YFInvitationAndVideoVC.m
//  jsyf_user
//
//  Created by 程辉 on 2018/8/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFInvitationAndVideoVC.h"
#import "YFMyInvitationVC.h"
#import "YFMyVideoVC.h"
#import "YFVideoNavigationController.h"
#import "YFPostStyleSelectVC.h"


@interface YFInvitationAndVideoVC ()<VTMagicViewDelegate,VTMagicViewDataSource>
@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong)  NSMutableArray *menuList;
@property (nonatomic, strong)  NSMutableArray *menuCodeList;

@property (nonatomic, assign) NSInteger videoCount;
@property (nonatomic, assign) NSInteger invitationCount;

@end

@implementation YFInvitationAndVideoVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self wr_setNavBarShadowImageHidden:NO];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的发布";
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self requestInvitationData:0];
    [self magicController];
    [self.menuList addObjectsFromArray:@[@"帖子(0)",@"视频(0)"]];
    [self.magicController.magicView reloadData];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deletePostInvitationSuccess:) name:YFDeletePostInvitation_success object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(postUpdateSuccess:) name:YFPostUpdate_success object:nil];
    [self addActionBtn];
    
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)deletePostInvitationSuccess:(NSNotification *)notification {
    if ([notification.object isEqualToString:@"1"]) {
        [self requestInvitationData:1];
        [self.magicController.magicView switchToPage:1 animated:YES];
    } else {
        [self requestInvitationData:0];
        [self.magicController.magicView switchToPage:0 animated:YES];
    }
    [self.magicController.magicView reloadData];
}
- (void)postUpdateSuccess:(NSNotification *)notification {
    if ([notification.object isEqualToString:@"1"]) {
        [self requestInvitationData:1];
        [self.magicController.magicView switchToPage:1 animated:YES];
    } else {
        [self requestInvitationData:0];
        [self.magicController.magicView switchToPage:0 animated:YES];
    }
    [self.magicController.magicView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
#pragma mark - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    return _menuList;
}

- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex {
    static NSString *itemIdentifier = @"itemIdentifier";
    WSMenuItem *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (menuItem == nil) {
        menuItem = [WSMenuItem buttonWithType:UIButtonTypeCustom];
    }
    [menuItem setTitleColor:k666Color forState:UIControlStateNormal];
    [menuItem setTitleColor:kSliderColor forState:UIControlStateSelected];
    menuItem.titleLabel.font = [UIFont systemFontOfSize:14];
    menuItem.dotHidden = YES;
    return menuItem;
    
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex {
    
    if (pageIndex == 0) {
        static NSString *gridId = @"relate.identifier";
        YFMyInvitationVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
        if (childVC == nil) {
            childVC = [[YFMyInvitationVC alloc] init];
        }
        return childVC;
        
    } else {
        NSString *gridId2 =  [NSString stringWithFormat:@"relate.identifier%ld",pageIndex+1];
        YFMyVideoVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId2];
        if (childVC == nil) {
            childVC = [[YFMyVideoVC alloc] init];
        }
       
        return childVC;
    }
    
}

#pragma mark - accessor methods
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
    _magicController.view.translatesAutoresizingMaskIntoConstraints = NO;
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = mHexColor(0xF48F4A);
        _magicController.magicView.switchStyle = 1;
        _magicController.magicView.layoutStyle = 0;
        _magicController.magicView.navigationHeight = 90*m6Scale;
        _magicController.magicView.sliderExtension = 10.f;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
        _magicController.magicView.needPreloading = YES;
        _magicController.magicView.itemScale = 1.1;
        
        [self addChildViewController:_magicController];
        [self.view addSubview:_magicController.view];
        
        [_magicController.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.view).offset(0);
            make.left.mas_equalTo(self.view).offset(0);
            make.bottom.mas_equalTo(self.view).offset(0);
            make.right.mas_equalTo(self.view).offset(0);
        }];
    }
    return _magicController;
}


- (CGFloat)magicView:(VTMagicView *)magicView itemWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/2;
}

- (CGFloat)magicView:(VTMagicView *)magicView sliderWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/2;
}

- (void)requestInvitationData:(NSInteger)index {
    NSDictionary *dict = @{@"jsonParam":@{
                                   @"createBy":[YFFlieTool getUserModel].userId,
                                   @"forumTypeFlag":@"0"
                                   },
                           @"page":@"1",
                           @"rows":@"1"
                           };
    [[[ESNetworkManager findPostArticleControllerList:dict] map:^id(id value) {
        return [YFNewestListModel mj_objectWithKeyValues:value];;
    }] subscribeNext:^(YFNewestListModel *  _Nullable x) {
        NSLog(@"帖子===%@====%ld", x, x.data.count);
        
        //        _menuView.InvitationLabel.text = [NSString stringWithFormat:@"帖子(%ld)", x.data.count];
        _invitationCount = x.data.count;
        
        [self requestVideoData:index];
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
    } completed:^{
        
    }];
}
- (void)requestVideoData:(NSInteger)index {
    NSDictionary *dict = @{@"jsonParam":@{
                                   @"createBy":[YFFlieTool getUserModel].userId,
                                   @"forumTypeFlag":@"1"
                                   },
                           @"page":@"1",
                           @"rows":@"1"
                           };
    [[[ESNetworkManager findPostArticleControllerList:dict] map:^id(id value) {
        return [YFNewestListModel mj_objectWithKeyValues:value];;
    }] subscribeNext:^(YFNewestListModel *  _Nullable x) {
        NSLog(@"视频===%@====%ld", x, x.data.count);
        _videoCount = x.data.count;

        [self.menuList removeAllObjects];
        NSString *str = [NSString stringWithFormat:@"帖子(%ld)", _invitationCount];
        NSString *str1 = [NSString stringWithFormat:@"视频(%ld)", _videoCount];
        [self.menuList addObjectsFromArray:@[str, str1]];
        
        [self.magicController.magicView reloadMenuTitles];
    
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
    } completed:^{
        
    }];
}


- (NSMutableArray *)menuList{
    if (!_menuList) {
        _menuList = [NSMutableArray array];
    }
    return _menuList;
}

- (NSMutableArray *)menuCodeList{
    if (!_menuCodeList) {
        _menuCodeList = [NSMutableArray array];
    }
    return _menuCodeList;
}
//添加拍视频按钮
- (void)addActionBtn {
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [addBtn setImage:[UIImage imageNamed:@"fatie"] forState:UIControlStateNormal];
    addBtn.contentMode = UIViewContentModeScaleAspectFill;
    [addBtn setClipsToBounds:YES];
    addBtn.layer.cornerRadius = 50/2;
    addBtn.layer.masksToBounds = YES;
    [self.view addSubview:addBtn];
    [self.view bringSubviewToFront:addBtn];
    [addBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view.mas_right).with.offset(-16);
        make.width.and.height.equalTo(@(50));
        make.bottom.equalTo(self.view.mas_bottom).with.offset(-20);
    }];
    [addBtn addTarget:self action:@selector(addBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)addBtnClicked:(UIButton *)sender {
    YFUserModelSenddata* model = [YFFlieTool getUserModel];
    if (model) {
        YFPostStyleSelectVC *cameraVC = [[YFPostStyleSelectVC alloc] init];
        //        self.definesPresentationContext = YES;
        YFVideoNavigationController *MineNav =[[YFVideoNavigationController alloc] initWithRootViewControllerNoWrapping:cameraVC];
        MineNav.view.backgroundColor = [UIColor clearColor];
        MineNav.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [self presentViewController:MineNav animated:YES completion:nil];
        return;
    } else {
        YFLoginVC * loginVC = [[YFLoginVC alloc] init];
        loginVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:loginVC animated:YES];
    }
}


@end
