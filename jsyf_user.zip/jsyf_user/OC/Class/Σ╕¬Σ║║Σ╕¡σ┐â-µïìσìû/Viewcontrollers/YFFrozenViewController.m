//
//  YFFrozenViewController.m
//  jsyf_user
//
//  Created by pro on 2018/1/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFrozenViewController.h"
#import "YFFrozenListViewController.h"
@interface YFFrozenViewController ()

@end

@implementation YFFrozenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"冻结记录";
    _menuList = @[@"全部",@"冻结",@"解冻"];
    [self addChildViewController:self.magicController];
    [self.view addSubview:_magicController.view];
    [_magicController.magicView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self setEdgesForExtendedLayout:UIRectEdgeNone];
}


- (void)viewWillLayoutSubviews {
    [_magicController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view).offset(0);
        make.left.mas_equalTo(self.view).offset(0);
        make.bottom.mas_equalTo(self.view).offset(0);
        make.right.mas_equalTo(self.view).offset(0);
    }];
}
#pragma mark - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    
    return _menuList;
}


- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex {
    static NSString *itemIdentifier = @"itemIdentifier";
    WSMenuItem *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (menuItem == nil) {
        menuItem = [WSMenuItem buttonWithType:UIButtonTypeCustom];
    }
    [menuItem setTitleColor:k666Color forState:UIControlStateNormal];
    [menuItem setTitleColor:kSliderColor forState:UIControlStateSelected];
    menuItem.titleLabel.font = [UIFont systemFontOfSize:14];
    menuItem.dotHidden = YES;
    return menuItem;
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex {
    static NSString *gridId = @"relate.identifier";
     YFFrozenListViewController * yffrozenListVC = [magicView dequeueReusablePageWithIdentifier:gridId];
    if (yffrozenListVC == nil) {
        yffrozenListVC = [[YFFrozenListViewController alloc] init];
    }
    yffrozenListVC.type = [self getTypeWithTitle:self.menuList[pageIndex]];
    return yffrozenListVC;
}


- (NSString * )getTypeWithTitle:(NSString *)title
{
    NSString * type = @"";
    if ([title isEqualToString:@"解冻"]) {
        type = @"8";
    }
    else if ([title isEqualToString:@"解冻"])
    {
        type = @"7";
    }
    return type;
}

#pragma mark - accessor methods
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        _magicController.view.translatesAutoresizingMaskIntoConstraints = NO;
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = kSliderColor;
        _magicController.magicView.switchStyle = 1;
        _magicController.magicView.layoutStyle = 0;
        _magicController.magicView.navigationHeight = 90*m6Scale;
        _magicController.magicView.sliderExtension = 10.f;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
    }
    return _magicController;
}

- (CGFloat)magicView:(VTMagicView *)magicView itemWidthAtIndex:(NSUInteger)itemIndex {
    return MAIN_WIDTH/self.menuList.count;
}

- (CGFloat)magicView:(VTMagicView *)magicView sliderWidthAtIndex:(NSUInteger)itemIndex {
    return MAIN_WIDTH/self.menuList.count;
}


@end
