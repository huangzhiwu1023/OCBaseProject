//
//  YFMyVideoVC.m
//  jsyf_user
//
//  Created by 程辉 on 2018/8/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFMyVideoVC.h"

#import "YFNewestListModel.h"

#import "YFNewListPictureViewCell.h"
#import "YFNewListVideoViewCell.h"
#import "YFNoDataView.h"
#import "YFForumFullScrollPlayerVC.h"
#import "YFPersonalHomeVC.h"
#import "YFVideoNavigationController.h"
#import "YFPostStyleSelectVC.h"
#import "PopoverView.h"
#import "YFGoRecordVideoManager.h"

@interface YFMyVideoVC ()
<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>{
    YFGoRecordVideoManager * _manager;
}


@property (nonatomic, strong) UICollectionView *collectionView;

@property (nonatomic, assign) NSInteger page;

@property(nonatomic, strong) NSMutableArray<NewestListSendData *> *dataSource;

@property (nonatomic, strong) YFNoDataView *noDataView;

@end

@implementation YFMyVideoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的视频";
    self.view.backgroundColor = [UIColor whiteColor];
    
    UICollectionViewFlowLayout *flowLayout = [UICollectionViewFlowLayout new];
    flowLayout.minimumInteritemSpacing = 8;
    flowLayout.sectionInset = UIEdgeInsetsMake(16, 5, -2, 5);
    
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight-NaviHeight) collectionViewLayout:flowLayout];
    self.collectionView.backgroundColor = mHexColor(0xF3F3F3);
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.view addSubview:_collectionView];
    [self setInsetNoneWithScrollView:self.collectionView];
    [_collectionView registerClass:[YFNewListPictureViewCell class] forCellWithReuseIdentifier:@"YFNewListPictureViewCell"];
    [_collectionView registerClass:[YFNewListVideoViewCell class] forCellWithReuseIdentifier:@"YFNewListVideoViewCell"];
    //
    self.page = 1;
    mWeakSelf
    [self.collectionView addHeaderRefresh:^{
        [weakSelf.collectionView endFooterRefresh];
        [weakSelf.collectionView.mj_footer resetNoMoreData];
        [weakSelf requestInvitationAndVideoData];
    }];
    [self requestInvitationAndVideoData];
    [self.collectionView addBackFooterRefresh:^{
        [weakSelf.collectionView endHeaderRefresh];
        [weakSelf requestMoreData];
    }];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateIsZanWay:) name:@"updateIsZanWay" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(needLoginUpdate:) name:@"needLoginUpdate" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(postUpdateSuccess) name:YFPostUpdate_success object:nil];
    [self addActionBtn];
}
- (void)updateIsZanWay:(NSNotification *)notification {
    [self.collectionView reloadData];
}
- (void)needLoginUpdate:(NSNotification *)notification {
     [[ESAlert API] OkAlertWithTitle:@"提示" message:@"需要您登录后才能点赞" :@"确定" :@"取消" vc:self sure:^{
        YFLoginVC *loginVC = [[YFLoginVC alloc] init];
        loginVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:loginVC animated:YES];
    }];
}
- (void)postUpdateSuccess {
    [self requestInvitationAndVideoData];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.collectionView reloadData];
}

#pragma mark -- UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return self.dataSource.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 1;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NewestListSendData *sendData = self.dataSource[indexPath.section];
    if ([sendData.forumTypeFlag isEqualToString:@"1"]) {
        YFNewListVideoViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFNewListVideoViewCell" forIndexPath:indexPath];
        cell.send_data = sendData;
        
        mWeakSelf
        [cell.base.relay_btn tapHandle:^NSString *{
            [weakSelf isShare:sendData];
            return @"转发";
        }];
        [cell.base.comment_btn tapHandle:^NSString *{
            [weakSelf isCommon:sendData indexPath:indexPath];
            return @"点击评论";
        }];
        [cell.dele_btn tapHandle:^NSString *{
            PopoverView *popV = [[PopoverView alloc] init];
            popV.style = PopoverViewStyleDefault;
            PopoverAction *action = [PopoverAction actionWithTitle:@"    删除    " handler:^(PopoverAction *action) {
                [weakSelf isDelete:sendData index:indexPath.section];
            }];
            [popV showToView:cell.dele_btn withActions:@[action]];
            return @"删除帖子";
        }];
        [cell.header_btn tapHandle:^NSString *{
            [weakSelf isPush:sendData];
            return @"";
        }];
        
        return cell;
    }
    return nil;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    NewestListSendData *sendData = self.dataSource[indexPath.section];
    if ([sendData.forumTypeFlag isEqualToString:@"1"]) {
        if ([sendData.delFlag isEqualToString:@"1"] || [sendData.shieldFlag isEqualToString:@"1"]) {
            return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH+122 +10);
        } else {
            return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH + 296);
        }
    }
    return CGSizeZero;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    YFForumFullScrollPlayerVC *vc = [[YFForumFullScrollPlayerVC alloc] init];
    vc.dataList = self.dataSource;
    vc.showIndex = indexPath.section;
    vc.page = self.page;
    vc.isMine = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (NSMutableArray<NewestListSendData *> *)dataSource {
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}
- (YFNoDataView *)noDataView {
    if (!_noDataView) {
        _noDataView = [[YFNoDataView alloc] initWithFrame:self.view.bounds];
        _noDataView.viewType = YFNoDataViewTypeNone;
        _noDataView.title =@"空空如也~";
        [self.view addSubview:_noDataView];
    }
    return _noDataView;
}
#pragma mark -- 转发
- (void)isShare:(NewestListSendData *)sendData {
    mWeakSelf//http://192.168.0.144:5000/帖子序列号/detail?u=当前用户id
    //视频分享
    NSString *shareUrl = [NSString stringWithFormat:@"%@/video/postshare/%@",WebMain,sendData.sequenceId];
    NSString *title = sendData.forumTitle;
    NSString *content = @"让买卖工程机械更容易";
    NSString *videoImg = sendData.coverPicture;
        //分享
    [[YFShareView shareview] showInViewWithView:self.view type:5 shareImageURL:videoImg shareContent:content shareTitle:title shareUrl:shareUrl isAd:false contentShareType:SSDKContentTypeVideo];
    [YFShareView shareview].isShareSuccess = ^(NSString * msg){
        if ([msg isEqualToString:@"1"]) {
            NSDictionary *param = @{@"forumArticlePostId":sendData.forumArticlePostId};
            [[[ESNetworkManager updateArticlePostForwardNumber:param] map:^id(id value) {
                return value;
            }] subscribeNext:^(id  _Nullable x) {
                NSLog(@"此时分享自增返回的结果===%@", x);
                sendData.forwardNumber += 1;
                [self.collectionView reloadData];
            } error:^(NSError * _Nullable error) {
                [weakSelf.view showWarning:error.localizedDescription];
            }];
        }
    };
    [YFShareView shareview].reportAction = ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)( 0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[ESAlert API] mAlertWithTitle:@"提示" message:@"亲，您的举报我们已经受理，感谢您的监督！我们将及时处理。" :@"好" ];
        });
    };
    
}
/**
 * 删除
 **/
- (void)isDelete:(NewestListSendData *)sendData index:(NSInteger)index{
    mWeakSelf
    NSDictionary *param = @{@"forumArticlePostId":sendData.forumArticlePostId};
    [[[ESNetworkManager removeArticlePostInvitation:param] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        NSLog(@"删除返回的数据===%@", x);
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        [window showCustomView:[UIImage imageNamed:@"login_success"] title:@"删除成功"];
        [self.dataSource removeObjectAtIndex:index];
        [self requestInvitationAndVideoData];
        [[NSNotificationCenter defaultCenter] postNotificationName:YFDeletePostInvitation_success object:@"1"];
        [self.collectionView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [weakSelf.view showWarning:error.localizedDescription];
    }];
}

/*[cell.base.comment_btn tapHandle:^NSString *{
 [weakSelf isCommon:sendData];
 return @"点击评论";
 }];*/
- (void)isCommon:(NewestListSendData *)sendData indexPath:(NSIndexPath *)indexPath {
    YFUserModelSenddata *model = [YFFlieTool getUserModel];
    if (model) {
        YFForumFullScrollPlayerVC *vc = [[YFForumFullScrollPlayerVC alloc] init];
        vc.dataList = self.dataSource;
        vc.showIndex = indexPath.section;
        vc.page = self.page;
        vc.isMine = YES;
        [self.navigationController pushViewController:vc animated:YES];
    } else {
        [[ESAlert API] OkAlertWithTitle:@"提示" message:@"需要您登录后才能评论" :@"确定" :@"取消" vc:self sure:^{
            YFLoginVC *loginVC = [[YFLoginVC alloc] init];
            loginVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:loginVC animated:YES];
        }];
    }
}
- (void)isPush:(NewestListSendData *)sendData {
    YFPersonalHomeVC *vc = [[YFPersonalHomeVC alloc] init];
    vc.parameterStr = sendData.customerId;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -- 数据请求
- (void)requestInvitationAndVideoData {
    [self.view showBusyHUD];
    NSDictionary *dict = @{@"jsonParam":@{
                                   @"createBy":[YFFlieTool getUserModel].userId,
                                   @"customerId":[YFFlieTool getUserModel].userId,
                                   @"forumTypeFlag":@"1"
                                   },
                           @"page":@1,
                           @"rows":@10
                           };
    [[[ESNetworkManager findPostArticleControllerList:dict] map:^id(id value) {
        return [YFNewestListModel mj_objectWithKeyValues:value];;
    }] subscribeNext:^(YFNewestListModel *  _Nullable x) {
        NSLog(@"===%@====%ld", x, x.data.count);
        [self.collectionView endHeaderRefresh];
        [self.dataSource removeAllObjects];
        [self.dataSource addObjectsFromArray:x.data.sendData];
        if (self.dataSource.count == 0) {
            self.noDataView.hidden = NO;
        } else {
            self.noDataView.hidden = YES;
        }
        self.page = 1;
        [self.view hideBusyHUD];
        [self.collectionView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.view hideBusyHUD];
        [self.collectionView endHeaderRefresh];
    } completed:^{
        [self.collectionView endHeaderRefresh];
    }];
}

- (void)requestMoreData {
    NSDictionary *dict = @{@"jsonParam":@{
                                   @"createBy":[YFFlieTool getUserModel].userId,
                                   @"customerId":[YFFlieTool getUserModel].userId,
                                   @"forumTypeFlag":@"1"
                                   },
                           @"page":@(self.page+1),
                           @"rows":@10
                           };
    [[[ESNetworkManager findPostArticleControllerList:dict] map:^id(id value) {
        return [YFNewestListModel mj_objectWithKeyValues:value];;
    }] subscribeNext:^(YFNewestListModel *  _Nullable x) {
        NSLog(@"===%@====%ld", x, x.data.count);
        
        [self.dataSource addObjectsFromArray:x.data.sendData];
        [self.collectionView reloadData];
        [self.collectionView endFooterRefresh];
        if([x.data.sendData count] > 0){  self.page += 1;}
        if ([x.data.sendData count] == 0) {
            [self.collectionView endFooterRefreshWithNoMoreData];
        }
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endFooterRefresh];
    }];
}
//添加拍视频按钮
- (void)addActionBtn {
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [addBtn setTitle:@"发视频" forState:UIControlStateNormal];
    [addBtn setBackgroundColor:mHexColor(0xF48F4A)];
    addBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [addBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    addBtn.contentMode = UIViewContentModeScaleAspectFill;
    [addBtn setClipsToBounds:YES];
    addBtn.layer.cornerRadius = 50/2;
    addBtn.layer.masksToBounds = YES;
    [self.view addSubview:addBtn];
    [self.view bringSubviewToFront:addBtn];
    [addBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view.mas_right).with.offset(-16);
        make.width.and.height.equalTo(@(50));
        make.bottom.equalTo(self.view.mas_bottom).with.offset(-20);
    }];
    [addBtn addTarget:self action:@selector(addBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)addBtnClicked:(UIButton *)sender {
    
    YFUserModelSenddata* model = [YFFlieTool getUserModel];
    if (model) {
        _manager = [[YFGoRecordVideoManager alloc] initWithPushVC:self];
        [_manager pushRecordVC];
        __weak typeof(self)weakSelf = self;
        
        [_manager setPublishSuccessBlock:^{
            [weakSelf.collectionView.mj_header beginRefreshing];
        }];
        
    } else {
        YFLoginVC * loginVC = [[YFLoginVC alloc] init];
        loginVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:loginVC animated:YES];
    }
}


@end
