//
//  YFRealnameSystemVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFRealnameSystemVC.h"
#import "YFRealnameCell.h"
#import "YFRealnamePhotoCell.h"

#import "AssetsLibrary/AssetsLibrary.h"
#import "Photos/Photos.h"

#import "LPActionSheet.h"
#import "WCLImagePicker.h"
#import "YFBackShowInfoModel.h"

@interface YFRealnameSystemVC ()<UITableViewDelegate,UITableViewDataSource,WCLImagePickerDelegate> {
}
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) UIButton *submitBtn;
//是否是身份证封面,默认是NO
@property(nonatomic, assign) BOOL isBack;
@property(nonatomic, strong) UIImage *upImage;
@property(nonatomic, strong) UIImage *backImage;
@property(nonatomic, strong) UITextField *nameTF;
@property(nonatomic, strong) UITextField *idCardTF;

@property(nonatomic, strong) NSString *upImgUrl;
@property(nonatomic, strong) NSString *backImgeUrl;
@property(nonatomic, strong) NSString *upImgID;
@property(nonatomic, strong) NSString *backImgID;

@property(nonatomic, strong) UIView *tableHeadView;
@property(nonatomic, strong) UILabel *reasonLB;

@property(nonatomic, assign) BOOL needUp;
@property(nonatomic, assign) BOOL needBack;
@end

@implementation YFRealnameSystemVC

- (void)viewDidLoad {
    [super viewDidLoad];
    //默认需要传图片
    self.needUp = YES;
    self.needBack = YES;
    self.title = @"实名认证";
    self.view.backgroundColor = kBottomBgColor;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self submitBtn];
    [self tableView];
    if ([self.userModel.auditStatus isEqualToString:@"1"]) {
        self.tableView.tableHeaderView = self.tableHeadView;
        [self getBackShowInfo];
    }
    else {
        self.tableView.tableHeaderView = nil;
    }
}

//获取回显数据
- (void)getBackShowInfo {
    [self.view showBusyHUD];
    NSString *userID = self.userModel.userId;
    if (userID == nil) {
        userID = @"";
    }
    NSString *identificationId = self.userModel.identificationId;
    if (identificationId == nil) {
        identificationId = @"";
    }
    NSDictionary *jsonParam = @{@"keywords" : @"", @"auditStatus" : @"", @"identificationId" : identificationId, @"customerId" : userID};
    NSDictionary *bodyDic = @{@"jsonParam" : jsonParam, @"page" : @"1", @"rows" : @"1"};
    [[[ESNetworkManager getBackShowInfo:bodyDic] map:^id(id value) {
        return [YFBackShowInfoModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFBackShowInfoModel *  _Nullable x) {
        [self.view hideBusyHUD];
        self.nameTF.text = x.data.sendData.firstObject.realName;
        self.idCardTF.text = x.data.sendData.firstObject.cardId;
        self.upImgID = x.data.sendData.firstObject.cardFront;
        self.backImgID = x.data.sendData.firstObject.cardVerso;
        
        NSData *data = [NSData  dataWithContentsOfURL:[NSURL URLWithString:x.data.sendData.firstObject.cardFrontUrl]];
        self.upImage = [UIImage imageWithData:data];
        NSData *data2 = [NSData  dataWithContentsOfURL:[NSURL URLWithString:x.data.sendData.firstObject.cardVersoUrl]];
        self.backImage = [UIImage imageWithData:data2];
        [self.tableView reloadData];
        
        if (self.upImgID.length != 0) {
            self.needUp = NO;
        }
        if (self.backImgID.length != 0) {
            self.needBack = NO;
        }
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
}

- (void)realNameCertifyWithNeedUpImg:(BOOL)up backImg:(BOOL)back {
    NSString *name = self.nameTF.text;
    NSString *idCard = self.idCardTF.text;
    if (name.length == 0 ) {
        [self.view showWarning:@"请输入您的姓名"];
        return;
    }
    if (!name.isChineseWords) {
        [self.view showWarning:@"姓名格式有误，可输入中文，最多10个字符"];
        return;
    }
    
    if ( idCard.length == 0) {
        [self.view showWarning:@"请输入您的身份证号"];
        return;
    }
    
    if ([[StringUtil sharedInstance] validateIDCardNumber:idCard] == NO) {
        [self.view showWarning:@"格式有误，请输入正确的身份证号"];
        return;
    }
    if (up) {
        if (self.upImage == nil) {
            [self.view showWarning:@"请上传身份证正面照"];
            return;
        }
    }
    if (back) {
        if (self.backImage == nil) {
            [self.view showWarning:@"请上传身份证反面照"];
            return;
        }
    }

    UIImage *upCompressImg,*backCompressImg;
    if (up) {
        upCompressImg = [self.upImage imageCompressForSize:self.upImage targetSize:CGSizeMake(600, 600 / self.upImage.size.width * self.upImage.size.height)];
    }
    if (back) {
        backCompressImg = [self.backImage imageCompressForSize:self.backImage targetSize:CGSizeMake(600, 600 / self.backImage.size.width * self.backImage.size.height)];
    }
    
    NSData *imgData = UIImageJPEGRepresentation(upCompressImg, 0.3f);
    if (imgData == nil) {
        imgData = [NSData data];
    }
    NSDictionary * bodyDic = @{@"file":imgData,@"fileType":@"1",@"path":@"personal/base/"};

    NSData *imgData2 = UIImageJPEGRepresentation(backCompressImg, 0.3f);
    if (imgData2 == nil) {
        imgData2 = [NSData data];
    }
    NSDictionary * bodyDic2 = @{@"file":imgData2,@"fileType":@"1",@"path":@"personal/base/"};
    if (up && back) {
         [self sendPicUploadImages:@[imgData] UploadImages2:@[imgData2] params1:bodyDic params2:bodyDic2 name:name idCard:idCard];
    }else if (up && !back) {
        [self sendPicUploadImages:@[imgData] params1:bodyDic name:name idCard:idCard];
    }
    else if(back && !up){
        [self sendPicUploadImages2:@[imgData2] params2:bodyDic2 name:name idCard:idCard];
    }
    else {
        [self sendPicname:name idCard:idCard];
    }
    
}

// 图片上传 - 正反照片
-(void)sendPicUploadImages:(NSArray *)uploadImages1 UploadImages2:(NSArray *)uploadImages2  params1:(NSDictionary *)params1 params2:(NSDictionary *)params2   name: (NSString *)name idCard :(NSString *)idCard {
    [self.view showBusyHudWithText:@"正在上传..."];
    RACSignal * fisrt = [ESNetworkManager rac_uploadImages:uploadImages1 urlString:@"/OSSFile/multiFileUpload.json" params:params1 targetWidth:1.0];
    
     RACSignal * second = [ESNetworkManager rac_uploadImages:uploadImages2 urlString:@"/OSSFile/multiFileUpload.json" params:params2 targetWidth:1.0];

    [[RACSignal combineLatest:@[fisrt, second]] subscribeNext:^(RACTuple * x) {
    
        NSArray * array = (NSArray *)x.first;
        NSDictionary * dict = array.firstObject;
        self.upImgID = dict[@"id"];
        
         NSArray * array2 = (NSArray *)x.second;
         NSDictionary * dict2 = array2.firstObject;
        self.backImgID = dict2[@"id"];

        if (self.upImgID.length == 0 || self.backImgID.length == 0) {
            [self.view hideBusyHUD];
            [self.view showWarning:@"图片上传失败"];
            return;
        }
        NSString *userID = self.userModel.userId;
        if (userID == nil) {
            userID = @"";
        }
        NSString *identificationId = self.userModel.identificationId;
        if (identificationId == nil) {
            identificationId = @"";
        }
        NSDictionary *bodyDic = @{@"customerId" : userID, @"realName" : name, @"cardId" : idCard, @"cardFront" : self.upImgID, @"cardVerso" : self.backImgID, @"source" : @"2", @"userId" : userID, @"identificationId" : identificationId};
        [self realnameCertifyWith:bodyDic];
        
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
         [self.view showWarning:error.localizedDescription];
    }];

}

// 图片上传 - 正照片
-(void)sendPicUploadImages:(NSArray *)uploadImages1 params1:(NSDictionary *)params1 name: (NSString *)name idCard :(NSString *)idCard {
    [self.view showBusyHudWithText:@"正在上传..."];
    RACSignal * fisrt = [ESNetworkManager rac_uploadImages:uploadImages1 urlString:@"/OSSFile/multiFileUpload.json" params:params1 targetWidth:1.0];
    [[RACSignal combineLatest:@[fisrt]] subscribeNext:^(RACTuple * x) {
        NSArray * array = (NSArray *)x.first;
        NSDictionary * dict = array.firstObject;
        self.upImgID = dict[@"id"];
        if (self.upImgID.length == 0 || self.backImgID == 0) {
            [self.view hideBusyHUD];
            [self.view showWarning:@"图片上传失败"];
            return;
        }
        NSString *userID = self.userModel.userId;
        if (userID == nil) {
            userID = @"";
        }
        NSString *identificationId = self.userModel.identificationId;
        if (identificationId == nil) {
            identificationId = @"";
        }
        
        NSDictionary *bodyDic = @{@"customerId" : userID, @"realName" : name, @"cardId" : idCard, @"cardFront" : self.upImgID, @"cardVerso" : self.backImgID, @"source" : @"2", @"userId" : userID, @"identificationId" : identificationId};
        [self realnameCertifyWith:bodyDic];
        
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
}

// 图片上传 - 反照片
-(void)sendPicUploadImages2:(NSArray *)uploadImages2 params2:(NSDictionary *)params2 name: (NSString *)name idCard :(NSString *)idCard {
    [self.view showBusyHudWithText:@"正在上传..."];
    RACSignal * second = [ESNetworkManager rac_uploadImages:uploadImages2 urlString:@"/OSSFile/multiFileUpload.json" params:params2 targetWidth:1.0];
    
    [[RACSignal combineLatest:@[second]] subscribeNext:^(RACTuple * x) {
        
        NSArray * array2 = (NSArray *)x.first;
        NSDictionary * dict2 = array2.firstObject;
        //        self.backImgeUrl = dict2[@"fileAllUrl"];
        self.backImgID = dict2[@"id"];
        
        if (self.upImgID.length == 0 || self.backImgID.length == 0) {
            [self.view hideBusyHUD];
            [self.view showWarning:@"图片上传失败"];
            return;
        }
        NSString *userID = self.userModel.userId;
        if (userID == nil) {
            userID = @"";
        }
        NSString *identificationId = self.userModel.identificationId;
        if (identificationId == nil) {
            identificationId = @"";
        }
        
        NSDictionary *bodyDic = @{@"customerId" : userID, @"realName" : name, @"cardId" : idCard, @"cardFront" : self.upImgID, @"cardVerso" : self.backImgID, @"source" : @"2", @"userId" : userID, @"identificationId" : identificationId};
        [self realnameCertifyWith:bodyDic];
        
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
    
}

// 图片上传 - 不上传照片
-(void)sendPicname: (NSString *)name idCard :(NSString *)idCard {
    [self.view showBusyHUD];
    if (self.upImgID.length == 0 || self.backImgID.length == 0) {
        [self.view hideBusyHUD];
        [self.view showWarning:@"图片上传失败"];
        return;
    }
    NSString *userID = self.userModel.userId;
    if (userID == nil) {
        userID = @"";
    }
    NSString *identificationId = self.userModel.identificationId;
    if (identificationId == nil) {
        identificationId = @"";
    }
    
    NSDictionary *bodyDic = @{@"customerId" : userID, @"realName" : name, @"cardId" : idCard, @"cardFront" : self.upImgID, @"cardVerso" : self.backImgID, @"source" : @"2", @"userId" : userID, @"identificationId" : identificationId};
    [self realnameCertifyWith:bodyDic];
}

- (void)realnameCertifyWith:(NSDictionary *)bodyDic {
    [[[ESNetworkManager realNameCertify:bodyDic] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        [self.view hideBusyHUD];
        self.userModel.auditStatus = @"2";
        [YFFlieTool saveUserModel:self.userModel];
        [self.navigationController popViewControllerAnimated:YES];
        [kAppDelegate.window showWarning:@"提交成功"];
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
}

- (void)submitBtnClicked:(UIButton *)sender {
    [self realNameCertifyWithNeedUpImg:self.needUp backImg:self.needBack];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFRealnameCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFRealnameCell" forIndexPath:indexPath];
        cell.titleLB.text = @"姓名";
        cell.titleLB.tintColor = mRGBA(0, 0, 0, 0.87);
        cell.inputTF.placeholder = @"请输入您真实姓名";
           cell.inputTF.textColor =  mRGBA(0, 0, 0, 0.54);
        self.nameTF = cell.inputTF;
        return cell;
    }
    else if (indexPath.section == 1) {
        YFRealnameCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFRealnameCell" forIndexPath:indexPath];
        cell.titleLB.text = @"身份证号";
        cell.titleLB.tintColor = mRGBA(0, 0, 0, 0.87);
        cell.inputTF.placeholder = @"请输入您的身份证号";
        cell.inputTF.textColor =  mRGBA(0, 0, 0, 0.54);
        self.idCardTF = cell.inputTF;
        return cell;
    }
    else {
        YFRealnamePhotoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFRealnamePhotoCell" forIndexPath:indexPath];
        cell.upView.image = self.upImage;
        cell.backView.image = self.backImage;
        mWeakSelf
        [cell.upView tapHandle:^NSString *{
            weakSelf.isBack = NO;
            [weakSelf showActionSheet];
            return @"选择身份证正面照片";
        }];
        [cell.backView tapHandle:^NSString *{
            weakSelf.isBack = YES;
            [weakSelf showActionSheet];
            return @"选择身份证反面照片";
        }];
        return cell;
    }
}
- (void)showActionSheet {
    [self.view endEditing:YES];
    LPActionSheet * actionSheep = [[LPActionSheet alloc] initWithTitle:@"" cancelButtonTitle:@"取消" destructiveButtonTitle:@"" otherButtonTitles:@[@"拍照",@"从手机相册选择"] handler:^(LPActionSheet *actionSheet, NSInteger index) {
        [self pushVcWithIndex:index];
        NSLog(@"index=%ld",index);
    }];
    [actionSheep show];
}

- (void)pushVcWithIndex:(NSInteger)index {
    if (index==1) {
        [self.view endEditing:YES];
        [self takePhoto];
    }
    else if(index ==2) {
        [self.view endEditing:YES];
        WCLImagePicker *imagePicker = [WCLImagePicker sharedInstance];
        imagePicker.delegate = self;
        [imagePicker showImagePickerWithType:index InViewController:self heightCompareWidthScale:1.0 isCropImage:NO];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0 || indexPath.section == 1) {
        return 48;
    }
    else {
        return (mScreenWidth - 2)/2.0 * 9.0/16.0 + 30 + 50;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headV = [[UIView alloc] init];
    headV.backgroundColor = kBottomBgColor;
    return headV;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        if ([self.userModel.auditStatus isEqualToString:@"1"]) {
            return 0;
        }
        return 8;
    }
    else if (section == 1){
        return 2;
    }
    return 0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {}
#pragma mark -------- LazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight - NaviHeight - 48) style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.bottom.equalTo(-48);
        }];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        //注册cell
        [_tableView registerClass:[YFRealnameCell class] forCellReuseIdentifier:@"YFRealnameCell"];
        [_tableView registerClass:[YFRealnamePhotoCell class] forCellReuseIdentifier:@"YFRealnamePhotoCell"];
    }
    return _tableView;
}
- (UIButton *)submitBtn {
    if (!_submitBtn) {
        _submitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.view addSubview:_submitBtn];
        [_submitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(0);
            make.height.equalTo(48);
        }];
        _submitBtn.backgroundColor = kYellowColor;
        _submitBtn.titleLabel.font = KFont16;
        [_submitBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
        [_submitBtn setTitle:@"提 交" forState:UIControlStateNormal];
        [_submitBtn addTarget:self action:@selector(submitBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _submitBtn;
}

- (UIView *)tableHeadView {
    if (!_tableHeadView) {
        UILabel *hLB = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth - 16, 1)];
        hLB.numberOfLines = 0;
        hLB.font = [UIFont systemFontOfSize:13];
        hLB.text = self.userModel.auditResult;
        [hLB sizeToFit];
        CGFloat textH = hLB.mj_h;
        
        _tableHeadView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, 45+textH)];
        _tableHeadView.backgroundColor = kBottomBgColor;
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 8, mScreenWidth, 37+textH)];
        [_tableHeadView addSubview:bgView];
        bgView.backgroundColor = mHexColor(0xFFEBEE);
        
        UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"realname_lose"]];
        [bgView addSubview:icon];
        [icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(-29.5);
            make.width.height.equalTo(15);
            make.top.equalTo(9);
        }];
        UILabel *tipsLB = [[UILabel alloc] init];
        [bgView addSubview:tipsLB];
        [tipsLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(icon.mas_right).equalTo(4);
            make.width.equalTo(55);
            make.centerY.equalTo(icon);
            make.height.equalTo(13);
        }];
        tipsLB.font = [UIFont systemFontOfSize:13];
        tipsLB.textColor = mHexColor(0xF9908A);
        tipsLB.text = @"未通过";
        
        self.reasonLB = [[UILabel alloc] init];
        [bgView addSubview:self.reasonLB];
        [self.reasonLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(icon.mas_bottom).equalTo(4);
            make.left.equalTo(8);
            make.right.equalTo(-8);
            make.height.equalTo(textH);
        }];
        self.reasonLB.font = [UIFont systemFontOfSize:13];
        self.reasonLB.textColor = mHexColor(0xF9908A);
        self.reasonLB.textAlignment = NSTextAlignmentCenter;
        self.reasonLB.text = self.userModel.auditResult;
        self.reasonLB.numberOfLines = 0;
        if (textH > 18) {
            self.reasonLB.textAlignment = NSTextAlignmentLeft;
        }
        else {
            self.reasonLB.textAlignment = NSTextAlignmentCenter;
        }
    }
    return _tableHeadView;
}

#pragma mark - UIImagePickerController
- (void)takePhoto {
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if ((authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied) && iOS7Later) {
        // 无权限 做一个友好的提示
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"无法使用相机" message:@"请在iPhone的""设置-隐私-相机""中允许访问相机" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"设置", nil];
        [alert show];
#define push @#clang diagnostic pop
    } else { // 调用相机
        WCLImagePicker *imagePicker = [WCLImagePicker sharedInstance];
        imagePicker.delegate = self;
        [imagePicker showImagePickerWithType:0 InViewController:self heightCompareWidthScale:1.0 isCropImage:NO];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
#pragma clang diagnostic pop
    if (buttonIndex == 1) { // 去设置界面，开启相机访问权限
        NSURL *url = UIApplicationOpenSettingsURLString.lx_URL;
        if([[UIApplication sharedApplication] canOpenURL:url]) {
            if (@available(iOS 10.0, *)) {
                [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                }];
            } else {
                [[UIApplication sharedApplication] openURL:url];
            }
        }
    }
}


#pragma -mark WCLImagePickerDelegate
- (void)imagePicker:(WCLImagePicker *)imagePicker didFinished:(UIImage *)editedImag{
    if (self.isBack) {
        self.backImage = editedImag;
        self.needBack = YES;
    }
    else {
        self.upImage = editedImag;
        self.needUp = YES;
    }
    [self.tableView reloadData];
};

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [self.view endEditing:YES];
}

- (YFUserModelSenddata *)userModel {
    if (!_userModel) {
        _userModel = [YFFlieTool getUserModel];
    }
    return _userModel;
}
@end
