//
//  YFFrozenListViewController.m
//  jsyf_user
//
//  Created by pro on 2018/1/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFrozenListViewController.h"
#import "YFForzenTableViewCell.h"
#import "YFFrozenModel.h"
@interface YFFrozenListViewController ()
{
    NSInteger  pageIndex;
}
@property (nonatomic,strong)NSMutableArray<YFFrozenListpageList *> * frozenList;

@property(nonatomic, strong) UIView *tableHeaderView;
@end
static NSString * identified = @"frozenCell";
@implementation YFFrozenListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    pageIndex = 1;
    [self setupUI];
    [self requestData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (void)setEvent {
    mWeakSelf
    [_emptyView.refreshBtn tapHandle:^NSString *{
        [weakSelf requestData];
        return @"重新加载";
    }];
}

- (void)requestData {
    [kAppDelegate.window showBusyHUD];
    mWeakSelf;
    [[[ESNetworkManager getFrozenlistWithMemberId:[[ESToolAPI BtnAPI] getESHid] PageIndex:@"1" pageSize:@"10" Type:weakSelf.type] map:^id(id value) {
        return [YFFrozenModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFrozenModel *  _Nullable x) {
        [kAppDelegate.window hideBusyHUD];
        pageIndex = 2;
        [self.frozenList removeAllObjects];
        [self.frozenList addObjectsFromArray: x.data.pageList];
        [weakSelf.frozenTableView reloadData];
        [weakSelf.frozenTableView.mj_header endRefreshing];
        [weakSelf.frozenTableView.mj_footer endRefreshing];
        if (self.frozenList.count==0) {
            self.emptyView.hidden = NO;
        }
        else
        {
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        self.emptyView.hidden = NO;
        [kAppDelegate.window hideBusyHUD];
        [kAppDelegate.window showWarning:error.localizedDescription];
        [weakSelf.frozenTableView.mj_header endRefreshing];
        [weakSelf.frozenTableView.mj_footer endRefreshing];
    }];
}

- (void)requestDataRefresh
{
    __weak typeof (self)weakSelf = self;
    [self.frozenTableView.mj_footer resetNoMoreData];
    [[[ESNetworkManager getFrozenlistWithMemberId:[[ESToolAPI BtnAPI] getESHid] PageIndex:@"1" pageSize:@"10" Type:weakSelf.type] map:^id(id value) {
        return [YFFrozenModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFrozenModel *  _Nullable x) {
        pageIndex = 2;;
        [self.frozenList removeAllObjects];
        [self.frozenList addObjectsFromArray: x.data.pageList];
        [weakSelf.frozenTableView reloadData];
        [weakSelf.frozenTableView.mj_header endRefreshing];
        [weakSelf.frozenTableView.mj_footer endRefreshing];
        if (self.frozenList.count==0) {
            self.emptyView.hidden = NO;
        }
        else
        {
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        self.emptyView.hidden = NO;
        [kAppDelegate.window hideBusyHUD];
        [kAppDelegate.window showWarning:error.localizedDescription];
        [weakSelf.frozenTableView.mj_header endRefreshing];
        [weakSelf.frozenTableView.mj_footer endRefreshing];
    }];
}

- (void)downRequestData
{
    __weak typeof (self)weakSelf = self;
    [[[ESNetworkManager getFrozenlistWithMemberId:[[ESToolAPI BtnAPI] getESHid] PageIndex:@(pageIndex).stringValue pageSize:@"10" Type:weakSelf.type] map:^id(id value) {
        return [YFFrozenModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFrozenModel *  _Nullable x) {
        pageIndex ++;
        [self.frozenList addObjectsFromArray:x.data.pageList];
        [weakSelf.frozenTableView reloadData];
        [weakSelf.frozenTableView.mj_header endRefreshing];
        [weakSelf.frozenTableView.mj_footer endRefreshing];
        if (self.frozenList.count==0) {
            [weakSelf.frozenTableView endFooterRefreshWithNoMoreData];
        }
    } error:^(NSError * _Nullable error) {
        [kAppDelegate.window showWarning:error.localizedDescription];
        [weakSelf.frozenTableView.mj_header endRefreshing];
        [weakSelf.frozenTableView.mj_footer endRefreshing];
    }];
}


-(void)setupUI
{
    if (@available(iOS 11.0, *)) {
        self.frozenTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.view.backgroundColor = kBottomBgColor;
    [self.frozenTableView registerClass:[YFForzenTableViewCell class] forCellReuseIdentifier:identified];
    self.frozenTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(requestDataRefresh)];
    self.frozenTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(downRequestData)];
}

- (UITableView *)frozenTableView
{
    if (!_frozenTableView) {
        _frozenTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-40) style:UITableViewStylePlain];
        _frozenTableView.delegate = self;
        _frozenTableView.dataSource = self;
        _frozenTableView.estimatedRowHeight = 0;
        _frozenTableView.estimatedSectionHeaderHeight = 0;
        _frozenTableView.estimatedSectionFooterHeight = 0;
        _frozenTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _frozenTableView.tableHeaderView = self.tableHeaderView;
        [self.view addSubview:_frozenTableView];
    }
    return _frozenTableView;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.frozenList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 140.0f;
}

- (UITableViewCell * )tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    YFForzenTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identified];
    if (cell==nil) {
        cell = [[YFForzenTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identified];
    }
    YFFrozenListpageList * pageList = self.frozenList[indexPath.row];
    [self SetDateWithCell:cell WithModel:pageList];
    return cell;
}

- (void)SetDateWithCell:(YFForzenTableViewCell *)cell WithModel:(YFFrozenListpageList *)model {
    cell.operationTypeLabel.text = model.usefor;
    cell.amountLabel.text = [NSString stringWithFormat:@"%.2f元",model.money];
    cell.remarkLabel.text = model.remark;
    cell.freezeDateLabel.text = model.date;
}


- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-(TABBARHEIGHT)-40)];
        [self.view addSubview:_emptyView];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.refreshBtn.hidden = NO;
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
    }
    return _emptyView;
}

- (NSMutableArray<YFFrozenListpageList *>*)frozenList
{
    if (!_frozenList) {
        _frozenList = [NSMutableArray array];
    }
    return _frozenList;
}
- (UIView *)tableHeaderView {
    if (!_tableHeaderView) {
        _tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, 4)];
        _tableHeaderView.backgroundColor = kBottomBgColor;
    }
    return _tableHeaderView;
}
@end
