//
//  YFMyMoneyVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/31.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFMyMoneyVC.h"
#import "YFMyMoneyCell.h"
#import "YFMyMoneyRecordCell.h"
#import "YFRechargeRecordVC.h"
#import "YFFrozenViewController.h"
#import "YFMyMoneyModel.h"
#import "YFMoneyListModel.h"
#import "YFReturnRecordVC.h"

@interface YFMyMoneyVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) UIButton *payBackBtn;
@property(nonatomic, strong) YFMyMoneyData *myMoneyData;
@property(nonatomic, assign) NSInteger page;
@property(nonatomic, strong) NSMutableArray<YFMoneyListpageList *> *listData;
@property(nonatomic, strong) YFNoDataView *emptyView;
@end

@implementation YFMyMoneyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的资金";
    self.page = 1;
    self.view.backgroundColor = kBottomBgColor;
    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;//UIScrollView也适用
    }else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self addNaviRightBtn];
    mWeakSelf
    [self.tableView addBackFooterRefresh:^{
        [[[ESNetworkManager getMoneyListWithMemberId:[[ESToolAPI BtnAPI] getESHid] PageIndex:@(weakSelf.page).stringValue pageSize:@"10"] map:^id(id value) {
            return [YFMoneyListModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFMoneyListModel *  _Nullable x) {
            [weakSelf.tableView endFooterRefresh];
            if (x.data.pageList.count == 0) {
                [weakSelf.tableView endFooterRefreshWithNoMoreData];
            }
            weakSelf.page += 1;
            [weakSelf.listData addObjectsFromArray:x.data.pageList];
            [weakSelf.tableView reloadData];
        } error:^(NSError * _Nullable error) {
            [weakSelf.tableView endFooterRefresh];
            [weakSelf.view showWarning:error.localizedDescription];
        }];
    }];
    [self getMyMoneyData];
    [self getMoneyListData];
}
//请求我的资金
- (void)getMyMoneyData {
    [self.view showBusyHUD];
    [[[ESNetworkManager getMyMoneyWithMemberId:[[ESToolAPI BtnAPI] getESHid]] map:^id(id value) {
        return [YFMyMoneyModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFMyMoneyModel *  _Nullable x) {
        [self.view hideBusyHUD];
        self.myMoneyData = x.data;
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
}

//请求资金流水
- (void)getMoneyListData {
    [self.view showBusyHUD];
    [[[ESNetworkManager getMoneyListWithMemberId:[[ESToolAPI BtnAPI] getESHid] PageIndex:@"1" pageSize:@"10"] map:^id(id value) {
        return [YFMoneyListModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFMoneyListModel *  _Nullable x) {
        [self.view hideBusyHUD];
        self.page += 1;
        [self.listData removeAllObjects];
        [self.listData addObjectsFromArray:x.data.pageList];
        [self.tableView reloadData];
        if (self.listData.count == 0) {
            self.emptyView.hidden = NO;
        }
        else {
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
}

- (void)addNaviRightBtn {
    UIButton *rightBtn = [[UIButton alloc] init];
    rightBtn.frame = CGRectMake(0, 0, 60, 44);
    [rightBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [rightBtn addTarget:self action:@selector(rightBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    rightBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [rightBtn setTitle:@"返还记录" forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
}
- (void)rightBtnClick:(UIButton *)sender {
    YFReturnRecordVC *returnVC = [[YFReturnRecordVC alloc] init];
    [self.navigationController pushViewController:returnVC animated:YES];
}

#pragma mark -------- tableViewDelegate/Datasource --------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    } else {
        return self.listData.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 144;
    }
    else {
        return 73;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFMyMoneyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFMyMoneyCell" forIndexPath:indexPath];
        cell.canUseMoneyLB.text = @(self.myMoneyData.bailmoney).stringValue;
        cell.freezeMoneyLB.text = @(self.myMoneyData.bailmoneyfreeze).stringValue;
        mWeakSelf
        [cell.freezeBtn tapHandle:^NSString *{
            YFFrozenViewController *vc = [[YFFrozenViewController alloc] init];
            [weakSelf.navigationController pushViewController:vc animated:true];
            return @"冻结记录";
        }];
        [cell.rechargeRecordBtn tapHandle:^NSString *{
            YFRechargeRecordVC *recordVC = [[YFRechargeRecordVC alloc] init];
            [weakSelf.navigationController pushViewController:recordVC animated:YES];
            return @"充值记录";
        }];
        return cell;
    }
    else {
        YFMyMoneyRecordCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFMyMoneyRecordCell" forIndexPath:indexPath];
        cell.titleLB.text = self.listData[indexPath.row].usefor;
        cell.timeLB.text = self.listData[indexPath.row].date;
        cell.numberLB.text = [NSString stringWithFormat:@"%@ %.2f", self.listData[indexPath.row].direction, self.listData[indexPath.row].money];
        return cell;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headV = [[UIView alloc] init];
    headV.backgroundColor = kBottomBgColor;
    UILabel *tipLB = [[UILabel alloc] init];
    [headV addSubview:tipLB];
    [tipLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(0);
        make.left.equalTo(15);
        make.right.equalTo(-15);
    }];
    tipLB.font = [UIFont systemFontOfSize:15];
    tipLB.textColor = kDarkWordColor;
    tipLB.text = @"资金流水";
    if (section == 1) {
        tipLB.hidden = NO;
    } else {
        tipLB.hidden = YES;
    }
    return headV;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 1) {
        return 40;
    }
    else {
        return 8;
    }
}
#pragma mark -------- LazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight - NaviHeight) style:UITableViewStyleGrouped];  //-48按钮H
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.separatorColor = kLineColor;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _tableView.sectionFooterHeight = 0;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        //注册cell
        [_tableView registerClass:[YFMyMoneyCell class] forCellReuseIdentifier:@"YFMyMoneyCell"];
        [_tableView registerClass:[YFMyMoneyRecordCell class] forCellReuseIdentifier:@"YFMyMoneyRecordCell"];
    }
    return _tableView;
}

- (UIButton *)payBackBtn {
    if (!_payBackBtn) {
        _payBackBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.view addSubview:_payBackBtn];
        [_payBackBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(0);
            make.height.equalTo(48);
        }];
        _payBackBtn.backgroundColor = kYellowColor;
        _payBackBtn.titleLabel.font = KFont16;
        [_payBackBtn setTitleColor:kDarkWordColor forState:UIControlStateNormal];
        [_payBackBtn setTitle:@"返还" forState:UIControlStateNormal];
    }
    return _payBackBtn;
}

- (NSMutableArray<YFMoneyListpageList *> *)listData {
    if (!_listData) {
        _listData = [NSMutableArray array];
    }
    return _listData;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 192, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-192)];
        [self.tableView addSubview:_emptyView];
        [self.tableView bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
        
    }
    return _emptyView;
}
@end
