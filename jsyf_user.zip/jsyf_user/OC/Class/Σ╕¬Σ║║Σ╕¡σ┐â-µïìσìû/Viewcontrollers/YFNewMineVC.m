//
//  YFNewMineVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/10/23.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFNewMineVC.h"
#import "YFMineNormalCell.h"

#import "YFRealnameSystemVC.h"
#import "FeedBackViewController.h"
#import "YFMyMoneyVC.h"
#import "SettingViewController.h"
#import "HezuoViewController.h"
#import "AboutMeViewController.h"
#import "UserInfoViewController.h"
#import "YFMyVideoListVC.h"
#import "YFLoginVC.h"

#import "YFApplyJobRootVC.h"
#import "YFRequestJobRootVC.h"

#import "YFESJListVC.h"
#import "YFESJManagerRootVC.h"
#import "YFESJDredgeVC.h"

#import "YFInvitationAndVideoVC.h"
#import "YFMyFansAndFollowsVC.h"
#import "YFNewsCenterVC.h"

//
#import "YFMineNotLoginUserCell.h"
#import "YFMineLoginUserCell.h"
#import "YFMineFunctionCell.h"
#import "YFMineESJAndToolCell.h"

#import "YFGameKeyListVC.h"//游戏密钥列表
#import "YFMyInvitationVC.h"
#import "YFHeadListVC.h"

@interface YFNewMineVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, assign) BOOL isLogin;
@property(nonatomic, strong) NSArray *titleList;
@property(nonatomic, strong) NSArray *imgList;
@property(nonatomic, strong) YFUserModelSenddata *userModel;
@property(nonatomic, strong) NSString *type;
@property(nonatomic, strong) NSString *number;

@property (nonatomic, strong) NSString *fansNum;//粉丝数
@property (nonatomic, strong) NSString *focusNum;//关注数
@property (nonatomic, strong) NSString *invitationNum;//帖子数
@property(nonatomic, strong) UIButton *rightBtn;
@property(nonatomic, strong) UIView *redPoint;
@property(nonatomic, assign) CGFloat alpha;
@property(nonatomic, strong)  UILabel *titleLabel;

@end

@implementation YFNewMineVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.titleLabel = [UILabel new];
    self.titleLabel.textColor = k333Color;
    self.titleLabel.font = kFont_PF_Regular(17);
    self.titleLabel.text = @"我的";
    self.navigationItem.titleView = self.titleLabel;
    self.title = @"我的";
    
    [self addNaviLeftBtn];
    self.view.backgroundColor = kBottomBgColor;
    [self setInsetNoneWithScrollView:self.tableView];
    self.userModel = [YFFlieTool getUserModel];
    if (self.userModel) {
        self.isLogin = YES;
        [self requestAttendAndInvitationData];
    } else {
        self.isLogin = NO;
    }
    self.number = @"0";
    
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"navback_icon"] forBarMetrics:UIBarMetricsDefault];
    [self wr_setNavBarShadowImageHidden:YES];
    [self addActionBtn];//暂时注释掉
 
}


//添加导航左按钮
- (void)addNaviLeftBtn {
    self.rightBtn = [[UIButton alloc] init];
    self.rightBtn.frame = CGRectMake(0, 0, 45, 44);
    [self.rightBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
    self.rightBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    self.rightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [self.rightBtn addTarget:self action:@selector(rightBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.rightBtn setImage:[UIImage imageNamed:@"消息"] forState:UIControlStateNormal];
    self.redPoint = [[UIView alloc] initWithFrame:CGRectMake(39, 10, 8, 8)];
    [self.rightBtn addSubview:self.redPoint];
    self.redPoint.backgroundColor = kRedColor;
    self.redPoint.clipsToBounds = YES;
    self.redPoint.layer.cornerRadius = 4;
    self.redPoint.hidden = YES;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.rightBtn];
}

//消息中心
- (void)rightBtnClick:(UIButton *)sender {
    if ([YFFlieTool getUserModel] == nil) {
        YFLoginVC *vc = [[YFLoginVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else if ([[RCIM sharedRCIM] getConnectionStatus] != ConnectionStatus_Connected) {
        YFLoginVC *vc = [[YFLoginVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else {
        YFNewsCenterVC *vc = [[YFNewsCenterVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}
//分享操作
- (void)shareClick:(UIButton *)sender {
    
    NSString *str = [NSString stringWithFormat:@"%@/d",YFWebMain];
    [[YFShareView shareview] showInViewWithView:self.view type:0 shareImageURL:@"" shareContent:@"感谢您把app分享给更多人, 快喊朋友来下载，世界因同用一个app而精彩" shareTitle:@"灜沣工程机械网-让买卖工程机械更容易" shareUrl:str isAd:false contentShareType:SSDKContentTypeAuto];
    [YFShareView shareview].isShareSuccess = ^(NSString * msg){
        
    };
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = NO;
    [self scrollViewDidScroll:self.tableView];
    [self wr_setNavBarShadowImageHidden:YES];
    [self modelFor];
    self.userModel = [YFFlieTool getUserModel];
    if (self.userModel) {
        self.isLogin = YES;
        [[ESToolAPI BtnAPI] getESHInfos];
    } else {
        self.isLogin = NO;
    }
    if (self.isLogin) {
        [self requestAttendAndInvitationData];
        if (self.userModel.usedBusinessFlag == 1){
            self.titleList = @[@"推荐给好友",@"设置",@"合作",@"关于",@"意见反馈"];
            self.imgList = @[@"newshare",@"setting",@"partner",@"about_us",@"feed_back"];
            
        }else{
            self.titleList = @[@"推荐给好友",@"设置",@"合作",@"关于",@"意见反馈"];
            self.imgList = @[@"newshare",@"setting",@"partner",@"about_us",@"feed_back"];
        }
        //
        [self requestDataRefresh];
    }
    else {
        self.titleList = @[@"推荐给好友",@"设置",@"合作",@"关于"];
        self.imgList = @[@"newshare",@"setting",@"partner",@"about_us"];
        
    }
    [self.tableView reloadData];
    
    //是否展示小红点
        if (self.userModel == nil) {
            self.redPoint.hidden = YES;
        } else {
            [[[YFFlieTool alloc] init] getRedPointNum:^(NSInteger redNum) {
                if (redNum > 0) {
                    self.redPoint.hidden = NO;
                } else {
                    self.redPoint.hidden = YES;
                }
            }];
        }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:mHexColor(0xffffff)] forBarMetrics:UIBarMetricsDefault];
    [self wr_setNavBarShadowImageHidden:NO];
}

//获取小红点个数
- (void)modelFor {
    [[ESNetworkManager getNumeber] subscribeNext:^(id  _Nullable x) {
        NSString * str = x[@"data"][@"sendData"][@"inquiry"][@"receivedNotCount"];
        NSLog(@"%@",str);
        self.number =  [NSString stringWithFormat:@"%@",str];//String(format:"%@",str);
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        
    }];
}


- (void)requestDataRefresh {
    
    if (self.userModel.username== nil) {
        self.userModel.username = @"";
    }
    if (self.userModel.loginSecretKey == nil) {
        self.userModel.loginSecretKey = @"";
    }
    NSString * password =  [[NSUserDefaults standardUserDefaults] objectForKey:@"password"];
    
    if (password == nil) {
        password  = @"";
    }
    NSDictionary * sendData = [[NSUserDefaults standardUserDefaults] objectForKey:@"LoginParam_SendData"];
    
    
    if (self.userModel.username.length != 0 && self.userModel.loginSecretKey.length != 0)
    {
        NSDictionary * bodyDic = @{@"phoneNumber":self.userModel.username,@"LOGIN_SECRET_KEY":self.userModel.loginSecretKey};
        
        [[[ESNetworkManager validateLoginKeyWithParam:bodyDic] map:^id(id value) {
            return [YFUserModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFUserModel *  _Nullable x) {
            x.data.sendData.loginSecretKey = self.userModel.loginSecretKey;
            [YFFlieTool saveUserModel:x.data.sendData];
            self.userModel = x.data.sendData;
            [JPUSHService setAlias:x.data.sendData.userId completion:nil seq:0];
            [self.tableView reloadData];
        } error:^(NSError * _Nullable error) {
            //            if (error.code==1 ) {
            [self.view showWarning:error.localizedDescription];
            [YFFlieTool saveUserModel:nil];
            // [KeychainTool deleteKeychainValue:USERNAME];
            [KeychainTool deleteKeychainValue:PASSWORD];
            [[RCIM sharedRCIM] disconnect];
            [JPUSHService deleteAlias:nil seq:0];
            
            self.isLogin = NO;
            self.titleList = @[@"推荐给好友",@"设置",@"合作",@"关于"];
            self.imgList = @[@"newshare",@"setting",@"partner",@"about_us"];
            //            }
            [self.tableView reloadData];
            
        } completed:^{
            
        }];
    }else  if (self.userModel.username.length != 0 && password.length != 0)
    {
        NSDictionary * bodyDic = @{@"username":self.userModel.username,@"password":password};
        [[[ESNetworkManager userLoginwithParam:bodyDic] map:^id(id value) {
            return [YFUserModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFUserModel *  _Nullable x) {
            [YFFlieTool saveUserModel:x.data.sendData];
            self.userModel = x.data.sendData;
            [JPUSHService setAlias:x.data.sendData.userId completion:^(NSInteger iResCode, NSString *iAlias, NSInteger seq) {
                
            } seq:0];
            
            [self.tableView reloadData];
        } error:^(NSError * _Nullable error) {
            //            if (error.code==1 ) {
            [self.view showWarning:error.localizedDescription];
            [YFFlieTool saveUserModel:nil];
            // [KeychainTool deleteKeychainValue:USERNAME];
            [KeychainTool deleteKeychainValue:PASSWORD];
            [[RCIM sharedRCIM] disconnect];
            [JPUSHService deleteAlias:nil seq:0];
            self.isLogin = NO;
            self.titleList = @[@"推荐给好友",@"设置",@"合作",@"关于"];
            self.imgList = @[@"newshare",@"setting",@"partner",@"about_us"];
            //            }
            [self.tableView reloadData];
        } completed:^{
        }];
    }else if(sendData&&password.length == 0){
        NSDictionary * bodyDic = sendData;
        [[[ESNetworkManager userLoginwithParam:bodyDic] map:^id(id value) {
            return [YFUserModel mj_objectWithKeyValues:value];
        }] subscribeNext:^(YFUserModel *  _Nullable x) {
            [YFFlieTool saveUserModel:x.data.sendData];
            self.userModel = x.data.sendData;
            [JPUSHService setAlias:x.data.sendData.userId completion:^(NSInteger iResCode, NSString *iAlias, NSInteger seq) {
                
            } seq:0];
            
            [self.tableView reloadData];
        } error:^(NSError * _Nullable error) {
            //            if (error.code==1 ) {
            [self.view showWarning:error.localizedDescription];
            [YFFlieTool saveUserModel:nil];
            // [KeychainTool deleteKeychainValue:USERNAME];
            [KeychainTool deleteKeychainValue:PASSWORD];
            [[RCIM sharedRCIM] disconnect];
            [JPUSHService deleteAlias:nil seq:0];
            self.isLogin = NO;
            self.titleList = @[@"推荐给好友",@"设置",@"合作",@"关于"];
            self.imgList = @[@"newshare",@"setting",@"partner",@"about_us"];
            //            }
            [self.tableView reloadData];
        } completed:^{
        }];
    } else {
        [YFFlieTool saveUserModel:nil];
        self.isLogin = NO;
        self.titleList = @[@"推荐给好友",@"设置",@"合作",@"关于"];
        self.imgList = @[@"newshare",@"setting",@"partner",@"about_us"];
        [self.tableView reloadData];
        
    }
}
#pragma mark -------- tableViewDelegate/Datasource --------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.isLogin) {
        return 5;
    } else {
        return 2;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.isLogin) {
        if (section == 4) {
            return self.titleList.count;
        } else {
            return 1;
        }
    }
    else {
        if (section == 1) {
            return self.titleList.count;
        }
        else {
            return 1;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.isLogin) {
        if (indexPath.section == 0) {
            YFMineLoginUserCell *userCell = [tableView dequeueReusableCellWithIdentifier:@"YFMineLoginUserCell"];
            
            userCell.infoView.invitNumlabel.text = _invitationNum;
            userCell.infoView.fansNumLabel.text = _fansNum;
            userCell.infoView.attNumLabel.text = _focusNum;
            [userCell fullCellWithModel:self.userModel];
            userCell.type = self.userModel.auditStatus;
            if (self.userModel.signature.length <= 0) {
                userCell.signatureLB.attributedText =
                [userCell stringWithUIImage:@"这个用户很懒，什么都没有留下~  "];
            }else{
                userCell.signatureLB.attributedText = [userCell stringWithUIImage:self.userModel.signature];
            }
            [userCell.infoView.attention_btn tapHandle:^NSString *{
                YFMyFansAndFollowsVC *vc = [[YFMyFansAndFollowsVC alloc] init];
                vc.joinFans = @"follow";
                vc.title_Str = @"我的关注";
                [self.navigationController pushViewController:vc animated:YES];
                return @"关注";
            }];
            
            [userCell.infoView.fans_btn tapHandle:^NSString *{
                YFMyFansAndFollowsVC *vc = [[YFMyFansAndFollowsVC alloc] init];
                vc.joinFans = @"fans";
                vc.title_Str = @"我的粉丝";
                [self.navigationController pushViewController:vc animated:YES];
                return @"粉丝";
            }];
            
            [userCell.infoView.invitation_btn tapHandle:^NSString *{
//                YFInvitationAndVideoVC *vc = [[YFInvitationAndVideoVC alloc] init];
//                [self.navigationController pushViewController:vc animated:NO];
                YFMyInvitationVC * vc = [[YFMyInvitationVC alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
                return @"帖子";
            }];
            
            return userCell;
            
        } else if (indexPath.section == 1) {
            YFMineFunctionCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFMineFunctionCell"];
            cell.userModel = self.userModel;
            return cell;
        } else if (indexPath.section == 2) {
            YFMineESJAndToolCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFMineESJAndToolCell"];
            if (self.userModel.usedBusinessFlag == 0) {
                cell.collView.hidden = YES;
                cell.esView.hidden = NO;
            } else {
                cell.collView.hidden = NO;
                cell.esView.hidden = YES;
                cell.isSelectTool = NO;
                cell.userModel = self.userModel;
                cell.number = self.number;
            }
            cell.ver_leftLB.text = @"二手机";
            cell.imgArray = @[@"mineIssue_n"];//,@"equi_n"
            cell.titleArray = @[@"我的发布"];//,@"收到询价"
            return cell;
        }else if (indexPath.section == 3) {
            YFMineESJAndToolCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFMineESJAndToolCell"];
            cell.ver_leftLB.text = @"工具";
            cell.isSelectTool = YES;
            cell.imgArray = @[@"job_n",@"recruit_n"];
            cell.titleArray = @[@"求职",@"招聘"];
            return cell;
        } else {
            YFMineNormalCell *normalCell = [tableView dequeueReusableCellWithIdentifier:@"YFMineNormalCell" forIndexPath:indexPath];
            normalCell.titleLB.text = self.titleList[indexPath.row];
            normalCell.iconIV.image = [UIImage imageNamed:self.imgList[indexPath.row]];
            normalCell.hotL.hidden = YES;
            return normalCell;
        }
    } else {
        if (indexPath.section == 0) {
            YFMineNotLoginUserCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFMineNotLoginUserCell"];
            mWeakSelf
            [cell.loginBtn tapHandle:^NSString *{
                YFLoginVC * loginVC = [[YFLoginVC alloc] init];
                loginVC.hidesBottomBarWhenPushed = YES;
                [weakSelf.navigationController pushViewController:loginVC animated:YES];
                return @"登录";
            }];
            return cell;
        } else {
            YFMineNormalCell *normalCell = [tableView dequeueReusableCellWithIdentifier:@"YFMineNormalCell" forIndexPath:indexPath];
            normalCell.titleLB.text = self.titleList[indexPath.row];
            normalCell.iconIV.image = [UIImage imageNamed:self.imgList[indexPath.row]];
            normalCell.hotL.hidden = YES;
            
            return normalCell;
        }
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    if (self.isLogin) {
        if (indexPath.section == 0) {
            return 146+10;
        } else if (indexPath.section == 1) {
            return 80;
        } else if (indexPath.section == 2|| indexPath.section == 3) {
            return 110;
        } else if (indexPath.section == 4) {
            return 48;
        } else {
            return 100;
        }
    } else {
        if (indexPath.section == 1) {
            return 48;
        } else {
            return 96;
        }
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headV = [[UIView alloc] init];
    headV.backgroundColor = kBottomBgColor;
    return headV;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (self.isLogin) {
        if (section == 0 || section == 1) {
            return 0.01;
        } else {
            return 16;
        }
    } else {
        if (section == 0) {
            return 0.01;
        } else {
            return 10;
        }
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}
//selectRow
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    YFHistoricalSignatures *vc = [[YFHistoricalSignatures alloc] init];
    [self.navigationController pushViewController:vc animated:true];
    return;
    
    if (self.isLogin) {
        if (indexPath.section == 0) {
            UserInfoViewController * userInfoVC= [[UserInfoViewController alloc] init];
            userInfoVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:userInfoVC animated:YES];
        } else if (indexPath.section == 2) {
            if (self.userModel.usedBusinessFlag == 0) {
                YFESJDredgeVC *vc = [[YFESJDredgeVC alloc] init];
                vc.userModel = self.userModel;
                [self.navigationController pushViewController:vc animated:YES];
            }
        } else if (indexPath.section == 4) {
            NSString *title = self.titleList[indexPath.row];
            [self didSelectRowWithTitle:title];
        }
    } else {
        if (indexPath.section == 0) {

        } else {
            NSString *title = self.titleList[indexPath.row];
            [self didSelectRowWithTitle:title];
        }
    }
}

- (void)didSelectRowWithTitle:(NSString *)title {
    if([title isEqualToString:@"推荐给好友"]) {
        [self shareClick:nil];
    } else if([title isEqualToString:@"设置"]) {
        SettingViewController * settingVC = [[SettingViewController alloc] initWithIsLogin:self.isLogin];
        settingVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:settingVC animated:YES];
    }
    else if([title isEqualToString:@"意见反馈"]) {
        FeedBackViewController * feedBackVc = [[FeedBackViewController alloc] initWithNibName:@"FeedBackViewController" bundle:nil];
        feedBackVc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:feedBackVc animated:YES];
    }
    else if([title isEqualToString:@"合作"]) {
        HezuoViewController * hezuoVC = [[HezuoViewController alloc] init];
        [self.navigationController pushViewController:hezuoVC animated:YES];
       
    }
    else if([title isEqualToString:@"关于"]) {
        AboutMeViewController * aboutMeVC = [[AboutMeViewController alloc] init];
        [self.navigationController pushViewController:aboutMeVC animated:YES];
    }
}
#pragma mark -------- LazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, -1, mScreenWidth, mScreenHeight - NaviHeight - TABBARHEIGHT) style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//        _tableView.separatorColor = kLineColor;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
//        _tableView.bounces = NO;
        //注册cell
        [_tableView registerClass:[YFMineNormalCell class] forCellReuseIdentifier:@"YFMineNormalCell"];
        [_tableView registerClass:[YFMineLoginUserCell class]  forCellReuseIdentifier:@"YFMineLoginUserCell"];
        [_tableView registerClass:[YFMineNotLoginUserCell class] forCellReuseIdentifier:@"YFMineNotLoginUserCell"];
        [_tableView registerClass:[YFMineESJAndToolCell class] forCellReuseIdentifier:@"YFMineESJAndToolCell"];
        [_tableView registerClass:[YFMineFunctionCell class] forCellReuseIdentifier:@"YFMineFunctionCell"];
        
    }
    return _tableView;
}
//获取关注数，粉丝数和帖子数
- (void)requestAttendAndInvitationData {
    
    [[ESNetworkManager findFocusCountAndFansCount] subscribeNext:^(id  _Nullable x) {
        if ([x[@"data"][@"sendData"] isKindOfClass:[NSDictionary class]]) {
            self.fansNum = x[@"data"][@"sendData"][@"fansCount"];
            self.focusNum = x[@"data"][@"sendData"][@"focusCount"];
            self.invitationNum = x[@"data"][@"sendData"][@"forumCount"];
            NSLog(@"拿到的数据===%@===%@==%@", _fansNum, _focusNum, _invitationNum);
            [self.tableView reloadData];
        }
        
    } error:^(NSError * _Nullable error) {
    }];
    
}

//页面滑动
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //头部去除弹性效果,底部保留 _tableView.bounces = YES;
    if (scrollView == self.tableView) {
        CGFloat offY = scrollView.contentOffset.y;
        if (offY < 0) {
            scrollView.contentOffset = CGPointZero;
        }
    }
    //计算导航栏的透明度
    CGFloat minAlphaOffset = 0;
    CGFloat maxAlphaOffset = 146+10;
//    if (!self.isLogin) {
//        maxAlphaOffset = 96;
//    }
    CGFloat offset = scrollView.contentOffset.y;
    self.alpha = (offset - minAlphaOffset) / (maxAlphaOffset - minAlphaOffset);
    if (self.alpha <= 0) {
        self.alpha = 0.0;
    }
    if (self.alpha >= 1) {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:mHexColor(0xFFFFFF)] forBarMetrics:UIBarMetricsDefault];
        [self wr_setNavBarShadowImageHidden:NO];
        [self.rightBtn setImage:[UIImage imageNamed:@"message_icon"] forState:UIControlStateNormal];
        self.titleLabel.textColor = k333Color;
    }
    else {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"navback_icon"] forBarMetrics:UIBarMetricsDefault];
        [self wr_setNavBarShadowImageHidden:YES];
        [self.rightBtn setImage:[UIImage imageNamed:@"消息"] forState:UIControlStateNormal];
        self.titleLabel.textColor = [UIColor clearColor];
    }
    [self setNeedsStatusBarAppearanceUpdate];
}

//修改电池条颜色
- (UIStatusBarStyle)preferredStatusBarStyle {
    if (self.alpha >= 1) {
        return UIStatusBarStyleDefault;
    }
    return UIStatusBarStyleLightContent;
}
/**
 * 获取游戏密钥
 **/
- (void)addActionBtn {
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    addBtn.hidden = true;
    [addBtn setImage:[UIImage imageNamed:@"game_n"] forState:UIControlStateNormal];
    addBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    addBtn.contentMode = UIViewContentModeScaleAspectFill;
    [addBtn setClipsToBounds:YES];
    [self.view addSubview:addBtn];
    [self.view bringSubviewToFront:addBtn];
    [addBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view.mas_right).equalTo(-16);
        make.height.equalTo(76);
        make.width.equalTo(80);
        make.bottom.equalTo(self.view.mas_bottom).equalTo(-30);
    }];
    [addBtn addTarget:self action:@selector(addBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)addBtnClicked:(UIButton *)sender {
    YFUserModelSenddata* model = [YFFlieTool getUserModel];
    if (model) {
        YFGameKeyListVC *vc = [[YFGameKeyListVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
        return;
    } else {
        YFLoginVC * loginVC = [[YFLoginVC alloc] init];
        loginVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:loginVC animated:YES];
    }
   
}
@end
