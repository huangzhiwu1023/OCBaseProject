//
//  YFRechargeChildVC.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/31.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFRechargeChildVC : UIViewController
@property(nonatomic, strong) NSString *stateStr;
//- (void)refreshAction;
@end
