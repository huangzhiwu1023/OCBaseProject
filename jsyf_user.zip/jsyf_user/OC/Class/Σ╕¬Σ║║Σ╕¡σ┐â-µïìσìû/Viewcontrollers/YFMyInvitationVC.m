//
//  YFMyInvitationVC.m
//  jsyf_user
//
//  Created by 程辉 on 2018/8/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFMyInvitationVC.h"

#import "YFNewestListModel.h"

#import "YFNewListPictureViewCell.h"
#import "YFNewListViewCell.h"
#import "YFNewListPictZeroViewCell.h"
#import "YFNewListPictureThereCell.h"
#import "YFNoDataView.h"
#import "YFInvitationDetailVC.h"
#import "YFPersonalHomeVC.h"
#import "YFVideoNavigationController.h"
#import "YFPostStyleSelectVC.h"
#import "PopoverView.h"
#import "YFPostInvitationVC.h"

@interface YFMyInvitationVC ()
<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView *collectionView;

@property (nonatomic, assign) NSInteger page;

@property(nonatomic, strong) NSMutableArray<NewestListSendData *> *dataSource;

@property (nonatomic, strong) YFNoDataView *noDataView;

@end

@implementation YFMyInvitationVC
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    [self.navigationController setNavigationBarHidden:NO animated:YES];
    self.navigationController.navigationBar.hidden = NO;

    [self.collectionView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的帖子";
    self.view.backgroundColor = [UIColor whiteColor];
    
    UICollectionViewFlowLayout *flowLayout = [UICollectionViewFlowLayout new];
    flowLayout.minimumInteritemSpacing = 8;
//    UIEdgeInsetsMake(<#CGFloat top#>, <#CGFloat left#>, <#CGFloat bottom#>, <#CGFloat right#>)
    flowLayout.sectionInset = UIEdgeInsetsMake(16, 5, -2, 5);
    
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight-NaviHeight) collectionViewLayout:flowLayout];
    self.collectionView.backgroundColor = mHexColor(0xF3F3F3);
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.view addSubview:_collectionView];
    [self setInsetNoneWithScrollView:self.collectionView];
    [_collectionView registerClass:[YFNewListPictureViewCell class] forCellWithReuseIdentifier:@"YFNewListPictureViewCell"];
    [_collectionView registerClass:[YFNewListViewCell class] forCellWithReuseIdentifier:@"YFNewListViewCell"];
    [_collectionView registerClass:[YFNewListPictZeroViewCell class] forCellWithReuseIdentifier:@"YFNewListPictZeroViewCell"];
    [_collectionView registerClass:[YFNewListPictureThereCell class] forCellWithReuseIdentifier:@"YFNewListPictureThereCell"];
    
    self.page = 1;
    mWeakSelf
    [self.collectionView addHeaderRefresh:^{
        [weakSelf.collectionView endFooterRefresh];
        [weakSelf.collectionView.mj_footer resetNoMoreData];
        [weakSelf requestInvitationAndVideoData];
    }];
    [self requestInvitationAndVideoData];
    [self.collectionView addBackFooterRefresh:^{
        [weakSelf.collectionView endHeaderRefresh];
        [weakSelf requestMoreData];
    }];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateIsZanWay:) name:@"updateIsZanWay" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(needLoginUpdate:) name:@"needLoginUpdate" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(postUpdateSuccess) name:YFPostUpdate_success object:nil];
    
    [self addActionBtn];
    
}
- (void)updateIsZanWay:(NSNotification *)notification {
        [self.collectionView reloadData];
}
- (void)needLoginUpdate:(NSNotification *)notification {
        [[ESAlert API] OkAlertWithTitle:@"提示" message:@"需要您登录后才能点赞" :@"确定" :@"取消" vc:self sure:^{
            YFLoginVC *loginVC = [[YFLoginVC alloc] init];
            loginVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:loginVC animated:YES];
        }];
}
- (void)postUpdateSuccess {
    [self requestInvitationAndVideoData];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -- UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return self.dataSource.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 1;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NewestListSendData *sendData = self.dataSource[indexPath.section];
    if ([sendData.forumTypeFlag isEqualToString:@"0"]) {
        if (sendData.contentList.count == 0) {
            YFNewListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFNewListViewCell" forIndexPath:indexPath];
            cell.send_data = sendData;
            mWeakSelf
            [cell.base.relay_btn tapHandle:^NSString *{
                [weakSelf isShare:sendData];
                return @"转发";
            }];
            [cell.base.comment_btn tapHandle:^NSString *{
                [weakSelf isCommon:sendData];
                return @"点击评论";
            }];
            [cell.dele_btn tapHandle:^NSString *{
                PopoverView *popV = [[PopoverView alloc] init];
                popV.style = PopoverViewStyleDefault;
                PopoverAction *action = [PopoverAction actionWithTitle:@"    删除    " handler:^(PopoverAction *action) {
                    [weakSelf isDelete:sendData];
                }];
                [popV showToView:cell.dele_btn withActions:@[action]];
                return @"删除帖子";
            }];
            [cell.header_btn tapHandle:^NSString *{
                [weakSelf isPush:sendData];
                return @"";
            }];
            
            return cell;
        } else if (sendData.contentList.count == 1) {
            YFNewListPictureViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFNewListPictureViewCell" forIndexPath:indexPath];
            cell.play_btn.hidden = YES;
            cell.send_data = sendData;
            mWeakSelf
            [cell.base.relay_btn tapHandle:^NSString *{
                [weakSelf isShare:sendData];
                return @"转发";
            }];
            [cell.base.comment_btn tapHandle:^NSString *{
                [weakSelf isCommon:sendData];
                return @"点击评论";
            }];
            [cell.dele_btn tapHandle:^NSString *{
                PopoverView *popV = [[PopoverView alloc] init];
                popV.style = PopoverViewStyleDefault;
                PopoverAction *action = [PopoverAction actionWithTitle:@"    删除    " handler:^(PopoverAction *action) {
                    [weakSelf isDelete:sendData];
                }];
                [popV showToView:cell.dele_btn withActions:@[action]];
                return @"删除帖子";
            }];
            [cell.header_btn tapHandle:^NSString *{
                [weakSelf isPush:sendData];
                return @"";
            }];
            return cell;
        } else if (sendData.contentList.count == 2) {
            YFNewListPictZeroViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFNewListPictZeroViewCell" forIndexPath:indexPath];
            cell.send_data = sendData;
            cell.dataSource = sendData.contentList.mutableCopy;
            mWeakSelf
            [cell.base.relay_btn tapHandle:^NSString *{
                [weakSelf isShare:sendData];
                return @"转发";
            }];
            [cell.base.comment_btn tapHandle:^NSString *{
                [weakSelf isCommon:sendData];
                return @"点击评论";
            }];
            [cell.dele_btn tapHandle:^NSString *{
                PopoverView *popV = [[PopoverView alloc] init];
                popV.style = PopoverViewStyleDefault;
                PopoverAction *action = [PopoverAction actionWithTitle:@"    删除    " handler:^(PopoverAction *action) {
                    [weakSelf isDelete:sendData];
                }];
                [popV showToView:cell.dele_btn withActions:@[action]];
                return @"删除帖子";
            }];
            [cell.header_btn tapHandle:^NSString *{
                [weakSelf isPush:sendData];
                return @"";
            }];
            return cell;
        } else if (sendData.contentList.count >= 3) {
            YFNewListPictureThereCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFNewListPictureThereCell" forIndexPath:indexPath];
            cell.send_data = sendData;
            cell.dataSource = sendData.contentList.mutableCopy;
            mWeakSelf
            [cell.base.relay_btn tapHandle:^NSString *{
                [weakSelf isShare:sendData];
                return @"转发";
            }];
            [cell.base.comment_btn tapHandle:^NSString *{
                [weakSelf isCommon:sendData];
                return @"点击评论";
            }];
            [cell.dele_btn tapHandle:^NSString *{
                PopoverView *popV = [[PopoverView alloc] init];
                popV.style = PopoverViewStyleDefault;
                PopoverAction *action = [PopoverAction actionWithTitle:@"    删除    " handler:^(PopoverAction *action) {
                    [weakSelf isDelete:sendData];
                }];
                [popV showToView:cell.dele_btn withActions:@[action]];
                return @"删除帖子";
            }];
            [cell.header_btn tapHandle:^NSString *{
                [weakSelf isPush:sendData];
                return @"";
            }];
            return cell;
        }
    }
    return nil;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    NewestListSendData *sendData = self.dataSource[indexPath.section];
    if ([sendData.forumTypeFlag isEqualToString:@"0"]) {
        if (sendData.contentList.count == 0) {
            if ([sendData.delFlag isEqualToString:@"1"] || [sendData.shieldFlag isEqualToString:@"1"]) {
                return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH+122 +10);
            } else {
                return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH+108);
            }
            
        } else if (sendData.contentList.count == 1 || sendData.contentList.count == 2) {
            if ([sendData.delFlag isEqualToString:@"1"] || [sendData.shieldFlag isEqualToString:@"1"]) {
                return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH+122 +10);
            } else {
                return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH + 257);
            }
        }
        else if (sendData.contentList.count >= 3) {
            if ([sendData.delFlag isEqualToString:@"1"] || [sendData.shieldFlag isEqualToString:@"1"]) {
                return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH+122+10);
            } else {
                return CGSizeMake(kScreenWidth-32, sendData.contentDisayH+sendData.forumTitleH + 214);
            }
        }
    }
    return CGSizeMake(kScreenWidth-32, 296);
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NewestListSendData *sendData = self.dataSource[indexPath.section];
    YFInvitationDetailVC *vc = [[YFInvitationDetailVC alloc] init];
    vc.sendData = sendData;
    [self.navigationController pushViewController:vc animated:YES];
}

- (NSMutableArray<NewestListSendData *> *)dataSource {
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}
- (YFNoDataView *)noDataView {
    if (!_noDataView) {
        _noDataView = [[YFNoDataView alloc] initWithFrame:self.view.bounds];
        _noDataView.viewType = YFNoDataViewTypeNone;
        _noDataView.title =@"空空如也~";
        [self.view addSubview:_noDataView];
    }
    return _noDataView;
}
#pragma mark -- 是否点赞---转发---删除
/**
 * 转发
 **/
- (void)isShare:(NewestListSendData *)sendData {
    mWeakSelf//http://192.168.0.144:5000/帖子序列号/detail?u=当前用户id
    YFUserModelSenddata *model = [YFFlieTool getUserModel];
    NSString *customerId;
    if (model) {
        customerId = model.userId;
    } else {
        customerId = @"";
    }
    NSString *imageUrl;
    NSString *str;
    if ([sendData.forumTypeFlag isEqualToString:@"0"]) {//帖子
        str = [NSString stringWithFormat:@"%@/%@/detail?u=%@&s=1",WebMain,sendData.sequenceId,customerId];
        if (sendData.contentList.count == 0) {
            imageUrl = @"";
        } else {
            NewestContentList *contentList = sendData.contentList[0];
            imageUrl = contentList.forumContent;
        }
        [[YFShareView shareview] showInViewWithView:self.view type:5 shareImageURL:imageUrl shareContent:sendData.contentDisplay shareTitle:sendData.forumTitle shareUrl:str isAd:false contentShareType:SSDKContentTypeAuto];
        [YFShareView shareview].isShareSuccess = ^(NSString * msg){
            if ([msg isEqualToString:@"1"]) {
                NSDictionary *param = @{@"forumArticlePostId":sendData.forumArticlePostId};
                [[[ESNetworkManager updateArticlePostForwardNumber:param] map:^id(id value) {
                    return value;
                }] subscribeNext:^(id  _Nullable x) {
                    NSLog(@"此时分享自增返回的结果===%@", x);
                    sendData.forwardNumber += 1;
                    [self.collectionView reloadData];
                } error:^(NSError * _Nullable error) {
                    [weakSelf.view showWarning:error.localizedDescription];
                }];
            }
        };
        [YFShareView shareview].reportAction = ^{
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)( 0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[ESAlert API] mAlertWithTitle:@"提示" message:@"亲，您的举报我们已经受理，感谢您的监督！我们将及时处理。" :@"好" ];
            });
        };
    } 
}
/**
 * 删除
 **/
- (void)isDelete:(NewestListSendData *)sendData {
    mWeakSelf
    NSDictionary *param = @{@"forumArticlePostId":sendData.forumArticlePostId};
    [[[ESNetworkManager removeArticlePostInvitation:param] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        NSLog(@"删除返回的数据===%@", x);
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        [window showCustomView:[UIImage imageNamed:@"login_success"] title:@"删除成功"];
        [weakSelf requestInvitationAndVideoData];
        [[NSNotificationCenter defaultCenter] postNotificationName:YFDeletePostInvitation_success object:nil];
    } error:^(NSError * _Nullable error) {
        [weakSelf.view showWarning:error.localizedDescription];
    }];
}
- (void)isPush:(NewestListSendData *)sendData {
    YFPersonalHomeVC *vc = [[YFPersonalHomeVC alloc] init];
    vc.parameterStr = sendData.customerId;
    [self.navigationController pushViewController:vc animated:YES];
}
/*[cell.base.comment_btn tapHandle:^NSString *{
 [weakSelf isCommon:sendData];
 return @"点击评论";
 }];*/
- (void)isCommon:(NewestListSendData *)sendData {
    YFUserModelSenddata *model = [YFFlieTool getUserModel];
    if (model) {
        YFInvitationDetailVC *vc = [[YFInvitationDetailVC alloc] init];
        vc.sendData = sendData;
        vc.isKeyboard = YES;
        [self.navigationController pushViewController:vc animated:YES];
    } else {
        [[ESAlert API] OkAlertWithTitle:@"提示" message:@"需要您登录后才能评论" :@"确定" :@"取消" vc:self sure:^{
            YFLoginVC *loginVC = [[YFLoginVC alloc] init];
            loginVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:loginVC animated:YES];
        }];
    }
}

#pragma mark -- 数据请求
- (void)requestInvitationAndVideoData {
    [self.view showBusyHUD];
    NSDictionary *dict = @{@"jsonParam":@{
                                   @"createBy":[YFFlieTool getUserModel].userId,
                                   @"customerId":[YFFlieTool getUserModel].userId,
                                   @"forumTypeFlag":@"0"
                                   },
                           @"page":@1,
                           @"rows":@10
                           };
    [[[ESNetworkManager findPostArticleControllerList:dict] map:^id(id value) {
        return [YFNewestListModel mj_objectWithKeyValues:value];;
    }] subscribeNext:^(YFNewestListModel *  _Nullable x) {
        NSLog(@"===%@====%ld", x, x.data.count);
        [self.collectionView endHeaderRefresh];
        [self.dataSource removeAllObjects];
        [self.dataSource addObjectsFromArray:x.data.sendData];
        if (self.dataSource.count == 0) {
            self.noDataView.hidden = NO;
            UIButton * addBtn = (UIButton*)[self.view viewWithTag:12306];
            [self.view bringSubviewToFront:addBtn];
        } else {
            self.noDataView.hidden = YES;
            
        }
        self.page = 1;
        [self.view hideBusyHUD];
        [self.collectionView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.view hideBusyHUD];
        [self.collectionView endHeaderRefresh];
    } completed:^{
        [self.collectionView endHeaderRefresh];
    }];
}

- (void)requestMoreData {
    NSDictionary *dict = @{@"jsonParam":@{
                                   @"createBy":[YFFlieTool getUserModel].userId,
                                   @"customerId":[YFFlieTool getUserModel].userId,
                                   @"forumTypeFlag":@"0"
                                   },
                           @"page":@(self.page+1),
                           @"rows":@10
                           };
    [[[ESNetworkManager findPostArticleControllerList:dict] map:^id(id value) {
        return [YFNewestListModel mj_objectWithKeyValues:value];;
    }] subscribeNext:^(YFNewestListModel *  _Nullable x) {
        NSLog(@"===%@====%ld", x, x.data.count);
        
        [self.dataSource addObjectsFromArray:x.data.sendData];
        [self.collectionView reloadData];
        [self.collectionView endFooterRefresh];
        if([x.data.sendData count] > 0){  self.page += 1;}
        if ([x.data.sendData count] == 0) {
            [self.collectionView endFooterRefreshWithNoMoreData];
        }
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.collectionView endFooterRefresh];
    }];
}

//添加拍视频按钮
- (void)addActionBtn {
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [addBtn setImage:[UIImage imageNamed:@"fatie"] forState:UIControlStateNormal];
    addBtn.contentMode = UIViewContentModeScaleAspectFill;
    [addBtn setClipsToBounds:YES];
    addBtn.tag = 12306;
    addBtn.layer.cornerRadius = 50/2;
    addBtn.layer.masksToBounds = YES;
    [self.view addSubview:addBtn];
    [self.view bringSubviewToFront:addBtn];
    [addBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view.mas_right).with.offset(-16);
        make.width.and.height.equalTo(@(50));
        make.bottom.equalTo(self.view.mas_bottom).with.offset(-20);
    }];
    [addBtn addTarget:self action:@selector(addBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)addBtnClicked:(UIButton *)sender {
    
    YFUserModelSenddata* model = [YFFlieTool getUserModel];
    if (model) {
//        YFPostInvitationVC *invitationVC = [[YFPostInvitationVC alloc] init];
//        [self.navigationController pushViewController:invitationVC animated:NO];
        
        YFPostStyleSelectVC *cameraVC = [[YFPostStyleSelectVC alloc] init];
        cameraVC.type = 2;
        YFVideoNavigationController *MineNav =[[YFVideoNavigationController alloc] initWithRootViewControllerNoWrapping:cameraVC];
        MineNav.view.backgroundColor = [UIColor clearColor];
        MineNav.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [self presentViewController:MineNav animated:YES completion:nil];
        return;
    } else {
        YFLoginVC * loginVC = [[YFLoginVC alloc] init];
        loginVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:loginVC animated:YES];
    }
}


@end
