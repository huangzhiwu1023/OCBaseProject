//
//  YFMyFansAndFollowsVC.h
//  jsyf_user
//
//  Created by 程辉 on 2018/8/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFMyFansAndFollowsVC : UIViewController

@property (nonatomic, strong) NSString *joinFans;

@property (nonatomic, strong) NSString *title_Str;

@property (nonatomic, assign) BOOL isReplay;//是否实名认证 YES是 NO否

@end
