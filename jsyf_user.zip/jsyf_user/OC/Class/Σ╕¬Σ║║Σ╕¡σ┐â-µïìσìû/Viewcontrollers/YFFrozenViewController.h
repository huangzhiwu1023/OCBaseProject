//
//  YFFrozenViewController.h
//  jsyf_user
//
//  Created by pro on 2018/1/30.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFFrozenViewController : UIViewController<VTMagicViewDelegate,VTMagicViewDataSource>
@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong)  NSArray *menuList;
@end
