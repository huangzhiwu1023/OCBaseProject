//
//  ScanViewController.h
//  jsyf_user
//
//  Created by pro on 2017/10/19.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "YFBaseViewController.h"
#import <AVFoundation/AVFoundation.h>

@protocol ScanViewDelegate <NSObject>
- (void)getCodeDidFishedWithString:(NSString *)str;
@end

@interface ScanViewController : YFBaseViewController<AVCaptureMetadataOutputObjectsDelegate>
{
    int num;
    BOOL upOrdown;
    NSTimer * timer;
    UIImageView * imageView;
    BOOL hasCameraRight;
}
@property (strong,nonatomic)AVCaptureDevice * device;
@property (strong,nonatomic)AVCaptureDeviceInput * input;
@property (strong,nonatomic)AVCaptureMetadataOutput * output;
@property (strong,nonatomic)AVCaptureSession * session;
@property (strong,nonatomic)AVCaptureVideoPreviewLayer * preview;
@property (weak,nonatomic) id<ScanViewDelegate> delegate;
@property (nonatomic, retain) UIImageView * line;
-(instancetype)initWithType:(NSInteger)type;
@end
