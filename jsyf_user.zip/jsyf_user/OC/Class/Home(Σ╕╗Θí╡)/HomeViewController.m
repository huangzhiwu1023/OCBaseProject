//
//  HomeViewController.m
//  jsyf_user
//
//  Created by pro on 2017/10/13.
//  Copyright © 2017年 com.yingfeng365. All rights reserved.
//

#import "HomeViewController.h"
#import "YFBannerView.h"
@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.title =@"";
    self.view.backgroundColor = [UIColor whiteColor];
    self.homeTable.backgroundColor = [UIColor clearColor];
    if (@available(iOS 11.0, *)) {
        self.homeTable.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;//UIScrollView也适用
    }else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UITableView *)homeTable{
    if (_homeTable==nil) {
        _homeTable = [[UITableView alloc] init];
        _homeTable.frame = CGRectMake(0, NaviHeight, MAIN_WIDTH, MAIN_HEIGHT-(NaviHeight)-(TABBARHEIGHT));
        _homeTable.delegate = self;
        _homeTable.dataSource = self;
        _homeTable.estimatedRowHeight = 0;
        _homeTable.estimatedSectionHeaderHeight = 0;
        _homeTable.estimatedSectionFooterHeight = 0;
        [self.view addSubview:_homeTable];
    }
    return _homeTable;
}

- (void)viewWillLayoutSubviews
{

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"第%zi行",indexPath.row];
   
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 30;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}


@end
