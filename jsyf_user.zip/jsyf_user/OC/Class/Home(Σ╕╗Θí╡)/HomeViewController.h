//
//  HomeViewController.h
//  jsyf_user
//
//  Created by pro on 2017/10/13.
//  Copyright © 2017年 com.yingfeng365. All rights reserved.
//

#import "YFBaseViewController.h"
@interface HomeViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * homeTable;
@end
