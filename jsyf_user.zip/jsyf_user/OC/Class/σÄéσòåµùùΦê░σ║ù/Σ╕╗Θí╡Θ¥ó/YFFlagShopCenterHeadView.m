//
//  YFFlagShopCenterHeadView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/2.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopCenterHeadView.h"
#import "SDCycleScrollView.h"
#import "YFArticleDetailsModel.h"


#define IMAGE_HEIGHT (mScreenWidth * 0.56)



@interface YFFlagShopCenterHeadView()

@property(nonatomic, strong) UIScrollView *scrollView;


@end

@implementation YFFlagShopCenterHeadView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.advView];
        
        self.headView = [[YFFlagShopCenterHeadDetailView alloc] init];
        [self addSubview:self.headView];
        [self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(0);
            make.top.equalTo(self.advView.mas_bottom);
        }];
        
//        mWeakSelf
        self.advView.clickItemOperationBlock = ^(NSInteger currentIndex) {
        };
    }
    return self;
}

- (SDCycleScrollView *)advView
{
    if (_advView == nil) {
        NSArray *localImages = @[];
        NSArray *descs = @[@""];
        _advView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, mScreenWidth, IMAGE_HEIGHT) imageNamesGroup:localImages];
        _advView.lvx_placeHolderImg = kShopPlaceHolder;
        [self addSubview:_advView];
        CGFloat bottomH = -93.0;
        [_advView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.bottom.equalTo(bottomH);
        }];
        
        _advView.pageDotColor = [UIColor grayColor];
        _advView.currentPageDotColor = [UIColor orangeColor];
        _advView.titlesGroup = descs;
        _advView.titleLabelHeight = IMAGE_HEIGHT * 0.25;
        _advView.titleLabelTextColor = [UIColor whiteColor];
        _advView.titleLabelTextFont = [UIFont systemFontOfSize:18];
        _advView.titleLabelBackgroundColor = [UIColor clearColor];
        _advView.bannerImageViewContentMode = UIViewContentModeScaleAspectFill;
        _advView.backgroundColor = kLineColor;
        
        UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"home_navi_bg"]];
        [_advView addSubview:iv];
        [iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
        }];
    }
    return _advView;
}



- (IBAction)tapOnImageView:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(userHeaderViewButtonDidClick:)]) {
        [self.delegate userHeaderViewButtonDidClick:self];
    }
}
//页面赋值
- (void)setFlagShopModel:(FlagShopHeadSenddata *)flagShopModel {
    _flagShopModel = flagShopModel;
    NSMutableArray *imgGroup = [NSMutableArray array];
    for (FlagShopHeadBanner *banner in flagShopModel.banner) {
        [imgGroup addObject:banner.imgPath];
    }
    self.advView.imageURLStringsGroup = imgGroup.copy;
    self.headView.flagShopHeadModel = flagShopModel;
}
@end
