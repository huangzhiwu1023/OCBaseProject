//
//  YFFlagShopCenterHeadView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/2.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDCycleScrollView.h"

#import "YFFlagShopCenterHeadDetailView.h"
#import "YFFlagShopHeadModel.h"

@class YFFlagShopCenterHeadView;

@protocol FlagShopCenterHeadViewDelegate <NSObject>
-(void)userHeaderViewButtonDidClick:(YFFlagShopCenterHeadView *)headerView;
@end

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopCenterHeadView : UIView


@property(nonatomic,weak)id<FlagShopCenterHeadViewDelegate> delegate;
@property(nonatomic, strong) UIView *bgView;
@property(nonatomic, strong) SDCycleScrollView *advView;

@property(nonatomic, strong) YFFlagShopCenterHeadDetailView *headView;

@property(nonatomic, strong) FlagShopHeadSenddata *flagShopModel;
@end

NS_ASSUME_NONNULL_END
