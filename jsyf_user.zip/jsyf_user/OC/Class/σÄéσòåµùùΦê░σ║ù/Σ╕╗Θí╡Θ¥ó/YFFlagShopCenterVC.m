//
//  YFFlagShopCenterVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/2.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopCenterVC.h"
#import "PersonalCenterTableView.h"
#import "YFFlagShopCenterCell.h"
#import "HFStretchableTableHeaderView.h"
#import "YUSegment.h"
#import "YFFlagShopCenterHeadView.h"
#import "YFTitleView.h"
//New
#import "YFFlagShopHeadModel.h"

#define storeBrandImgH (mScreenWidth * 0.56)
#define kMaxNum 6
@interface YFFlagShopCenterVC ()<UITableViewDelegate, UITableViewDataSource,FlagShopCenterCellDelegate,CAAnimationDelegate>

//tableView
@property (strong, nonatomic)  PersonalCenterTableView *tableView;
//下拉头部放大控件
@property (strong, nonatomic) HFStretchableTableHeaderView* stretchableTableHeaderView;
//分段控制器
@property (strong, nonatomic) YUSegment *segment;
//YES代表能滑动
@property (nonatomic, assign) BOOL canScroll;
//pageViewController
@property (strong, nonatomic) YFFlagShopCenterCell *contentCell;
//是否应该刷新
@property(nonatomic,assign)BOOL shouldRefresh;
//偏移量
@property(nonatomic,assign)NSInteger lastContentOffY;
//是否在刷新
@property(nonatomic,assign)BOOL isRefreshing;
@property(nonatomic,strong) YFFlagShopCenterHeadView *userHeaderView;

@property(nonatomic, strong) UIButton *writeBtn;

//店铺头部Model
@property(nonatomic, strong) FlagShopHeadSenddata *flagShopHeadModel;
//经销商详情titleView
@property(nonatomic, strong) YFTitleView *titleView;
@property(nonatomic, strong) UILabel *companyNaviLB;

//用于分享的参数
@property(nonatomic, strong) NSString *shareImgUrl;
@property(nonatomic, strong) NSString *shareTitle;
@property(nonatomic, strong) NSString *shareContent;
//分享按钮
@property(nonatomic, strong) UIButton *rightBtn;
//返回按钮
@property(nonatomic, strong) UIButton *leftBtn;
@property(nonatomic, assign) CGFloat scrollAlpha;

@property(nonatomic, strong) NSString *storeAddress;
@property(nonatomic, strong) NSString *storeHeadImg;

@end

@implementation YFFlagShopCenterVC

- (YUSegment *)segment {
    if (!_segment) {
        NSArray *titles = @[];
        if (self.haveESJ) {
            if (self.haveLive) {
                titles = @[@"首页",@"产品",@"二手设备",@"维修",@"经销商",@"直播"];
            }
            else {
                
            }
            
        } else {
            if (self.haveLive) {
                titles = @[@"首页",@"产品",@"维修",@"经销商",@"直播"];
            }
            else {
                titles = @[@"首页",@"产品",@"二手设备",@"维修",@"经销商"];
            }
        }
        _segment = [[YUSegment alloc] initWithTitles:titles];
        _segment.frame = CGRectMake(0, 0, self.view.frame.size.width, 44);
        _segment.font = kFont14;
        _segment.selectedFont = [UIFont systemFontOfSize:15];
        _segment.backgroundColor = [UIColor colorWithRed:1.00 green:1.00 blue:1.00 alpha:1.00];
        _segment.textColor = k666Color;
        _segment.selectedTextColor = kSliderColor;
        _segment.indicator.backgroundColor = kSliderColor;
        [_segment addTarget:self action:@selector(onSegmentChange) forControlEvents:UIControlEventValueChanged];
        //默认选中第几个segment 设置完index 需要手动调用onSegmentChange一次
        //        _segment.selectedIndex = 1;
        //        [self onSegmentChange];
        
        //        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, 1)];
        //        [_segment addSubview:lineView];
        //        lineView.backgroundColor = kLineColor;
        _segment.layer.shadowColor = mHexColorAlpha(0x000000, 0.5).CGColor;
        _segment.layer.shadowOffset = CGSizeMake(0, 0.5);
        _segment.layer.shadowOpacity = 0.5;
        _segment.layer.shadowRadius = 1.0;
        
    }
    return _segment;
}

- (void)loadView {
    [super loadView];
    //设置导航栏透明度
    [self wr_setNavBarBackgroundAlpha:0];
    [self wr_setNavBarShadowImageHidden:YES];
}
#pragma mark -------- lifeCycle --------
- (void)viewDidLoad {
    [super viewDidLoad];
    [self dl_uiConfig];
    [self dl_addNotification];
    
    self.segment.selectedIndex = self.selectIndex;
    if (@available(iOS 11.0, *)) {   //ios 11 及以上
        [self setInsetNoneWithScrollView:self.tableView];
        [self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(-NaviHeight);
        }];
    }
    else {
        
    }
    [self requesFlagShopHeadDetail];
}

- (void)viewWillAppear:(BOOL)animated {
    [self scrollViewDidScroll:self.tableView];
}
- (void)viewWillDisappear:(BOOL)animated {
    [self wr_setNavBarShadowImageHidden:NO];
}

#pragma mark -------- UI --------
- (void)dl_uiConfig {
    [self addRightBtn];
    [self addNaviLeftBtn];
    [self addCompanyNaviView];
    self.tableView = [[PersonalCenterTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.bottom.left.equalTo(0);
    }];
    self.tableView.delegate =self;
    self.tableView.dataSource = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    [YFFlagShopCenterCell regisCellForTableView:self.tableView];
    self.canScroll = YES;
    self.title = @"";
    CGFloat headH = 93.0;
    self.userHeaderView = [[YFFlagShopCenterHeadView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, storeBrandImgH + headH)];
    _stretchableTableHeaderView = [HFStretchableTableHeaderView new];
    [_stretchableTableHeaderView stretchHeaderForTableView:self.tableView withView:self.userHeaderView];
}

- (void)dl_addNotification {
    //通知的处理，本来也不需要这么多通知，只是写一个简单的demo，所以...根据项目实际情况进行优化吧
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onPageViewCtrlChange:) name:@"CenterPageViewScroll" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onOtherScrollToTop:) name:@"kLeaveTopNtf" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onScrollBottomView:) name:@"PageViewGestureState" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(headerScrollToTop:) name:@"headerToTop" object:nil];
    
}

//添加分享按钮
- (void)addRightBtn {
    self.rightBtn = [[UIButton alloc] init];
    self.rightBtn.frame = CGRectMake(0, 0, 45, 44);
    [self.rightBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
    self.rightBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    self.rightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [self.rightBtn addTarget:self action:@selector(shopShareBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.rightBtn setImage:[UIImage imageNamed:@"flagshopshare_white"] forState:UIControlStateNormal];
    UIBarButtonItem * rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.rightBtn];
    self.navigationItem.rightBarButtonItem = rightButtonItem;
}

//添加返回按钮
- (void)addNaviLeftBtn {
    self.leftBtn = [[UIButton alloc] init];
    self.leftBtn.frame = CGRectMake(0, 0, 40, 44);
    self.leftBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [self.leftBtn addTarget:self action:@selector(popBack:) forControlEvents:UIControlEventTouchUpInside];
    [self.leftBtn setImage:[UIImage imageNamed:@"head_nav_back_white"] forState:UIControlStateNormal];
    self.leftBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
//    self.leftBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 10);
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.leftBtn];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
}
- (void)popBack:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
//店铺分享
- (void)shopShareBtnClicked:(UIButton *)sender {
    NSString *title = self.flagShopHeadModel.storeName;
    NSString *shareContent = self.flagShopHeadModel.storeAddress;
    NSString *urlStr = [NSString stringWithFormat:@"%@/brand/shops/%@",WebMain,self.flagShopSku];
    NSString *shareImg = self.flagShopHeadModel.headImgUrl;
    [[YFShareView shareview] showInViewWithView:self.view type:0 shareImageURL:shareImg shareContent:shareContent shareTitle:title shareUrl:urlStr isAd:false contentShareType:SSDKContentTypeAuto];
}

//经销商头部视图
- (void)addCompanyNaviView {
    self.titleView = [[YFTitleView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth*0.4, 44)];
    self.companyNaviLB = [[UILabel alloc] init];
    [self.titleView addSubview:self.companyNaviLB];
    [self.companyNaviLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(0);
        make.centerY.equalTo(0);
    }];
    self.companyNaviLB.font = kFont_system(17);
    self.companyNaviLB.textColor = k333Color;
    self.companyNaviLB.textAlignment = NSTextAlignmentCenter;
    self.companyNaviLB.text = @"";
    self.navigationItem.titleView = self.titleView;
    self.titleView.alpha = 0;
}

#pragma mark -------- Network --------
//登录返回刷新数据,获取收藏状态

//请求店铺头部详情
- (void)requesFlagShopHeadDetail {
    if (self.flagShopSku.length == 0) {
        return;
    }
    NSString *customID = [YFFlieTool getUserModel].userId;
    if (customID.length == 0) {
        customID = @"";
    }
    [self.view showBusyHUD];
    NSDictionary *bodyDic = @{@"storeSequence":self.flagShopSku,@"customerId":customID};
    [[[ESNetworkManager getFlagShopHeadData:bodyDic] map:^id(id value) {
        return [YFFlagShopHeadModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFlagShopHeadModel *  _Nullable x) {
        [self.view hideBusyHUD];
        self.companyNaviLB.text = x.data.sendData.storeName;
        self.flagShopHeadModel = x.data.sendData;
        self.userHeaderView.flagShopModel = self.flagShopHeadModel;
        self.storeAddress = self.flagShopHeadModel.storeAddress;
        self.storeHeadImg = self.flagShopHeadModel.headImgUrl;
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view hideBusyHUD];
        [self.view showWarning:error.localizedDescription];
    }];
}

#pragma mark -------- 通知的处理 --------
//pageViewController页面变动时的通知
- (void)onPageViewCtrlChange:(NSNotification *)ntf {
    //更改YUSegment选中目标
    self.segment.selectedIndex = [ntf.object integerValue];
}

//子控制器到顶部了 主控制器可以滑动
- (void)onOtherScrollToTop:(NSNotification *)ntf {
    self.canScroll = YES;
    self.contentCell.canScroll = NO;
}

//当滑动下面的PageView时，当前要禁止滑动
- (void)onScrollBottomView:(NSNotification *)ntf {
    if ([ntf.object isEqualToString:@"ended"]) {
        //bottomView停止滑动了  当前页可以滑动
        self.tableView.scrollEnabled = YES;
    } else {
        //bottomView滑动了 当前页就禁止滑动
        self.tableView.scrollEnabled = NO;
    }
}

//table向上滑动到顶
- (void)headerScrollToTop:(NSNotification *)ntf {
    CGFloat tabOffsetY = [_tableView rectForSection:0].origin.y-NaviHeight;
    NSLog(@"tabOffsetY = %lf",tabOffsetY);
    [self.tableView setContentOffset:CGPointMake(0, tabOffsetY) animated:YES];
}
//监听segment的变化
- (void)onSegmentChange {
    //改变pageView的页码
    self.contentCell.selectIndex = self.segment.selectedIndex;
    CGFloat tabOffsetY = [_tableView rectForSection:0].origin.y-NaviHeight;
    NSLog(@"tabOffsetY = %lf",tabOffsetY);
    [self.tableView setContentOffset:CGPointMake(0, tabOffsetY) animated:YES];
}

#pragma mark - UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    //要减去导航栏 状态栏 以及 sectionheader的高度
    return self.view.frame.size.height - 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    //sectionheader的高度，这是要放分段控件的
    return 44;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return self.segment;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.contentCell) {
        self.contentCell = [YFFlagShopCenterCell dequeueCellForTableView:tableView];
        self.contentCell.selectionStyle = UITableViewCellSelectionStyleNone;
        self.contentCell.delegate = self;
        self.contentCell.canSidesRoll = NO;
        self.contentCell.paramStr = self.flagShopSku;
        self.contentCell.flagShopId = self.flagShopId;
        self.contentCell.haveESJ = self.haveESJ;
        self.contentCell.haveLive = self.haveLive;
        [self.contentCell setPageView];
        self.contentCell.selectIndex = self.selectIndex;
    }
    self.contentCell.flagShopMobile = self.flagShopHeadModel.mobile;
    
    return self.contentCell;
}

//修改电池条颜色
- (UIStatusBarStyle)preferredStatusBarStyle {
    if (self.scrollAlpha >= 0.3) {
        return UIStatusBarStyleDefault;
    }
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //下拉放大 必须实现
    [_stretchableTableHeaderView scrollViewDidScroll:scrollView];
    //计算导航栏的透明度
    CGFloat minAlphaOffset = 0;
    CGFloat maxAlphaOffset = mScreenWidth  / 1.7;
    CGFloat offset = scrollView.contentOffset.y;
    self.scrollAlpha = (offset - minAlphaOffset) / (maxAlphaOffset - minAlphaOffset);
    //    NSLog(@"alpha==%f",alpha);
    if (self.scrollAlpha <= 0) {
        self.scrollAlpha = 0.0;
    }
    [self wr_setNavBarBackgroundAlpha:self.scrollAlpha];
    if (self.scrollAlpha <= 0.3) {
        [self wr_setNavBarShadowImageHidden:YES];
        [self.leftBtn setImage:[UIImage imageNamed:@"head_nav_back_white"] forState:UIControlStateNormal];
        [self.rightBtn setImage:[UIImage imageNamed:@"flagshopshare_white"] forState:UIControlStateNormal];
    }
    else {
        [self wr_setNavBarShadowImageHidden:NO];
        [self.leftBtn setImage:[UIImage imageNamed:@"head_nav_back"] forState:UIControlStateNormal];
        [self.rightBtn setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    }
    self.titleView.alpha = self.scrollAlpha;
    self.titleView.hidden = self.scrollAlpha <= 0.3 ? YES:NO;
    
    //子控制器和主控制器之间的滑动状态切换
    CGFloat tabOffsetY = [_tableView rectForSection:0].origin.y-NaviHeight;
    //    NSLog(@"tabOffsetY = %f    ==== sy = %f",tabOffsetY,scrollView.contentOffset.y);
    if (scrollView.contentOffset.y >= tabOffsetY) {
        scrollView.contentOffset = CGPointMake(0, tabOffsetY);
        if (_canScroll) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"kScrollToTopNtf" object:@1];
            _canScroll = NO;
            self.contentCell.canScroll = YES;
        }
    }
    else {
        if (!_canScroll) {
            scrollView.contentOffset = CGPointMake(0, tabOffsetY);
        }
    }
    [self configRefreshStateWithScrollView:scrollView];
    [self setNeedsStatusBarAppearanceUpdate];
}

-(void)configRefreshStateWithScrollView:(UIScrollView *)scrollView {
    if (scrollView.contentOffset.y <= -NaviHeight && scrollView.contentOffset.y < self.lastContentOffY) {
        self.shouldRefresh = YES;
    }else{
        self.shouldRefresh = NO;
    }
    
    if (scrollView.contentOffset.y < 0 && !self.isRefreshing && scrollView.contentOffset.y < self.lastContentOffY && self.lastContentOffY < 0) {
        if(!self.isRefreshing){
        }else{
        }
    }
    self.lastContentOffY = scrollView.contentOffset.y;
}


-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (self.shouldRefresh && !self.isRefreshing) {
        self.isRefreshing  = YES;
    }else if(!self.isRefreshing){
        self.isRefreshing = NO;
    }
}

-(void)dl_contentViewCellDidRecieveFinishRefreshingNotificaiton:(YFFlagShopCenterCell *)cell {
    self.isRefreshing = NO;
}


//下拉放大必须实现
- (void)viewDidLayoutSubviews {
    [_stretchableTableHeaderView resizeView];
}


//添加评论按钮
- (void)addWriteCommentBtn {
    [self.view addSubview:self.writeBtn];
    [self.writeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.equalTo(0);
        make.height.equalTo(50);
    }];
    [self.view bringSubviewToFront:self.writeBtn];
}
- (void)removeWriteCommentBtn {
    [self.writeBtn removeFromSuperview];
}

- (UIButton *)writeBtn {
    if (!_writeBtn) {
        _writeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _writeBtn.backgroundColor = kYellowColor;
        [_writeBtn setTitle:@"写点评" forState:UIControlStateNormal];
        [_writeBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
    }
    return _writeBtn;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
