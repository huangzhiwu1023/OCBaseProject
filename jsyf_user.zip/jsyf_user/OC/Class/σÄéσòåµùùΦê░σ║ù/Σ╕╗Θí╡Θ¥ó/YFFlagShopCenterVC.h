//
//  YFFlagShopCenterVC.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/2.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopCenterVC : UIViewController

//店铺sku squeuence
@property(nonatomic, strong) NSString *flagShopSku;

@property(nonatomic, strong) NSString *flagShopId;

//默认进来选中第几个segment页,默认0
@property(nonatomic, assign) NSInteger selectIndex;
/** 店铺下是否包含二手机 */
@property(nonatomic, assign) BOOL haveESJ;
/** 店铺下是否包含直播 */
@property(nonatomic, assign) BOOL haveLive;

- (void)addWriteCommentBtn;
- (void)removeWriteCommentBtn;
@end

NS_ASSUME_NONNULL_END
