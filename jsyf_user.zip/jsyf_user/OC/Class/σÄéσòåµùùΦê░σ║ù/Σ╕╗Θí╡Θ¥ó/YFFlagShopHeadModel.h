//
//  YFFlagShopHeadModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FlagShopHeadE,FlagShopHeadData,FlagShopHeadSenddata,FlagShopHeadBanner;
@interface YFFlagShopHeadModel : NSObject

@property (nonatomic, strong) FlagShopHeadE *e;

@property (nonatomic, strong) FlagShopHeadData *data;

@end
@interface FlagShopHeadE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface FlagShopHeadData : NSObject

@property (nonatomic, strong) FlagShopHeadSenddata *sendData;

@end

@interface FlagShopHeadSenddata : NSObject

@property (nonatomic, copy) NSString *storeAddress;

@property (nonatomic, assign) NSInteger storeSequence;

@property (nonatomic, copy) NSString *storeName;

@property (nonatomic, copy) NSString *discussFlag;

@property (nonatomic, copy) NSString *fax;

@property (nonatomic, copy) NSString *headImg;

@property (nonatomic, copy) NSString *delFlag;

@property (nonatomic, copy) NSString *storeId;

@property (nonatomic, copy) NSString *companyPhone;

@property (nonatomic, copy) NSString *collectionId;

@property (nonatomic, copy) NSString *collectFlag;

@property (nonatomic, copy) NSString *headImgUrl;

@property (nonatomic, strong) NSArray<FlagShopHeadBanner *> *banner;

@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, copy) NSString *operateStatus;

@property (nonatomic, copy) NSString *liveInfo;

@property (nonatomic, copy) NSString *postCode;

@property (nonatomic, copy) NSString *showSecondFlag;

@property (nonatomic, copy) NSString *storeType;

@property (nonatomic, copy) NSString *storeEnglishName;

@end

@interface FlagShopHeadBanner : NSObject

@property (nonatomic, copy) NSString *bannerType;

@property (nonatomic, copy) NSString *appImage;

@property (nonatomic, copy) NSString *appImageUrl;

@property (nonatomic, copy) NSString *bannerSource;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *bannerId;

@property (nonatomic, copy) NSString *remark;

@property (nonatomic, copy) NSString *onlineFlag;

@property (nonatomic, copy) NSString *webImage;

@property (nonatomic, copy) NSString *imgPath;

@property (nonatomic, copy) NSString *webImageUrl;

@property (nonatomic, copy) NSString *sort;

@property (nonatomic, copy) NSString *bannerLink;

@end

