//
//  YFFlagShopCenterCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/2.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFFlagShopCenterCell;

@protocol FlagShopCenterCellDelegate <NSObject>

-(void)dl_contentViewCellDidRecieveFinishRefreshingNotificaiton:(YFFlagShopCenterCell *)cell;

@end

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopCenterCell : UITableViewCell
//cell注册
+ (void)regisCellForTableView:(UITableView *)tableView;
+ (YFFlagShopCenterCell *)dequeueCellForTableView:(UITableView *)tableView;
//子控制器是否可以滑动  YES可以滑动
@property (nonatomic, assign) BOOL canScroll;
//外部segment点击更改selectIndex,切换页面
@property (assign, nonatomic) NSInteger selectIndex;
@property(nonatomic,weak)id<FlagShopCenterCellDelegate> delegate;

//PageController 是否可以左右滑动 default = NO
@property(nonatomic, assign) BOOL canSidesRoll;

//sku
@property(nonatomic, strong) NSString *paramStr;

@property(nonatomic, strong) NSString *brandIdStr;

@property(nonatomic, strong) NSString *flagShopId;

//厂商服务热线
@property(nonatomic, strong) NSString *flagShopMobile;

//创建pageViewController
- (void)setPageView;

-(void)dl_refresh;


/** 店铺下是否包含二手机 */
@property(nonatomic, assign) BOOL haveESJ;

/** 店铺下是否包含直播*/
@property(nonatomic, assign) BOOL haveLive;

@property(nonatomic, strong) NSString *storeAddress;
@property(nonatomic, strong) NSString *storeHeadImg;
@end

NS_ASSUME_NONNULL_END
