//
//  YFFlagShopCenterHeadDetailView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopCenterHeadDetailView.h"  //85+8 = 93
#import "YFFlagShopOtherRootVC.h"

@implementation YFFlagShopCenterHeadDetailView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = kBottomBgColor;
        [self iconIV];
        [self nameLB];
        [self engNameLB];
        [self stateIV];
        [self collectBtn];
        [self arrowIV];
        self.nameLB.text = @"沃尔沃建筑设备";
        self.engNameLB.text = @"woerwojianzhushebei";
    }
    return self;
}

#pragma mark -------- UI --------
- (UIView *)bgView {
    if (!_bgView) {
        _bgView = [[UIView alloc] init];
        [self addSubview:_bgView];
        [_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.bottom.equalTo(-8);
        }];
        _bgView.backgroundColor = mHexColor(0xFFFFFF);
    }
    return _bgView;
}

- (UIImageView *)iconIV {
    if (!_iconIV) {
        _iconIV = [[UIImageView alloc] init];
        [self.bgView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            make.centerY.equalTo(0);
            make.width.height.equalTo(64);
        }];
        _iconIV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _iconIV;
}

- (UILabel *)nameLB {
    if (!_nameLB) {
        _nameLB = [[UILabel alloc] init];
        [self.bgView addSubview:_nameLB];
        [_nameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.iconIV.mas_right).equalTo(14);
            make.right.equalTo(-30);
            make.top.equalTo(14);
            make.height.equalTo(15);
        }];
        _nameLB.font = kFont_system(15);
        _nameLB.textColor = k333Color;
    }
    return _nameLB;
}

- (UILabel *)engNameLB {
    if (!_engNameLB) {
        _engNameLB = [[UILabel alloc] init];
        [self.bgView addSubview:_engNameLB];
        [_engNameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.nameLB.mas_bottom).equalTo(4);
            make.left.right.equalTo(self.nameLB);
            make.height.equalTo(10);
        }];
        _engNameLB.font = kFont_system(10);
        _engNameLB.textColor = k666Color;
    }
    return _engNameLB;
}

- (UIImageView *)stateIV {
    if (!_stateIV) {
        _stateIV = [[UIImageView alloc] init];
        [self.bgView addSubview:_stateIV];
        [_stateIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.nameLB);
            make.top.equalTo(self.engNameLB.mas_bottom).equalTo(8);
            make.width.equalTo(76);
            make.height.equalTo(20);
        }];
        _stateIV.contentMode = UIViewContentModeScaleAspectFit;
        _stateIV.image = [UIImage imageNamed:@"flagshop_state"];
    }
    return _stateIV;
}

- (UIButton *)collectBtn {
    if (!_collectBtn) {
        _collectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.bgView addSubview:_collectBtn];
        [_collectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.stateIV.mas_right).equalTo(10);
            make.centerY.equalTo(self.stateIV);
            make.width.equalTo(56);
            make.height.equalTo(20);
        }];
        [_collectBtn setBackgroundImage:[UIImage imageNamed:@"flagshop_nocollect"] forState:UIControlStateNormal];
        [_collectBtn setBackgroundImage:[UIImage imageNamed:@"flagshop_collected"] forState:UIControlStateSelected];
        [_collectBtn addTarget:self action:@selector(collectBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _collectBtn;
}


- (UIImageView *)arrowIV {
    if (!_arrowIV) {
        _arrowIV = [[UIImageView alloc] init];
        [self.bgView addSubview:_arrowIV];
        [_arrowIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-16);
            make.centerY.equalTo(0);
            make.width.equalTo(12);
            make.height.equalTo(20);
        }];
        _arrowIV.contentMode = UIViewContentModeScaleAspectFit;
        _arrowIV.image = [UIImage imageNamed:@"flagshop_arrow"];
        _arrowIV.userInteractionEnabled = YES;
        
        UIButton *goBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.bgView addSubview:goBtn];
        [goBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-8);
            make.centerY.equalTo(0);
            make.width.equalTo(28);
            make.height.equalTo(30);
        }];
        [goBtn addTarget:self action:@selector(goBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _arrowIV;
}

- (void)goBtnClicked:(UIButton *)sender {
    YFFlagShopOtherRootVC *vc = [[YFFlagShopOtherRootVC alloc] init];
    vc.showTitle = self.flagShopHeadModel.storeName;
    vc.flagShopId = self.flagShopHeadModel.storeId;
    vc.shareContent = self.flagShopHeadModel.storeAddress;
    vc.shareImg = self.flagShopHeadModel.headImgUrl;
    vc.shareSku = @(self.flagShopHeadModel.storeSequence).stringValue;
    [self.viewController.navigationController pushViewController:vc animated:YES];
}

//收藏和取消收藏
- (void)collectBtnClicked:(UIButton *)sender {
    if (self.flagShopHeadModel == nil) {
        return;
    }
    NSString *userID = [YFFlieTool getUserModel].userId;
    if (userID == nil) { //未登录
        YFLoginVC *vc = [[YFLoginVC alloc] init];
        [self.viewController.navigationController pushViewController:vc animated:YES];
        return;
    }
    if (sender.isSelected) {  //已收藏,取消收藏
        [[ESAlert API] OkAlertWithTitle:@"提示" message:@"确认取消收藏?" :@"确定" :@"取消" vc:self.viewController sure:^{
            sender.enabled = NO;
            if (self.flagShopHeadModel.collectionId == nil) {
                self.flagShopHeadModel.collectionId = @"";
            }
            NSDictionary *bodyDic = @{@"id":self.flagShopHeadModel.collectionId};
            [[[ESNetworkManager doCollectAction:bodyDic] map:^id(id value) {
                return value;
            }] subscribeNext:^(id  _Nullable x) {
                [self.collectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.width.equalTo(58);
                }];
                sender.enabled = YES;
                sender.selected = NO;
                self.flagShopHeadModel.collectFlag = @"0";
            } error:^(NSError * _Nullable error) {
                sender.enabled = YES;
                [kAppDelegate.window showWarning:error.localizedDescription];
            }];
        }];
    }
    else {  //收藏
        sender.enabled = NO;
        NSDictionary *bodyDic = @{@"id":@"", @"collectionType":@"0", @"collectionId":self.flagShopHeadModel.storeId, @"customerId":userID, @"equipmentTypeCode":@"", @"collectionSource":@"0"};
        [[[ESNetworkManager doCollectAction:bodyDic] map:^id(id value) {
            return value;
        }] subscribeNext:^(id  _Nullable x) {
            [self.collectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
                make.width.equalTo(68);
            }];
            sender.enabled = YES;
            sender.selected = YES;
            self.flagShopHeadModel.collectionId = x[@"data"][@"sendData"][@"collectionId"];
            self.flagShopHeadModel.collectFlag = @"1";
            [self.viewController.view showWarning:@"收藏成功"];
        } error:^(NSError * _Nullable error) {
            sender.enabled = YES;
            [self.viewController.view showWarning:error.localizedDescription];
        }];
    }
}

- (void)setFlagShopHeadModel:(FlagShopHeadSenddata *)flagShopHeadModel {
    _flagShopHeadModel = flagShopHeadModel;
    [self.iconIV sd_setImageWithURL:flagShopHeadModel.headImgUrl.lx_URL placeholderImage:kPlaceholderImage];
    self.nameLB.text = flagShopHeadModel.storeName;
    self.engNameLB.text = flagShopHeadModel.storeEnglishName;
    if ([flagShopHeadModel.collectFlag isEqualToString:@"1"]) {
        //已收藏
        self.collectBtn.selected = YES;
        [self.collectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(68);
        }];
    }
    else {
        self.collectBtn.selected = NO;
        [self.collectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(56);
        }];
    }
}
@end
