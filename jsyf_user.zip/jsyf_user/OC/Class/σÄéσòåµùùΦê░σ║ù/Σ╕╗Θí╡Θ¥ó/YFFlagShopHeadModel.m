//
//  YFFlagShopHeadModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFFlagShopHeadModel.h"

@implementation YFFlagShopHeadModel

@end
@implementation FlagShopHeadE

@end


@implementation FlagShopHeadData

@end


@implementation FlagShopHeadSenddata

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"banner" : [FlagShopHeadBanner class]};
}

@end


@implementation FlagShopHeadBanner

@end


