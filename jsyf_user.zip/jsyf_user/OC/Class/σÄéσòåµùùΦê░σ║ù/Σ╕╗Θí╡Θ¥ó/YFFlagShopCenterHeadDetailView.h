//
//  YFFlagShopCenterHeadDetailView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YFFlagShopHeadModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopCenterHeadDetailView : UIView
@property(nonatomic, strong) UIView *bgView;
@property(nonatomic, strong) UIImageView *iconIV;
@property(nonatomic, strong) UILabel *nameLB;
@property(nonatomic, strong) UILabel *engNameLB;
@property(nonatomic, strong) UIImageView *stateIV;
@property(nonatomic, strong) UIButton *collectBtn;
@property(nonatomic, strong) UIImageView *arrowIV;

@property(nonatomic, strong) FlagShopHeadSenddata *flagShopHeadModel;
@end

NS_ASSUME_NONNULL_END
