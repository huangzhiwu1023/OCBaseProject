//
//  YFFlagShopContactModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/22.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FlagShopContactE,FlagShopContactData,FlagShopContactSenddata;
@interface YFFlagShopContactModel : NSObject

@property (nonatomic, strong) FlagShopContactE *e;

@property (nonatomic, strong) FlagShopContactData *data;

@end
@interface FlagShopContactE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface FlagShopContactData : NSObject

@property (nonatomic, strong) FlagShopContactSenddata *sendData;

@end

@interface FlagShopContactSenddata : NSObject

@property (nonatomic, assign) long long createdTime;

@property (nonatomic, copy) NSString *postCode;

@property (nonatomic, copy) NSString *storeId;

@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, assign) NSInteger storeSequence;

@property (nonatomic, copy) NSString *fax;

@property (nonatomic, copy) NSString *address;

@property (nonatomic, copy) NSString *brandId;

@property (nonatomic, copy) NSString *attachmentId;

@property (nonatomic, copy) NSString *companyEnglishName;

@property (nonatomic, copy) NSString *companyName;

@property (nonatomic, copy) NSString *companyPhone;

@property (nonatomic, copy) NSString *brandName;

@property (nonatomic, copy) NSString *fileUrl;

@property (nonatomic, copy) NSString *status;

@end

