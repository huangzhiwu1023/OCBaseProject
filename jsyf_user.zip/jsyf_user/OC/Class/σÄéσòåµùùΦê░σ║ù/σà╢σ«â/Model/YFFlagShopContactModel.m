//
//  YFFlagShopContactModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/22.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFFlagShopContactModel.h"

@implementation YFFlagShopContactModel

@end
@implementation FlagShopContactE

@end


@implementation FlagShopContactData

@end


@implementation FlagShopContactSenddata

@end


