//
//  YFFlagShopNewsModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/22.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FlagShopNewsE,FlagShopNewsData,FlagShopNewsSenddata,FlagShopNewsContentlist;
@interface YFFlagShopNewsModel : NSObject

@property (nonatomic, strong) FlagShopNewsE *e;

@property (nonatomic, strong) FlagShopNewsData *data;

@end
@interface FlagShopNewsE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface FlagShopNewsData : NSObject

@property (nonatomic, strong) FlagShopNewsSenddata *sendData;

@end

@interface FlagShopNewsSenddata : NSObject

@property (nonatomic, strong) NSArray<FlagShopNewsContentlist *> *contentList;

@property (nonatomic, assign) NSInteger count;

@end

@interface FlagShopNewsContentlist : NSObject

@property (nonatomic, copy) NSString *shareFlag;

@property (nonatomic, assign) long long modifyTime;

@property (nonatomic, copy) NSString *contentSource;

@property (nonatomic, assign) long long releaseTime;

@property (nonatomic, copy) NSString *bigPictureFullUrl;

@property (nonatomic, copy) NSString *keyword;

@property (nonatomic, assign) NSInteger storeSequence;

@property (nonatomic, copy) NSString *summary;

@property (nonatomic, copy) NSString *storeName;

@property (nonatomic, assign) NSInteger sort;

@property (nonatomic, assign) NSInteger likeNumber;

@property (nonatomic, copy) NSString *auditStatus;

@property (nonatomic, assign) NSInteger commentNumber;

@property (nonatomic, copy) NSString *onlineFlag;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *windowOpenFlag;

@property (nonatomic, assign) NSInteger sequenceId;

@property (nonatomic, copy) NSString *bigPictureUrl;

@property (nonatomic, copy) NSString *commentFlag;

@property (nonatomic, assign) long long createdTime;

@property (nonatomic, copy) NSString *createdBy;
//id -> idField
@property (nonatomic, copy) NSString *idField;

@property (nonatomic, copy) NSString *storeId;

@property (nonatomic, copy) NSString *collectFlag;

@property (nonatomic, copy) NSString *contentType;

@property (nonatomic, copy) NSString *del_flag;

@property (nonatomic, assign) NSInteger readNumber;

@property (nonatomic, copy) NSString *auditResult;

@property (nonatomic, copy) NSString *content;
//
@property (nonatomic, copy) NSString *descriptions;

@end

