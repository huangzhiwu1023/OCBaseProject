//
//  YFFlagShopNewsModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/22.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFFlagShopNewsModel.h"

@implementation YFFlagShopNewsModel

@end
@implementation FlagShopNewsE

@end


@implementation FlagShopNewsData

@end


@implementation FlagShopNewsSenddata

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"contentList" : [FlagShopNewsContentlist class]};
}

@end


@implementation FlagShopNewsContentlist
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"idField": @"id", @"descriptions" : @"description"};
}


@end


