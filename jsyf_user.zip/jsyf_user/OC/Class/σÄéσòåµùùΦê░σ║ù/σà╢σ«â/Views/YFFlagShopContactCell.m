//
//  YFFlagShopContactCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopContactCell.h"

@implementation YFFlagShopContactCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        self.backgroundColor = mHexColor(0xFFFFFF);
        [self titleLB];
        [self contentLB];
    }
    return self;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            make.centerY.equalTo(0);
            make.width.equalTo(60);
        }];
        _titleLB.font = kFont_system(15);
        _titleLB.textColor = k333Color;
    }
    return _titleLB;
}

- (UILabel *)contentLB {
    if (!_contentLB) {
        _contentLB = [[UILabel alloc] init];
        [self.contentView addSubview:_contentLB];
        [_contentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-16);
            make.centerY.equalTo(0);
            make.left.equalTo(self.titleLB.mas_right).equalTo(8);
            
        }];
        _contentLB.textAlignment = NSTextAlignmentRight;
        _contentLB.textColor = k333Color;
    }
    return _contentLB;
}
@end
