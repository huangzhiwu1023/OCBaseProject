//
//  YFFlagShopContactHeadView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopContactHeadView.h"

@implementation YFFlagShopContactHeadView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self bgIV];
        [self titleLB];
        [self locationIV];
        [self addressLB];
    }
    return self;
}

- (UIImageView *)bgIV {
    if (!_bgIV) {
        _bgIV = [[UIImageView alloc] init];
        [self addSubview:_bgIV];
        [_bgIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        _bgIV.contentMode = UIViewContentModeScaleAspectFill;
        _bgIV.clipsToBounds = YES;
        _bgIV.image = [UIImage imageNamed:@"contact_bg"];
    }
    return _bgIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.mas_centerY).equalTo(-5);
            make.left.right.equalTo(0);
            make.height.equalTo(16);
        }];
        _titleLB.textAlignment = NSTextAlignmentCenter;
        _titleLB.font = kFont_boldsys(16);
        _titleLB.textColor = k333Color;
    }
    return _titleLB;
}

- (UILabel *)addressLB {
    if (!_addressLB) {
        _addressLB = [[UILabel alloc] init];
        [self addSubview:_addressLB];
        [_addressLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.mas_centerY).equalTo(5);
            make.centerX.equalTo(8);
            make.height.equalTo(13);
        }];
        _addressLB.textAlignment = NSTextAlignmentCenter;
        _addressLB.textColor = mHexColor(0x4A90E2);
        _addressLB.font = kFont_system(13);
    }
    return _addressLB;
}

- (UIImageView *)locationIV {
    if (!_locationIV) {
        _locationIV = [[UIImageView alloc] init];
        [self addSubview:_locationIV];
        [_locationIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.addressLB);
            make.right.equalTo(self.addressLB.mas_left).equalTo(-6);
            make.width.equalTo(10);
            make.height.equalTo(13);
        }];
        _locationIV.contentMode = UIViewContentModeScaleAspectFit;
        _locationIV.image = [UIImage imageNamed:@"job_location_new"];
    }
    return _locationIV;
}
@end
