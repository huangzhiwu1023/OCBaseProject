//
//  YFFlagShopPicVC.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopPicCell : UICollectionViewCell
@property(nonatomic, strong) UIImageView *imageIV;
@end

@interface YFFlagShopPicVC : UIViewController

@property(nonatomic, strong) NSString *flagShopInfoId;
@end

NS_ASSUME_NONNULL_END
