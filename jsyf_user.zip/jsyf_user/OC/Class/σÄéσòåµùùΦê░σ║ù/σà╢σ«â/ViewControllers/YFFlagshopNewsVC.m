//
//  YFFlagshopNewsVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagshopNewsVC.h"
#import "YFFlagShopFourthCell.h"  //h=98
#import "YFFlagShopNewsModel.h"
#import "YFActivityAndNewsModel.h"

@interface YFFlagshopNewsVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, assign) NSInteger page;
@property(nonatomic, strong) YFNoDataView *emptyView;
@property(nonatomic, strong) NSMutableArray<ActivityAndNewsSenddata *> *dataList;
@end

@implementation YFFlagshopNewsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kBottomBgColor;
    [self setInsetNoneWithScrollView:self.tableView];
    self.page = 1;
    [self requestData];
    mWeakSelf
    [self.tableView addBackFooterRefresh:^{
        [weakSelf requestDataMore];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (void)requestData {
    [kAppDelegate.window showBusyHUD];
    [self.tableView.mj_footer resetNoMoreData];
    NSDictionary *tmpDic = @{@"storeId" : self.flagShopId};
    NSDictionary *bodyDic = @{@"jsonParam" : tmpDic, @"page" : @"1", @"rows" : @"10"};
    [[[ESNetworkManager getCompanyNewsList:bodyDic] map:^id(id value) {
        return [YFActivityAndNewsModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFActivityAndNewsModel * _Nullable x) {
        [kAppDelegate.window hideBusyHUD];
        self.page = 1;
        [self.dataList removeAllObjects];
        [self.dataList addObjectsFromArray:x.data.sendData];
        if (self.dataList.count == 0) {
            self.emptyView.hidden = NO;
        }
        else {
            self.emptyView.hidden = YES;
        }
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        [kAppDelegate.window hideBusyHUD];
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
    
}
- (void)requestDataMore {
    NSDictionary *tmpDic = @{@"storeId" : self.flagShopId};
    NSDictionary *bodyDic = @{@"jsonParam" : tmpDic, @"page" : @(self.page+1).stringValue, @"rows" : @"10"};
    [[[ESNetworkManager getCompanyNewsList:bodyDic] map:^id(id value) {
        return [YFActivityAndNewsModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFActivityAndNewsModel * _Nullable x) {
        [self.tableView endFooterRefresh];
        self.page += 1;
        [self.dataList addObjectsFromArray:x.data.sendData];
        if (x.data.sendData.count == 0) {
            [self.tableView endFooterRefreshWithNoMoreData];
        }
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.tableView endFooterRefresh];
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
}

#pragma mark -------- tableViewDelegate --------

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFFlagShopFourthCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopFourthCell" forIndexPath:indexPath];
    cell.newsModel = self.dataList[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    YFNewsDesVC *vc = [[YFNewsDesVC alloc] init];
    ActivityAndNewsSenddata *model = self.dataList[indexPath.row];
    model.readNumber += 1;
    vc.articleId = @(model.sequenceId).stringValue;
    vc.shareTitle = model.title;
    vc.shareContent = model.descriptions;
    vc.shareImageURL = model.bigPictureUrl;
    vc.time = model.releaseTime;
    vc.seeCount = model.readNumber;
    vc.articleSequenceId = @(model.sequenceId).stringValue;
    vc.appCmsDetailUrlWithNotUp = model.appCmsDetailUrlWithNotUp;
    vc.appCmsDetailUrlWithUp = model.appCmsDetailUrlWithUp;
    vc.authour = model.contentSource;
    
    [self.navigationController pushViewController:vc animated:YES];
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 4, mScreenWidth, mScreenHeight- NaviHeight - 40 - 4) style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = 0;
        _tableView.rowHeight = 98;
        [_tableView registerClass:[YFFlagShopFourthCell class] forCellReuseIdentifier:@"YFFlagShopFourthCell"];
        
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
     
        
    }
    return _tableView;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-40)];
        [self.view addSubview:_emptyView];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
    }
    return _emptyView;
}

- (NSMutableArray<ActivityAndNewsSenddata *> *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}

- (NSString *)flagShopId {
    if (!_flagShopId) {
        _flagShopId = @"";
    }
    return _flagShopId;
}
@end
