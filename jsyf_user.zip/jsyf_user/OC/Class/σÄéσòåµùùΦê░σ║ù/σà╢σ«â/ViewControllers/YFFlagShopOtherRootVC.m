//
//  YFFlagShopOtherRootVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopOtherRootVC.h"
#import "YFFlagshopNewsVC.h"
#import "YFFlagShopVideoVC.h"
#import "YFFlagShopPicVC.h"
#import "YFFlagShopContactVC.h"

@interface YFFlagShopOtherRootVC ()<VTMagicViewDelegate,VTMagicViewDataSource>
@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong)  NSMutableArray *menuList;
@property (nonatomic, strong)  NSMutableArray *menuCodeList;

@end

@implementation YFFlagShopOtherRootVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.showTitle;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = kBottomBgColor;
    [self magicController];
    [self.menuList addObjectsFromArray:@[@"新闻",@"视频",@"图片",@"联系我们"]] ;
    [self.magicController.magicView reloadData];
    [self addNaviRightBtn];
}

//添加导航又按钮
- (void)addNaviRightBtn {
    UIButton *rightBtn = [[UIButton alloc] init];
    rightBtn.frame = CGRectMake(0, 0, 45, 44);
    [rightBtn setTitleColor:kBlackWordColor forState:UIControlStateNormal];
    rightBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [rightBtn addTarget:self action:@selector(rightBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
}

- (void)rightBtnClick:(UIButton *)sender {
    //店铺分享
    NSString *title = self.showTitle;
    NSString *shareContent = self.shareContent;
    NSString *urlStr = [NSString stringWithFormat:@"%@/brand/shops/%@",WebMain,self.shareSku];
    NSString *shareImg = self.shareImg;
    [[YFShareView shareview] showInViewWithView:self.view type:0 shareImageURL:shareImg shareContent:shareContent shareTitle:title shareUrl:urlStr isAd:false contentShareType:SSDKContentTypeAuto];
}

#pragma mark - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    return self.menuList;
}


- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex {
    static NSString *itemIdentifier = @"itemIdentifier";
    WSMenuItem *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (menuItem == nil) {
        menuItem = [WSMenuItem buttonWithType:UIButtonTypeCustom];
    }
    [menuItem setTitleColor:k666Color forState:UIControlStateNormal];
    [menuItem setTitleColor:kSliderColor forState:UIControlStateSelected];
    menuItem.titleLabel.font = [UIFont systemFontOfSize:14];
    menuItem.dotHidden = YES;
    return menuItem;
    
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex {
    if (pageIndex == 0) {
        static NSString *gridId = @"relate.identifier";
        YFFlagshopNewsVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
        if (childVC == nil) {
            childVC = [[YFFlagshopNewsVC alloc] init];
        }
        childVC.flagShopId = self.flagShopId;
        return childVC;
        
    }
    else if(pageIndex == 1){
        static NSString *gridId = @"relate.identifier1";
        YFFlagShopVideoVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
        if (childVC == nil) {
            childVC = [[YFFlagShopVideoVC alloc] init];
        }
        childVC.flagShopId = self.flagShopId;
        return childVC;
    }
    else if (pageIndex == 2) {
        static NSString *gridId = @"relate.identifier2";
        YFFlagShopPicVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
        if (childVC == nil) {
            childVC = [[YFFlagShopPicVC alloc] init];
        }
        childVC.flagShopInfoId = self.flagShopId;
        return childVC;
    }
    else {
        static NSString *gridId = @"relate.identifier3";
        YFFlagShopContactVC * childVC = [magicView dequeueReusablePageWithIdentifier:gridId];
        if (childVC == nil) {
            childVC = [[YFFlagShopContactVC alloc] init];
        }
        childVC.flagShopId = self.flagShopId;
        return childVC;
    }
    return nil;
}

#pragma mark - accessor methods
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        _magicController.view.translatesAutoresizingMaskIntoConstraints = NO;
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = kSliderColor;
        _magicController.magicView.switchStyle = 1;
        _magicController.magicView.layoutStyle = 0;
        _magicController.magicView.navigationHeight = 40;
        _magicController.magicView.sliderExtension = 10.f;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
        _magicController.magicView.needPreloading = YES;
        _magicController.magicView.itemScale = 1.1;
        
        [self addChildViewController:_magicController];
        [self.view addSubview:_magicController.view];
        [_magicController.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.view).offset(0);
            make.left.mas_equalTo(self.view).offset(0);
            make.bottom.mas_equalTo(self.view).offset(0);
            make.right.mas_equalTo(self.view).offset(0);
        }];
    }
    return _magicController;
}


- (CGFloat)magicView:(VTMagicView *)magicView itemWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/4;
}

- (CGFloat)magicView:(VTMagicView *)magicView sliderWidthAtIndex:(NSUInteger)itemIndex {
    return mScreenWidth/4;
}


//init
- (NSMutableArray *)menuList{
    if (!_menuList) {
        _menuList = [NSMutableArray array];
    }
    return _menuList;
}


@end
