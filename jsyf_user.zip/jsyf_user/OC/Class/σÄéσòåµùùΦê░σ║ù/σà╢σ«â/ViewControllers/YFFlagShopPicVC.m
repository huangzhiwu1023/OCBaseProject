//
//  YFFlagShopPicVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopPicVC.h"
#import "YFStorePicModel.h"

@implementation YFFlagShopPicCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self imageIV];
    }
    return self;
}

- (UIImageView *)imageIV {
    if (!_imageIV) {
        _imageIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_imageIV];
        _imageIV.backgroundColor = [UIColor whiteColor];
        [_imageIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        _imageIV.clipsToBounds = YES;
        _imageIV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _imageIV;
}
@end

@interface YFFlagShopPicVC ()<UICollectionViewDataSource,UICollectionViewDelegate>
@property(nonatomic, strong) UICollectionView *collectionView;
@property(nonatomic, strong) NSMutableArray<UIImageView *> *imageViewList;
@property(nonatomic, strong) NSMutableArray *imageUrlList;
@property (nonatomic, strong) NSMutableArray<StorePicProfileimg*> *storePicDataSource;
@property(nonatomic, strong) YFNoDataView *emptyView;
@property(nonatomic, strong) NSArray<UIView *> *viewList;
@end

@implementation YFFlagShopPicVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setInsetNoneWithScrollView:self.collectionView];
    [self requestData];
}

- (void)requestData {
    NSDictionary *param = @{@"storeInfoFormalId":self.flagShopInfoId};
    [[[ESNetworkManager getStoredpPic:param] map:^id(id value) {
        return [YFStorePicModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFStorePicModel *  _Nullable x) {
        [self.storePicDataSource removeAllObjects];
        [self.storePicDataSource addObjectsFromArray:x.data.sendData.profileImg];
        NSMutableArray *tmp = [NSMutableArray array];
        for (int j = 0; j < self.storePicDataSource.count; j ++) {
            UIView *view = [[UIView alloc] init];
            view.backgroundColor = [UIColor clearColor];
            [tmp addObject:view];
        }
        self.viewList = tmp.copy;
        if (self.storePicDataSource.count == 0) {
            self.emptyView.hidden = NO;
        } else {
            self.emptyView.hidden = YES;
        }
        [self.view hideBusyHUD];
        [self.collectionView reloadData];
    
    } error:^(NSError * _Nullable error) {
        [kAppDelegate.window showWarning:error.localizedDescription];
        self.emptyView.hidden = NO;
    }];
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.viewList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    YFFlagShopPicCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFFlagShopPicCell" forIndexPath:indexPath];
    [cell.contentView addSubview:self.viewList[indexPath.row]];
    StorePicProfileimg *model = self.storePicDataSource[indexPath.row];
    [cell.imageIV sd_setImageWithURL:model.url.lx_URL placeholderImage:kPlaceholderImage];
    return cell;
}




- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [self.imageUrlList removeAllObjects];
    [self.imageViewList removeAllObjects];
    for (NSInteger i = 0; i < self.viewList.count; i++) {
            YFFlagShopPicCell *cell = (YFFlagShopPicCell *)self.viewList[i].superview.superview;
            if (cell == nil) {
                cell = (YFFlagShopPicCell *)self.viewList[indexPath.row].superview.superview;
            }
            [self.imageViewList addObject:cell.imageIV];
//            添加判断,防止越界
            if (self.storePicDataSource.count > i) {
                [self.imageUrlList addObject:self.storePicDataSource[i].url];
            }
        
        }
    [[[ESPhotoBrower alloc] init] showWithImageList:self.imageUrlList.copy parentViews:self.imageViewList.copy onVC:self index:indexPath.row];
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 64) / 3.0, ((mScreenWidth - 64) / 3.0));
        layout.minimumLineSpacing = 16;
        layout.minimumInteritemSpacing = 16;
        layout.sectionInset = UIEdgeInsetsMake(16, 16, 16, 16);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight - NaviHeight - 40) collectionViewLayout:layout];
        _collectionView.backgroundColor = kBottomBgColor;
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        [self.view addSubview:_collectionView];
        [_collectionView registerClass:[YFFlagShopPicCell class] forCellWithReuseIdentifier:@"YFFlagShopPicCell"];
        _collectionView.alwaysBounceVertical = YES;
    }
    return _collectionView;
}

- (NSMutableArray<UIImageView *> *)imageViewList {
    if (!_imageViewList) {
        _imageViewList = [NSMutableArray array];
    }
    return _imageViewList;
}
- (NSMutableArray *)imageUrlList {
    if (!_imageUrlList) {
        _imageUrlList = [NSMutableArray array];
    }
    return _imageUrlList;
}

- (NSMutableArray<StorePicProfileimg *> *)storePicDataSource {
    if (!_storePicDataSource) {
        _storePicDataSource = [NSMutableArray array];
    }
    return _storePicDataSource;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-44)];
        [self.view addSubview:_emptyView];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
        
    }
    return _emptyView;
}

- (NSString *)flagShopInfoId {
    if (!_flagShopInfoId) {
        _flagShopInfoId = @"";
    }
    return _flagShopInfoId;
}
@end
