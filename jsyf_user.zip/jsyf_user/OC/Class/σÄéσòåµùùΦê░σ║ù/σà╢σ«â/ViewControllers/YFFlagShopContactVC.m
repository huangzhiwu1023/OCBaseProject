//
//  YFFlagShopContactVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopContactVC.h"
#import "YFFlagShopContactHeadView.h"
#import "YFFlagShopContactCell.h"
#import "YFFlagShopContactModel.h"

@interface YFFlagShopContactVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) YFFlagShopContactHeadView *headView;
@property(nonatomic, strong) FlagShopContactSenddata *contactData;
@end

@implementation YFFlagShopContactVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setInsetNoneWithScrollView:self.tableView];
    [self getData];
}

#pragma mark -------- netWork --------
- (void)getData {
    NSDictionary *bdoyDic = @{@"storeId":self.flagShopId};
    [[[ESNetworkManager getFlagShopContactData:bdoyDic] map:^id(id value) {
        return [YFFlagShopContactModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFlagShopContactModel *  _Nullable x) {
        self.contactData = x.data.sendData;
        self.headView.titleLB.text = self.contactData.companyName;
        self.headView.addressLB.text = self.contactData.address;
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFFlagShopContactCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopContactCell" forIndexPath:indexPath];
    if (indexPath.row == 0) {
        cell.titleLB.text = @"邮编";
        cell.contentLB.textColor = k333Color;
        cell.contentLB.text = self.contactData.postCode;
    }
    else if (indexPath.row == 1) {
        cell.titleLB.text = @"客服";
        cell.contentLB.textColor = mHexColor(0x4A90E2);
        cell.contentLB.text = self.contactData.companyPhone;
    }
    else {
        cell.titleLB.text = @"传真";
        cell.contentLB.textColor = k333Color;
        cell.contentLB.text = self.contactData.fax;
    }
    return cell;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 4, mScreenWidth, mScreenHeight- NaviHeight - 40 - 4) style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorColor = kLineColor;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 16, 0, 0);
        _tableView.rowHeight = 50;
        [_tableView registerClass:[YFFlagShopContactCell class] forCellReuseIdentifier:@"YFFlagShopContactCell"];
        _tableView.tableHeaderView = self.headView;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        
        
    }
    return _tableView;
}

- (YFFlagShopContactHeadView *)headView {
    if (!_headView) {
        _headView = [[YFFlagShopContactHeadView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, 150)];
    }
    return _headView;
}

- (NSString *)flagShopId {
    if (!_flagShopId) {
        _flagShopId = @"";
    }
    return _flagShopId;
}

@end
