//
//  YFFlagShopVideoVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/14.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopVideoVC.h"
#import "YFShortVideoCollectionCell.h"

@interface YFFlagShopVideoVC ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray <YFUserVideoModel *> *videoDataSource;
@property (nonatomic,assign) NSInteger page;
@property (nonatomic, strong) YFNoDataView *emptyView;
@end

@implementation YFFlagShopVideoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kBottomBgColor;
    [self setInsetNoneWithScrollView:self.collectionView];
    self.page = 1;
    [self requestData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.collectionView reloadData];
    
}

- (void)requestData {
    [self.view showBusyHUD];
    NSDictionary *param = @{@"storeId":self.flagShopId};
    [[[ESNetworkManager getStoredVideo:param] map:^id(id value) {
        return [YFUserVideoModel mj_objectArrayWithKeyValuesArray:value[@"data"][@"sendData"]];
    }] subscribeNext:^(id _Nullable arr) {
        [self.collectionView endHeaderRefresh];
        [self.videoDataSource removeAllObjects];
        [self.videoDataSource addObjectsFromArray:arr];
        if (self.videoDataSource.count == 0) {
            self.emptyView.hidden = NO;
        } else {
            self.emptyView.hidden = YES;
        }
        self.page = 1;
        [self.view hideBusyHUD];
        [self.collectionView reloadData];
        CGFloat h = ((mScreenWidth - 44) / 2.0 * 0.59 + 45)  * (self.videoDataSource.count) + 16 ;
        if (h >= mScreenHeight - NaviHeight - 44) {
            h = mScreenHeight - NaviHeight - 44;
        }
        [self.collectionView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(0);
            make.top.equalTo(4);
            make.height.equalTo(h);
        }];
        
    } error:^(NSError * _Nullable error) {
        [self.view showWarning:error.localizedDescription];
        [self.view hideBusyHUD];
        [self.collectionView endHeaderRefresh];
        self.emptyView.hidden = NO;
    }];
}

//collectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.videoDataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    YFShortVideoCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFShortVideoCollectionCell" forIndexPath:indexPath];
    cell.model = self.videoDataSource[indexPath.row];
    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    YFFullScrollPlayerVC *vc = [[YFFullScrollPlayerVC alloc] init];
    vc.dataList = self.videoDataSource;
    vc.showIndex = indexPath;
    vc.isNoMore = YES;
    vc.isCanZan = NO;
    vc.paramCode = @"";  //用于加载更多数据
    vc.isStore = YES;
    vc.page = self.page;
    vc.commentTypeCode = @"DISCUSS_CODE_STORE_VIDEO";
    [self.navigationController pushViewController:vc animated:YES];
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 44) / 2.0, (mScreenWidth - 44) / 2.0 * 0.59 + 45);
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 12;
        layout.sectionInset = UIEdgeInsetsMake(16, 16, 0, 16);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.top.equalTo(4);
            make.bottom.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView registerClass:[YFShortVideoCollectionCell class] forCellWithReuseIdentifier:@"YFShortVideoCollectionCell"];
    }
    return _collectionView;
}

- (NSMutableArray<YFUserVideoModel *> *)videoDataSource {
    if (!_videoDataSource) {
        _videoDataSource = [NSMutableArray array];
    }
    return _videoDataSource;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-44)];
        [self.view addSubview:_emptyView];
        [_emptyView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(0);
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.bottom.equalTo(0);
        }];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
        
    }
    return _emptyView;
}

- (NSString *)flagShopId {
    if (!_flagShopId) {
        _flagShopId = @"";
    }
    return _flagShopId;
}
@end
