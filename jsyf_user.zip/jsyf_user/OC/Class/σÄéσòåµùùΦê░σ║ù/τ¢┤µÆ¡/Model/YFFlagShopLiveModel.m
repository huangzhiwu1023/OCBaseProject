//
//  YFFlagShopLiveModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFFlagShopLiveModel.h"

@implementation YFFlagShopLiveModel

@end
@implementation FlagShopLiveE

@end


@implementation FlagShopLiveData

@end


@implementation FlagShopLiveSenddata

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"foreShow" : [FlagShopLiveForeshow class], @"lookBack" : [FlagShopLiveLookback class], @"isLive" : [FlagShopLiveIslive class]};
}

@end


@implementation FlagShopLiveForeshow
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"idField": @"id"};
}

@end


@implementation FlagShopLiveLookback
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"idField": @"id"};
}
@end


@implementation FlagShopLiveIslive
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"idField": @"id"};
}
@end


