//
//  YFFlagShopLiveModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FlagShopLiveE,FlagShopLiveData,FlagShopLiveSenddata,FlagShopLiveForeshow,FlagShopLiveLookback,FlagShopLiveIslive;
@interface YFFlagShopLiveModel : NSObject

@property (nonatomic, strong) FlagShopLiveE *e;

@property (nonatomic, strong) FlagShopLiveData *data;

@end
@interface FlagShopLiveE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface FlagShopLiveData : NSObject

@property (nonatomic, strong) FlagShopLiveSenddata *sendData;

@end

@interface FlagShopLiveSenddata : NSObject

@property (nonatomic, strong) NSArray<FlagShopLiveIslive *> *isLive;

@property (nonatomic, strong) NSArray<FlagShopLiveLookback *> *lookBack;

@property (nonatomic, strong) NSArray<FlagShopLiveForeshow *> *foreShow;

@end

@interface FlagShopLiveForeshow : NSObject

@property (nonatomic, copy) NSString *belongId;
//id -> idField
@property (nonatomic, copy) NSString *idField;

@property (nonatomic, copy) NSString *coverImg;

@property (nonatomic, copy) NSString *liveName;

@property (nonatomic, assign) NSInteger readNumber;

@property (nonatomic, assign) long long startTime;

@end

@interface FlagShopLiveLookback : NSObject

@property (nonatomic, copy) NSString *belongId;

//id -> idField
@property (nonatomic, copy) NSString *idField;

@property (nonatomic, copy) NSString *coverImg;

@property (nonatomic, copy) NSString *liveName;

@property (nonatomic, assign) NSInteger readNumber;

@property (nonatomic, assign) long long startTime;

@end

@interface FlagShopLiveIslive : NSObject

@property (nonatomic, copy) NSString *belongId;

//id -> idField
@property (nonatomic, copy) NSString *idField;

@property (nonatomic, copy) NSString *coverImg;

@property (nonatomic, copy) NSString *liveName;

@property (nonatomic, assign) NSInteger readNumber;

@property (nonatomic, assign) long long startTime;

@end

