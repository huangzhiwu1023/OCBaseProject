//
//  YFFlagShopLiveVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopLiveVC.h"
#import "YFStoreNowPreLiveCell.h"
#import "YFStoreLiveBackCell.h"
#import "YFStoreLiveHeadView.h"
#import "YFStoreLiveListModel.h"
#import "YFLiveDetailWebVC.h"

@interface YFFlagShopLiveVC ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property(nonatomic, strong) UICollectionView *collectionView;
@property(nonatomic, strong) StoreLiveListSenddata *liveList;
@property(nonatomic, strong) YFNoDataView *emptyView;
@end

@implementation YFFlagShopLiveVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"直播";
    [self setInsetNoneWithScrollView:self.collectionView];
    [self getDataList];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.collectionView reloadData];
}

#pragma mark -------- Network --------
- (void)getDataList {
    NSDictionary *bodyDic = @{@"storeId" : self.flagShopId};
    [[[ESNetworkManager getStoreLiveList:bodyDic] map:^id(id value) {
        return [YFStoreLiveListModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFStoreLiveListModel * _Nullable x) {
        [self.collectionView endHeaderRefresh];
        self.liveList = x.data.sendData;
        [self.collectionView reloadData];
        if (self.liveList.isLive.count + self.liveList.foreShow.count + self.liveList.lookBack.count == 0) {
            self.emptyView.hidden = NO;
        }
        else {
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        [self.collectionView endHeaderRefresh];
        self.emptyView.hidden = NO;
        [self.view showWarning:error.localizedDescription];
    }];
}

#pragma mark -------- collectionViewDlegate --------
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 3;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return self.liveList.isLive.count;
    }
    else if(section == 1) {
        return self.liveList.foreShow.count;
    }
    return self.liveList.lookBack.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFStoreNowPreLiveCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFStoreNowPreLiveCell" forIndexPath:indexPath];
        cell.liveModel = self.liveList.isLive[indexPath.row];
        return cell;
    }
    else if (indexPath.section == 1) {
        YFStoreNowPreLiveCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFStoreNowPreLiveCell" forIndexPath:indexPath];
        cell.foreModel = self.liveList.foreShow[indexPath.row];
        return cell;
    }
    else {
        YFStoreLiveBackCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFStoreLiveBackCell" forIndexPath:indexPath];
        cell.backModel = self.liveList.lookBack[indexPath.row];
        return cell;
    }
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    if ([kind isEqual:UICollectionElementKindSectionHeader]) {
        YFStoreLiveHeadView *head = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"YFStoreLiveHeadView" forIndexPath:indexPath];
        return head;
    }
    return nil;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0 || indexPath.section == 1) {
        return CGSizeMake(mScreenWidth, (mScreenWidth)*0.667+16);
    }
    else {
        return CGSizeMake((mScreenWidth-44)/2.0, (mScreenWidth-44)/2.0*0.6+47);
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    if (section == 0 || section == 1) {
        return CGSizeMake(mScreenWidth, 0);
    }
    else {
        if (self.liveList.lookBack.count > 0) {
            return CGSizeMake(mScreenWidth, 40);
        }
        return CGSizeMake(mScreenWidth, 0);
    }
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    if (section == 0 || section == 1) {
        return UIEdgeInsetsMake(0, 0, 0, 0);
    }
    else {
        return UIEdgeInsetsMake(15, 16, 0, 16);
    }
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFLiveDetailWebVC *vc = [[YFLiveDetailWebVC alloc] init];
        vc.liveWebUrl = [NSString stringWithFormat:@"%@/video/shoplive/%@?ia=0",WebMain,self.liveList.isLive[indexPath.row].belongId];
        vc.shareImg = self.liveList.isLive[indexPath.row].coverImg;
        vc.shareTitle = self.liveList.isLive[indexPath.row].liveName;
        vc.shareContent = @"正在直播";
        [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
    }
    else if (indexPath.section == 1) {
        YFLiveDetailWebVC *vc = [[YFLiveDetailWebVC alloc] init];
        vc.liveWebUrl = [NSString stringWithFormat:@"%@/video/shoplive/%@?ia=0",WebMain,self.liveList.foreShow[indexPath.row].belongId];
        vc.shareImg = self.liveList.foreShow[indexPath.row].coverImg;
        vc.shareTitle = self.liveList.foreShow[indexPath.row].liveName;
        vc.shareContent = @"直播预告";
        [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
    }
    else {
        YFLiveDetailWebVC *vc = [[YFLiveDetailWebVC alloc] init];
        self.liveList.lookBack[indexPath.row].readNumber += 1;
        vc.liveWebUrl = [NSString stringWithFormat:@"%@/video/shoplive/%@?ia=0",WebMain,self.liveList.lookBack[indexPath.row].belongId];
        vc.shareImg = self.liveList.lookBack[indexPath.row].coverImg;
        vc.shareTitle = self.liveList.lookBack[indexPath.row].liveName;
        vc.shareContent = @"直播回看";
        
        [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
    }
}

#pragma mark -------- lazyLoad --------
- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 12;
        layout.sectionInset = UIEdgeInsetsMake(0, 16, 0, 16);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(0);
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.bottom.equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.alwaysBounceVertical = YES;
        _collectionView.backgroundColor = mHexColor(0xFFFFFF);
        [_collectionView registerClass:[YFStoreNowPreLiveCell class] forCellWithReuseIdentifier:@"YFStoreNowPreLiveCell"];
        [_collectionView registerClass:[YFStoreLiveBackCell class] forCellWithReuseIdentifier:@"YFStoreLiveBackCell"];
        [_collectionView registerClass:[YFStoreLiveHeadView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"YFStoreLiveHeadView"];
        self.contentScrollView = _collectionView;
    }
    return _collectionView;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-44)];
        [self.view addSubview:_emptyView];
        [_emptyView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(0);
            make.left.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.bottom.equalTo(0);
        }];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
        
    }
    return _emptyView;
}

- (NSString *)flagShopSku {
    if (!_flagShopSku) {
        _flagShopSku = @"";
    }
    return _flagShopSku;
}


@end
