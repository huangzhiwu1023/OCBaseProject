//
//  YFFlagShopHomeModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FlagShopHomeE,FlagShopHomeData,FlagShopHomeSenddata,FlagShopHomeBanner,FlagShopHomeNews;
@interface YFFlagShopHomeModel : NSObject

@property (nonatomic, strong) FlagShopHomeE *e;

@property (nonatomic, strong) FlagShopHomeData *data;

@end
@interface FlagShopHomeE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface FlagShopHomeData : NSObject

@property (nonatomic, strong) FlagShopHomeSenddata *sendData;

@end

@interface FlagShopHomeSenddata : NSObject

@property (nonatomic, strong) NSArray<FlagShopHomeBanner *> *banner;

@property (nonatomic, strong) NSArray<FlagShopHomeNews *> *news;

@property (nonatomic, copy) NSString *storeName;

@end

@interface FlagShopHomeBanner : NSObject

@property (nonatomic, copy) NSString *bannerType;

@property (nonatomic, copy) NSString *appImage;

@property (nonatomic, copy) NSString *appImageUrl;

@property (nonatomic, copy) NSString *bannerSource;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *bannerId;

@property (nonatomic, copy) NSString *remark;

@property (nonatomic, copy) NSString *onlineFlag;

@property (nonatomic, copy) NSString *webImage;

@property (nonatomic, copy) NSString *imgPath;

@property (nonatomic, copy) NSString *webImageUrl;

@property (nonatomic, assign) NSInteger sort;

@property (nonatomic, copy) NSString *bannerLink;
//add 图片高度
@property(nonatomic, assign) CGFloat cellH;

@end

@interface FlagShopHomeNews : NSObject

@property (nonatomic, copy) NSString *shareFlag;

@property (nonatomic, assign) long long modifyTime;

@property (nonatomic, copy) NSString *contentSource;

@property (nonatomic, assign) long long releaseTime;

@property (nonatomic, copy) NSString *bigPictureFullUrl;

@property (nonatomic, copy) NSString *keyword;

@property (nonatomic, assign) NSInteger storeSequence;

@property (nonatomic, copy) NSString *summary;

@property (nonatomic, copy) NSString *storeName;

@property (nonatomic, assign) NSInteger sort;

@property (nonatomic, assign) NSInteger likeNumber;

@property (nonatomic, copy) NSString *auditStatus;

@property (nonatomic, assign) NSInteger commentNumber;

@property (nonatomic, copy) NSString *onlineFlag;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *windowOpenFlag;

@property (nonatomic, assign) NSInteger sequenceId;

@property (nonatomic, copy) NSString *bigPictureUrl;

@property (nonatomic, copy) NSString *commentFlag;

@property (nonatomic, assign) long long createdTime;

@property (nonatomic, copy) NSString *createdBy;
//id -> idField
@property (nonatomic, copy) NSString *idField;

@property (nonatomic, copy) NSString *storeId;

@property (nonatomic, copy) NSString *collectFlag;

@property (nonatomic, copy) NSString *contentType;

@property (nonatomic, copy) NSString *del_flag;

@property (nonatomic, assign) NSInteger readNumber;

@property (nonatomic, copy) NSString *auditResult;

@property (nonatomic, copy) NSString *content;
//description -> descriptions
@property (nonatomic, copy) NSString *descriptions;

@property(nonatomic, copy) NSString *appCmsDetailUrlWithNotUp;

@property(nonatomic, copy) NSString *appCmsDetailUrlWithUp;
@end

