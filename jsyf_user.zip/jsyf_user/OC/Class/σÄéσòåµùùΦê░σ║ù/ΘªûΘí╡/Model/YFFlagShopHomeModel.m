//
//  YFFlagShopHomeModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFFlagShopHomeModel.h"
#import "SDWebImageManager.h"

@implementation YFFlagShopHomeModel

@end
@implementation FlagShopHomeE

@end


@implementation FlagShopHomeData

@end


@implementation FlagShopHomeSenddata

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"banner" : [FlagShopHomeBanner class], @"news" : [FlagShopHomeNews class]};
}

@end


@implementation FlagShopHomeBanner

@end


@implementation FlagShopHomeNews
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"idField" : @"id",@"descriptions": @"description"};
}

@end


