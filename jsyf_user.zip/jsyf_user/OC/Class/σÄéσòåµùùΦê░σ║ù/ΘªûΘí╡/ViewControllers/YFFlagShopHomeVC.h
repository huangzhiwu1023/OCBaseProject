//
//  YFFlagShopHomeVC.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFBaseCollectVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopHomeVC : YFBaseCollectVC
@property(nonatomic, strong) NSString *flagShopSku;
@property(nonatomic, strong) NSString *flagShopId;

@property(nonatomic, strong) NSString *storeAddress;
@property(nonatomic, strong) NSString *storeHeadImg;
@end

NS_ASSUME_NONNULL_END
