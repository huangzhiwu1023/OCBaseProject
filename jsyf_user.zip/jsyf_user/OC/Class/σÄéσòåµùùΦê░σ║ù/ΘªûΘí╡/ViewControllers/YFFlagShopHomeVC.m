//
//  YFFlagShopHomeVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopHomeVC.h"
#import "YFFlagShopHomeFirstCell.h"
#import "YFFlagShopHomeSecondCell.h"
#import "YFFlagShopThirdCell.h"
#import "YFFlagShopFourthCell.h"
#import "YFFlagShopHomeImageCell.h"
#import "YFFlagShopNewsHeadView.h"
#import "YFFlagShopNewsFooterView.h"
#import "YFFlagShopHomeModel.h"
#import "YFFlagShopOtherRootVC.h"

@interface YFFlagShopHomeVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) YFNoDataView *emptyView;
@property(nonatomic, strong) FlagShopHomeSenddata *sendData;

@end

@implementation YFFlagShopHomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kBottomBgColor;
    [self tableView];
    [self getData];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

#pragma mark -------- netWork --------
- (void)getData {
    NSDictionary *bodyDic = @{@"storeSequence" : self.flagShopSku};
    [[[ESNetworkManager getFlagShophHomeData:bodyDic] map:^id(id value) {
        return [YFFlagShopHomeModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFlagShopHomeModel *  _Nullable x) {
        self.sendData = x.data.sendData;
        for (FlagShopHomeBanner *banner in x.data.sendData.banner) {
            SDWebImageManager *manager = [SDWebImageManager sharedManager];
            __block UIImage * image;
            __block CGFloat itemH = 0;
            [manager cachedImageExistsForURL:banner.appImage.lx_URL completion:^(BOOL isInCache) {
                if (isInCache) {
                    image = [[manager imageCache] imageFromDiskCacheForKey:banner.appImage];
                    if (image == nil) {
                        NSData *data = [NSData dataWithContentsOfURL:banner.appImage.lx_URL];
                        image = [UIImage imageWithData:data];
                    }
                }
                else {
                    NSData *data = [NSData dataWithContentsOfURL:banner.appImage.lx_URL];
                    image = [UIImage imageWithData:data];
                }
                if (image.size.width) {
                    itemH = image.size.height / image.size.width * mScreenWidth;
                    banner.cellH = itemH + 6;
                    [self.tableView reloadData];
                }
            }];
        }
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
}


#pragma mark -------- tableViewDelegate --------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.sendData.news.count == 0) {
        return 1;
    }
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.sendData.banner.count;
    }
    return self.sendData.news.count > 2 ? 2 : self.sendData.news.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFFlagShopHomeImageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopHomeImageCell" forIndexPath:indexPath];
        [cell.imageIV sd_setImageWithURL:self.sendData.banner[indexPath.row].appImage.lx_URL placeholderImage:kPlaceholderImage];
        return cell;
    }
    else {
        YFFlagShopFourthCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopFourthCell" forIndexPath:indexPath];
        cell.model = self.sendData.news[indexPath.row];
        return cell;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return self.sendData.banner[indexPath.row].cellH;
    }
    else {
        return 98;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 1) {
        YFFlagShopNewsHeadView *headV = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"YFFlagShopNewsHeadView"];
        return headV;
    }
    
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 1){
        return 40;
    }
    return 0.01f;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (section == 1) {
        YFFlagShopNewsFooterView *footV = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"YFFlagShopNewsFooterView"];
        [footV.goBtn addTarget:self action:@selector(goMoewNews:) forControlEvents:UIControlEventTouchUpInside];
        return footV;
    }
    return nil;
}

- (void)goMoewNews:(UIButton *)sender {
    YFFlagShopOtherRootVC *vc = [[YFFlagShopOtherRootVC alloc] init];
    vc.flagShopId = self.flagShopId;
    vc.showTitle = self.sendData.storeName;
    vc.shareContent = self.storeAddress;
    vc.shareImg = self.storeHeadImg;
    vc.shareSku = self.flagShopSku; [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 1) {
        return 40;
    }
    return 0.01;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        YFBannerWebVC *vc = [[YFBannerWebVC alloc] init];
        FlagShopHomeBanner *model = self.sendData.banner[indexPath.row];
        vc.urlString = model.bannerLink;
        vc.shareTitle = model.title;
        vc.shareImageURL = model.imgPath;
        vc.shareContent = model.remark;
        vc.shareUrl = model.bannerLink;
        [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
    }
    else {
        YFNewsDesVC *vc = [[YFNewsDesVC alloc] init];
        FlagShopHomeNews *model = self.sendData.news[indexPath.row];
        model.readNumber += 1;
        vc.articleId = @(model.sequenceId).stringValue;
        vc.shareTitle = model.title;
        vc.shareContent = model.descriptions;
        vc.shareImageURL = model.bigPictureUrl;
        vc.time = model.modifyTime;
        vc.seeCount = model.readNumber;
        vc.articleSequenceId = @(model.sequenceId).stringValue;
        vc.appCmsDetailUrlWithNotUp = model.appCmsDetailUrlWithNotUp;
        vc.appCmsDetailUrlWithUp = model.appCmsDetailUrlWithUp;
        vc.authour = model.contentSource;
//        vc.sourceFlag = model.sourceFlag;
        [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
    }
}



- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight- NaviHeight - 44) style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = 0;
        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        [_tableView registerClass:[YFFlagShopHomeFirstCell class] forCellReuseIdentifier:@"YFFlagShopHomeFirstCell"];
        [_tableView registerClass:[YFFlagShopHomeSecondCell class] forCellReuseIdentifier:@"YFFlagShopHomeSecondCell"];
        [_tableView registerClass:[YFFlagShopThirdCell class] forCellReuseIdentifier:@"YFFlagShopThirdCell"];
        [_tableView registerClass:[YFFlagShopFourthCell class] forCellReuseIdentifier:@"YFFlagShopFourthCell"];
        [_tableView registerClass:[YFFlagShopHomeImageCell class] forCellReuseIdentifier:@"YFFlagShopHomeImageCell"];
        [_tableView registerClass:[YFFlagShopNewsHeadView class] forHeaderFooterViewReuseIdentifier:@"YFFlagShopNewsHeadView"];
        [_tableView registerClass:[YFFlagShopNewsFooterView class] forHeaderFooterViewReuseIdentifier:@"YFFlagShopNewsFooterView"];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        self.contentScrollView = _tableView;
        
    }
    return _tableView;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, MAIN_WIDTH,MAIN_HEIGHT-(NaviHeight)-44)];
        [self.view addSubview:_emptyView];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
    }
    return _emptyView;
}
- (NSString *)flagShopSku {
    if (!_flagShopSku) {
        _flagShopSku = @"";
    }
    return _flagShopSku;
}
@end
