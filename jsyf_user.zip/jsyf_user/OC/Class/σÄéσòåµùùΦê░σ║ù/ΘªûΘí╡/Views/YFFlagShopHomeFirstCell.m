//
//  YFFlagShopHomeFirstCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//
/**
mScreenWidth * 0.54 + 10 + titleH + 6 + desH + 10 + 20 + 10
== mScreenWidth * 0.54 + 50 + titleH +  desH
 */
#import "YFFlagShopHomeFirstCell.h"

@implementation YFFlagShopHomeFirstCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        [self imgIV];
        [self titleLB];
        [self desLB];
        [self protocolBtn];
    }
    return self;
}

- (UIImageView *)imgIV {
    if (!_imgIV) {
        _imgIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_imgIV];
        [_imgIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.equalTo(0);
            make.height.equalTo(mScreenWidth * 0.54);
        }];
        _imgIV.contentMode = UIViewContentModeScaleAspectFill;
        _imgIV.clipsToBounds = YES;
    }
    return _imgIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            make.top.equalTo(self.imgIV.mas_bottom).equalTo(10);
            make.right.equalTo(-16);
        }];
        _titleLB.numberOfLines = 0;
        _titleLB.font = kFont_system(15);
        _titleLB.textColor = k333Color;
    }
    return _titleLB;
}

- (UILabel *)desLB {
    if (!_desLB) {
        _desLB = [[UILabel alloc] init];
        [self.contentView addSubview:_desLB];
        [_desLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.titleLB);
            make.top.equalTo(self.titleLB.mas_bottom).equalTo(6);
            
        }];
        _desLB.numberOfLines = 0;
        _desLB.font = kFont_system(12);
        _desLB.textColor = k999Color;
    }
    return _desLB;
}

- (UIButton *)protocolBtn {
    if (!_protocolBtn) {
        _protocolBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:_protocolBtn];
        [_protocolBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLB);
            make.top.equalTo(self.desLB.mas_bottom).equalTo(10);
            make.width.equalTo(95);
            make.height.equalTo(20);
        }];
        _protocolBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        _protocolBtn.titleLabel.font = kFont_system(13);
        [_protocolBtn setTitleColor:mHexColor(0x4A90E2) forState:UIControlStateNormal];
        [_protocolBtn setTitle:@"客户支持协议>" forState:UIControlStateNormal];
    }
    return _protocolBtn;
}
@end
