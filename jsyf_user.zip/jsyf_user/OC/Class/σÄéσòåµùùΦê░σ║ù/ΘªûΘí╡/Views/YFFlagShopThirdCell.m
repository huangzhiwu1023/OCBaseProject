//
//  YFFlagShopThirdCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopThirdCell.h"

@implementation YFFlagShopThirdCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = kBottomBgColor;
        [self bgIV];
        [self titleLB];
        [self desLB];
    }
    return self;
}

- (UIImageView *)bgIV {
    if (!_bgIV) {
        _bgIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_bgIV];
        [_bgIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(6);
            make.left.right.bottom.equalTo(0);
        }];
        
        UIView *coverV = [[UIView alloc] init];
        [_bgIV addSubview:coverV];
        [coverV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
        coverV.backgroundColor = mHexColorAlpha(0x000000, 0.4);
    }
    return _bgIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.bgIV addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(4);
            make.right.equalTo(-4);
            make.bottom.equalTo(self.bgIV.mas_centerY).equalTo(-5);
            make.height.equalTo(18);
        }];
        _titleLB.font = kFont_boldsys(18);
        _titleLB.textColor = mHexColor(0xFFFFFF);
        _titleLB.textAlignment = NSTextAlignmentCenter;
    }
    return _titleLB;
}

- (UILabel *)desLB {
    if (!_desLB) {
        _desLB = [[UILabel alloc] init];
        [self.bgIV addSubview:_desLB];
        [_desLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.titleLB);
            make.top.equalTo(self.titleLB.mas_bottom).equalTo(5);
            make.bottom.lessThanOrEqualTo(-8);
        }];
        _desLB.font = kFont_system(14);
        _desLB.textColor = mHexColor(0xFFFFFF);
        _desLB.textAlignment = NSTextAlignmentCenter;
        _desLB.numberOfLines = 0;
    }
    return _desLB;
}
@end
