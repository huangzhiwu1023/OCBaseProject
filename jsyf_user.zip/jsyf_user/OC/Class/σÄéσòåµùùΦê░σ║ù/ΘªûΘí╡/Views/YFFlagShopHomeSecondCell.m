//
//  YFFlagShopHomeSecondCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopHomeSecondCell.h"
//(mScreenWidth-90-44)/3.0 + 35
@implementation SencondCollectionCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self iconIV];
        [self titleLB];
    }
    return self;
}

- (UIImageView *)iconIV {
    if (!_iconIV) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.equalTo(0);
            make.bottom.equalTo(35);
        }];
        _iconIV.contentMode = UIViewContentModeScaleAspectFit;
        _iconIV.clipsToBounds = YES;
    }
    return _iconIV;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV.mas_bottom).equalTo(6);
            make.left.right.equalTo(0);
            make.height.equalTo(13);
        }];
        _titleLB.font = kFont_system(13);
        _titleLB.textColor = mHexColor(0x4A90E2);
    }
    return _titleLB;
}

@end

//56+desH + ((mScreenWidth - 44 - 90) / 3.0 + 35) * line
@interface YFFlagShopHomeSecondCell ()<UICollectionViewDelegate,UICollectionViewDataSource>

@end

@implementation YFFlagShopHomeSecondCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        [self tipsLB];
        [self titleLB];
        [self desLB];
        [self collectionView];
    }
    return self;
}

- (UILabel *)tipsLB {
    if (!_tipsLB) {
        _tipsLB = [[UILabel alloc] init];
        [self.contentView addSubview:_tipsLB];
        [_tipsLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(0);
            make.top.equalTo(10);
            make.height.equalTo(12);
        }];
        _tipsLB.font = kFont_system(12);
        _tipsLB.textColor = k999Color;
        _tipsLB.textAlignment = NSTextAlignmentCenter;
        _tipsLB.text = @"完美无瑕的品质";
    }
    return _tipsLB;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(0);
            make.top.equalTo(self.tipsLB.mas_bottom).equalTo(6);
            make.height.equalTo(16);
        }];
        _titleLB.font = kFont_boldsys(16);
        _titleLB.textColor = k333Color;
        _titleLB.textAlignment = NSTextAlignmentCenter;
        _titleLB.text = @"沃尔沃建筑设备全系列产品";
    }
    return _titleLB;
}

- (UILabel *)desLB {
    if (!_desLB) {
        _desLB = [[UILabel alloc] init];
        [self.contentView addSubview:_desLB];
        [_desLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(8);
            make.right.equalTo(-8);
            make.top.equalTo(self.titleLB.mas_bottom).equalTo(10);
        }];
        _desLB.numberOfLines = 0;
        _desLB.textAlignment = NSTextAlignmentCenter;
        _desLB.text = @"沃尔沃建筑设备为您提供各种高品质的产品，\n完全能够您的作业需要。";
    }
    return _desLB;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake((mScreenWidth - 44 - 90) / 3.0, (mScreenWidth - 44 - 90) / 3.0 + 35);
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 45;
        layout.sectionInset = UIEdgeInsetsMake(0, 22, 0, 22);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        [self.contentView addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            //            make.right.equalTo(0);
            make.width.equalTo(mScreenWidth);
            make.top.bottom.equalTo(0);
        }];
        _collectionView.scrollEnabled = NO;
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView registerClass:[SencondCollectionCell class] forCellWithReuseIdentifier:@"SencondCollectionCell"];
    }
    return _collectionView;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 3;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SencondCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SencondCollectionCell" forIndexPath:indexPath];
    return cell;
}

@end
