//
//  YFFlagShopHomeImageCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/19.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopHomeImageCell.h"

@implementation YFFlagShopHomeImageCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        self.backgroundColor = kBottomBgColor;
        [self imageIV];
    }
    return self;
}

- (UIImageView *)imageIV {
    if (!_imageIV) {
        _imageIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_imageIV];
        [_imageIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.bottom.equalTo(-6);
        }];
        _imageIV.contentMode = UIViewContentModeScaleAspectFill;
        _imageIV.clipsToBounds = YES;
    }
    return _imageIV;
}
@end
