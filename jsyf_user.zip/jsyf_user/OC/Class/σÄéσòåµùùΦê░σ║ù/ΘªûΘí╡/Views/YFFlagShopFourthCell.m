//
//  YFFlagShopFourthCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopFourthCell.h"

@implementation YFFlagShopFourthCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        [self picIV];
        [self titleLB];
        [self readNumLB];
        [self timeLB];
    }
    return self;
}

- (void)setModel:(FlagShopHomeNews *)model {
    _model = model;
    [self.picIV sd_setImageWithURL:model.bigPictureFullUrl.lx_URL placeholderImage:kPlaceholderImage];
    self.titleLB.text = model.title;
    self.readNumLB.text = [NSString stringWithFormat:@"阅读数 %ld",model.readNumber];
    self.timeLB.text = [SysUtil getTimeWithTimeStamp:model.modifyTime];
}

- (void)setNewsModel:(ActivityAndNewsSenddata *)newsModel {
    _newsModel = newsModel;
    [self.picIV sd_setImageWithURL:newsModel.bigPictureUrl.lx_URL placeholderImage:kPlaceholderImage];
    self.titleLB.text = newsModel.title;
    self.readNumLB.text = [NSString stringWithFormat:@"阅读数 %ld",newsModel.readNumber];
    self.timeLB.text = [SysUtil getTimeWithTimeStamp:newsModel.releaseTime];
}


- (UIImageView *)picIV {
    if (!_picIV) {
        _picIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_picIV];
        [_picIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(15);
            make.height.equalTo(66);
            make.width.equalTo(88);
            make.centerY.equalTo(0);
        }];
        _picIV.contentMode = UIViewContentModeScaleAspectFill;
        _picIV.clipsToBounds = YES;
        
        UIView *bottomLine = [[UIView alloc] init];
        [self.contentView addSubview:bottomLine];
        [bottomLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(15);
            make.bottom.right.equalTo(0);
            make.height.equalTo(0.5);
        }];
        bottomLine.backgroundColor = kLineColor;
    }
    return _picIV;
}



- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.picIV.mas_right).equalTo(12);
            make.right.equalTo(-15);
            make.top.equalTo(self.picIV);
        }];
        _titleLB.font = kFont_system(14);
        _titleLB.textColor = mHexColor(0x333333);
        _titleLB.numberOfLines = 2;
    }
    return _titleLB;
}

- (UILabel *)readNumLB {
    if (!_readNumLB) {
        _readNumLB = [[UILabel alloc] init];
        [self.contentView addSubview:_readNumLB];
        [_readNumLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.picIV.mas_right).equalTo(12);
            make.right.equalTo(-100);
            make.bottom.equalTo(self.picIV);
            make.height.equalTo(12);
        }];
        _readNumLB.font = kFont_system(12);
        _readNumLB.textColor = k999Color;
    }
    return _readNumLB;
}

- (UILabel *)timeLB {
    if (!_timeLB) {
        _timeLB = [[UILabel alloc] init];
        [self.contentView addSubview:_timeLB];
        [_timeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-15);
            make.bottom.height.equalTo(self.readNumLB);
            make.width.equalTo(80);
        }];
        _timeLB.textAlignment = NSTextAlignmentRight;
        _timeLB.font = kFont_system(12);
        _timeLB.textColor = k999Color;
    }
    return _timeLB;
}
@end
