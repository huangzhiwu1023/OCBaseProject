//
//  YFFlagShopNewsFooterView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopNewsFooterView.h"

@implementation YFFlagShopNewsFooterView

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = kBottomBgColor;
        [self goBtn];
        [self arrowIV];
    }
    return self;
}

- (UIButton *)goBtn {
    if (!_goBtn) {
        _goBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:_goBtn];
        [_goBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(0);
        }];
    }
    return _goBtn;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(-7);
            make.centerY.equalTo(0);
        }];
        _titleLB.textAlignment = NSTextAlignmentCenter;
        _titleLB.font = kFont_system(12);
        _titleLB.textColor = mHexColor(0x4A90E2);
        _titleLB.text = @"查看所有新闻";
    }
    return _titleLB;
}

- (UIImageView *)arrowIV {
    if (!_arrowIV) {
        _arrowIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_arrowIV];
        [_arrowIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLB.mas_right).equalTo(4);
            make.width.height.equalTo(10);
            make.centerY.equalTo(0);
        }];
        _arrowIV.contentMode = UIViewContentModeScaleAspectFit;
        _arrowIV.image = [UIImage imageNamed:@"flagshop_morenews"];
    }
    return _arrowIV;
}

@end
