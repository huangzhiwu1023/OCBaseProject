//
//  YFFlagShopThirdCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopThirdCell : UITableViewCell
@property(nonatomic, strong) UIImageView *bgIV;
@property(nonatomic, strong) UILabel *titleLB;
@property(nonatomic, strong) UILabel *desLB;
@end

NS_ASSUME_NONNULL_END
