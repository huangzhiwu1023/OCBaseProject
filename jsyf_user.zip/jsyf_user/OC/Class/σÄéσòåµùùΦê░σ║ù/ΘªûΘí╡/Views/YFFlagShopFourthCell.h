//
//  YFFlagShopFourthCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YFFlagShopHomeModel.h"
#import "YFFlagShopNewsModel.h"
#import "YFActivityAndNewsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopFourthCell : UITableViewCell
@property(nonatomic, strong) UIImageView *picIV;
@property(nonatomic, strong) UILabel *titleLB;
@property(nonatomic, strong) UILabel *readNumLB;
@property(nonatomic, strong) UILabel *timeLB;

@property(nonatomic, strong) FlagShopHomeNews *model;
@property(nonatomic, strong) ActivityAndNewsSenddata *newsModel;
@end

NS_ASSUME_NONNULL_END
