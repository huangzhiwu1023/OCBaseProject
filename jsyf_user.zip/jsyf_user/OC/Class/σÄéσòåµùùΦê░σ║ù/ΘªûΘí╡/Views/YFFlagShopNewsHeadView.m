//
//  YFFlagShopNewsHeadView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopNewsHeadView.h"

@implementation YFFlagShopNewsHeadView

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = kBottomBgColor;
        [self imageIV];
    }
    return self;
}

- (UIImageView *)imageIV {
    if (!_imageIV) {
        _imageIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_imageIV];
        [_imageIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
        }];
        _imageIV.image = [UIImage imageNamed:@"flagshop_newshead"];
    }
    return _imageIV;
}
@end
