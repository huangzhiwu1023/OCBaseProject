//
//  YFFlagShopHomeSecondCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SencondCollectionCell : UICollectionViewCell
@property(nonatomic, strong) UIImageView *iconIV;
@property(nonatomic, strong) UILabel *titleLB;
@end

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopHomeSecondCell : UITableViewCell
@property(nonatomic, strong) UILabel *tipsLB;
@property(nonatomic, strong) UILabel *titleLB;
@property(nonatomic, strong) UILabel *desLB;
@property(nonatomic, strong) UICollectionView *collectionView;
@end

NS_ASSUME_NONNULL_END
