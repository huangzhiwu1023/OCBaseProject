//
//  YFFlagShopESJVC.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFBaseCollectVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopESJVC : YFBaseCollectVC
@property(nonatomic, strong) NSString *flagShopSku;
@property(nonatomic, strong) NSString *flagShopId;
@end

NS_ASSUME_NONNULL_END
