//
//  YFFlagShopESJVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopESJVC.h"
#import "YFFlagShopESJCell.h"

@interface YFFlagShopESJVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, assign) NSInteger page;
@property(nonatomic, strong) YFNoDataView *emptyView;
@property(nonatomic, strong) UIView *tableHeadView;
@property(nonatomic, strong) NSMutableArray<ESJListSenddata *> *dataList;

@end

@implementation YFFlagShopESJVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self tableView];
    self.page = 1;
    [self requestData];
    mWeakSelf
    [self.tableView addBackFooterRefresh:^{
        [weakSelf requestDataMore];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

#pragma mark -------- network --------
- (void)requestData {
    [kAppDelegate.window showBusyHUD];
    NSDictionary *param = @{@"firstTypeCode":@"", @"brandId":@"", @"belongId":self.flagShopId,@"belongTypeCode":@"1", @"provinceCode":@"", @"orderByFlag":@"0", @"customerId":@"", @"queryKey":@"",@"searchList":@[]};
    NSDictionary *bodyDic = @{@"jsonParam":param,@"page":@"1",@"rows":@"20"};
    [[[ESNetworkManager getESJList:bodyDic] map:^id(id value) {
        return [YFESJListModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFESJListModel *  _Nullable x) {
        [kAppDelegate.window hideBusyHUD];
        self.page = 1;
        [self.dataList removeAllObjects];
        [self.dataList addObjectsFromArray:x.data.sendData];
        [self.tableView reloadData];
        if (self.dataList.count == 0) {
            self.emptyView.hidden = NO;
        }
        else {
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        [kAppDelegate.window hideBusyHUD];
        [kAppDelegate.window  showWarning:error.localizedDescription];
    }];
}


- (void)requestDataMore {
    NSDictionary *param = @{@"firstTypeCode":@"", @"brandId":@"",@"belongId":self.flagShopId,@"belongTypeCode":@"1", @"provinceCode":@"", @"orderByFlag":@"0", @"customerId":@"", @"queryKey":@"",@"searchList":@[]};
    NSDictionary *bodyDic = @{@"jsonParam":param,@"page":@(self.page+1).stringValue,@"rows":@"20"};
    [[[ESNetworkManager getESJList:bodyDic] map:^id(id value) {
        return [YFESJListModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFESJListModel *  _Nullable x) {
        [self.tableView endFooterRefresh];
        if (x.data.sendData.count == 0) {
            [self.tableView endFooterRefreshWithNoMoreData];
        }
        self.page += 1;
        [self.dataList addObjectsFromArray:x.data.sendData];
        [self.tableView reloadData];
    } error:^(NSError * _Nullable error) {
        [self.tableView endFooterRefresh];
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
}


#pragma mark -------- UITableViewDelegate --------
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFFlagShopESJCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopESJCell" forIndexPath:indexPath];
    cell.model = self.dataList[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    YFGoodsDetailVC *vc = [[YFGoodsDetailVC alloc] init];
    NSInteger  sku =  self.dataList[indexPath.row].equipmentSku;
    vc.parameterStr = [NSString stringWithFormat:@"%zi",sku];
    self.dataList[indexPath.row].viewNumber += 1;
    vc.listModel = self.dataList[indexPath.row];
    [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
}

#pragma mark -------- lazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight - NaviHeight-44) style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(0);
            make.left.right.bottom.equalTo(0);
        }];
        _tableView.tableHeaderView = self.tableHeadView;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.rowHeight = 143;
        _tableView.separatorStyle = 0;
        _tableView.tableHeaderView = self.tableHeadView;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        //注册cell
        [_tableView registerClass:[YFFlagShopESJCell class] forCellReuseIdentifier:@"YFFlagShopESJCell"];
        
        
    }
    return _tableView;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth,mScreenHeight - NaviHeight-44)];
        [self.tableView addSubview:_emptyView];
        [self.tableView bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
    }
    return _emptyView;
}

- (UIView *)tableHeadView {
    if (!_tableHeadView) {
        _tableHeadView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, 4)];
        _tableHeadView.backgroundColor = kBottomBgColor;
    }
    return _tableHeadView;
}

- (NSMutableArray<ESJListSenddata *> *)dataList {
    if (!_dataList) {
        _dataList  =[NSMutableArray array];
    }
    return _dataList;
}
@end
