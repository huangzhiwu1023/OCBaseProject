//
//  YFFlagShopESJCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopESJCell.h"

@interface YFFlagShopESJCell()  //80+60+4 = 124
@property(nonatomic, strong) UIView *bgView;

@property(nonatomic, strong) UIImageView *iconIV;
@property(nonatomic, strong) UILabel *nameLB;

@property(nonatomic, strong) UILabel *desLB;

@property(nonatomic, strong) UILabel *askLB;
@property(nonatomic, strong) UILabel *priceLB;

@property(nonatomic, strong) UILabel *lookLB;

@property(nonatomic, strong) UILabel *collectLB;

@property(nonatomic, strong) UILabel *timeLB;

@end

@implementation YFFlagShopESJCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        self.contentView.backgroundColor = kBottomBgColor;
        [self bgView];
        [self iconIV];
        [self nameLB];
        [self desLB];
        [self askLB];
        [self priceLB];
        [self lookLB];
        [self collectLB];
        [self timeLB];
    }
    return self;
}



- (void)setModel:(ESJListSenddata *)model {
    _model = model;
    [self.iconIV sd_setImageWithURL:model.thumbnail.lx_URL placeholderImage:kPlaceholderImage];
    self.nameLB.text = [NSString stringWithFormat:@"%@%@%@",model.brandName,model.equipmentName,model.firstTypeName];
    NSString *yearStr = @(model.productionYear).stringValue;
    if (model.productionYear == 0) {
        yearStr = @"其它";
    }
    NSString *hourStr = @"";
    if ([model.firstTypeCode isEqualToString:@"18e-2123c2cd3b81"]) {
        hourStr = [NSString stringWithFormat:@"%ld公里",model.hourAge];
    }
    else {
        hourStr = [NSString stringWithFormat:@"%ld小时",model.hourAge];
    }

    self.desLB.text = [NSString stringWithFormat:@"%@ · %@ · %@%@",yearStr,hourStr,model.provinceName,model.cityName];
    if ([model.provinceName isEqualToString:model.cityName]) {
        self.desLB.text = [NSString stringWithFormat:@"%@ · %@ · %@",yearStr,hourStr,model.provinceName];
    }
    if ([model.sellingPriceStr isEqualToString:@"面议"]) {
        self.priceLB.text = [NSString stringWithFormat:@"%@",model.sellingPriceStr];
    }
    else {
        self.priceLB.text = [NSString stringWithFormat:@"¥%@万",model.sellingPriceStr];
    }
    self.lookLB.text = [NSString stringWithFormat:@"浏览:%ld", model.viewNumber];
    self.collectLB.text = [NSString stringWithFormat:@"收藏:%ld", model.collectionNumber];
    self.askLB.text = [NSString stringWithFormat:@"%ld人询价", model.enquiryNumber];
     self.askLB.hidden = true;
    self.timeLB.text = [NSString stringWithFormat:@"发布时间: %@",[SysUtil getSlashMonthAndDayTimeWithTimeStamp:model.modifyTime]];
}


#pragma mark -------- UI --------
- (UIView *)bgView {
    if (!_bgView) {
        _bgView = [UIView new];
        [self.contentView addSubview:_bgView];
        [_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.bottom.equalTo(-4);
        }];
        _bgView.backgroundColor = [UIColor whiteColor];
    }
    return _bgView;
}

- (UIImageView *)iconIV {
    if (!_iconIV) {
        _iconIV = [[UIImageView alloc] init];
        [self.bgView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            make.top.equalTo(15);
            make.width.equalTo(105);
            make.height.equalTo(80);
        }];
        _iconIV.contentMode = UIViewContentModeScaleAspectFill;
        _iconIV.clipsToBounds = YES;
    }
    return _iconIV;
}

- (UILabel *)nameLB {
    if (!_nameLB) {
        _nameLB = [[UILabel alloc] init];
        [self.bgView addSubview:_nameLB];
        [_nameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.iconIV.mas_right).equalTo(8);
            make.right.equalTo(-4);
            make.top.equalTo(self.iconIV).equalTo(0);
            make.height.equalTo(16);
        }];
        _nameLB.font = [UIFont boldSystemFontOfSize:16];
        _nameLB.textColor = k333Color;
    }
    return _nameLB;
}

- (UILabel *)desLB {
    if (!_desLB) {
        _desLB = [[UILabel alloc] init];
        [self.contentView addSubview:_desLB];
        [_desLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.nameLB);
            make.right.equalTo(-4);
            make.top.equalTo(_nameLB.mas_bottom).equalTo(6);
            make.height.equalTo(12);
        }];
        _desLB.font = [UIFont systemFontOfSize:12];
        _desLB.textColor = k999Color;
    }
    return _desLB;
}

- (UILabel *)askLB {
    if (!_askLB) {
        _askLB = [[UILabel alloc] init];
        [self.bgView addSubview:_askLB];
        [_askLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.nameLB);
            make.top.equalTo(self.desLB.mas_bottom).equalTo(6);
            make.height.equalTo(12);
        }];
        _askLB.font = [UIFont systemFontOfSize:12];
        _askLB.textColor = k999Color;
    }
    return _askLB;
}


- (UILabel *)priceLB {
    if (!_priceLB) {
        _priceLB = [[UILabel alloc] init];
        [self.bgView addSubview:_priceLB];
        [_priceLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.nameLB);
            make.right.equalTo(-8);
            make.bottom.equalTo(self.iconIV.mas_bottom).equalTo(0);
        }];
        _priceLB.font = [UIFont systemFontOfSize:12];
        _priceLB.textColor = mHexColor(0xF65044);
        
        UIView *lineV = [[UIView alloc] init];
        [self.bgView addSubview:lineV];
        [lineV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            make.right.equalTo(-16);
            make.top.equalTo(self.iconIV.mas_bottom).equalTo(15);
            make.height.equalTo(0.5);
        }];
        lineV.backgroundColor = mHexColor(0XEDEDED);
    }
    return _priceLB;
}



- (UILabel *)lookLB {
    if (!_lookLB) {
        _lookLB = [[UILabel alloc] init];
        [self.bgView addSubview:_lookLB];
        [_lookLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            //            make.centerY.equalTo(self.lookIV);
            make.top.equalTo(self.iconIV.mas_bottom).equalTo(24);
            make.width.equalTo(70);
            make.height.equalTo(12);
        }];
        _lookLB.font = [UIFont systemFontOfSize:12];
        _lookLB.textColor = k999Color;
        
//        UIView *lineView = [[UIView alloc] init];
//        [self.bgView addSubview:lineView];
//        [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.equalTo(_lookLB.mas_right).equalTo(8);
//            make.centerY.equalTo(_lookLB);
//            make.width.equalTo(1);
//            make.height.equalTo(11);
//        }];
//        lineView.backgroundColor = mHexColor(0XEDEDED);
    }
    return _lookLB;
}



- (UILabel *)collectLB {
    if (!_collectLB) {
        _collectLB = [[UILabel alloc] init];
        [self.bgView addSubview:_collectLB];
        [_collectLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.lookLB.mas_right).equalTo(16);
            make.centerY.equalTo(self.lookLB);
            make.width.equalTo(70);
        }];
        _collectLB.font = [UIFont systemFontOfSize:12];
        _collectLB.textColor = k999Color;
    }
    return _collectLB;
}



- (UILabel *)timeLB {
    if (!_timeLB) {
        _timeLB = [[UILabel alloc] init];
        [self.bgView addSubview:_timeLB];
        [_timeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-15);
            make.centerY.equalTo(self.lookLB);
            make.width.equalTo(120);
        }];
        _timeLB.textAlignment = NSTextAlignmentRight;
        _timeLB.font = [UIFont systemFontOfSize:12];
        _timeLB.textColor = k999Color;
    }
    return _timeLB;
}

@end
