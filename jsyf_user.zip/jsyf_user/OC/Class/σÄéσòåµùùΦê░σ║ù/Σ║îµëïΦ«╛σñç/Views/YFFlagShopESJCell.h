//
//  YFFlagShopESJCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/7.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
//143
NS_ASSUME_NONNULL_BEGIN

@interface YFFlagShopESJCell : UITableViewCell
@property(nonatomic, strong) ESJListSenddata *model;
@end

NS_ASSUME_NONNULL_END
