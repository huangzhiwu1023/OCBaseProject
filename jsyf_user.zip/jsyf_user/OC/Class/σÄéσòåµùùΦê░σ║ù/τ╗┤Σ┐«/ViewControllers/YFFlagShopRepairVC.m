//
//  YFFlagShopRepairVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopRepairVC.h"
#import "YFFlagShopRepairFirstCell.h"
#import "YFFlagShopRepairSecondCell.h"

@interface YFFlagShopRepairVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) UIView *tableHeadView;
@property(nonatomic, strong) UIButton *commitBtn;
@end

@implementation YFFlagShopRepairVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kBottomBgColor;
    [self tableView];
    [self addCommitBtn];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)keyboardWillShow:(NSNotification *)note {
}

- (void)keyboardWillHide:(NSNotification *)note {
}

//添加评论按钮
- (void)addCommitBtn {
    [self.view addSubview:self.commitBtn];
    [self.commitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.equalTo(0);
        make.height.equalTo(44);
    }];
    [self.view bringSubviewToFront:self.commitBtn];
}
#pragma mark -------- UITableViewDelegate --------
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        YFFlagShopRepairFirstCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopRepairFirstCell" forIndexPath:indexPath];
        cell.titleLB.attributedText = [YFFlieTool LabelAttributedstr1:@"手机号码 *" nameStr:@"*" color:mHexColor(0xF4514A) size:16];
        cell.inputTF.placeholder = @"请输入您的手机号";
        cell.inputTF.keyboardType = UIKeyboardTypePhonePad;
        return cell;
    }
    else if (indexPath.row == 1) {
        YFFlagShopRepairFirstCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopRepairFirstCell" forIndexPath:indexPath];
        cell.titleLB.text = @"您的姓名";
        cell.inputTF.placeholder = @"请输入您的姓名";
        cell.inputTF.keyboardType = UIKeyboardTypeDefault;
        return cell;
    }
    else {
        YFFlagShopRepairSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFFlagShopRepairSecondCell" forIndexPath:indexPath];
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0 || indexPath.row == 1) {
        return 70;
    }
    else {
        return 152;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

//点击提交
- (void)confimWithActionBtn:(UIButton *)sener {
    YFFlagShopRepairFirstCell *cell1 = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    YFFlagShopRepairFirstCell *cell2 = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
    YFFlagShopRepairSecondCell *cell3 = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
    NSString *matters = cell3.inputTV.text;
    NSString *phone = [[StringUtil sharedInstance] stringToTrim:cell1.inputTF.text];
    NSString *name = [[StringUtil sharedInstance] stringToTrim:cell2.inputTF.text];
    if (phone.length == 0) {
        [kAppDelegate.window showWarning: @"电话不能为空"];
        return;
    }
    if (![[StringUtil sharedInstance] isMobilePhone:phone]) {
        [kAppDelegate.window showWarning:@"手机号格式不正确"];
        return;
    }
    if (name == nil) {
        name = @"";
    }
    if (matters == nil) {
        matters = @"";
    }
    NSDictionary *param = @{@"storeBookingId":@"",
                            @"storeId":self.flagShopId,
                            @"name":name,
                            @"mobile":phone,
                            @"serviceMatters":matters,
                            @"remark":@"",
                            @"sourceFlag":@"1"};
    
    [[[ESNetworkManager storeBookingEditStoreBooking:param] map:^id(id value) {
        return value;
    }] subscribeNext:^(id  _Nullable x) {
        [kAppDelegate.window showWarning:@"提交成功"];
    } error:^(NSError * _Nullable error) {
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
    
}

#pragma mark -------- lazyLoad --------
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight - NaviHeight- 44 - 44) style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(14);
            make.left.equalTo(16);
            make.right.equalTo(-16);
            make.bottom.equalTo(0);
        }];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = 0;
        _tableView.tableHeaderView = self.tableHeadView;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = kBottomBgColor;
        //注册cell
        [_tableView registerClass:[YFFlagShopRepairFirstCell class] forCellReuseIdentifier:@"YFFlagShopRepairFirstCell"];
        [_tableView registerClass:[YFFlagShopRepairSecondCell class] forCellReuseIdentifier:@"YFFlagShopRepairSecondCell"];
        self.contentScrollView = _tableView;
        
    }
    return _tableView;
}


- (UIView *)tableHeadView {
    if (!_tableHeadView) {
        _tableHeadView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth-32, (mScreenWidth-32)*0.248+10)];
        _tableHeadView.backgroundColor = [UIColor whiteColor];
        
        UIImageView *iv = [[UIImageView alloc] init];
        [_tableHeadView addSubview:iv];
        [iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.bottom.equalTo(-10);
        }];
        iv.contentMode = UIViewContentModeScaleAspectFill;
        iv.clipsToBounds = YES;
        iv.image = [UIImage imageNamed:@"flagshop_repair"];
        
        UILabel *platMobileLB = [[UILabel alloc] init];
        [iv addSubview:platMobileLB];
        [platMobileLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            make.right.equalTo(-100);
            make.bottom.equalTo(-10);
            make.height.equalTo(10);
        }];
        platMobileLB.font = kFont_system(10);
        platMobileLB.textColor = mHexColor(0x75BBB2);
        
        UILabel *shopMobileLB = [[UILabel alloc] init];
        [iv addSubview:shopMobileLB];
        [shopMobileLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(platMobileLB);
            make.bottom.equalTo(platMobileLB.mas_top).equalTo(-4);
            make.height.equalTo(10);
        }];
        shopMobileLB.font = kFont_system(10);
        shopMobileLB.textColor = mHexColor(0x75BBB2);
        
        shopMobileLB.text = [NSString stringWithFormat:@"欢迎拨打厂商服务热线: %@",self.flagShopMobile];
        platMobileLB.text = [NSString stringWithFormat:@"平台客服热线: %@",@"400-6363-648"];
        
    }
    return _tableHeadView;
}


- (UIButton *)commitBtn {
    if (!_commitBtn) {
        _commitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _commitBtn.backgroundColor = kOrangeColor;
        [_commitBtn setTitle:@"提交" forState:UIControlStateNormal];
        [_commitBtn setTitleColor:mHexColor(0xFFFFFF) forState:UIControlStateNormal];
        _commitBtn.titleLabel.font = kFont_system(16);
        [_commitBtn addTarget:self action:@selector(confimWithActionBtn:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _commitBtn;
}



@end
