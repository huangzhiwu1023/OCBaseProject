//
//  YFFlagShopRepairSecondCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/13.
//  Copyright © 2018年 YF. All rights reserved.
//

#define maxNum 100

#import "YFFlagShopRepairSecondCell.h"

@interface YFFlagShopRepairSecondCell ()<UITextViewDelegate>
@property(nonatomic, assign) NSUInteger totalNum;
@end

@implementation YFFlagShopRepairSecondCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        self.backgroundColor = [UIColor whiteColor];
        [self titleLB];
        [self inputTV];
        [self setupTextView];
    }
    return self;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(14);
            make.top.equalTo(0);
            make.height.equalTo(14);
        }];
        _titleLB.font = kFont_system(14);
        _titleLB.textColor = k333Color;
        _titleLB.text = @"服务事项";
    }
    return _titleLB;
}

- (UITextView *)inputTV {
    if (!_inputTV) {
        UIView *bgView = [[UIView alloc] init];
        [self.contentView addSubview:bgView];
        [bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(14);
            make.right.equalTo(-14);
            make.top.equalTo(self.titleLB.mas_bottom).equalTo(6);
            make.bottom.equalTo(-12);
        }];
        bgView.layer.cornerRadius = 2;
        bgView.layer.masksToBounds = YES;
        bgView.backgroundColor = mHexColor(0xF6F6F6);
        
        _inputTV = [[UITextView alloc] init];
        [bgView addSubview:_inputTV];
        [_inputTV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.right.equalTo(-10);
            make.top.equalTo(8);
            make.bottom.equalTo(-24);
        }];
        _inputTV.backgroundColor = mHexColor(0xF6F6F6);
        _inputTV.font = kFont_system(15);
        _inputTV.returnKeyType = UIReturnKeyDone;
        _inputTV.delegate = self;
        
        _numLB = [[UILabel alloc] init];
        [bgView addSubview:_numLB];
        [_numLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-10);
            make.top.equalTo(_inputTV.mas_bottom).equalTo(4);
            make.height.equalTo(12);
        }];
        _numLB.textColor = k999Color;
        _numLB.font = kFont_system(12);
        _numLB.textAlignment = NSTextAlignmentRight;
        _numLB.text = @"0/100";
    }
    return _inputTV;
}

//为textview添加placeHoder
- (void)setupTextView {
    UILabel *placeHolderLabel = [[UILabel alloc] init];
    placeHolderLabel.text = @"选填,请简要输入您需要的维修事项";
    placeHolderLabel.numberOfLines = 0;
    placeHolderLabel.textColor = k999Color;
    [placeHolderLabel sizeToFit];
    [self.inputTV addSubview:placeHolderLabel];
    //    placeHolderLabelOne.font = [UIFont systemFontOfSize:14.f];
    placeHolderLabel.font = self.inputTV.font;
    
    [self.inputTV setValue:placeHolderLabel forKey:@"_placeholderLabel"];
}

#pragma mark -- UITextViewDelegate
- (void)textViewDidChange:(UITextView *)textView {
    NSInteger value=textView.text.length;
    //高亮不进入统计 避免未输入的中文在拼音状态被统计入总长度限制
    value -= [textView textInRange:[textView markedTextRange]].length;
    if (value<=maxNum) {
        NSLog(@"%@",[NSString stringWithFormat:@"%d/%d",(int)value,maxNum]);
    } else {
        //截断长度限制以后的字符 避免截断字符
        NSString *tempStr = [textView.text substringWithRange:[textView.text rangeOfComposedCharacterSequencesForRange:NSMakeRange(0, maxNum)]];
        textView.text=tempStr;
        
        NSLog(@"%@",[NSString stringWithFormat:@"最多只能输入%d字",maxNum]);
    }
    if (textView.text.length == 0) {
        self.numLB.text = [NSString stringWithFormat:@"%d/%d",0,maxNum];
        
    }else{
        self.totalNum = textView.text.length;
        if (self.totalNum <= 0) {
            self.totalNum = 0;
        }
        self.numLB.text = [NSString stringWithFormat:@"%ld/%d",self.totalNum,maxNum];
    }
    
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([@"\n" isEqualToString:text] == YES) {
        [textView resignFirstResponder];
        return NO;
    }
    
    UITextRange *selectedRange = [textView markedTextRange];
    //获取高亮部分
    UITextPosition *pos = [textView positionFromPosition:selectedRange.start offset:0];
    //获取高亮部分内容
    //NSString * selectedtext = [textView textInRange:selectedRange];
    //如果有高亮且当前字数开始位置小于最大限制时允许输入
    if (selectedRange && pos) {
        NSInteger startOffset = [textView offsetFromPosition:textView.beginningOfDocument toPosition:selectedRange.start];
        NSInteger endOffset = [textView offsetFromPosition:textView.beginningOfDocument toPosition:selectedRange.end];
        NSRange offsetRange = NSMakeRange(startOffset, endOffset - startOffset);
        
        if (offsetRange.location < maxNum) {
            return YES;
        }
        else {
            return NO;
        }
    }
    
    NSString *comcatstr = [textView.text stringByReplacingCharactersInRange:range withString:text];
    NSInteger caninputlen = maxNum - comcatstr.length;
    if (caninputlen >= 0) {
        return YES;
    }
    else {
        NSInteger len = text.length + caninputlen;
        //防止当text.length + caninputlen < 0时，使得rg.length为一个非法最大正数出错
        NSRange rg = {0,MAX(len,0)};
        NSLog(@"rg==%ld", rg.length);
        if (rg.length > 0) {
            NSString *s = @"";
            //判断是否只普通的字符或asc码(对于中文和表情返回NO)
            BOOL asc = [text canBeConvertedToEncoding:NSASCIIStringEncoding];
            if (asc) {
                s = [text substringWithRange:rg];//因为是ascii码直接取就可以了不会错
            }
            else {
                __block NSInteger idx = 0;
                __block NSString  *trimString = @"";//截取出的字串
                //使用字符串遍历，这个方法能准确知道每个emoji是占一个unicode还是两个
                [text enumerateSubstringsInRange:NSMakeRange(0, [text length])
                                         options:NSStringEnumerationByComposedCharacterSequences
                                      usingBlock: ^(NSString* substring, NSRange substringRange, NSRange enclosingRange, BOOL* stop) {
                                          
                                          NSInteger steplen = substring.length;
                                          
                                          if (idx >= rg.length) {
                                              *stop = YES; //取出所需要就break，提高效率
                                              
                                              return ;
                                          }
                                          
                                          trimString = [trimString stringByAppendingString:substring];
                                          
                                          //                                          idx++;
                                          idx = idx + steplen;//这里变化了，使用了字串占的长度来作为步长
                                      }];
                
                s = trimString;
            }
            //rang是指从当前光标处进行替换处理(注意如果执行此句后面返回的是YES会触发didchange事件)
            [textView setText:[textView.text stringByReplacingCharactersInRange:range withString:s]];
            //既然是超出部分截取了，哪一定是最大限制了。
            self.numLB.text = [NSString stringWithFormat:@"%d/%d",maxNum,maxNum];
        }
        return NO;
    }
}

@end
