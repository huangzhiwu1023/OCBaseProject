//
//  YFFlagShopRepairFirstCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/13.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopRepairFirstCell.h"
@interface YFFlagShopRepairFirstCell()<UITextFieldDelegate>

@end

@implementation YFFlagShopRepairFirstCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = 0;
        self.backgroundColor = [UIColor whiteColor];
        [self titleLB];
        [self xinIV];
        [self inputTF];
    }
    return self;
}

- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(14);
            make.top.equalTo(0);
            make.height.equalTo(14);
            make.right.equalTo(-10);
        }];
        _titleLB.font = kFont_system(14);
        _titleLB.textColor = k333Color;
        _titleLB.text = @"手机号码";
    }
    return _titleLB;
}

- (UIImageView *)xinIV {
    if (!_xinIV) {
        _xinIV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@""]];
        [self.contentView addSubview:_xinIV];
        [_xinIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLB.mas_right).equalTo(8);
            make.top.equalTo(0);
        }];
        _xinIV.contentMode = UIViewContentModeScaleAspectFit;
        _xinIV.hidden = YES;
    }
    return _xinIV;
}

- (UITextField *)inputTF {
    if (!_inputTF) {
        _inputTF = [[UITextField alloc] init];
        [self.contentView addSubview:_inputTF];
        [_inputTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(14);
            make.right.equalTo(-14);
            make.top.equalTo(self.titleLB.mas_bottom).equalTo(6);
            make.height.equalTo(40);
        }];
        _inputTF.returnKeyType = UIReturnKeyDone;
        _inputTF.delegate = self;
        _inputTF.layer.cornerRadius = 2;
        _inputTF.layer.masksToBounds = YES;
        _inputTF.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 40)];
        _inputTF.leftViewMode = UITextFieldViewModeAlways;
        _inputTF.textColor = mHexColor(0x666666);
        _inputTF.font = kFont_system(15);
        _inputTF.backgroundColor = mHexColor(0xF6F6F6);
        _inputTF.placeholder = @"请输入您的手机号";
        [_inputTF setValue:mHexColor(0x999999) forKeyPath:@"_placeholderLabel.textColor"];
    }
    return _inputTF;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

@end
