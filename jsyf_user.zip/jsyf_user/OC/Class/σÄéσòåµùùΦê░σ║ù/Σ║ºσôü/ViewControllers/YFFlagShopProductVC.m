//
//  YFFlagShopProductVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopProductVC.h"
#import "YFShopDesCell.h"
#import "YFCollectionViewFlowLayout.h"
#import "MMComboBox.h"
#import "YFFlagShopProductModel.h"
#import "YFCompanyTypeFilterModel.h"

@interface YFFlagShopProductVC ()<UICollectionViewDelegate, UICollectionViewDataSource, MMComBoBoxViewDataSource, MMComBoBoxViewDelegate>

@property (nonatomic, strong) UICollectionView *collectionView;

@property(nonatomic, strong) YFNoDataView *emptyView;

@property (nonatomic, strong) MMComBoBoxView *comBoBoxView;

@property(nonatomic, strong) NSMutableArray *mutableArray;

@property(nonatomic, strong) NSArray<FlagShopProductSenddata *> *dataList;
//筛序条件
@property(nonatomic, strong) NSArray<CompanyTypeListSenddata *> *filterList;
//当前二级分类数据
@property(nonatomic, strong) NSArray<CompanyTypeListChildlist *> *sencondFilterList;
@property(nonatomic, strong) NSString *firstCode;
@property(nonatomic, strong) NSString *secondCode;

@property(nonatomic, assign) NSInteger currentTypeIndex;

@end

@implementation YFFlagShopProductVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kBottomBgColor;
    [self setBtnsUI];
    [self collectionView];
    [self getData];
    [self getFilterData];
}

#pragma mark -------- netWork --------
- (void)getData {
    NSString *userId = [YFFlieTool getUserModel].userId;
    if (userId == nil) {
        userId = @"";
    }
    NSDictionary *tmpDic = @{@"customerId":userId,@"goodsEquipmentType":self.firstCode,@"equipmentTwoTypeCode":self.secondCode,@"goodsStoreId":self.flagShopId,@"goodsPutAwayStatusFlag":@"0"};
    NSDictionary *bodyDic = @{@"jsonParam" : tmpDic};
    [[[ESNetworkManager getFlagShopProductData:bodyDic] map:^id(id value) {
        return [YFFlagShopProductModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFlagShopProductModel * _Nullable x) {
        self.dataList = x.data.sendData;
        [self.collectionView reloadData];
        if (self.dataList.count == 0) {
            self.emptyView.hidden = NO;
        }
        else{
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        self.emptyView.hidden = NO;
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
}

- (void)getFilterData {
    NSDictionary *bodyDic = @{@"goodsStoreId" : self.flagShopId};
    [[[ESNetworkManager getFlagShopProductFilter:bodyDic] map:^id(id value) {
        return [YFCompanyTypeFilterModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFCompanyTypeFilterModel *  _Nullable x) {
        self.filterList = x.data.sendData;
        NSMutableArray *tmpArr = [NSMutableArray arrayWithArray:self.filterList.firstObject.childList];
        CompanyTypeListChildlist *child = [[CompanyTypeListChildlist alloc] init];
        child.equipmentTwoTypeCode = @"";
        child.equipmentTowTypeName = @"全部";
        [tmpArr insertObject:child atIndex:0];
        self.sencondFilterList = tmpArr.copy;
        self.mutableArray = nil;
        [self.comBoBoxView reload];
        self.firstCode = self.filterList.firstObject.equipmentFirstTypeCode;
        self.secondCode = self.sencondFilterList.firstObject.equipmentTwoTypeCode;
        [self getData];
    } error:^(NSError * _Nullable error) {
        
//        [self.view showWarning:error.localizedDescription];
    }];;
}
#pragma mark -- UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    YFShopDesCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"YFShopDesCell" forIndexPath:indexPath];
    cell.model = self.dataList[indexPath.row];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    PersonalCenterController *centerVC =[[PersonalCenterController alloc] init];
    FlagShopProductSenddata *model = self.dataList[indexPath.row];
    centerVC.detailStyle = 1;
    centerVC.isFromShop = NO;
    centerVC.parameterStr = model.equipmentSku;  //equipmentID ->SKU
    centerVC.goodsSku = @(model.goodsSequenceId).stringValue;
    centerVC.equipmentName = [NSString stringWithFormat:@"%@%@",model.goodsBrandName,model.goodsEquipmentModelName];
    centerVC.typeName = model.equipmentTwoTypeName;
    centerVC.typeCode = model.goodsEquipmentType;
    centerVC.brandIDStr = model.goodsBrandId;
    centerVC.equipIntro = model.introduction;
    centerVC.equipmentID = model.equipmentId;
    centerVC.storeId = self.flagShopId;
    centerVC.sencondID = model.equipmentTwoTypeCode;
    [[ESToolAPI BtnAPI] saveRecentlyWithModel:model cellType:@"BrandTableViewCell" id:model.goodsId]; [self.parentViewController.view.superview.viewController.navigationController pushViewController:centerVC animated:YES];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake((mScreenWidth-32-8)/2, 250);
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        YFCollectionViewFlowLayout *layout = [[YFCollectionViewFlowLayout alloc] init];
        
        layout.minimumLineSpacing = 8;
        layout.minimumInteritemSpacing = 8;
        layout.sectionInset = UIEdgeInsetsMake(16, 16, 6, 16);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _collectionView.backgroundColor = kBottomBgColor;
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        [self.view addSubview:_collectionView];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.right.equalTo(0);
            make.top.equalTo(40);
            make.bottom.equalTo(0);
        }];
        //注册cell
        [_collectionView registerClass:[YFShopDesCell class] forCellWithReuseIdentifier:@"YFShopDesCell"];
        self.contentScrollView = _collectionView;
    }
    return _collectionView;
}
#pragma mark -------- UI --------
- (void)setBtnsUI {
    self.comBoBoxView = [[MMComBoBoxView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 40)];
    self.comBoBoxView.dataSource = self;
    self.comBoBoxView.delegate = self;
    self.comBoBoxView.isJob = YES;
    [self.view addSubview:self.comBoBoxView];
    [self.comBoBoxView reload];
}


#pragma mark - MMComBoBoxViewDataSource
- (NSUInteger)numberOfColumnsIncomBoBoxView :(MMComBoBoxView *)comBoBoxView {
    return self.mutableArray.count;
}

- (MMItem *)comBoBoxView:(MMComBoBoxView *)comBoBoxView infomationForColumn:(NSUInteger)column {
    return self.mutableArray[column];
}

- (void)reloadBoBoxView:(MMComBoBoxView *)comBoBoxView {
    [self getFilterData];
}
#pragma mark - MMComBoBoxViewDelegate
- (void)comBoBoxView:(MMComBoBoxView *)comBoBoxViewd didSelectedItemsPackagingInArray:(NSArray *)array atIndex:(NSUInteger)index {
    MMItem *rootItem = self.mutableArray[index];
    switch (rootItem.displayType) {
        case MMPopupViewDisplayTypeNormal:
        {
            NSMutableString *title = [NSMutableString string];
            __block NSInteger firstPath;
            __block NSString *str;
            [array enumerateObjectsUsingBlock:^(MMSelectedPath * path, NSUInteger idx, BOOL * _Nonnull stop) {
                [title appendString:idx?[NSString stringWithFormat:@";%@",[rootItem findTitleBySelectedPath:path]]:[rootItem findTitleBySelectedPath:path]];
                
                str = [rootItem findCodeBySelectedPath:path];
                if (index == 0) {
                    self.firstCode = str;
                    self.currentTypeIndex = path.firstPath;
                    NSMutableArray *tmpArr = [NSMutableArray arrayWithArray:self.filterList[path.firstPath].childList];
                    CompanyTypeListChildlist *child = [[CompanyTypeListChildlist alloc] init];
                    child.equipmentTwoTypeCode = @"";
                    child.equipmentTowTypeName = @"全部";
                    [tmpArr insertObject:child atIndex:0];
                    self.sencondFilterList = tmpArr.copy;
                    self.mutableArray = nil;
                    self.secondCode = @"";
                    [self.comBoBoxView reload];
                }
                else {
                    self.secondCode = str;
                }
                [self getData];  //更新数据
                
                if (idx == 0) {
                    firstPath = path.firstPath;
                }
            }];
            NSLog(@"当title为%@时，所选字段为 %@==========%@",rootItem.title ,title, str);
        }
            break;
            
        default:
            break;
    }
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 40, mScreenWidth,mScreenHeight-(NaviHeight)-40)];
        [self.view addSubview:_emptyView];
        [self.view bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
    }
    return _emptyView;
}
- (NSArray *)mutableArray {
    
    if (_mutableArray == nil) {
        NSMutableArray *mutableArray = [NSMutableArray array];
        NSString *itemT1 = @"";
        if (self.filterList.firstObject.equipmentFirstTypeName.length == 0) {
            itemT1 = @"设备类型";
        }
        else {
            itemT1 = self.filterList[self.currentTypeIndex].equipmentFirstTypeName;
        }
        //root 1
        MMMultiItem *rootItem1 = [MMMultiItem itemWithItemType:MMPopupViewDisplayTypeUnselected titleName:itemT1];
        for (int i = 0; i < self.filterList.count; i ++) {
            BOOL isSelected = [self.filterList[i].equipmentFirstTypeName isEqualToString:itemT1];
            MMItem *subItem = [MMItem itemWithItemType:MMPopupViewDisplayTypeSelected isSelected:isSelected titleName:self.filterList[i].equipmentFirstTypeName subtitleName:nil code:self.filterList[i].equipmentFirstTypeCode];
            [rootItem1 addNode:subItem];
        }
        
        NSString *itemT2 = @"";
        if (self.sencondFilterList.firstObject.equipmentTowTypeName.length == 0) {
            itemT2 = @"全部";
        }
        else {
            itemT2 = self.sencondFilterList.firstObject.equipmentTowTypeName;
        }
        //root 2
        MMSingleItem *rootItem2 = [MMSingleItem itemWithItemType:MMPopupViewDisplayTypeUnselected titleName:itemT2];
        for (int i = 0; i < self.sencondFilterList.count; i ++) {
            BOOL isSelected = [self.sencondFilterList[i].equipmentTowTypeName isEqualToString:itemT2];
            MMItem *subItem = [MMItem itemWithItemType:MMPopupViewDisplayTypeSelected isSelected:isSelected titleName:self.sencondFilterList[i].equipmentTowTypeName subtitleName:nil code:self.sencondFilterList[i].equipmentTwoTypeCode];
            [rootItem2 addNode:subItem];
        }
        
        [mutableArray addObject:rootItem1];
        [mutableArray addObject:rootItem2];
        _mutableArray  = [mutableArray copy];
    }
    return _mutableArray;
}

- (NSString *)firstCode {
    if (!_firstCode) {
        _firstCode = @"";
    }
    return _firstCode;
}

- (NSString *)secondCode {
    if (!_secondCode) {
        _secondCode = @"";
    }
    return _secondCode;
}
@end
