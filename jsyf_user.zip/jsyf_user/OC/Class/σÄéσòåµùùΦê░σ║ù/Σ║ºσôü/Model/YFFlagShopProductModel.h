//
//  YFFlagShopProductModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FlagShopProductE,FlagShopProductData,FlagShopProductSenddata,FlagShopProductParamlist;
@interface YFFlagShopProductModel : NSObject

@property (nonatomic, strong) FlagShopProductE *e;

@property (nonatomic, strong) FlagShopProductData *data;

@end
@interface FlagShopProductE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface FlagShopProductData : NSObject

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, strong) NSArray<FlagShopProductSenddata *> *sendData;

@end

@interface FlagShopProductSenddata : NSObject

@property (nonatomic, copy) NSString *goodsCarouselImage;

@property (nonatomic, copy) NSString *goodsThumbnail;

@property (nonatomic, copy) NSString *goodsPutAwayStatusFlag;

@property (nonatomic, copy) NSString *equipmentTwoTypeCode;

@property (nonatomic, copy) NSString *goodsPrice;

@property (nonatomic, assign) long long goodsCreatedTime;

@property (nonatomic, assign) NSInteger goodsSort;

@property (nonatomic, copy) NSString *equipmentSku;

@property (nonatomic, copy) NSString *goodsId;

@property (nonatomic, assign) NSInteger goodsSequenceId;

@property (nonatomic, copy) NSString *hotGoodsId;

@property (nonatomic, copy) NSString *hotGoodsSort;

@property (nonatomic, assign) NSInteger topFlag;

@property (nonatomic, copy) NSString *goodsHotGoodFlag;

@property (nonatomic, assign) NSInteger downFlag;

@property (nonatomic, copy) NSString *equipmentTwoTypeName;

@property (nonatomic, copy) NSString *goodsBrandId;

@property (nonatomic, copy) NSString *goodsEquipmentModel;

@property (nonatomic, assign) long long goodsModifyTime;

@property (nonatomic, copy) NSString *goodsStoreId;

@property (nonatomic, copy) NSString *goodsEquipmentTypeName;

@property (nonatomic, copy) NSString *goodsEquipmentModelName;

@property (nonatomic, copy) NSString *goodsEquipmentType;

@property (nonatomic, copy) NSString *goodsBrandName;

@property (nonatomic, copy) NSString *equipmentId;

@property (nonatomic, copy) NSString *hotGoodsCreatedTime;

@property (nonatomic, copy) NSString *goodsEquipmentImage;

@property (nonatomic, copy) NSString *introduction;

@property (nonatomic, strong) NSArray<FlagShopProductParamlist *> *paramList;

@end

@interface FlagShopProductParamlist : NSObject

@property (nonatomic, copy) NSString *equipmentParamName;

@property (nonatomic, copy) NSString *equipmentParamValue;

@end

