//
//  YFFlagShopProductModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFFlagShopProductModel.h"

@implementation YFFlagShopProductModel

@end
@implementation FlagShopProductE

@end


@implementation FlagShopProductData

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"sendData" : [FlagShopProductSenddata class]};
}

@end


@implementation FlagShopProductSenddata

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"paramList" : [FlagShopProductParamlist class]};
}

@end


@implementation FlagShopProductParamlist

@end


