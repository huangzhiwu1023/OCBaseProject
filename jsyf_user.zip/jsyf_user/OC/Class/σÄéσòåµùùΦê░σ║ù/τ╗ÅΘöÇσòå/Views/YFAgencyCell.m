//
//  YFAgencyCell.m
//  jsyf_user
//
//  Created by 程辉 on 2018/11/8.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFAgencyCell.h"

@implementation YFAgencyCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self headImg];
        [self nameLB];
        [self levelIV];
        [self certifyImg];
        [self addressLB];
        [self lineView];
        
    }
    return self;
}

- (void)setModel:(FlagShopAgencySenddata *)model {
    _model = model;
    [self.headImg sd_setImageWithURL:model.headImg.lx_URL placeholderImage:kPlaceholderImage];
    self.nameLB.text = model.storeName;
    if ([model.vipLevel isEqualToString:@"0"]) {
        [self.certifyImg mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.levelIV.mas_left).offset(0);
        }];
    }
    else {
        [self.certifyImg mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.levelIV.mas_right).offset(8);
        }];
    }
    if ([model.vipLevel isEqualToString:@"0"]) {
        self.levelIV.hidden = YES;
    } else if ([model.vipLevel isEqualToString:@"1"]) {
        self.levelIV.hidden = NO;
        self.levelIV.image = [UIImage imageNamed:@"vip_normal"];
    } else if ([model.vipLevel isEqualToString:@"2"]) {
        self.levelIV.hidden = NO;
        self.levelIV.image = [UIImage imageNamed:@"vip_middle"];
    } else if ([model.vipLevel isEqualToString:@"3"]) {
        self.levelIV.hidden = NO;
        self.levelIV.image = [UIImage imageNamed:@"vip_vip"];
    } else if ([model.vipLevel isEqualToString:@"4"]) {
        self.levelIV.hidden = NO;
        self.levelIV.image = [UIImage imageNamed:@"vip_high"];
    }
    self.addressLB.text = model.storeAddress;
}

- (UIImageView *)headImg {
    if (!_headImg) {
        _headImg = [[UIImageView alloc] init];
        _headImg.contentMode = UIViewContentModeScaleAspectFill;
        _headImg.layer.masksToBounds = YES;
        _headImg.layer.cornerRadius = 4;
        [self.contentView addSubview:_headImg];
        [_headImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.left.equalTo(16);
            make.width.equalTo(105);
            make.height.equalTo(80);
        }];
        
    }
    return _headImg;
}

- (UILabel *)nameLB {
    if (!_nameLB) {
        _nameLB = [[UILabel alloc] init];
        _nameLB.text = @"";
        _nameLB.font = KFont16;
        _nameLB.textColor = k333Color;
        [self.contentView addSubview:_nameLB];
        [_nameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.headImg.mas_top);
            make.left.equalTo(self.headImg.mas_right).offset(8);
            make.height.equalTo(22);
            make.right.equalTo(-16);
        }];
    }
    return _nameLB;
}

- (UIImageView *)levelIV {
    if (!_levelIV) {
        _levelIV = [[UIImageView alloc] init];
        _levelIV.image = [UIImage imageNamed:@"vip_high"];
        [self addSubview:_levelIV];
        [_levelIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.nameLB.mas_bottom).offset(6);
            make.left.equalTo(self.nameLB.mas_left);
            make.width.equalTo(45);
            make.height.equalTo(16);
        }];
        _levelIV.contentMode = UIViewContentModeLeft;
    }
    return _levelIV;
}

- (UIImageView *)certifyImg {
    if (!_certifyImg) {
        _certifyImg = [[UIImageView alloc] init];
        _certifyImg.image = [UIImage imageNamed:@"cer_n"];
        [self addSubview:_certifyImg];
        [_certifyImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.levelIV.mas_centerY);
            make.left.equalTo(self.levelIV.mas_right).offset(8);
            make.width.equalTo(56);
            make.height.equalTo(15);
        }];
        _certifyImg.contentMode = UIViewContentModeLeft;
    }
    return _certifyImg;
}

- (UILabel *)addressLB {
    if (!_addressLB) {
        _addressLB = [[UILabel alloc] init];
        _addressLB.text = @"";
        _addressLB.font = kFont12;
        _addressLB.textColor = k999Color;
        _addressLB.numberOfLines = 2;
        [self.contentView addSubview:_addressLB];
        [_addressLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.levelIV.mas_bottom).offset(5);
            make.left.equalTo(self.nameLB.mas_left);
            make.bottom.equalTo(self.headImg.mas_bottom);
            make.right.equalTo(-16);
        }];
    }
    return _addressLB;
}

- (UIView *)lineView {
    if (!_lineView) {
        _lineView = [[UIView alloc] init];
        _lineView.backgroundColor = mHexColor(0xEDEDED);
        [self.contentView addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(0);
            make.height.equalTo(1);
            make.top.equalTo(109);
        }];
    }
    return _lineView;
}


@end
