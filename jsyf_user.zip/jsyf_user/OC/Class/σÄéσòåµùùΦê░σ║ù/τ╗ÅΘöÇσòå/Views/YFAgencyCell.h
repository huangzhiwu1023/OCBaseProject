//
//  YFAgencyCell.h
//  jsyf_user
//
//  Created by 程辉 on 2018/11/8.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YFFlagShopAgencyModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface YFAgencyCell : UITableViewCell

@property (nonatomic, strong) UIImageView *headImg;
@property (nonatomic, strong) UILabel *nameLB;
@property (nonatomic, strong) UIImageView *levelIV;
@property (nonatomic, strong) UIImageView *certifyImg;
@property (nonatomic, strong) UILabel *addressLB;
@property (nonatomic, strong) UIView *lineView;

@property(nonatomic, strong) FlagShopAgencySenddata *model;

@end

NS_ASSUME_NONNULL_END
