//
//  YFFlagShopAgencyVC.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/11/6.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFFlagShopAgencyVC.h"
#import "YFAgencyCell.h"
#import "YFShopSelectProvinceView.h"
#import "YFFlagShopAgencyModel.h"

@interface YFFlagShopAgencyVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property(nonatomic, strong) NSString *areaCode;
@property(nonatomic, strong) YFShopSelectProvinceView *selectView;

@property(nonatomic, strong) YFNoDataView  *emptyView;

@property(nonatomic, strong) NSMutableArray<FlagShopAgencySenddata *> *dataList;
@property(nonatomic, assign) NSInteger page;

@end

@implementation YFFlagShopAgencyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.page = 1;
    self.view.backgroundColor = kBottomBgColor;
    [self tableView];
    [self addSelectView];
    [self requestData];
    mWeakSelf
    [self.tableView addBackFooterRefresh:^{
        [weakSelf requestDataMore];
    }];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self hideSelectView];
}

#pragma mark -------- netWork --------
- (void)requestData {
    [self.tableView.mj_footer resetNoMoreData];
    NSDictionary *tmpDic = @{@"storeId" : self.flagShopId,@"provinceCode":self.areaCode};
    NSDictionary *bodyDic = @{@"jsonParam":tmpDic,@"page":@"1",@"rows":@"10"};
    [[[ESNetworkManager getFlagShopAgencyData:bodyDic] map:^id(id value) {
        return [YFFlagShopAgencyModel mj_objectWithKeyValues:value];
    }] subscribeNext:^(YFFlagShopAgencyModel *  _Nullable x) {
        self.page = 1;
        [self.dataList removeAllObjects];
        [self.dataList addObjectsFromArray:x.data.sendData];
        [self.tableView reloadData];
        if (self.dataList.count == 0) {
            self.emptyView.hidden = NO;
        }
        else {
            self.emptyView.hidden = YES;
        }
    } error:^(NSError * _Nullable error) {
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
}

- (void)requestDataMore {
    NSDictionary *tmpDic = @{@"storeId" : self.flagShopId,@"provinceCode":self.areaCode};
    NSDictionary *bodyDic = @{@"jsonParam":tmpDic,@"page":@(self.page+1).stringValue,@"rows":@"10"};
    [[[ESNetworkManager getFlagShopAgencyData:bodyDic] map:^id(id value) {
        return [YFFlagShopAgencyModel mj_objectWithKeyValues:value];;
    }] subscribeNext:^(YFFlagShopAgencyModel * _Nullable x) {
        if (x.data.sendData.count == 0) {
            [self.tableView endFooterRefreshWithNoMoreData];
        }
        else {
            [self.tableView endFooterRefresh];
        }
        self.page += 1;
        [self.dataList addObjectsFromArray:x.data.sendData];
        [self.tableView reloadData];
       
    } error:^(NSError * _Nullable error) {
        [self.tableView endFooterRefresh];
        [kAppDelegate.window showWarning:error.localizedDescription];
    }];
}
#pragma mark -------- 筛选省 --------
- (void)addSelectView {
    self.selectView = [[YFShopSelectProvinceView alloc] initWithFrame:CGRectMake(mScreenWidth-38, CGRectGetMidX(self.view.bounds)-125, 300, 250)];
    [self.view addSubview:self.selectView];
    NSString *currentStr = [self getCurrentProvince];
    self.selectView.locationStr = currentStr;
    //请求数据
    NSArray *arr = [[ESToolAPI BtnAPI] getProvinceCodeWithProvincename:currentStr cityname:@""];
    self.areaCode = arr.firstObject;
//    [self requestListData];
    //添加点击事件
    [self.selectView.locationBtn addTarget:self action:@selector(selectProvince:) forControlEvents:UIControlEventTouchUpInside];
    //确定选择省份回调
    mWeakSelf
    self.selectView.changeBlock = ^(NSString *name, NSString *code) {
        [weakSelf saveCurrentProince:name];
        weakSelf.areaCode = code;
        [weakSelf requestData];
        [weakSelf hideSelectView];
    };
}

//选择省
- (void)selectProvince:(UIButton *)sender {
    sender.selected = !sender.isSelected;
    if (sender.isSelected) {
        [self showSelectView];
    } else {
        [self hideSelectView];
    }
}
//展开选择View
- (void)showSelectView {
    self.selectView.isShow = YES;
    [UIView animateWithDuration:0.3 animations:^{
        self.selectView.frame = CGRectMake(mScreenWidth-300, CGRectGetMidX(self.view.bounds)-125, 300, 250);
    } completion:^(BOOL finished) {
        
    }];
}
//收起选择View
- (void)hideSelectView {
    self.selectView.isShow = NO;
    [UIView animateWithDuration:0.3 animations:^{
        self.selectView.frame = CGRectMake(mScreenWidth-38, CGRectGetMidX(self.view.bounds)-125, 300, 250);
    } completion:^(BOOL finished) {
    }];
}
//获取省名
- (NSString *)getCurrentProvince {
    NSString *locationStr = [[YFUserDefaultTool sharedInstance] getStringValue:@"centerProvince"];
    if (locationStr.length == 0) {
        locationStr = [[YFUserDefaultTool sharedInstance] getStringValue:@"provice"];
    }
    if (locationStr.length == 0) {
        locationStr = @"北京市";
    }
    return locationStr;
}

//缓存省名
- (void)saveCurrentProince:(NSString *)province {
    [[YFUserDefaultTool sharedInstance] setStringValue:@"centerProvince" andValue:province];
}


#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFAgencyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"YFAgencyCell"];
    cell.model = self.dataList[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    PersonalCenterController *vc =[[PersonalCenterController alloc] init];
    FlagShopAgencySenddata *model = self.dataList[indexPath.row];
    vc.detailStyle = 2;
    vc.haveESJ = [model.secondFlag isEqualToString:@"1"]; //是否包含二手机
    vc.haveLive = [model.liveFlag isEqualToString:@"1"];  //是否包含直播
    vc.parameterStr = @(model.storeSequence).stringValue;
    vc.storeId = model.storeId;
    vc.isNoCentify = NO;
    vc.companyName = model.storeName;
    [[ESToolAPI BtnAPI] saveRecentlyWithModel:model cellType:@"YFAllShopCell" id:model.storeId];
   [self.parentViewController.view.superview.viewController.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 110;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *back = [[UIView alloc] init];
    return back;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 4;
}

- (UITableView *)tableView {
    if (!_tableView) {
         _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth, mScreenHeight- NaviHeight - 44) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.backgroundColor = kBottomBgColor;
        [self.view addSubview:_tableView];
        
        //注册cell
        [_tableView registerClass:[YFAgencyCell class] forCellReuseIdentifier:@"YFAgencyCell"];
        self.contentScrollView = _tableView;
    }
    return _tableView;
}

- (YFNoDataView *)emptyView {
    if (!_emptyView) {
        _emptyView = [[YFNoDataView alloc] initWithFrame:CGRectMake(0, 0, mScreenWidth,mScreenHeight - NaviHeight-44)];
        [self.tableView addSubview:_emptyView];
        [self.tableView bringSubviewToFront:_emptyView];
        _emptyView.viewType = YFNoDataViewTypeNone;
        _emptyView.titleLabel.text = @"空空如也~";
        _emptyView.hidden = YES;
        _emptyView.userInteractionEnabled = NO;
    }
    return _emptyView;
}

- (NSString *)areaCode {
    if (!_areaCode) {
        _areaCode = @"";
    }
    return _areaCode;
}
- (NSMutableArray<FlagShopAgencySenddata *> *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}
@end
