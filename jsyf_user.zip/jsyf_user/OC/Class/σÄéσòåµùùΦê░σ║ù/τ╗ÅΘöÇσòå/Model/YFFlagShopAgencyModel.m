//
//  YFFlagShopAgencyModel.m
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import "YFFlagShopAgencyModel.h"

@implementation YFFlagShopAgencyModel

@end
@implementation FlagShopAgencyE

@end


@implementation FlagShopAgencyData

+ (NSDictionary *)mj_objectClassInArray{
    return @{@"sendData" : [FlagShopAgencySenddata class]};
}

@end


@implementation FlagShopAgencySenddata

@end


