//
//  YFFlagShopAgencyModel.h
//  UITableViewLInkageDemo
//
//  Created by 吕祥 on 2018/11/16.
//  Copyright © 2018年 Hawk. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FlagShopAgencyE,FlagShopAgencyData,FlagShopAgencySenddata;
@interface YFFlagShopAgencyModel : NSObject

@property (nonatomic, strong) FlagShopAgencyE *e;

@property (nonatomic, strong) FlagShopAgencyData *data;

@end
@interface FlagShopAgencyE : NSObject

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, assign) NSInteger code;

@end

@interface FlagShopAgencyData : NSObject

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, strong) NSArray<FlagShopAgencySenddata *> *sendData;

@end

@interface FlagShopAgencySenddata : NSObject

@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, copy) NSString *storeAddress;

@property (nonatomic, copy) NSString *brandId;

@property (nonatomic, assign) NSInteger storeSequence;

@property (nonatomic, copy) NSString *vipLevel;

@property (nonatomic, copy) NSString *storeId;

@property (nonatomic, copy) NSString *headImg;

@property (nonatomic, copy) NSString *provinceName;

@property (nonatomic, copy) NSString *storeName;

@property (nonatomic, copy) NSString *secondFlag;
@property (nonatomic, copy) NSString *liveFlag;
@end

