//
//  YFWXPayUtil.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/25.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFWXPayUtil.h"
#import "WXApi.h"
#import "WXApiObject.h"

@interface YFWXPayUtil()
-(id)initialize;
@end

@implementation YFWXPayUtil

//单例模式
+(YFWXPayUtil *)sharedInstance {
    static YFWXPayUtil *sharedSingleton = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^(void) {
        sharedSingleton = [[self alloc] initialize];
    });
    return sharedSingleton;
}

-(id)initialize {
    if(self == [super init]){
        //initial something here
    }
    return self;
}

- (void)doPay {
    PayReq *request = [[PayReq alloc] init];
    request.partnerId = @"10000100";
    request.prepayId= @"1101000000140415649af9fc314aa427";
    request.package = @"Sign=WXPay";
    request.nonceStr= @"a462b76e7436e98e0ed6e13c64b4fd1c";
    UInt32 timeStamp =[@"1397527777" intValue];
    request.timeStamp= timeStamp;
    request.sign= @"582282D72DD2B03AD892830965F428CB16E7A256";
    
    [WXApi sendReq:request];
}
@end
