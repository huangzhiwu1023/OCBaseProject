//
//  YFWXPayUtil.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/25.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFWXPayUtil : NSObject
+ (YFWXPayUtil *)sharedInstance;
- (void)doPay;
@end
