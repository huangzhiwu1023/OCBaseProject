//
//  YFPlayOrPauseView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/9/13.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YFPlayOrPauseView;
@protocol YFPlayOrPauseViewDelegate <NSObject>
@required
/**
 暂停和播放视图和状态
 
 @param pauseOrPlayView 暂停或者播放视图
 @param state 返回状态
 */
-(void)pauseOrPlayView:(YFPlayOrPauseView *)pauseOrPlayView withState:(BOOL)state;

@end

@interface YFPlayOrPauseView : UIView
@property (nonatomic,strong) UIButton *imageBtn;
@property (nonatomic,weak) id<YFPlayOrPauseViewDelegate> delegate;
@property (nonatomic,assign,readonly) BOOL state;
@end
