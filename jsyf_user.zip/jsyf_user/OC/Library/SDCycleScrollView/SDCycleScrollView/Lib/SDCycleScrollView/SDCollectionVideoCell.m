//
//  SDCollectionVideoCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/9/5.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "SDCollectionVideoCell.h"

@implementation SDCollectionVideoCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self playerView];
    }
    return self;
}

- (UIView *)playerView {
    if (!_playerView) {
        _playerView = [[UIView alloc] init];
        [self.contentView addSubview:_playerView];
        _playerView.frame = CGRectMake(0, 0, mScreenWidth, mScreenWidth*0.56);
        
    }
    return _playerView;
}


@end
