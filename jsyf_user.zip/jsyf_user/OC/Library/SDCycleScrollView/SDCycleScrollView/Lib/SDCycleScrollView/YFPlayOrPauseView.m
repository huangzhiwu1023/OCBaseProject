//
//  YFPlayOrPauseView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/9/13.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFPlayOrPauseView.h"

@implementation YFPlayOrPauseView

- (void)drawRect:(CGRect)rect {
    [self imageBtn];
}

- (UIButton *)imageBtn {
    if (!_imageBtn) {
        _imageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_imageBtn setImage:[UIImage imageNamed:@"video_pause"] forState:UIControlStateNormal];
        [_imageBtn setShowsTouchWhenHighlighted:YES];
        [_imageBtn setImage:[UIImage imageNamed:@"video_play"] forState:UIControlStateSelected];
        [_imageBtn addTarget:self action:@selector(handleImageTapAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_imageBtn];
        [_imageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(self);
        }];
    }
    return _imageBtn;
}

-(void)handleImageTapAction:(UIButton *)button{
    button.selected = !button.selected;
    _state = button.isSelected ? YES : NO;
    if ([self.delegate respondsToSelector:@selector(pauseOrPlayView:withState:)]) {
        [self.delegate pauseOrPlayView:self withState:_state];
    }
}

@end
