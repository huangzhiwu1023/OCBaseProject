//
//  UITableView+CCPIndexView.h
//  CCPIndexView
//
//  Created by chuchengpeng on 2017/12/21.
//  Copyright © 2017年 chuchengpeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (CCPIndexView)

- (void)ccpIndexView;

@end

