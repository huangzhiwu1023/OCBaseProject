//
//  YFAlipayUtil.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/24.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFAlipayUtil : NSObject
+ (YFAlipayUtil *)sharedInstance;

- (void)doPay:(YFAlipayProductInfo *)product;

//随机生成订单号(用于测试,订单号有服务器返回)
- (NSString *)generateTradeNO;
@end
