//
//  YFAlipayProductInfo.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/24.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFAlipayProductInfo.h"

@implementation YFAlipayProductInfo

@end
