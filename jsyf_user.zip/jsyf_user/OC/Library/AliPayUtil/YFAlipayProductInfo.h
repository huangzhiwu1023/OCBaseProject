//
//  YFAlipayProductInfo.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/24.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface YFAlipayProductInfo : NSObject
//订单ID
@property(nonatomic, strong) NSString *orderNO;
//商品的标题/交易标题/订单标题/订单关键字等
@property(nonatomic, strong) NSString *subject;
// NOTE: (非必填项)商品描述
@property(nonatomic, strong) NSString *body;
//NOTE: 订单总金额，单位为元，精确到小数点后两位，取值范围[0.01,100000000]
@property(nonatomic, strong) NSString *total_amount;
//支付宝回调地址
@property(nonatomic, strong) NSString *callbackurl;

//如果加签放在服务器,则sing有此入口传入
@property(nonatomic, strong) NSString *signedString;
@end
