//
//  ZTLetterIndex.h
//  ZTLetterIndexDemo
//
//  Created by 赵天福 on 2017/3/20.
//  Copyright © 2017年 赵天福. All rights reserved.
//

#import "ZTLetterIndex.h"
#import <objc/runtime.h>

#define kAnimationDuration  0.01f  //0.2->0.01
#define kLableHeight 56

@interface ZTIndexLabel:UILabel
@end

@implementation ZTIndexLabel

- (instancetype)init {
    if (self = [super init]) {
        self.bounds = CGRectMake(0, 0, 60, 60);
        self.textColor = [UIColor whiteColor];
        self.font = [UIFont systemFontOfSize:18 weight:1.5];
        self.adjustsFontSizeToFitWidth = YES;
        self.textAlignment = NSTextAlignmentCenter;
        self.layer.cornerRadius = 30;
        self.clipsToBounds = YES;
        self.backgroundColor = [UIColor colorWithRed:65/255 green:65/255 blue:125/255 alpha:0.5];
        // [self circelLayer];
    }
    return self;
}

@end

@interface ZTLetterIndex ()
{
    NSInteger _lastIndex;
    CALayer   *_slidr;
    CALayer *_slidrColor;
}

@property (nonatomic, strong) ZTIndexLabel *idLabel;

@end
static const void *indexLabel_key = &indexLabel_key;
@implementation ZTLetterIndex

- (void)setIdLabel:(ZTIndexLabel *)idLabel {
    objc_setAssociatedObject(self, indexLabel_key, idLabel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (ZTIndexLabel *)idLabel {
    return objc_getAssociatedObject(self, &indexLabel_key);
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _lastIndex = 0;
        self.textColor = [UIColor lightGrayColor];
        self.selectedTextColor = [UIColor whiteColor];
        self.itemSize = CGSizeMake(16.0f, 18.0f);
        self.sliderSize = CGSizeMake(16.0f, 16.0f);
        self.sliderColor = [UIColor lightGrayColor];
        self.textFont = [UIFont fontWithName:@"PingFangSC-Medium" size:12.0f];
        self.sliderSpace = 4.0f;
    }
    return self;
}

- (void)setDataArray:(NSArray *)dataArray
{
    _dataArray = dataArray;
    [self setupItems];
}

- (void)setupItems
{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.width, 40)];
    [self addSubview:label];
    label.textColor = k333Color;
    label.font = [UIFont systemFontOfSize:11];
    label.numberOfLines = 0;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = @"按\n拼\n音";
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake((self.width-12)/2, 45, 12, 1)];
    line.backgroundColor = mHexColor(0xCCCCCC);
    [self addSubview:line];
    
    
    
    _slidr = [CALayer layer];
    _slidr.frame = CGRectMake((self.bounds.size.width - self.sliderSize.width)/2, kLableHeight, self.sliderSize.width, self.sliderSize.height + 2*self.sliderSpace);
    _slidr.backgroundColor = [UIColor clearColor].CGColor;
    [self.layer addSublayer:_slidr];
    
    _slidrColor = [CALayer layer];
    _slidrColor = [CALayer layer];
    _slidrColor.frame = CGRectMake(0, self.sliderSpace, self.sliderSize.width, self.sliderSize.height);
    _slidrColor.cornerRadius = _slidrColor.bounds.size.width/2;
    _slidrColor.backgroundColor = self.sliderColor.CGColor;
    [_slidr addSublayer:_slidrColor];
    
    [self.dataArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UILabel *item = [[UILabel alloc] init];
        item.frame = CGRectMake((self.bounds.size.width - self.itemSize.width)/2, self.itemSize.height * idx + (_slidr.bounds.size.height - self.itemSize.height) + kLableHeight, self.itemSize.width, self.itemSize.height);
        
        item.backgroundColor = [UIColor clearColor];
      
        item.text = [NSString stringWithFormat:@"%@",obj];
        item.font = self.textFont;
        item.textAlignment = NSTextAlignmentCenter;
        item.textColor = self.textColor;
        item.tag = 999 + idx;
        item.layer.masksToBounds = NO;
        item.userInteractionEnabled = YES;
        [self addSubview:item];
        
        UITapGestureRecognizer *singleTapGR;
        UILongPressGestureRecognizer *longPressGR;
        
        longPressGR = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(touchLong:)];
        longPressGR.allowableMovement=NO;
        longPressGR.minimumPressDuration = 0.2;
        singleTapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchDown:)];
        singleTapGR.numberOfTapsRequired = 1;
        singleTapGR.numberOfTouchesRequired = 1;
//        [item addGestureRecognizer:longPressGR];
        [item addGestureRecognizer:singleTapGR];
    }];
    
    UILabel *firstItem = (UILabel *)[self viewWithTag:999];
    firstItem.frame = CGRectMake((self.bounds.size.width - self.itemSize.width)/2, kLableHeight, self.itemSize.width, _slidr.bounds.size.height);
    firstItem.textColor = self.selectedTextColor;
//     _slidrColor.backgroundColor = [UIColor clearColor].CGColor;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"===%@ ===",(touches.anyObject.gestureRecognizers.firstObject.view));
    if ([touches.anyObject.gestureRecognizers.firstObject.view isKindOfClass:[UILabel class]]) {
        UILabel *item = (UILabel *)touches.anyObject.gestureRecognizers.firstObject.view;
        [self selectIndex:item.tag - 999];
        if (self.delegate && [self.delegate respondsToSelector:@selector(ZTLetterIndex:didSelectedItemWithIndex:)]) {
            [self.delegate ZTLetterIndex:self didSelectedItemWithIndex:item.tag - 999];
            [self addIdLabelWithText:item.text isHidden:NO];
        }
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
     CGPoint point = [touches.anyObject locationInView:self];
    if (point.y < _lastIndex * self.itemSize.height + kLableHeight && point.y > 0 + kLableHeight) {
        [self selectIndex:_lastIndex - 1];
    }
    else if (point.y > _lastIndex * self.itemSize.height + _slidr.bounds.size.height + kLableHeight && point.y < self.itemSize.height * self.dataArray.count + _slidr.bounds.size.height - self.itemSize.height + kLableHeight) {
        [self selectIndex:_lastIndex + 1];
    }
    if (self.delegate && [self.delegate respondsToSelector:@selector(ZTLetterIndex:isChangingItemWithIndex:)]) {
        [self.delegate ZTLetterIndex:self isChangingItemWithIndex:_lastIndex];
        UILabel *item = (UILabel *)[self viewWithTag:_lastIndex + 999];
        [self addIdLabelWithText:item.text isHidden:NO];
    }
    
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self dismissIdLable];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

}

- (void)touchDown:(UITapGestureRecognizer *)recognizer {
    if ([recognizer.view isKindOfClass:[UILabel class]]) {
        UILabel *item = (UILabel *)recognizer.view;
        [self selectIndex:item.tag - 999];
        if (self.delegate && [self.delegate respondsToSelector:@selector(ZTLetterIndex:didSelectedItemWithIndex:)]) {
            [self.delegate ZTLetterIndex:self didSelectedItemWithIndex:item.tag - 999];
            [self addIdLabelWithText:item.text isHidden:NO];
        }
    }
    [self dismissIdLable];
}

- (void)touchLong:(UILongPressGestureRecognizer *)recognizer
{
    UILabel *item = (UILabel *)recognizer.view;
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        NSLog(@"===== Began ====");
        [self selectIndex:item.tag - 999];
        if (self.delegate && [self.delegate respondsToSelector:@selector(ZTLetterIndex:beginChangeItemWithIndex:)]) {
            [self.delegate ZTLetterIndex:self beginChangeItemWithIndex:item.tag - 999];
        }
    }
    else if (recognizer.state == UIGestureRecognizerStateChanged) {
        CGPoint point = [recognizer locationInView:self];
        
        if (point.y < _lastIndex * self.itemSize.height + kLableHeight && point.y > 0 + kLableHeight) {
            [self selectIndex:_lastIndex - 1];
        }
        else if (point.y > _lastIndex * self.itemSize.height + _slidr.bounds.size.height+kLableHeight && point.y < self.itemSize.height * self.dataArray.count + _slidr.bounds.size.height - self.itemSize.height + kLableHeight) {
            [self selectIndex:_lastIndex + 1];
        }
        if (self.delegate && [self.delegate respondsToSelector:@selector(ZTLetterIndex:isChangingItemWithIndex:)]) {
            [self.delegate ZTLetterIndex:self isChangingItemWithIndex:_lastIndex];
        }
    }
    else if (recognizer.state == UIGestureRecognizerStateEnded || recognizer.state == UIGestureRecognizerStateCancelled) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(ZTLetterIndex:endChangeItemWithIndex:)]) {
            [self.delegate ZTLetterIndex:self endChangeItemWithIndex:_lastIndex];
        }
    }
    
}

- (void)selectIndex:(NSInteger)index;
{
//    _slidrColor.backgroundColor = self.sliderColor.CGColor;
    UILabel *item = (UILabel *)[self viewWithTag:index + 999];
    
    if (item.tag - 999 == _lastIndex) {
        return;
    }
    
    UILabel *oldItem = [self viewWithTag:_lastIndex + 999];
    
    [UIView animateWithDuration:kAnimationDuration
                     animations:^{
                         _slidr.frame = CGRectMake(_slidr.frame.origin.x, index*self.itemSize.height+kLableHeight, _slidr.bounds.size.width, _slidr.bounds.size.height);
                     }
                     completion:^(BOOL finished) {
                         item.textColor = self.selectedTextColor;
                         oldItem.textColor = self.textColor;
                     }];
    
    if (oldItem.tag < item.tag) {
        oldItem.frame = CGRectMake(oldItem.frame.origin.x, oldItem.frame.origin.y + (_slidr.bounds.size.height - self.itemSize.height), self.itemSize.width, self.itemSize.height);
        for (int i = (int)_lastIndex; i < item.tag - 999; ++i) {
            UILabel *changeItem = [self viewWithTag:i + 999];
            changeItem.frame = CGRectMake(changeItem.frame.origin.x, changeItem.frame.origin.y - (_slidr.bounds.size.height - self.itemSize.height), changeItem.bounds.size.width, changeItem.bounds.size.height);
        }
        item.frame = _slidr.frame;
    }
    else if (oldItem.tag > item.tag) {
        oldItem.frame = CGRectMake(oldItem.frame.origin.x, oldItem.frame.origin.y + (_slidr.bounds.size.height - self.itemSize.height), self.itemSize.width, self.itemSize.height);
        for (int i = (int)item.tag - 999 + 1; i < _lastIndex; ++i) {
            UIButton *changeItem = [self viewWithTag:i + 999];
            changeItem.frame = CGRectMake(changeItem.frame.origin.x, changeItem.frame.origin.y + (_slidr.bounds.size.height - self.itemSize.height), changeItem.bounds.size.width, changeItem.bounds.size.height);
        }
        item.frame = _slidr.frame;
    }
    _lastIndex = item.tag - 999;
}
//idLable 出现与消失
- (void)addIdLabelWithText:(NSString *)text isHidden:(BOOL)hidden {
    [self.layer removeAllAnimations];
    if (self.idLabel == nil) {
        self.idLabel = [[ZTIndexLabel alloc] init];
        self.idLabel.frame = CGRectMake(100, 100, 60, 60);
        [[UIApplication sharedApplication].keyWindow addSubview:self.idLabel];
        [self.idLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
            make.width.height.equalTo(60);
        }];
    }
    self.idLabel.alpha = 1;
    self.idLabel.text = text;
    self.idLabel.hidden = hidden;
}

- (void)dismissIdLable {
    [self.layer removeAllAnimations];
    [UIView animateWithDuration:0.8 animations:^{
        self.idLabel.alpha = 0;
    } completion:^(BOOL finished) {
    }];
}

@end
