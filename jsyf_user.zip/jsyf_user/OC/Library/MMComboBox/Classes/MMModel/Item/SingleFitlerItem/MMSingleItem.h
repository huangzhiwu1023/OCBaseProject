//
//  MMSingleItem.h
//  MMComboBoxDemo
//
//  Created by wyy on 2017/4/10.
//  Copyright © 2017年 wyy. All rights reserved.
//

#import "MMItem.h"

@interface MMSingleItem : MMItem

@end
