//
//  YFMMFilterFooterView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/7/20.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFMMFilterFooterView : UIView 

@property(nonatomic, strong) UILabel *nameLB;
@property(nonatomic, strong) UILabel *contentLB;
@property(nonatomic, strong) UIButton *confirmBtn;

@end
