//
//  MMJobRightCell.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/24.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "MMJobRightCell.h"
#import "MMComboBoxHeader.h"
static const CGFloat horizontalMargin = 10.0f;
@interface MMJobRightCell ()
@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UILabel *subTitle;
@property (nonatomic, strong) UIImageView *selectedImageview;
@property (nonatomic, strong) CALayer *bottomLine;
@end

@implementation MMJobRightCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.selectionStyle = 0;
    self.selectedImageview.frame = CGRectMake(self.width-24-18, (self.height -12)/2, 18, 12);
    self.title.frame = CGRectMake(24, 0, self.width-24-18-20-24, self.height);
//    self.title.textAlignment = NSTextAlignmentCenter;
    if (_item.subTitle != nil) {
        self.subTitle.frame = CGRectMake(self.width - horizontalMargin - 100 , 0, 100, self.height);
    }
    self.bottomLine.frame = CGRectMake(0, self.height - 1.0/MMscale , self.width, 1.0/MMscale);
}

- (void)setItem:(MMItem *)item{
    _item = item;
    self.title.text = item.title;
    self.title.textColor = item.isSelected?mHexColor(0xF48F4A):kDarkWordColor;
    if (item.subTitle != nil) {
        self.subTitle.text  = item.subTitle;
    }
    self.backgroundColor = item.isSelected?[UIColor colorWithHexString:SelectedBGColor]:[UIColor colorWithHexString:UnselectedBGColor];
    self.selectedImageview.hidden = !item.isSelected;
}

#pragma mark - get
- (UILabel *)title {
    if (!_title) {
        _title = [[UILabel alloc] init];
        _title.textColor = kDarkWordColor;
        _title.font = [UIFont systemFontOfSize:MainTitleFontSize];
        [self addSubview:_title];
    }
    return _title;
}

- (UILabel *)subTitle {
    if (!_subTitle) {
        _subTitle = [[UILabel alloc] init];
        _subTitle.textColor = [UIColor blackColor];
        _subTitle.textAlignment = NSTextAlignmentRight;
        _subTitle.font = [UIFont systemFontOfSize:SubTitleFontSize];
        [self addSubview:_subTitle];
    }
    return _subTitle;
}

- (UIImageView *)selectedImageview {
    if (!_selectedImageview) {
        _selectedImageview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"job_selected"]];
        [self addSubview:_selectedImageview];
    }
    return _selectedImageview;
}

- (CALayer *)bottomLine {
    if (!_bottomLine) {
        _bottomLine = [CALayer layer];
        _bottomLine.backgroundColor = kLineColor.CGColor;
        _bottomLine.backgroundColor = [UIColor clearColor].CGColor;
        [self.layer addSublayer:_bottomLine];
    }
    return _bottomLine;
}
@end
