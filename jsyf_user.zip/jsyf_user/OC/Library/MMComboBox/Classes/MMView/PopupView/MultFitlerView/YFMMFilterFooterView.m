//
//  YFMMFilterFooterView.m
//  jsyf_user
//
//  Created by 吕祥 on 2018/7/20.
//  Copyright © 2018年 YF. All rights reserved.
//

#import "YFMMFilterFooterView.h"

@implementation YFMMFilterFooterView
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        [self nameLB];
        [self contentLB];
        [self confirmBtn];
    }
    return self;
}

- (UILabel *)nameLB {
    if (!_nameLB) {
        _nameLB = [[UILabel alloc] init];
        [self addSubview:_nameLB];
        [_nameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(16);
            make.centerY.equalTo(0);
            make.width.equalTo(50);
        }];
        _nameLB.textColor = mHexColor(0x333333);
        _nameLB.font = [UIFont systemFontOfSize:13];
        _nameLB.text = @"已选择:";
    }
    return _nameLB;
}

- (UILabel *)contentLB {
    if (!_contentLB) {
        _contentLB = [[UILabel alloc] init];
        [self addSubview:_contentLB];
        [_contentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.nameLB.mas_right).equalTo(4);
            make.centerY.equalTo(0);
            make.right.equalTo(self.confirmBtn.mas_left).equalTo(-4);
        }];
        _contentLB.textColor = mHexColor(0x666666);
        _contentLB.font = [UIFont systemFontOfSize:13];
    }
    return _contentLB;
}

- (UIButton *)confirmBtn {
    if (!_confirmBtn) {
        _confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_confirmBtn];
        [_confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-16);
            make.centerY.equalTo(0);
            make.width.equalTo(64);
            make.height.equalTo(30);
        }];
        _confirmBtn.backgroundColor = mHexColor(0xF48F4A);
        [_confirmBtn setTitle:@"确定" forState:UIControlStateNormal];
        [_confirmBtn setTitleColor:mHexColor(0xFFFFFF) forState:UIControlStateNormal];
        _confirmBtn.titleLabel.font = [UIFont systemFontOfSize:13];
        _confirmBtn.layer.cornerRadius = 4;
        _confirmBtn.layer.masksToBounds = YES;
    }
    return _confirmBtn;
}
@end
