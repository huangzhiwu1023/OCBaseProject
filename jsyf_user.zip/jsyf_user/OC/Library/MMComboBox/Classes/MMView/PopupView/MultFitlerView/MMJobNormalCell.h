//
//  MMJobNormalCell.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/4/24.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMItem.h"

@interface MMJobNormalCell : UITableViewCell
@property (nonatomic, strong) MMItem *item;
@end
