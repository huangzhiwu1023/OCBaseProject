//
//  MMDropDownBox.m
//  MMComboBoxDemo
//
//  Created by wyy on 2016/12/7.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import "MMDropDownBox.h"
#import "MMComboBoxHeader.h"
@interface MMDropDownBox ()
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIImageView *arrow;
@property (nonatomic, strong) CAGradientLayer *line;
@end

@implementation MMDropDownBox
- (id)initWithFrame:(CGRect)frame titleName:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        self.title = title;
        self.isSelected = NO;
        self.userInteractionEnabled = YES;
        self.backgroundColor = kBottomBgColor;
        //add recognizer
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(respondToTapAction:)];
        [self addGestureRecognizer:tap];
        
        //add subView
        self.arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"PR_filter_choice.png"]];
        self.arrow.frame = CGRectMake(self.width - ArrowWidth - ArrowToRight,(self.height - ArrowHeight)/2  , ArrowWidth , ArrowHeight);
        if (self.isJob) {
             self.arrow.frame = CGRectMake(self.width - 10 - ArrowToRight,(self.height - 6)/2  , 10 , 6);
        }
        [self addSubview:self.arrow];
        
        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.font = [UIFont systemFontOfSize:DropDownBoxFontSize];
        self.titleLabel.text = self.title;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.textColor = kDarkWordColor;
        self.titleLabel.frame = CGRectMake(DropDownBoxTitleHorizontalToLeft, 0 ,self.arrow.left - DropDownBoxTitleHorizontalToArrow - DropDownBoxTitleHorizontalToLeft  , self.height);
        [self addSubview:self.titleLabel];
        
        //lvx add 修改图片和文字间距
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(-6.5);
            make.centerY.equalTo(0);
            make.width.lessThanOrEqualTo(self.width-20);
        }];
        [self.titleLabel sizeToFit];
        [self.arrow mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLabel.mas_right).equalTo(5);
            make.centerY.equalTo(0);
        }];
        //lvx add
        
        UIColor *dark = [UIColor colorWithWhite:0 alpha:0.2];
        UIColor *clear = [UIColor colorWithWhite:0 alpha:0];
        NSArray *colors = @[(id)clear.CGColor,(id)dark.CGColor, (id)clear.CGColor];
        NSArray *locations = @[@0.2, @0.5, @0.8];
        self.line = [CAGradientLayer layer];
        self.line.colors = colors;
        self.line.locations = locations;
        self.line.startPoint = CGPointMake(0, 0);
        self.line.endPoint = CGPointMake(0, 1);
        self.line.frame = CGRectMake(self.arrow.right + ArrowToRight - 1.0/MMscale , 0, 1.0/MMscale, self.height);
//        [self.layer addSublayer:self.line];
    }
    return self;

}

- (void)setIsJob:(BOOL)isJob {
    _isJob = isJob;
    if (_isJob) {
        self.backgroundColor = [UIColor whiteColor];
        //设置箭头
        self.arrow.image = [UIImage imageNamed:@"job_filter_new_down"];
//        self.arrow.frame = CGRectMake(CGRectGetMidX(self.bounds)+35, (self.height - ArrowHeight)/2, ArrowWidth,  ArrowHeight);
    }
    else {
        self.backgroundColor = kBottomBgColor;
    }
}

- (void)updateTitleState:(BOOL)isSelected {
    if (isSelected) {
        self.titleLabel.textColor = kBlackWordColor;
        if (self.isJob) {
            self.titleLabel.textColor = mHexColor(0xF48F4A);
            self.arrow.image = [UIImage imageNamed:@"job_filter_new_up"];
        } else {
            self.arrow.image = [UIImage imageNamed:@"PR_filter_choice_top"];
        }
        
    } else{
        self.titleLabel.textColor = kDarkWordColor;
        if (self.isJob) {
             self.arrow.image = [UIImage imageNamed:@"job_filter_new_down"];
        } else {
             self.arrow.image = [UIImage imageNamed:@"PR_filter_choice"];
        }
    }
}

- (void)updateTitleContent:(NSString *)title {
    self.titleLabel.text = title;
}

- (void)respondToTapAction:(UITapGestureRecognizer *)gesture {
    if ([self.delegate respondsToSelector:@selector(didTapDropDownBox:atIndex:)]) {
        [self.delegate didTapDropDownBox:self atIndex:self.tag];
    }
}
@end
