//
//  MMComBoBoxView.h
//  MMComboBoxDemo
//
//  Created by wyy on 2016/12/7.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMItem.h"
#import "MMDropDownBox.h"

@protocol MMComBoBoxViewDataSource;
@protocol MMComBoBoxViewDelegate;
@interface MMComBoBoxView : UIView
@property (nonatomic, weak) id<MMComBoBoxViewDataSource> dataSource;
@property (nonatomic, weak) id<MMComBoBoxViewDelegate> delegate;

@property(nonatomic, assign) BOOL isJob;
- (void)reload;
- (void)dimissPopView;
//从.m移动到.h为了vc手动给box赋值
@property (nonatomic, strong) NSMutableArray <MMDropDownBox *> *dropDownBoxArray;
@end

@protocol MMComBoBoxViewDataSource <NSObject>
@required;
- (NSUInteger)numberOfColumnsIncomBoBoxView :(MMComBoBoxView *)comBoBoxView;
- (MMItem *)comBoBoxView:(MMComBoBoxView *)comBoBoxView infomationForColumn:(NSUInteger)column;
- (void)reloadBoBoxView:(MMComBoBoxView *)comBoBoxView;
@end

@protocol MMComBoBoxViewDelegate <NSObject>
@optional
- (void)comBoBoxView:(MMComBoBoxView *)comBoBoxViewd didSelectedItemsPackagingInArray:(NSArray *)array atIndex:(NSUInteger)index;
@end
