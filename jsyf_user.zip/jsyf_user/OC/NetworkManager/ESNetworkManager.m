//
//  ESNetworkManager.m
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import "ESNetworkManager.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import "AFNetworking/AFNetworking.h"
#import <sys/utsname.h>
#define kTimeOutInterval 15


@implementation ESNetworkManager
+ (AFHTTPSessionManager *)shareSessionManager
{
  
    static AFHTTPSessionManager *shareManager = nil;
    static dispatch_once_t onceToken;
    mWeakSelf
    dispatch_once(&onceToken, ^{
        AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] initWithBaseURL: [NSURL URLWithString:N_HostSiteMain]];
        [manager setSecurityPolicy:[weakSelf customSecurityPolicy]];
      manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html", @"text/plain", @"text/json", @"text/javascript", @"application/json", @"application/xml"]];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.requestSerializer.timeoutInterval = 15;
        shareManager = manager;
    });
    return shareManager;
}

+ (NSURLSessionDataTask *)GET:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure
{
    NSString *urlString = [NSString stringWithFormat:@"%@",hostString];
    if ([hostString hasPrefix:@"http"]) {
        
    }else {

        urlString = [NSString stringWithFormat:@"%@%@", N_HostSiteMain, hostString];

    }

    
     AFHTTPSessionManager *manager = [self shareSessionManager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    return [manager GET:urlString
              parameters:params
                progress:nil
                 success:^(NSURLSessionDataTask * task, id responseObject){
                     NSError *jsonError = nil;
                     NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
                     if ([responseDic isKindOfClass:[NSDictionary class]]) {
                             success(task, responseObject);
                     } else {
                         success(task, responseObject);
                     }
                 } failure:failure];
}

+ (NSURLSessionDataTask *)POST:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure
{
    NSMutableDictionary *paramsDic = (params?:@{}).mutableCopy;
    NSString *urlString = [NSString stringWithFormat:@"%@",hostString];
    
    if ([hostString hasPrefix:@"http"]) {
    }else {
        urlString = [NSString stringWithFormat:@"%@%@", N_HostSiteMain, hostString];
    }
    AFHTTPSessionManager *manager = [self shareSessionManager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
   // manager.requestSerializer.HTTPRequestHeaders
    
   // [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    //验证token
    return [manager POST:urlString
              parameters:paramsDic
                progress:nil
                 success:^(NSURLSessionDataTask * task, id responseObject){
                     NSError *jsonError = nil;
                     NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
                     if ([responseDic isKindOfClass:[NSDictionary class]]) {
                            //特殊错误码判断
                             success(task, responseObject);
                     } else {
                         success(task, responseObject);
                     }
                 } failure:failure];
}

+ (AFSecurityPolicy*)customSecurityPolicy
{
    // /先导入证书
    NSString *cerPath = [[NSBundle mainBundle] pathForResource:@"avantouch" ofType:@"cer"];//证书的路径
    NSData *certData = [NSData dataWithContentsOfFile:cerPath];
    
    // AFSSLPinningModeCertificate 使用证书验证模式
//    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    AFSecurityPolicy *securityPolicy;
    // allowInvalidCertificates 是否允许无效证书（也就是自建的证书），默认为NO
    // 如果是需要验证自建证书，需要设置为YES
    securityPolicy.allowInvalidCertificates = YES;
    
    //validatesDomainName 是否需要验证域名，默认为YES；
    //假如证书的域名与你请求的域名不一致，需把该项设置为NO；如设成NO的话，即服务器使用其他可信任机构颁发的证书，也可以建立连接，这个非常危险，建议打开。
    //置为NO，主要用于这种情况：客户端请求的是子域名，而证书上的是另外一个域名。因为SSL证书上的域名是独立的，假如证书上注册的域名是www.google.com，那么mail.google.com是无法验证通过的；当然，有钱可以注册通配符的域名*.google.com，但这个还是比较贵的。
    //如置为NO，建议自己添加对应域名的校验逻辑。
    securityPolicy.validatesDomainName = NO;
    
    securityPolicy.pinnedCertificates = [NSSet setWithObjects:certData, nil];
    
    return securityPolicy;
}

#pragma mark - 文件下载

+ (void)downloadFileWithSavaPath:(NSString *)savePath
                       urlString:(NSString *)urlString
                          result:(ESNetWordResult)resultBlock
                        progress:(ESDownloadProgress)progress;
{
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [manager downloadTaskWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]] progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress.completedUnitCount / downloadProgress.totalUnitCount);
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        return  [NSURL URLWithString:savePath];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        resultBlock(filePath, error);
    }];
}

#pragma mark - 多图上传
+ (void)uploadImages:(NSArray *)imageArray
           urlString:(NSString *)urlString
              params:(NSDictionary *)params
         targetWidth:(float)width
        successBlock:(ESNetWordSuccess)successBlock
         failurBlock:(ESNetWordFailure)failureBlock
            progress:(ESUploadProgress)progress;
{
    NSString *hostString = [NSString stringWithFormat:@"%@",urlString];
    
    if ([urlString hasPrefix:@"http"]) {
    }else {
        hostString = [NSString stringWithFormat:@"%@%@", N_HostSiteMain, urlString];

    }
    //1.创建管理者对象
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html", @"text/plain", @"text/json", @"text/javascript", @"application/json", @"application/xml"]];
    
    
    [manager POST:hostString parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSUInteger i = 0 ;
        /**出于性能考虑,将上传图片进行压缩*/
        for (NSData * imageData in imageArray) {
            //拼接data
           [formData appendPartWithFileData:imageData name:@"file" fileName:@"something.jpg" mimeType:@"image/jpeg"];
            i++;
        }
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
      NSLog(@"%lld/%lld",uploadProgress.completedUnitCount ,uploadProgress.totalUnitCount);
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary *  _Nullable responseObject) {
        successBlock(task, responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task, error);
    }];

}

//文件上传
+ (void)upLoadToUrlString:(NSString *)url parameters:(NSDictionary *)parameters fileData:(NSData *)fileData name:(NSString *)name fileName:(NSString *)fileName mimeType:(NSString *)mimeType progress:(void (^)(NSProgress *))progress success:(void (^)(NSURLSessionDataTask *, id))success failure:(void (^)(NSURLSessionDataTask *, NSError *))failure {
        NSString *hostString = [NSString stringWithFormat:@"%@",url];
        if ([url hasPrefix:@"http"]) {
        }else {
            hostString = [NSString stringWithFormat:@"%@%@", N_HostSiteMain, url];
        }
        //1.创建管理者对象
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html", @"text/plain", @"text/json", @"text/javascript", @"application/json", @"application/xml"]];
        [manager POST:hostString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
            [formData appendPartWithFileData:fileData name:name fileName:fileName mimeType:mimeType];
        } progress:^(NSProgress * _Nonnull uploadProgress) {
            if (progress) {
                progress(uploadProgress);
            }
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            if (success) {
                success(task, responseObject);
            }
            
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            if (failure) {
                failure(task, error);
            }
          
    }];
    
    
}

+(void)upa {
    NSArray* images = [NSMutableArray array];
    
    // 准备保存结果的数组，元素个数与上传的图片个数相同，先用 NSNull 占位
    NSMutableArray* result = [NSMutableArray array];
    for (UIImage* image in images) {
        [result addObject:[NSNull null]];
    }
    
    dispatch_group_t group = dispatch_group_create();
    
    for (NSInteger i = 0; i < images.count; i++) {
        
        dispatch_group_enter(group);
        
//
//        if (error) {
//            NSLog(@"第 %d 张图片上传失败: %@", (int)i + 1, error);
//            dispatch_group_leave(group);
//        } else {
//            NSLog(@"第 %d 张图片上传成功: %@", (int)i + 1, responseObject);
//            @synchronized (result) { // NSMutableArray 是线程不安全的，所以加个同步锁
//                result[i] = responseObject;
//            }
//            dispatch_group_leave(group);
//        }
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html", @"text/plain", @"text/json", @"text/javascript", @"application/json", @"application/xml"]];
        
        NSError *serializationError = nil;
        NSMutableURLRequest *request = [manager.requestSerializer multipartFormRequestWithMethod:@"POST" URLString:[[NSURL URLWithString:@"" relativeToURL:@""] absoluteString] parameters:nil constructingBodyWithBlock:nil error:&serializationError];
    
        
        NSURLSessionDataTask *task = [manager uploadTaskWithStreamedRequest:result progress:^(NSProgress * _Nonnull uploadProgress) {
            
        } completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
            
        }];

        
        [task resume];
    }
    
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        NSLog(@"上传完成!");
        for (id response in result) {
            NSLog(@"%@", response);
        }
    });
}

#pragma mark - 取消所有的网络请求

+ (void)cancelAllRequest
{
    [[self shareSessionManager].operationQueue cancelAllOperations];
}

#pragma mark - 取消指定的url请求/

+ (void)cancelHttpRequestWithRequestType:(NSString *)requestType requestUrlString:(NSString *)string
{
    NSError * error;
    /**根据请求的类型 以及 请求的url创建一个NSMutableURLRequest---通过该url去匹配请求队列中是否有该url,如果有的话 那么就取消该请求*/
    NSString * urlToPeCanced = [[[[AFHTTPSessionManager manager].requestSerializer requestWithMethod:requestType URLString:string parameters:nil error:&error] URL] path];
    for (NSOperation * operation in [AFHTTPSessionManager manager].operationQueue.operations) {
        //如果是请求队列
        if ([operation isKindOfClass:[NSURLSessionTask class]]) {
            //请求的类型匹配
            BOOL hasMatchRequestType = [requestType isEqualToString:[[(NSURLSessionTask *)operation currentRequest] HTTPMethod]];
            //请求的url匹配
            BOOL hasMatchRequestUrlString = [urlToPeCanced isEqualToString:[[[(NSURLSessionTask *)operation currentRequest] URL] path]];
            //两项都匹配的话  取消该请求
            if (hasMatchRequestType&&hasMatchRequestUrlString) {
                [operation cancel];
            }
        }
    }
}
#pragma mark ---------------RAC-------------------------

+ (RACSignal *)rac_GET:(NSString *)hostString params:(NSDictionary *)params{
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        [self GET:hostString params:params success:^(NSURLSessionDataTask *task, id responseObject) {
            NSError *jsonError = nil;
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
            if ([responseDic isKindOfClass:[NSDictionary class]]) {
                NSString *errorCode = responseDic[@"e"][@"code"];
                if (errorCode.integerValue == 0) {
                    [subscriber sendNext:responseDic];
                    [subscriber sendCompleted];
                } else {
                   [subscriber sendError:[NSError errorWithDomain:responseDic[@"e"][@"desc"] code:0 userInfo:@{NSLocalizedDescriptionKey: responseDic[@"e"][@"desc"]?: @"未知网络错误"}]];
                }
            }else{
                [subscriber sendError:jsonError];
            }
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            [subscriber sendError:error];
        }];
        return [RACDisposable disposableWithBlock:^{
            
        }];
    }];
    return signal;
    
}

+ (RACSignal *)rac_POST:(NSString *)hostString params:(NSDictionary *)params
{
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        [self POST:hostString params:params success:^(NSURLSessionDataTask *task, id responseObject) {
            NSError *jsonError = nil;
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
                if ([responseDic isKindOfClass:[NSDictionary class]]) {
                    NSString *errorCode = responseDic[@"e"][@"code"];
                    if (errorCode.integerValue == 0) {
                        [subscriber sendNext:responseDic];
                        [subscriber sendCompleted];
                    } else {
                        NSLog(@"%@",hostString);
                        [subscriber sendError:[NSError errorWithDomain:responseDic[@"e"][@"desc"] ?: @"" code:errorCode.integerValue userInfo:@{NSLocalizedDescriptionKey: responseDic[@"e"][@"desc"]?: @"未知网络错误"}]];
                    }
                }else{
                    [subscriber sendError:jsonError];
                }
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
          NSError *newError = [NSError errorWithDomain:error.localizedDescription code:error.code userInfo:@{NSLocalizedDescriptionKey: @"网络错误,请稍后重试"}];
            
            [subscriber sendError:newError];
        }];
        return [RACDisposable disposableWithBlock:^{
            
        }];
    }];
    return signal;
}

//为个人中心创建的请求
+ (RACSignal *)rac_GETForMine:(NSString *)hostString params:(NSDictionary *)params{
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        [self GET:hostString params:params success:^(NSURLSessionDataTask *task, id responseObject) {
            NSError *jsonError = nil;
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
            if ([responseDic isKindOfClass:[NSDictionary class]]) {
                NSString *errorCode = responseDic[@"success"];
                if (errorCode.integerValue == 1) {
                    [subscriber sendNext:responseDic];
                    [subscriber sendCompleted];
                } else {
                    [subscriber sendError:[NSError errorWithDomain:responseDic[@"message"] code:0 userInfo:@{NSLocalizedDescriptionKey: responseDic[@"message"]?: @"未知网络错误"}]];
                }
            }else{
                [subscriber sendError:jsonError];
            }
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            NSError *newError = [NSError errorWithDomain:error.localizedDescription code:error.code userInfo:@{NSLocalizedDescriptionKey: @"网络错误,请稍后重试"}];
            [subscriber sendError:newError];
        }];
        return [RACDisposable disposableWithBlock:^{
            
        }];
    }];
    return signal;
    
}

+ (RACSignal *)rac_POSTForMine:(NSString *)hostString params:(NSDictionary *)params
{
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        [self POST:hostString params:params success:^(NSURLSessionDataTask *task, id responseObject) {
            NSLog(@"hostStr = %@ dic = %@",hostString,params);
            NSError *jsonError = nil;
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
            
            if ([responseDic isKindOfClass:[NSDictionary class]]) {
                NSString *errorCode = responseDic[@"success"];
                if (errorCode.integerValue == 1) {
                    [subscriber sendNext:responseDic];
                    [subscriber sendCompleted];
                } else {
                    [subscriber sendError:[NSError errorWithDomain:responseDic[@"message"] code:errorCode.integerValue userInfo:@{NSLocalizedDescriptionKey: responseDic[@"message"]?: @"未知网络错误"}]];
                }
            }else{
                [subscriber sendError:jsonError];
            }
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            NSError *newError = [NSError errorWithDomain:error.localizedDescription code:error.code userInfo:@{NSLocalizedDescriptionKey: @"网络错误,请稍后重试"}];
            
            [subscriber sendError:newError];
        }];
        return [RACDisposable disposableWithBlock:^{
            
        }];
    }];
    return signal;
}

//多图上传

+ (RACSignal *)rac_uploadImages:(NSArray *)uploadImages urlString:(NSString *)urlString params:(NSDictionary *)params targetWidth:(float)targetWidth
{
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        //这个上传接口格式不统一
        [self uploadImages:uploadImages urlString:urlString params:params targetWidth:targetWidth successBlock:^(NSURLSessionDataTask *task, id responseObject) {
            
             if ([responseObject isKindOfClass:[NSDictionary class]]) {
 
            NSError *jsonError = nil;
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
            if ([responseDic isKindOfClass:[NSDictionary class]]) {
                NSString *errorCode = responseDic[@"e"][@"code"];
                if (errorCode.integerValue == 0) {
                    [subscriber sendNext:responseDic];
                    [subscriber sendCompleted];
                } else {
                    [subscriber sendError:[NSError errorWithDomain:responseDic[@"e"][@"desc"] code:0 userInfo:@{NSLocalizedDescriptionKey: responseDic[@"e"][@"desc"]?: @"未知网络错误"}]];
                }
            }else{
                [subscriber sendError:jsonError];
            }
             }else if ([responseObject isKindOfClass:[NSArray class]]) {
                 [subscriber sendNext:responseObject];
                 [subscriber sendCompleted];
             }
            
        } failurBlock:^(NSURLSessionDataTask *task, NSError *error) {
            NSError *newError = [NSError errorWithDomain:error.localizedDescription code:error.code userInfo:@{NSLocalizedDescriptionKey: @"网络错误,请稍后重试"}];
            [subscriber sendError:newError];
        } progress:^(float progress) {
            
        }];

        return [RACDisposable disposableWithBlock:^{
        }];
    }];
    return signal;
}

+ (RACSignal *)upLoadImageData:(NSData *)imgData{
    NSDictionary * dic = @{@"file":imgData,@"fileType":@"1"};
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        [[ESNetworkManager rac_uploadImages:@[imgData] urlString:@"/OSSFile/multiFileUpload.json" params:dic targetWidth:1.0] subscribeNext:^(id  _Nullable x) {
            [subscriber sendNext:x];
            [subscriber sendCompleted];
        } error:^(NSError * _Nullable error) {
            NSError *newError = [NSError errorWithDomain:error.localizedDescription code:error.code userInfo:@{NSLocalizedDescriptionKey: @"网络错误,请稍后重试"}];
            [subscriber sendError:newError];
        }];
        return [RACDisposable disposableWithBlock:^{
        }];
    }];
      return signal;
}



#pragma mark- ---------------------------实例-------------------------------



#pragma mark------------新机模块---------------------
+ (RACSignal *)getStoreEquipmentParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/storeEquipmentParam/findParamListToChild.json" params:dic];
}
+ (RACSignal *)getBrandListParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/home/findBrandListByTypeCode.json" params:dic];
}
+ (RACSignal *)getAllNewMachineWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/home/findEquipmentByParam.json" params:dic];
}
// /home/findBrandListByParam.json->/baseHomeController/findBrandListByEquipment.json
+ (RACSignal *)getBrandFilterParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/baseHomeController/findBrandListWithNoAliasGroup.json" params:dic];
}
+ (RACSignal *)getBrandHeadDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findBrandDetailHead.json" params:dic];
}
+ (RACSignal *)getCompanyListData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findStoreList.json" params:dic];
}
+ (RACSignal *)getCompanyHeadDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findStoreDetailHead.json" params:dic];
}
+ (RACSignal *)getProvinceList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/area/listProvince.json" params:dic];
}
+ (RACSignal *)getCityList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/area/listCityByProCode.json" params:dic];
}
+ (RACSignal *)getCompanyNewMachineList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findGoodsList.json" params:dic];
}
+ (RACSignal *)getCompanyNewsList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/shopFrontPage/findStoreContent.json" params:dic];
}
+ (RACSignal *)getStyleAndTonList:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:@"/home/findTypeCodeWithTonnageCode.json" params:dic];
}
+ (RACSignal *)getEquipmentHeadDetail:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:@"/goodsDetail/productDetail.json" params:dic];
}
+ (RACSignal *)getEquipmentDesc:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/equipmentDetails/getEquipmentIntroductionAndContrastParam.json" params:dic];
}
+ (RACSignal *)getEquipmentParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/equipDetail/appParam.json" params:dic]; //

}
+ (RACSignal *)getEquipmentPhotos:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/equipDetail/atlas.json" params:dic]; //
}

+ (RACSignal *)getGoodsPhotos:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/goodsDetail/atlas.json" params:dic]; //
}
+ (RACSignal *)getAskPrice:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/shopDetails/saveEnquiryInfo.json" params:dic];
}
+ (RACSignal *)getComparisonBrand:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/parameterComparison/queryBrandByEquipmentParamCode.json" params:dic];   //
}
+ (RACSignal *)getComparisonModel:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/parameterComparison/queryModelNameByEquipmentCodeAndBrandId.json" params:dic];  //
}
+ (RACSignal *)getCompareParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/parameterComparison/compareEquipmentToApp.json" params:dic];
}
+ (RACSignal *)getAllProvinceAndCity:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/area/findAllProviceWithCity.json" params:dic];
}
+ (RACSignal *)getPriceShop:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/enquiry/enquiryDetail.json" params:dic];
}
+ (RACSignal *)sendComment:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/discuss/pushComment.json" params:dic];
}
+ (RACSignal *)getCommentList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/discuss/findDiscussList.json" params:dic];
}
+ (RACSignal *)getArticleDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/storeActivity/getStoreActivityDetailById.json" params:dic];
}
+ (RACSignal *)getNewBrandList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/home/findBrandListByTypeCodeToApp.json" params:dic];
}

#pragma mark- ---------------New - 新机----------------

+ (RACSignal *)getBrandListAndHot:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/baseHomeController/findBrandListByEquipment.json" params:dic];
}
+ (RACSignal *)getSelectMachineFilter:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/baseHomeController/findSearchCondition.json" params:dic];
}
+ (RACSignal *)getSelectMchineList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/baseHomeController/findEquipmentListByParam.json" params:dic];
}
+ (RACSignal *)getEquipmentHead:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/baseHomeController/findEquipmentDetailBySku.json" params:dic];
}
///判断是否收藏
+ (RACSignal *)judgeCommonCollection:(NSDictionary*)dic{
    return [ESNetworkManager rac_POST:@"/collection/judge.json" params:dic];
}

+ (RACSignal *)getEquipSencondList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/parameterComparison/querySecondParamByEquipmentParamTypeParamCode.json" params:dic];
}
+ (RACSignal *)getEquipType:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/parameterComparison/findDeviceType.json" params:dic];
}
+ (RACSignal *)getNewCompareParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/parameterComparison/listAllParam.json" params:dic];
}
+ (RACSignal *)getProvinceCodeWithName:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/area/findProvinceByName.json" params:dic];
}

+ (RACSignal *)getCompanyType:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findGoodTypeAndBrand.json" params:dic];
}

+ (RACSignal *)getCompanyBrand:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findGoodBrand.json" params:dic];
}

+ (RACSignal *)getGoodsHeadDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/goodsDetail/base.json" params:dic];
}

+ (RACSignal *)getShopGoodsDetailToAddOne:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/goodsDetail/detail.json" params:dic];
}

#pragma mark- ----------个人中心模块------------------

+(RACSignal *)userLoginwithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customer/login.json"] params:dic];
}

+(RACSignal *)updateCustomImgWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customerBaseInfo/updateCustomImg.json"] params:dic];
}

+(RACSignal *)getCodeWithParam:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/securityCode/getPhoneCode.json"] params:dic];
}

+(RACSignal *)uploadingImagWithParam:(NSDictionary *)dic
{
     return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/OSSFile/multiFileUpload.json"] params:dic];
}

+(RACSignal *)checkPhoneCodeWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/securityCode/judgePhoneCodeAndCodeImage.json"] params:dic];
}

+ (RACSignal *)userregisterWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customer/signUp.json"] params:dic];
}

+ (RACSignal *)feedBackWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customerSuggestion/saveCustomerSuggestion.json"] params:dic];
}

+(RACSignal *)codeLoginWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customer/loginByPhoneCode.json"] params:dic];
}

+(RACSignal *)checkPhoneisRegisterWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customer/validateUserName.json"] params:dic];
}

+ (RACSignal *)updateNickNameWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customerSignature/editSignature.json"] params:dic];
}

+(RACSignal *)updateCustomerPasswordWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customerSignature/editSignature.json"] params:dic];
}

+(RACSignal *)validateLoginKeyWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customer/validateLoginKey.json"] params:dic];
}


+ (RACSignal *)wechatLoginWithParam:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/wxApp/signIn.json"] params:dic];
}

+ (RACSignal *)validatePhoneCodeAndWechatBindingParam:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/wxApp/weChatBinding.json"] params:dic];
}

+(RACSignal *)wechatSignUpWithParam:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/wxApp/signUp.json"] params:dic];
}

+ (RACSignal *)wechatRemoveBindParam:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/wxApp/unTie.json"] params:dic];
}

+ (RACSignal *)wechatBingingParam:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/wxApp/tie.json"] params:dic];
}
+ (RACSignal *)distinctNickNamePara:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/customerBaseInfo/distinctNickName.json"] params:dic];
}
#pragma mark- --------首页与资讯模块----------------

+ (RACSignal *)getADImageWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/advertise/findAppAdvertiseList.json"] params:dic];
}

#pragma mark -------- 个人中心-拍卖 --------
+ (RACSignal *)getMyMoneyWithMemberId:(NSString *)memberId {
    return [ESNetworkManager rac_GETForMine:[NSString stringWithFormat:@"%@/api/Member/GetMoneyInfo?memberId=%@",ESHHostMain,memberId] params:nil];
}
+ (RACSignal *)getMoneyListWithMemberId:(NSString *)memberId PageIndex:(NSString *)pageIndex pageSize:(NSString *)pageSize {
     return [ESNetworkManager rac_GETForMine:[NSString stringWithFormat:@"%@/api/Member/MyMoneyList?memberId=%@&pageIndex=%@&pageSize=%@",ESHHostMain,memberId,pageIndex,pageSize] params:nil];
}
+ (RACSignal *)getEnumState {
    return [ESNetworkManager rac_GETForMine:[NSString stringWithFormat:@"%@/api/Member/GetOrderStateEnum",ESHHostMain] params:nil];
}
+ (RACSignal *)getRechargeListWithMemberId:(NSString *)memberId State:(NSString *)state PageIndex:(NSString *)pageIndex pageSize:(NSString *)pageSize {
     return [ESNetworkManager rac_GETForMine:[NSString stringWithFormat:@"%@/api/Member/MyOrderList?memberId=%@&state=%@&pageIndex=%@&pageSize=%@",ESHHostMain,memberId,state,pageIndex,pageSize] params:nil];
}
+ (RACSignal *)getFrozenlistWithMemberId:(NSString *)memberId PageIndex:(NSString *)pageIndex pageSize:(NSString *)pageSize Type:(NSString *)type {
    return [ESNetworkManager rac_GETForMine:[NSString stringWithFormat:@"%@/api/Member/MyBailMoneyList?memberId=%@&type=%@&pageIndex=%@&pageSize=%@",ESHHostMain,memberId,type,pageIndex,pageSize] params:nil];
}
+ (RACSignal *)getrealNameCertifyMemberId:(NSString *)memberId MemberName:(NSString *)memberName MemberIdcard:(NSString *)memberIdcard IdCardImgPositive:(NSString *)idCardImgPositive IdCardImgNegative:(NSString *)idCardImgNegative AreaPCC:(NSString *)areaPCC {
    NSString *url1 = [NSString stringWithFormat:@"%@/api/Member/SavePersonIdcardInfo?",ESHHostMain];
    NSString *url2 = [NSString stringWithFormat:@"%@memberId=%@&memberName=%@&memberIdcard=%@&idCardImgPositive=%@&idCardImgNegative=%@&areaPCC=%@",url1,memberId,memberName,memberIdcard,idCardImgPositive,idCardImgNegative,areaPCC];
    NSString *url3 = [url2 stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return [ESNetworkManager rac_GETForMine:url3 params:nil];
}

+ (RACSignal *)getRefundListWithDic:(NSDictionary *)dic {
    return [ESNetworkManager rac_GETForMine:[NSString stringWithFormat:@"%@/api/Member/MyReturnOrderList",ESHHostMain] params:dic];
}

#pragma mark -------- 小视频 --------
+ (RACSignal *)postVideoAndCoverPicWithDic:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/videoManagement/saveVideo.json" params:dic];
}

//获取视频栏目code
+ (RACSignal *)getVideoMenu {
    return [ESNetworkManager rac_POST:@"/videoManagement/videoDropdown.json" params:@{@"paramCode" : @"VEDIO_COLUMN"}];
}

//获取视频栏目code
+ (RACSignal *)addVideoPlayNum:(NSString *)videoId {
    return [ESNetworkManager rac_POST:@"/video/updatePlayNumberById.json" params:@{@ "videoId":videoId}];
}


//获取栏目下视频
+ (RACSignal *)getVideoList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/video/findVideoListToApp.json" params:dic];
}
+ (RACSignal *)zanVideoWithDic:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/video/updateLikeNumberById.json" params:dic];
}
+ (RACSignal *)getVideoCommentList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/comment/findDiscussList.json" params:dic];
}
+ (RACSignal *)sendVideoComment:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:@"/comment/pushComment.json" params:dic];
}
+ (RACSignal *)deleteVideo:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/video/removeVideoById.json" params:dic];
}

///小视频列表
+ (RACSignal *)shortVideosListWithParam:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:@"/articlePostController/getVideoList.json" params:dic];
}
/*{
 "recordId": "记录id",
 "scene": "0:平台视频,1:bbs视频,2:直播视频,3:企业视频",
 "type": "0:分享数,1:浏览量，2:播放量"
 }*/
+ (RACSignal *)videoRecordCommonParam:(NSDictionary *)dic{
    return [ESNetworkManager rac_POST:@"/videoRecord/increase.json" params:dic];
}

#pragma mark -------- 二找相关 --------
+ (RACSignal *)getJobInfoList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/recruit/list.json" params:dic];
}

+ (RACSignal *)getJobFilter:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/recruit/filter.json" params:dic];
}
+ (RACSignal *)getPublishJobDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/recruit/employ.json" params:dic];
}
+ (RACSignal *)getApplyJobDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/recruit/apply.json" params:dic];
}
+ (RACSignal *)backPublish:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/recruit/revoke.json" params:dic];
}
+ (RACSignal *)deleteJob:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/recruit/del.json" params:dic];
}

#pragma mark -------- 二手机接口 --------
+ (RACSignal *)getESJList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/secondEquipment/findSecondEquList.json" params:dic];
}
+ (RACSignal *)getESJFirstType:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/secondEquipment/findFirstTypeList.json" params:dic];
}
+ (RACSignal *)getESJBrandList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/secondEquipment/findSearchBrandWithGroup.json" params:dic];
}
+ (RACSignal *)getESJDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/shopDetails/queryShopDetailsByStoreId.json" params:dic];
}
+ (RACSignal *)doCollectAction:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/collection/saveCollection.json" params:dic];
}
+ (RACSignal *)getESJPersonalHomeData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/customer/personalPageHome.json" params:dic];
}
+ (RACSignal *)getShopESJFilterData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findSecondFirstTypeAndBrand.json" params:dic];
}


+ (RACSignal *)getNumeber{
    YFUserModelSenddata * model = [YFFlieTool getUserModel];
    NSString *str = @"";
    if(model != nil) {
        str = model.userId;
    }
    NSDictionary *dic = @{@"customerId":str};
    return [ESNetworkManager rac_POST:@"/app/findCountNumber.json" params:dic];
}

+ (RACSignal *)deleteMyESJ:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/secondHandEquipment/deleteGoodsInfo.json" params:dic];
}

+ (RACSignal *)upAndDwonESJ:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/secondHandEquipment/updateGoodsStatus.json" params:dic];
}

+ (RACSignal *)getMyESJGroupList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/secondEquipment/findSecondEquListWithTimeGroup.json" params:dic];
}

+ (RACSignal *)getMyESJDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/secondHandEquipment/getSecondHandEquipmentInfo.json" params:dic];
}

+ (RACSignal *)realNameCertify:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/real/saveOrUpdate.json" params:dic];
}
+ (RACSignal *)openESJBusiness:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/store/openSecondHandCertification.json" params:dic];
}
+ (RACSignal *)getBackShowInfo:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/real/queryRealNameList.json" params:dic];
}
//收藏用户/collection/findCollectionCustomerList.json
+ (RACSignal *)findCollectionCustomerList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/collection/findCollectionCustomerList.json" params:dic];
}
//询价用户enquiry/findEnquiryCustomerList.json
+ (RACSignal *)findEnquiryCustomerList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/enquiry/findEnquiryCustomerList.json" params:dic];
}
//浏览人数customerBaseInfo/listViewVisitor.json
+ (RACSignal *)listCustomerViewVisitor:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/customerBaseInfo/listViewVisitor.json" params:dic];
}
//保存浏览信息equipDetail/view.json
+ (RACSignal *)saveBrowseEquipDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/equipDetail/view.json" params:dic];
}
#pragma mark ------------------论坛--------------------
//获取用户标签列表 /label/getUserLabelList.json
+ (RACSignal *)getUserLabelList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/label/getUserLabelList.json" params:dic];
}
//获取可以添加的标签列表 /label/getLabelListToAdd.json
+ (RACSignal *)getLabelListToAdd:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/label/getLabelListToAdd.json" params:dic];
}

//设置用户标签 /label/setUserLabelList.json
+ (RACSignal *)setUserLabelList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/label/setUserLabelList.json" params:dic];
}
//论坛列表 /articlePostController/findPostList.json
+ (RACSignal *)findPostArticleControllerList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/findPostList.json" params:dic];
}
//标题敏感词过滤 /articlePostController/judgePostTitle.json
+ (RACSignal *)judgeArticlePostTitle:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/judgePostTitle.json" params:dic];
}
//发布图文贴 /articlePostController/saveArticlePost.json
+ (RACSignal *)saveArticlePostImageText:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/saveArticlePost.json" params:dic];
}
//查询关注数，粉丝数和帖子数 /articlePostController/findFocusCountAndFansCount.json
+ (RACSignal *)findFocusCountAndFansCount {
    YFUserModelSenddata * model = [YFFlieTool getUserModel];
    NSString *str = @"";
    if(model != nil) {
        str = model.userId;
    }
    NSDictionary *dic = @{@"customerId":str};
    return [ESNetworkManager rac_POST:@"/articlePostController/findFocusCountAndFansCount.json" params:dic];
}

//点赞和取消点赞 articlePostController/praisePost.json
+ (RACSignal *)praiseInvitationArticlePost:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/praisePost.json" params:dic];
}
///直播点赞和取消点赞
+ (RACSignal *)praiseLiveWithParam:(NSDictionary*)dic{
    return [ESNetworkManager rac_POST:@"/liveSubsidiary/praiseLive.json" params:dic];
}

//转发数自增 /articlePostController/updateForwardNumber.json
+ (RACSignal *)updateArticlePostForwardNumber:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/updateForwardNumber.json" params:dic];
}
//删除帖子 /articlePostController/removePost.json
+ (RACSignal *)removeArticlePostInvitation:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/removePost.json" params:dic];
}
//阅读量自增 /articlePostController/updateReadNumber.json
+ (RACSignal *)updateArticleReadNumber:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/updateReadNumber.json" params:dic];
}
//个人主页获取头部信息 /customer/personalPageHomeHead.json
+ (RACSignal *)personalCustomerPageHomeHeader:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/customer/personalPageHomeHead.json" params:dic];
}
//关注和取消关注 articlePostController/focusOn.json
+ (RACSignal *)focusPersonArticleOn:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/focusOn.json" params:dic];
}

+ (RACSignal *)getAliyunSecretKey:(NSDictionary *)dic {
    NSString *params = [NSString stringWithFormat:@"BusinessType=vodai&TerminalType=iphone&DeviceModel=%@&UUID=%@&AppVersion=1.0.0", [self getDeviceId], [self getDeviceModel]];
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"/aliyun/findSercetKey.json?%@",params] params:nil];
}

+ (NSString *)getDeviceId {
    return [[[UIDevice currentDevice] identifierForVendor] UUIDString];
}
+ (NSString*)getDeviceModel{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    return deviceString;
}

+ (RACSignal *)sendForumVideoComment:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/postReply/pushComment.json" params:dic];
}

+ (RACSignal *)addForumVideoNum:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:@"/articlePostController/updatePlayNumber.json" params:dic];
}

+ (RACSignal *)getForumVideoCommentList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/postReply/findDiscussList.json" params:dic];
}

+ (RACSignal *)zanForumVideo:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/praisePost.json" params:dic];
}
+ (RACSignal *)deleteForumComment:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/postReply/delComment.json" params:dic];
}
//修改用户访问时间/customer/updateVisitTime.json
+ (RACSignal *)customerUpdateVisitTime:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/customer/updateVisitTime.json" params:dic];
}
//帖子详情界面 /articlePostController/findPostDetailByIdOrSequenceId.json
+ (RACSignal *)findPostDetailByIdSequence:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/articlePostController/findPostDetailByIdOrSequenceId.json" params:dic];
}

#pragma mark -------- 消息中心 --------
+ (RACSignal *)getTipsList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/tips/getTipsList.json" params:dic];
}

+ (RACSignal *)readTips:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/tips/readTips.json" params:dic];
}

+(RACSignal *)getCustomerInfo:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:@"/rongCloud/getCustomerListById.json" params:dic];
}

+(RACSignal *)getNoticeList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/notice/findCustomerNoticeList.json" params:dic];
}

+ (RACSignal *)getNewsCenterFirstInfo:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/tips/getTipsInfoForApp.json" params:dic];
}
+ (RACSignal *)deleteSystemNews:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/tips/deleteTips.json" params:dic];
}

//二手汇
+ (RACSignal *)ESHUpPic:(NSString *)str{
    NSDictionary *parameters = @{@"moduleflag":@"remvou",
                                 @"files":str};
//    NSString* strs = [NSString stringWithFormat:@"http://auction.yingfeng365.net/Ashx/UploadFileToAliyun.ashx?files=%@&moduleflag=remvou",str];
    
    // String(format:@"http://auction.yingfeng365.net/Ashx/UploadFileToAliyun.ashx?files=%@&moduleflag=remvou",str);
   // return  [ESNetworkManager rac_GETForMine:strs params:nil];
    
    
    //rac_POSTForMine:(NSString *)hostString params:(NSDictionary *)params
    return [ESNetworkManager rac_POSTForMine:@"http://auction.yingfeng365.net/Ashx/UploadFileToAliyun.ashx" params:parameters];
  // return [ESNetworkManager rac_POST:@"http://auction.yingfeng365.net/Ashx/UploadFileToAliyun.ashx" params:parameters];
}

+ (RACSignal *)getESHDD {
    NSString *str = [NSString stringWithFormat:@"%@/api/Member/GetMemberByTel?telephone=%@&type=0",ESHHostMain,[YFFlieTool getUserModel].username];
    return [ESNetworkManager rac_GETForMine:str params:nil];
}


//func getESHInfo(tel:String)->Observable<[String:Any]>  {
//    let urlStr = String(format:"%@/api/Member/GetMemberByTel?telephone=%@&type=0",ESHHostMain,tel)//type 0 为私人
//    //  print("\(urlStr)")
//    return get(urlStr, nil)
//}

#pragma mark -------- 直播 --------
+ (RACSignal *)getLiveList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/liveSubsidiary/findLiveList.json" params:dic];
}
#pragma mark ---------服务预约--------
//店铺预约服务管理编辑/storeBooking/editStoreBooking.json
+ (RACSignal *)storeBookingEditStoreBooking:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/storeBooking/editStoreBooking.json" params:dic];
}

//经销商首页头部轮播/shopFrontPage/findStoreHeadByStoreSequence.json
+ (RACSignal *)shopFrontPageFindStoreHeadByStoreSequence:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/shopFrontPage/findStoreHeadByStoreSequence.json" params:dic];
}

//经销商简介
+ (RACSignal *)getStoredDes:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/shopFrontPage/getShopIntroductionByStoreId.json" params:dic];
}
//经销商图册
+ (RACSignal *)getStoredpPic:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/imgLib/echo.json" params:dic];
}
//经销商视频
+ (RACSignal *)getStoredVideo:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/storeVideo/findListStoreVideoToApp.json" params:dic];
}
//经销商直播列表
+ (RACSignal *)getStoreLiveList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/liveSubsidiary/findStoreLive.json" params:dic];
}
#pragma mark ------------ 小游戏---
//获取游戏密钥/storeGame/listSecretKey.json
+ (RACSignal *)storeGameListSecrrtKey:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/storeGame/listSecretKey.json" params:dic];
}

#pragma mark -------- 厂商旗舰店 --------
//厂商旗舰店头部接口
+ (RACSignal *)getFlagShopHeadData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/flagshipStore/findFlagshipStoreBySequence.json" params:dic];
}
//厂商旗舰店首页接口
+ (RACSignal *)getFlagShophHomeData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/flagshipStore/findFlagshipIndex.json" params:dic];
}
//厂商旗舰店产品接口
+ (RACSignal *)getFlagShopProductData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findGoodsList.json" params:dic];
}
//产品筛选条件接口
+ (RACSignal *)getFlagShopProductFilter:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/app/findGoodTypeAndBrand.json" params:dic];
}
//厂商旗舰店经销商列表接口
+ (RACSignal *)getFlagShopAgencyData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/product/getStoreList.json" params:dic];
}
//详情新闻列表接口
+ (RACSignal *)getFlagShopNewsList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/storeContent/listStoreContent.json" params:dic];
}
//厂商旗舰店联系我们接口
+ (RACSignal *)getFlagShopContactData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/brandStore/getBrandStoreInfo.json" params:dic];
}

//获取头像库数组
+ (RACSignal *)getHeadImages {
    NSDictionary * dic = @{@"bucketName":@"yf-prod-public-file",@"pathPrefix":@"public/sys/profile/"};
    return [ESNetworkManager rac_POST:@"/OSSFile/listFile.json" params:dic];
}

@end
