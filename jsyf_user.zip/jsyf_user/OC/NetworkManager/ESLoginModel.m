//
//  ESLoginModel.m
//  ESH_OA
//
//  Created by 黄志武 on 2017/9/26.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import "ESLoginModel.h"

#define USING_ENCODE_KIT            1
@implementation ESLoginModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}

MJExtensionCodingImplementation
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end

@implementation LoginData
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}



MJExtensionCodingImplementation

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end

@implementation Company
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}

MJExtensionCodingImplementation

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end

@implementation Depart
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}

MJExtensionCodingImplementation

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end

@implementation DepartBig
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}

MJExtensionCodingImplementation
- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end


@implementation Role
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}

MJExtensionCodingImplementation

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end
@implementation IsOnJob
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}

MJExtensionCodingImplementation

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}
@end

@implementation Sex
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"idField": @"id"};
}

MJExtensionCodingImplementation

- (NSString *)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property
{
    if (!oldValue && [property.srcClass isSubclassOfClass:self.class]) {
        return @"";
    }
    return oldValue;
}


WZLSERIALIZE_CODER_DECODER();

WZLSERIALIZE_COPY_WITH_ZONE();

WZLSERIALIZE_DESCRIPTION();
@end

