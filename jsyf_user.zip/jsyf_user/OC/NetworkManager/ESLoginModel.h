//
//  ESLoginModel.h
//  ESH_OA
//
//  Created by 黄志武 on 2017/9/26.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LoginData,Company,Depart,Role,IsOnJob,DepartBig,Sex;
@interface ESLoginModel : NSObject<NSCopying, NSCoding>
@property(nonatomic, assign) BOOL success;
@property(nonatomic, strong) NSString *message;
@property(nonatomic, strong) LoginData *data;

@end

@interface LoginData:NSObject
@property (nonatomic, strong) NSString * carNo;
@property (nonatomic, strong) NSString * cardNO;
@property (nonatomic, strong) Company  *company;
@property (nonatomic, strong) NSString * createTime;
@property (nonatomic, assign) NSInteger createUser;
@property (nonatomic, strong) Depart * depart;
@property (nonatomic, strong) DepartBig * departBig;
@property (nonatomic, strong) NSString * entryDate;
@property (nonatomic, copy) NSString *idField;
@property (nonatomic, assign) NSInteger isFullWorker;
@property (nonatomic, strong) IsOnJob * isOnJob;
@property (nonatomic, strong) NSString * leaveDate;
@property (nonatomic, assign) NSInteger orderNo;
@property (nonatomic, assign) NSInteger parentId;
@property (nonatomic, strong) NSString * qiyeEmail;
@property (nonatomic, strong) NSString * qiyeEmailPwd;
@property (nonatomic, assign) NSInteger reallyParentId;
@property (nonatomic, strong) NSString * remark;
@property (nonatomic, strong) Role * role;
@property (nonatomic, strong) Sex * sex;
@property (nonatomic, strong) NSString * telExt;
@property (nonatomic, strong) NSString * telMini;
@property (nonatomic, strong) NSString * telphone;
@property (nonatomic, strong) NSString * trueName;
@property (nonatomic, strong) NSString * updateTime;
@property (nonatomic, assign) NSInteger updateUser;
@property (nonatomic, strong) NSString * userEmail;
@property (nonatomic, strong) NSString * userName;
@property (nonatomic, strong) NSString * userPwd;
@property (nonatomic, strong) NSString * wxIcon;
@property (nonatomic, strong) NSString * wxId;
@end

@interface Company : NSObject
@property (nonatomic, strong) NSString * companyName;
@property (nonatomic, strong) NSString * createTime;
@property (nonatomic, assign) NSInteger createUser;
@property (nonatomic, strong) NSString * dbPrev;
@property (nonatomic, assign) NSInteger idField;
@property (nonatomic, assign) NSInteger orderNo;
@property (nonatomic, strong) NSString * provinceName;
@property (nonatomic, strong) NSString * updateTime;
@property (nonatomic, assign) NSInteger updateUser;
@end

@interface Depart : NSObject
@property (nonatomic, strong) Company * company;
@property (nonatomic, strong) NSString * createTime;
@property (nonatomic, assign) NSInteger createUser;
@property (nonatomic, strong) NSString * departName;
@property (nonatomic, assign) NSInteger idField;
@property (nonatomic, assign) NSInteger isDel;
@property (nonatomic, assign) NSInteger orderNo;
@property (nonatomic, assign) NSInteger parentId;
@property (nonatomic, strong) NSString * updateTime;
@property (nonatomic, assign) NSInteger updateUser;
@end

@interface IsOnJob : NSObject
@property (nonatomic, assign) NSInteger idField;
@property (nonatomic, strong) NSString * name;
@end

@interface Role : NSObject
@property (nonatomic, strong) Company * company;
@property (nonatomic, strong) NSString * createTime;
@property (nonatomic, assign) NSInteger createUser;
@property (nonatomic, strong) Depart * depart;
@property (nonatomic, strong) Depart * departBig;
//1193-区域检测
@property (nonatomic, assign) NSInteger idField;
@property (nonatomic, assign) NSInteger isDel;
@property (nonatomic, assign) NSInteger orderNo;
@property (nonatomic, assign) NSInteger parentId;
@property (nonatomic, strong) NSString * roleDesc;
@property (nonatomic, strong) NSString * roleName;
@property (nonatomic, strong) NSString * roleShortName;
@property (nonatomic, strong) NSString * updateTime;
@property (nonatomic, assign) NSInteger updateUser;
@end

@interface DepartBig : NSObject
@property (nonatomic, strong) Company * company;
@property (nonatomic, strong) NSString * createTime;
@property (nonatomic, assign) NSInteger createUser;
@property (nonatomic, strong) NSString * departName;
@property (nonatomic, assign) NSInteger idField;
@property (nonatomic, assign) NSInteger isDel;
@property (nonatomic, assign) NSInteger orderNo;
@property (nonatomic, assign) NSInteger parentId;
@property (nonatomic, strong) NSString * updateTime;
@property (nonatomic, assign) NSInteger updateUser;
@end

@interface Sex : NSObject
@property (nonatomic, assign) NSInteger idField;
@property (nonatomic, strong) NSString * name;
@end


