//
//  publicMacro.h
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/16.
//  Copyright © 2017年 YF. All rights reserved.
//

#ifndef publicMacro_h
#define publicMacro_h
#pragma mark - 判断当前设备
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define iPhone3                   ([UIScreen mainScreen].bounds.size.height < 480)
#define iPhone4                   ([UIScreen mainScreen].bounds.size.height == 480)
#define iPhone5                   ([UIScreen mainScreen].bounds.size.height == 568)
#define iPhone6                   ([UIScreen mainScreen].bounds.size.height == 667)
#define iPhone6p                  ([UIScreen mainScreen].bounds.size.height == 736)
#define IS_IPHONE_X (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 812.0f)
#define NETWOTK_MANAGER             [YFHttpManager sharedInstance]
//定义屏幕框 高
#define  MAIN_HEIGHT                  [UIScreen mainScreen].bounds.size.height
#define  MAIN_WIDTH                   [UIScreen mainScreen].bounds.size.width
//阿里小视频相关宏
#define ScreenHeight                  [UIScreen mainScreen].bounds.size.height
#define  ScreenWidth                   [UIScreen mainScreen].bounds.size.width
#define SizeHeight(H) (H *(ScreenHeight)/568)
#define SizeWidth(W) (W *CGRectGetWidth([[UIScreen mainScreen] bounds])/320)
#ifdef kQPEnableDevNetwork
#define kQPResourceHostUrl @"http://m.api.inner.alibaba.net"
#else
#define kQPResourceHostUrl @"https://m-api.qupaicloud.com"
#endif
#define BundleID [[NSBundle mainBundle] bundleIdentifier]
#define SafeTop (([[UIScreen mainScreen] bounds].size.height-812) ? 0 : 44)
#define SafeBottom (([[UIScreen mainScreen] bounds].size.height-812) ? 0 : 34)
#define StatusBarHeight (CGRectGetHeight([UIApplication sharedApplication].statusBarFrame))
#define DebugModule 0b111101

#define  MAIN_FRAME                   [UIScreen mainScreen].bounds
#define  HEIGHT_NAVIGATION             64
#define  HEIGHT_NAVIGATION_X           88

#define  SCREEN_EQUAL_480              (MAIN_HEIGHT == 480 ? YES :NO )
#define  DISTANCE_TOP                  ((OS_ABOVE_IOS7) ? 0 : 20)
#define  DISTANCE_TOP_IOS6             0
#define  CIRCLE_TOP                    ((OS_ABOVE_IOS7) ? 20 :0)
#define  HEIGTH_IS_480                  ((int)MAIN_HEIGHT==480)
#define  HEIGHT_TAB_BOTTOM             49

#define statusBarH (CGRectGetHeight([UIApplication sharedApplication].statusBarFrame))
#define statusBar  (IS_IPHONE_X ? 24 : 0)
#define NaviHeight (statusBarH + 44)
#define TABBARHEIGHT (IS_IPHONE_X ? 83 : 49)
#define BottomHeight (IS_IPHONE_X ? 34 : 0)

#define mWindow             [[[UIApplication sharedApplication] windows] lastObject]
#define mKeyWindow          [[UIApplication sharedApplication] keyWindow]
#define mDelegateWindow     [[[UIApplication sharedApplication] delegate] window]

#define RANDOM_COLOR [UIColor colorWithHue: (arc4random() % 256 / 256.0) saturation:((arc4random()% 128 / 256.0 ) + 0.5) brightness:(( arc4random() % 128 / 256.0 ) + 0.5) alpha:1]

#define isDevice_iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)

//单例声明的公用函数
#define SINGLETON_FOR_HEADER(className) \
+ (className *)sharedInstance;

//单例实现的公用函数
#define SINGLETON_FOR_CLASS(className) \
+ (className *)sharedInstance { \
static className *shared = nil; \
static dispatch_once_t onceToken; \
dispatch_once(&onceToken, ^{ \
shared = [[self alloc] init]; \
}); \
return shared; \
}



#ifdef DEBUG
#define SpeLog(format, ...) NSLog(format, ## __VA_ARGS__)
#else
#define SpeLog(format, ...)
#endif

#ifdef DEBUG
#define SpeAssert(e) assert(e)
#else
#define SpeAssert(e)
#endif

//是否为空或是[NSNull null]
#define NotNilAndNull(_ref)  (((_ref) != nil) && (![(_ref) isEqual:[NSNull null]]))
#define IsNilOrNull(_ref)   (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]))

//字符串是否为空
#define IsStrEmpty(_ref)    (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]) ||([(_ref)isEqualToString:@""]))
//数组是否为空
#define IsArrEmpty(_ref)    (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]) ||([(_ref) count] == 0))

//颜色创建
#undef  RGBCOLOR
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]

#undef  RGBACOLOR
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#undef    HEX_RGB
#define HEX_RGB(V)        [UIColor colorWithRGBHex:V]

#undef UIColorFromHex
#define UIColorFromHex(s)  [UIColor colorWithRed:(((s & 0xFF0000) >> 16))/255.0green:(((s &0xFF00) >>8))/255.0 blue:((s &0xFF))/255.0 alpha:1.0]

//颜色转换

#define mRGB(r, g, b)     [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define mRGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

//rgb颜色转换（16进制->10进制）
#define mHexColor(hex) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:1.0]



typedef NS_ENUM(NSInteger, STATETYPE)
{
    STATETYPEBROWSE = 0,
    STATETYPECOLLECT,
};
#define equalTo(...)                     mas_equalTo(__VA_ARGS__)
#define mHexColorAlpha(hex,a) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:a]


//================

#define mDocumentDir   [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]
#define mCacheDir      [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject]
#define mTmpDir        NSTemporaryDirectory()
#define mHomeDir       NSHomeDirectory()

#define kAppDelegate ((AppDelegate *)[UIApplication sharedApplication].delegate)
//----------方法简写-------
#define mWindow             [[[UIApplication sharedApplication] windows] lastObject]
#define mKeyWindow          [[UIApplication sharedApplication] keyWindow]
#define mDelegateWindow     [[[UIApplication sharedApplication] delegate] window]
#define mUserDefaults       [NSUserDefaults standardUserDefaults]
#define mNotificationCenter [NSNotificationCenter defaultCenter]
#define mFont(size)         [UIFont systemFontOfSize:size]
#define mB_Font(size)       [UIFont boldSystemFontOfSize:size]
//id对象与NSData之间转换

#define mObjectToData(object)   [NSKeyedArchiver archivedDataWithRootObject:object]
#define mDataToObject(data)     [NSKeyedUnarchiver unarchiveObjectWithData:data]
//度弧度转换

#define mDegreesToRadian(x)      (M_PI * (x) / 180.0)
#define mRadianToDegrees(radian) (radian*180.0) / (M_PI)
//颜色转换

#define mRGB(r, g, b)     [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define mRGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

//系统蓝色
#define mAppMainColor mHexColor(0x3071b3)
#define mAppLightColor  mRGB(185, 180, 176)

//rgb颜色转换（16进制->10进制）
#define mHexColor(hex) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:1.0]

#define mHexColorAlpha(hex,a) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:a]

//G－C－D
#define mGCDBackground(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), block)
#define mGCDMain(block)       dispatch_async(dispatch_get_main_queue(),block)
#define mGCDAfter(sec, block) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)), dispatch_get_main_queue(), block)
#define mTimeSec 5

//简单的以AlertView显示提示信息
#define mAlertView(title, msg) \
UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil \
cancelButtonTitle:@"确定" \
otherButtonTitles:nil]; \
[alertView show];

//简单的以AlertController显示提示信息
#define mAlertController(title, msg, currentVC) \
UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];\
[alertController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {\
}]];\
[currentVC presentViewController:alertController animated:YES completion:nil];\


//----------设备系统相关---------
#define mIsiP4     ([UIScreen mainScreen].bounds.size.height == 480.0)
#define mIsiP5     ([UIScreen mainScreen].bounds.size.height == 568.0)
#define mIsiP6     ([UIScreen mainScreen].bounds.size.height == 667.0)
#define mIsiP6P    ([UIScreen mainScreen].bounds.size.height == 736.0)
#define mIsiPad     [[UIDevice currentDevice].model containString:@"iPad"]
#define mIsiPhone   (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define mIsiOS8     [[[UIDevice currentDevice] systemVersion] integerValue] == 8
#define mIsiOS7     [[[UIDevice currentDevice] systemVersion] integerValue] == 7
#define mIsiOS6     [[[UIDevice currentDevice] systemVersion] integerValue] == 6

#define iOS7Later ([UIDevice currentDevice].systemVersion.floatValue >= 7.0f)
#define iOS8Later ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f)
#define iOS9Later ([UIDevice currentDevice].systemVersion.floatValue >= 9.0f)
#define iOS9_1Later ([UIDevice currentDevice].systemVersion.floatValue >= 9.1f)
#define iOS10Later ([UIDevice currentDevice].systemVersion.floatValue >= 10.0f)

#define mLanguage   [[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"][0]
#define mSystemVersion   ([[UIDevice currentDevice] systemVersion])
#define mCurrentLanguage ([[NSLocale preferredLanguages] objectAtIndex:0])
#define mAPPVersion      [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
//----------页面设计相关-------
#define mNavBarHeight         44
#define mTabBarHeight         49
#define mScreenBounds         ([UIScreen mainScreen].bounds)
#define mScreenWidth          ([UIScreen mainScreen].bounds.size.width)
#define mScreenHeight         ([UIScreen mainScreen].bounds.size.height)
#define mMaxScreen            (MAX(mScreenWidth, mScreenHeight))//横竖屏切换
#define mMinScreen            (MIN(mScreenWidth, mScreenHeight))

#define mStatusBarHeight      ([UIApplication sharedApplication].statusBarFrame.size.height)
#define mNavHeight            (NaviHeight + mStatusBarHeight)
#define m6PScale              (mScreenWidth/1242.0)
#define m6Scale               (mScreenWidth/750.0)
#define m5Scale               (mScreenWidth/640.0)
#define k6Scale               (mScreenWidth/375.0)


#define USERNAME @"username"
#define PASSWORD @"password"
#define SECRETKEY @"secretkey"

//调试模式下输入NSLog，发布后不再输入。
#ifdef DEBUG
#define NSLog(...) NSLog(@"%s 第%d行 \n %@\n\n",__func__,__LINE__,[NSString stringWithFormat:__VA_ARGS__])
#else
#define NSLog(...)
#endif

// block self
#define mWeakSelf  __weak typeof (self)weakSelf = self;
#define mStrongSelf typeof(weakSelf) __strong strongSelf = weakSelf;

/* 封装归档keyedArchiver操作 */
#define mWZLSERIALIZE_ARCHIVE(__objToBeArchived__, __key__, __filePath__)    \
\
NSMutableData *data = [NSMutableData data]; \
NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];   \
[archiver encodeObject:__objToBeArchived__ forKey:__key__];    \
[archiver finishEncoding];  \
[data writeToFile:__filePath__ atomically:YES]


/* 封装反归档keyedUnarchiver操作 */
#define mWZLSERIALIZE_UNARCHIVE(__objToStoreData__, __key__, __filePath__)   \
NSMutableData *dedata = [NSMutableData dataWithContentsOfFile:__filePath__]; \
NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:dedata];  \
__objToStoreData__ = [unarchiver decodeObjectForKey:__key__];  \
[unarchiver finishDecoding]


#define gkeyFromEnvironment @"abcd01234567890123456789"
#define gdqFromEnvironment @"abcd01234567890123456789"

#define UmengKey @"5a3773f6b27b0a11940000ec"



#define SystemVersion [[[UIDevice currentDevice] systemVersion] floatValue]
#define IS_iOS8_x floor(SystemVersion) == 8
#define IS_iOS9_x floor(SystemVersion) == 9
#define IS_iOS10_x floor(SystemVersion) ==10
#define APP_VERSION [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"]

// webAPI 地址
#if DEBUG
//===================================================
#define YINGFENG_WEBAPI_URL @"https://www.ershouhui.com/"
//手机站地址
#define YINGFENG_HTML5_URL @"http://m1.yingfeng365.com/"

#define WEBAPI_URL @"http://auction.yingfeng365.net/"
//手机站测试地址
#define HTML5_URL @"http://m1.yingfeng365.com/"
//===================================================
//#define WEBAPI_URL @"http://101.200.86.224:8088/"
////手机站地址
//#define HTML5_URL @"http://101.200.86.224:8089/"
//
//#define YINGFENG_WEBAPI_URL @"http://60.205.140.180:84/"
////手机站地址
//#define YINGFENG_HTML5_URL @"http://60.205.140.180:83/"
//===================================================
#else

#define YINGFENG_WEBAPI_URL @"https://www.ershouhui.com/"
//手机站地址
#define YINGFENG_HTML5_URL @"http://m1.yingfeng365.com/"

#define WEBAPI_URL @"https://www.ershouhui.com/"
//手机站测试地址
#define HTML5_URL @"http://m1.yingfeng365.com/"

#endif

//阿里云图片地址
#define ALIYUN_IMAGE_URL @"http://image.ershouhui.com/"

//API地址拼接
#define getESHFullPath(param) [WEBAPI_URL stringByAppendingPathComponent:(param)]
#define getAPI(param) [WEBAPI_URL stringByAppendingPathComponent:(param)]
#define getYingFengAPI(param) [YINGFENG_WEBAPI_URL stringByAppendingPathComponent:(param)]
#define getH5API(param) [HTML5_URL stringByAppendingPathComponent:(param)]
#define getAliyunImage(param) [ALIYUN_IMAGE_URL stringByAppendingPathComponent:(param)]
#define getHtml5(param) [HTML5_URL stringByAppendingPathComponent:(param)]

//color 代码
#define Color_Text_Default_Black [UIColor colorWithHexString:@"#333333"]
#define Color_Text_Deep_Grey [UIColor colorWithHexString:@"#666666"]
#define Color_Text_Medium_Grey [UIColor colorWithHexString:@"999999"]
#define Color_Text_Light_Grey [UIColor colorWithHexString:@"d2d2d2"]
#define Color_Text_Green_Grey [UIColor colorWithHexString:@"dc0909"]

#define Color_Backgroud_Nav [UIColor colorWithHexString:@"#f9f9f9"]
#define Color_Backgroud_TabBar [UIColor colorWithHexString:@"#f9f9f9"]
#define Color_Backgroud_Content  [UIColor colorWithHexString:@"#f4f4f4"]

#define Color_Separator_Content [UIColor colorWithHexString:@"#eeeeee"]
#define Color_Orange [UIColor colorWithHexString:@"#ff6600"]
#define Color_red [UIColor colorWithHexString:@"#ff3300"]
#define Color_white [UIColor whiteColor]
//  默认常用颜色
#define ESHDefultBackGroundColor [UIColor colorWithHexString:@"#eeeeee"]
#define colorOrange [UIColor colorWithHexString:@"#ff6600"]
#define colorGreen [UIColor colorWithHexString:@"#7cd43a"]
#define colorYellow [UIColor colorWithHexString:@"#fee016"]
#define colorBlue [UIColor colorWithHexString:@"#00a1e9"]

//一像素的线
#define SINGLE_LINE_WIDTH           (1 / [UIScreen mainScreen].scale)
#define SINGLE_LINE_ADJUST_OFFSET   ((1 / [UIScreen mainScreen].scale) / 2)

//Tabbar
#define TabBarHomePageIndex 0
#define TabBarMessageIndex 1
#define TabBarUserProfileIndex 2
#define TabBarMoreIndex 3

//存储的用户信息
#define USERID @"user_id"
#define LOGINNAME @"login_name"
#define IOSClientID @"IOSClientID"  //clientID
#define IOSNewClientID @"IOSNewClientID"  //clientID

#define getLocal(key) [[NSUserDefaults standardUserDefaults]objectForKey:(key)]
#define setLocal(key, value) [[NSUserDefaults standardUserDefaults]setObject:(value) forKey:(key)]

//网络参数
#define RequestTimeoutInterval 10  //请求时长
#define CountDownTime 60        //请求验证码的间隔时长

#define baseViewTag 1000    //用作view的tag

//动画参数
#define SwitchStoryboardDuration 0.2

//debug
#ifdef DEBUG
#define debugLog(...) NSLog(__VA_ARGS__)
#define debugMethod() NSLog(@"%s", __func__)
#else
#define debugLog(...)
#define debugMethod()
#endif

//个推信息 development
#define kGtAppId           @"FVW7KE3ovR60R6hOyemKL"
#define kGtAppKey          @"WkL8px5NEh9OhVsjMUY585"
#define kGtAppSecret       @"TSzThpYj4U9DxCmvMq9EHA"

//KeyChain
#define KeyChainPassword @"user_password"
#define ESHNullPassword @""
#define isNullPassword(param) (param == nil || [ESHNullPassword isEqualToString:(param)])

/**
 用户相关
 */
//注册
#define ESHAPIMemberRegistePersonal getAPI(@"api/Member/Register")
#define ESHAPIMemberRegisteEnterprise getAPI(@"api/Member/ComRegister")
#define ESHAPIMemberCheckMobilePhoneRegisteState getAPI(@"api/Member/CheckTel")
#define ESHAPIMemberCheckEmailRegisteState getAPI(@"api/Member/CheckComEmail")
//  检查用户名是否可用
#define ESHAPIMemberCheckUserNameLog getAPI(@"api/Member/CheckUserNameLog")
//登录
#define ESHAPIMemberLogin getAPI(@"api/Member/Login")
//会员信息
#define ESHAPIMemberGetInfo getAPI(@"api/Member/GetMemberById")
//根据旧密码修改密码
#define ESHAPIMemberUpdataPsd getAPI(@"api/Member/ModifyPwd")
//重置密码
#define ESHAPIMemberRestPsd getAPI(@"api/Pwd/ResetPwd")
//保存帐号基本信息
#define ESHAPIMemberSaveAccountInfo getAPI(@"api/Member/SaveAccountInfo")
//将个推的clientID和用户关联起来
#define ESHAPIUpdateClientID getAPI(@"api/Member/UpdateClientID")
//根据cid回去邀请码
#define ESHAPIGetInviCodeByCid getAPI(@"api/AppSpread/GetInviCodeByCid")
//统一图片上传
#define ESHAPIAshxUploadFileToAliyun getAPI(@"Ashx/UploadFileToAliyun.ashx")
//上传个人身份证图片
#define ESHAPIPostImage getAPI(@"Ashx/UPIdCard.ashx")
//上传头像
#define ESHAPIPostAvator getAPI(@"Ashx/UPHeadPic.ashx")
//实名认证
#define ESHAPIPersonalMemberAuthe getAPI(@"api/Member/SavePersonIdcardInfo")
//获取用户资金情况
#define ESHAPIGetFunds getAPI(@"api/Member/GetMoneyInfo")
//上传企业认证中的图片
#define ESHAPIEnterprisePostImage getAPI(@"Ashx/UPCompanyImage.ashx")
//企业实名认证
#define ESHAPIEnterpriseRealnameAuth getAPI(@"api/Member/SaveCompanyInfo_app")
//企业申请人信息认证
#define ESHAPIEnterpriseApplyRoleAuth getAPI(@"api/Member/SaveComLegalAgent")
//绑定或修改邮箱
#define ESHAPIMemberBindOrUpdateEmail getAPI(@"api/Member/BindOrEditEmail")
//绑定或修改手机号
#define ESHAPIMemberBindOrUpdateMobilePhone getAPI(@"api/Member/BindOrEditPhone")
//单独修改个人用户某个用户信息
#define ESHAPIMemberUpdatePersonOneProperty getAPI(@"api/Member/SaveMemberPerInfo")
//单独修改企业用户某个用户信息
#define ESHAPIMemberUpdateEnterpriseProperty getAPI(@"api/Member/SaveMemberComInfo")
//绑定或更改个人电子邮箱
#define ESHAPIMemberBindPersonBindingEmail getAPI(@"api/Member/BindOrEditEmail_APP")
//绑定或更改企业手机号码
#define ESHAPIMemberBindEnterpriseBindingMobilePhone getAPI(@"api/Member/BindOrEditPhone_APP")

/**
 拍卖相关
 */
//获取专场拍最近场次
#define ESHAPIAuctionGetAppAucMenuName getAPI(@"api/Auction/GetAppAucMenuName")
//获取VIP金额
#define ESHAPIPayGetMoneyForVIP getAPI(@"api/Pay/GetMoneyForVIP")
//根据拍品ID请求需要交的保证金金额
#define ESHAPIPayGetRechargeBail getAPI(@"api/Pay/GetRechargeBail")
//获取天天拍数量
#define ESHAPIAuctionGetAuctionDayNum getAPI(@"api/Auction/GetAuctionDayNum")
//获取天天拍已成交设备数量
#define ESHAPIAuctionGetTenderTradedCount getAPI(@"api/Auction/GetTenderTradedCount")
//我的天天拍设备分类列表
#define ESHAPIBusinessGetDayDayAucEquStateEnum getAPI(@"api/Business/GetDayDayAucEquStateEnum")
//天天拍设备列表（旧机用）
#define ESHAPIAuctionFindTenderList getAPI(@"api/Auction/FindTenderList")
//天天拍设备列表（模型用 FT004）
#define ESHAPIAuctionFindAuctionDayList getAPI(@"api/Auction/FindAuctionDayList")
//已预约设备列表
#define ESHAPIAuctionFindToStartAuctionList getAPI(@"api/Auction/FindToStartAuctionList")
// 预约拍卖增加设备
#define ESHAPIBusinessAddBusApplySell getAPI(@"api/Business/AddBusApplySell")
//获取拍品预告列表
#define ESHAPIAuctionGetAuctionForecast getAPI(@"api/Auction/GetAuctionForecast")
//天天拍关注设备数量
#define ESHAPIAuctionFindAttTenderListCount getAPI(@"api/Auction/FindAttTenderListCount")
//专场拍关注设备数量
#define ESHAPIAuctionGetAttAuctionCount getAPI(@"api/Auction/GetAttAuctionCount")
//天天拍历史竞价设备列表
#define ESHAPIAuctionAuctionDayListHistory getAPI(@"api/Auction/AuctionDayListHistory")
//天天拍我关注的设备列表（旧机）
#define ESHAPIAuctionFindAttTenderList getAPI(@"api/Auction/FindAttTenderList")
//天天拍我关注的设备列表（模型）
#define ESHAPIAuctionFindAttAuctionDayList getAPI(@"api/Auction/FindAttAuctionDayList")
//获取天天拍人工估价（废弃）
#define ESHAPIBusinessGetDayAuctionManualPrice getAPI(@"api/Business/GetDayAuctionManualPrice")
//获取天天拍阶梯人工估价
#define ESHAPIBusinessGetReferPriceLadder getAPI(@"api/Business/GetReferPriceLadder")
//确认并充值保证金
#define ESHAPIBusinessConfirmDayAuction getAPI(@"api/Business/ConfirmDayAuction")
//获取送拍保证金金额
#define ESHAPIBusinessGetAppAucIdAndMargin getAPI(@"api/Business/GetAppAucIdAndMargin")
//流拍拍品是否需要在线充值
#define ESHAPIBusinessNoBidAuctionIsRecharge getAPI(@"api/Business/NoBidAuctionIsRecharge")
// 预约拍卖
#define ESHAPIBusinessApplyDayAuction getAPI(@"api/Business/ApplyDayAuction")
//提交 预约拍卖申请单
#define ESHAPIBusinessAddDayDayAucProduct getAPI(@"api/Business/AddDayDayAucProduct")
//修改要价
#define ESHAPIBusinessUpdateProductChargePrice getAPI(@"api/Business/UpdateProductChargePrice")
//取消预约
#define ESHAPIBusinessCancelAppointment getAPI(@"api/Business/CancelAppointment")
//天天拍设备列表筛选
#define ESHAPIAuctionGetTenderAuctionBrand getAPI(@"api/Auction/GetTenderAuctionBrand")

//专场拍列表
#define ESHAPIGetSpecialAuctions getAPI(@"api/Auction/FindAuctionField")
// 10 条资讯
#define ESHAPIGetNewsList getAPI(@"api/Home/GetZiXun")
//资讯地址
#define ESHAPIGetNews getAPI(@"Home/InfoDetailPhone/")
//获取专场拍拍品列表
#define ESHAPIFetchAuctionItemList getAPI(@"api/Auction/FindAuctionList")
//根据场次id获取场次中设备开拍时间是否确定
#define ESHAPIAuctionIsDefinite getAPI(@"api/Auction/IsDefinite")
//关注、取消关注
#define ESHAPIToggleAttention getAPI(@"api/Auction/AttentionProduct")
//用户协议地址
#define ESHAPIUserAgreementURL getAPI(@"HtmlPage/userProtocol.html")

//可退货规则地址
#define ESHAPIReturnRuleURL getH5API(@"Htmlpage/returnRule.html")
//可退货规则地址-寄售
#define ESHAPIReturnRuleURLForConsignSale getH5API(@"Htmlpage/returnRuleForConsignSale.html")
//质保规则地址
#define ESHAPIQualityRulesURL getH5API(@"Htmlpage/qualityRules.html")
//质保规则地址-寄售
#define ESHAPIQualityRulesURLForConsignSale getH5API(@"Htmlpage/qualityRulesForConsignSale.html")
//竞价规则地址
#define ESHAPIBidRuleURL getH5API(@"Htmlpage/BidRule.html")
//成交及服务费规则地址
#define ESHAPIServiceRuleURL getH5API(@"Htmlpage/serviceRule.html")
//卖家保证金规则地址
#define ESHAPISellBondURL getH5API(@"Htmlpage/sellBond.html")
//买家保证金规则地址
#define ESHAPIBuyBondURL getH5API(@"Htmlpage/BuyBond.html")
//获取用户订单列表
#define ESHAPIGetOrderList getAPI(@"api/Member/GetOrderList")
//获取下级区域
#define ESHAPIGetAreaListByParentId getAPI(@"api/Pcc/GetAreaListByParentId")
//发布卖品
#define ESHAPIAddSale  getAPI(@"Ashx/AddProduct.ashx")
//上传卖品照片
#define ESHAPISalePostImage getAPI(@"Ashx/PutObject.ashx")
//专场拍详情 阿里云图片地址
#define ESHAPIGetItemImage @"http://image.ershouhui.com/productlist/%@/%@.jpg@!list-01"         //@!yfmark9 压缩后的图片
//专场拍详情 视频地址
#define ESHAPIGetVideo  @"http://esh-product.oss-cn-beijing.aliyuncs.com/productlist/%@/video.mp4"
//获取从设备进入的竞价记录（所有竞价记录）
#define ESHAPIAuctionGetProductTenderListByPager getAPI(@"api/Auction/GetProductTenderListByPager")
//获取从拍品进入的竞价记录（本人的竞价记录-三条）
#define ESHAPIAuctionGetAuctionTenderList getAPI(@"api/Auction/GetAuctionTenderList")
//获取10条竞价信息
#define ESHAPIGetTop10Bid getAPI(@"api/Auction/FindAuctionBid")
//获取{挖掘机、装载机、破碎锤、压路机}机器基本信息
#define ESHAPIGetMechineInfoBasic getAPI(@"api/Auction/FindProModel")
//获取机器详细信息，包括外观、发动机、液压、底盘件
#define ESHAPIGetMechineInfoDetail getAPI(@"api/Auction/FindDetailInfo")
//获取{挖掘机、装载机}机器四个部位某一个的详细图片
#define ESHAPIGetMechineImagesDetail getAPI(@"api/Auction/FindImageInfo")
//获取{挖掘机、装载机}机器的损伤图，包括所有部位的大图、小图
#define ESHAPIGetMechineImagesdamaged getAPI(@"api/Auction/FindProductInfo")
//获取{破碎锤、压路机}机器的所有详细图片
#define ESHAPIGetMechineImagesDetail1 getAPI(@"api/Auction/FindProMacImageInfo")
//获取未检设备的详细信息
#define ESHAPIGetNotDetectedDetailInfo getAPI(@"api/Business/GetNotDetectedDetailInfo")
//获取未检设备的详细信息(new)
#define ESHAPIGetNotDetectedDetailInfoNew getAPI(@"api/Business/GetNotDetectedDetailInfo2")

/**
 我要买
 */
//搜索参数
#define ESHAPIBusinessGetAllProdutType getAPI(@"api/Business/GetAllProdutType")
//搜索参数
#define ESHAPIGetSearchInfo getAPI(@"api/Business/GetSearchInfo")
//我要买的设备列表（old-区分检测和未检测）
#define ESHAPIGetBusiness getAPI(@"api/Business/GetBusinessByPager")
//我要买的设备列表（new-不区分检测和未检测）
#define ESHAPIBusinessGetBusinessByPagerAll getAPI(@"api/Business/GetBusinessByPagerAll")
//我要买的设备数量（old）
#define ESHAPIGetBusinessCount getAPI(@"api/Business/GetPagerCount")
//我要买的设备数量（new）
#define ESHAPIGetPagerCountAll getAPI(@"api/Business/GetPagerCountAll")
//马上联系
#define ESHAPIBusinessAddContactNow getAPI(@"api/Business/AddContactNow")
//猜你喜欢
#define ESHAPIBusinessGetRecommendEquipment getAPI(@"api/Business/GetRecommendEquipment")
//降价通知
#define ESHAPIBusinessGetAddReducePrice getAPI(@"api/Business/AddReducePrice")
// 砍价
#define ESHAPIBusinessGetAddBargainPrice getAPI(@"api/Business/AddBargainPrice")

/**
 寄售
 */
// 已添加寄售设备
#define ESHAPIBusinessGetConsignSalePagerInfo getAPI(@"api/Business/GetConsignSalePagerInfo")
// 添加寄售设备
#define ESHAPIBusinessAddOrUpdateEquipment getAPI(@"api/Business/AddOrUpdateEquipment")
//寄售的设备列表
#define ESHAPIBusinessGetBusinessByPagerAllForConsignSale getAPI(@"api/Business/GetBusinessByPagerAllForConsignSale")
//获取寄售的设备类型
#define ESHAPIBusinessGetAllProdutTypeForConsignSale getAPI(@"api/Business/GetAllProdutTypeForConsignSale")
//寄售的设备数量
#define ESHAPIGetPagerCountAllForConsignSale getAPI(@"api/Business/GetPagerCountAllForConsignSale")
//搜索参数
#define ESHAPIGetSearchInfoForConsignSale getAPI(@"api/Business/GetSearchInfoForConsignSale")
//寄售数据-查看数、出价数
#define ESHAPIBusinessGetConsignSaleBargainInfo getAPI(@"api/Business/GetConsignSaleBargainInfo")
//出价记录前三条
#define ESHAPIBusinessGetConsignSaleBargainListTop3 getAPI(@"api/Business/GetConsignSaleBargainListTop3")
//取消寄售申请
#define ESHAPIBusinessCancelApplyConsignSale getAPI(@"api/Business/CancelApplyConsignSale")
//获取寄售场地
#define ESHAPIBusinessGetConsignAddress getAPI(@"api/Business/GetConsignAddress")
//申请寄售
#define ESHAPIBusinessAddConsignSaleProduct getAPI(@"api/Business/AddConsignSaleProduct")
//申请寄售
#define ESHAPIBusinessUpdateConsignSaleProduct getAPI(@"api/Business/UpdateConsignSaleProduct")
//获取年度协议
#define ESHAPIBusinessGetAgreementYear getAPI(@"api/Business/GetAgreementYear")
//我申请寄售的详细信息
#define ESHAPIBusinessGetConsignSaleModelInfo getAPI(@"api/Business/GetConsignSaleModelInfo")
//申请召回
#define ESHAPIBusinessApplyConsignRecall getAPI(@"api/Business/ApplyConsignRecall")
/** 取消申请寄售成功的通知 */
#define ESHBusinessCancelApplyConsignSaleSuccess @"ESHAPIBusinessCancelApplyConsignSaleSuccess"
/** 申请召回寄售成功的通知 */
#define ESHBusinessApplyConsignRecallSuccess @"ESHAPIBusinessApplyConsignRecall"
/** 获取寄售设备的出价记录 */
#define ESHAPISysConsignmentGetBargainListForUser getAPI(@"api/SysConsignment/GetBargainListForUser")

/**
 关于卖品 Sale
 */
//图片详细信息
#define ESHAPISaleGetDetailImages  getAPI(@"api/Business/GetDetailImg")
//商品详细信息
#define ESHAPISaleGetDetailInfo getAPI(@"api/Business/GetDetailInfo")
//商品是否被本人关注
#define ESHAPISaleIsCollectedByMe getAPI(@"api/BusOPLog/GetProductIsCollect")
//增加浏览次数
#define ESHAPISaleAddWatchCount getAPI(@"api/Shops/UpdateProBrowserNumber")
//关注卖品
#define ESHAPISaleCollectIt getAPI(@"api/BusOPLog/AddProductCollect")
//取消关注卖品
#define ESHAPISaleCancelCollecting getAPI(@"api/BusOPLog/CancelProductCollect")
//获取我的设备old（已废弃-必须要传是否已检测）
#define ESHAPISaleGetMyProduct getAPI(@"api/Member/GetMyProduct")
//获取我的设备new（有分页）
#define ESHAPIBusinessGetBusinessPagerInfo getAPI(@"api/Business/GetBusinessPagerInfo")
//我的设备-申请急售（OA功能，调试使用）
#define ESHAPIBusinessApplyUrgentSale getAPI(@"api/Business/ApplyUrgentSale")
//我的设备-确认急售
#define ESHAPIBusinessSureUrgentSale getAPI(@"api/Business/SureUrgentSale")
//我的设备-获取急售价格（点击确认急售时调用）
#define ESHAPIBusinessGetUrgentSalePrice getAPI(@"api/Business/GetUrgentSalePrice")
//我的设备-设置上传设备列状态（下架设备、已售设备）
#define ESHAPIBusinessSetBusApplySellState getAPI(@"api/Business/SetBusApplySellState")
//获取关注的产品
#define ESHAPISaleGetMyCollectedSalesNew getAPI(@"api/Shops/GetProCollectNew")
//获取关注（关注）产品列表
#define ESHAPIShopsGetProCollectPageInfo getAPI(@"api/Shops/GetProCollectPageInfo")
//首页我要卖发送手机号给后台
#define ESHAPISaleSendMobilePhoneToConnect getAPI(@"api/Business/AddProductForTel")
//获取推荐列表
#define ESHAPISaleGetRecommendedList getAPI(@"api/BuyNew/GetBuyRecommend")
//发送到手机
#define ESHAPIPaySendRemittanceSMS getAPI(@"api/Pay/SendRemittanceSMS")
//提交汇款信息
#define ESHAPIPaySubmintRemittanceInfo getAPI(@"api/Pay/SubmintRemittanceInfo")

/**
 关于商铺 Shop
 */
//获取该用户的商铺信息
#define ESHAPIShopGetDetailInfo  getAPI(@"api/Shops/GetShopInfo")
//获取该商铺下的设备列表
#define ESHAPIShopGetShopMechineList getAPI(@"api/Shops/GetBusinessByPager")
//查询申请的店铺名是否可用
#define ESHAPIShopCheckNameVisiable getAPI(@"api/Shops/CheckShopName")
//提交要申请的店铺信息
#define ESHAPIShopSubmitInfo getAPI(@"api/Shops/AddShopsInfo")
//修改店铺信息
#define ESHAPIShopUpdateShopInfo getAPI(@"api/Shops/UpdateShopsInfo")
//获取历史浏览数
#define ESHAPIShopGetWatchCountAll getAPI(@"api/Shops/GetShopBrowserAll")
//获取今日浏览数
#define ESHAPIShopGetWatchCountToday getAPI(@"api/Shops/GetShopBrowserToday")
//获取点赞数
#define ESHAPIShopGetPraiseCount  getAPI(@"api/Shops/GetShopGoodNum")
//判断是否被该用户点赞
#define ESHAPIShopIsPraisedByMe getAPI(@"api/BusOPLog/GetShopIsGood")
//判断是否被该用户关注
#define ESHAPIShopIsCollectedByMe getAPI(@"api/BusOPLog/GetShopIsCollect")
//关注商铺
#define ESHAPIShopCollectIt getAPI(@"api/BusOPLog/AddShopCollect")
//取消关注商铺
#define ESHAPIShopCancelCollecting  getAPI(@"api/BusOPLog/CancelShopCollect")
//点赞商铺
#define ESHAPIShopPraiseIt getAPI(@"api/BusOPLog/AddShopGood")
//取消点赞
#define ESHAPIShopCancelPraising  getAPI(@"api/BusOPLog/CancelShopGood")
//获取关注的店铺
#define ESHAPIShopGetMyCollectedShops getAPI(@"api/Shops/GetShopCollect")

/**
 求购
 */
//  发布求购信息
#define ESHAPIPurchaseUpdateBuyInfoNew getAPI(@"api/BuyNew/UpdateBuyInfoNew")
//  获取产品类型
#define ESHAPIPurchaseGetMechineType getAPI(@"api/Product/GetProType")
//  根据产品类型获取品牌
#define ESHAPIPurchaseGetBrandByProType getAPI(@"api/Product/GetBrandByProductTypeId")
//  根据品牌获取机型
#define ESHAPIPurchaseGetModelByBrand getAPI(@"api/Product/GetModelByBrandId")

//  获取求购范围搜索信息 新版（设备类型、品牌、省份、价格、吨位、年份、小时数、额度载重、功率、行走方式、类型、驱动方式、路况等）
#define ESHAPIPurchaseGetPriceAndTonRange getAPI(@"api/Product/GetRangeValue")
//  获取求购列表
#define ESHAPIPurchaseGetBuyingRequest getAPI(@"api/BuyNew/GetBuyInfoByPager")
//  提交求购信息
#define ESHAPIPurchaseSubmitBuyingRequest getAPI(@"api/BuyNew/AddNew")
//  删除求购信息
#define ESHAPIBuyNewDeleteBuyInfo getAPI(@"api/BuyNew/DeleteBuyInfo")

/**
 *  评估
 */
//  获取品牌类型
#define ESHAPIProductGetNewModel getAPI(@"api/Product/GetNewModel")
//  获取年份(old)
#define ESHAPIProductGetDateList getAPI(@"api/Assess/GetDateList")
//  获取年份(new)
#define ESHAPIProductGetDateListByType getAPI(@"api/Assess/GetDateListByType")
//  获取省份（所在地）列表-卖设备
#define ESHAPIAssessGetProvinceList getAPI(@"api/Assess/GetProvinceList")
//  获取评估结果（old）
#define ESHAPIProductGetAssWJResult getAPI(@"api/Assess/GetAssWJResult")
//  获取评估结果（new）
#define ESHAPIProductGetAssResult getAPI(@"api/Assess/GetAssResult")
//  根据价格获取建议价格
#define ESHAPIBusinessGetUpPrice getAPI(@"api/Business/GetUpPrice")

/**
 Pay 支付相关
 */
//  获取汇款金额
#define ESHAPIPayGetRemittanceAmount getAPI(@"api/Pay/GetRemittanceAmount")
//  获取正在进行的汇款单（true的时候所有设备不可以再确认送拍）
#define ESHAPIPayIsDoingRemittance getAPI(@"api/Pay/IsDoingRemittance")
//  新增支付订单
#define ESHAPIOnlinePayAddPayOrder getAPI(@"api/Pay/AddPayOrder")
//  资金流水
#define ESHAPIMemberMyMoneyList getAPI(@"api/Member/MyMoneyList")
//  冻结、解冻记录
#define ESHAPIMemberMyBailMoneyList getAPI(@"api/Member/MyBailMoneyList")
//  返还记录
#define ESHAPIMemberMyReturnOrderList getAPI(@"api/Member/MyReturnOrderList")
//  充值记录
#define ESHAPIMemberMyOrderList getAPI(@"api/Member/MyOrderList")
//  可返还保证金列表
#define ESHAPIMemberMyReturnOrder getAPI(@"api/Member/MyReturnOrder")
//  返还保证金提交
#define ESHAPIMemberSubmitReturnOrder getAPI(@"api/Member/SubmitReturnOrder")
//  获取订单状态的枚举
#define ESHAPIMemberGetOrderStateEnum getAPI(@"api/Member/GetOrderStateEnum")
//  根据客户电话获取看车保证金列表(单客户)
#define ESHAPISeeCarMarginGetSeeCarMarginModel getAPI(@"api/SeeCarMargin/GetSeeCarMarginModel")
//  获取公司账户信息
#define ESHAPIPayGetCompanyAccountInfo getAPI(@"api/Pay/GetCompanyAccountInfo")
/**
 关于消息
 */
#define ESHAPIMessageGetMessageList getAPI(@"api/ChatRoom/PostMyMsgList")
#define ESHAPIMessageGetMessageContent getAPI(@"api/ChatRoom/GetMessageById")
#define ESHAPIMessageReplayMessage getAPI(@"api/ChatRoom/ReplayMsg")

/**
 其他
 */
//验证码
//#define ESHAPITelCode getAPI(@"api/Member/SendTelCode")
//  获取验证码之前先获取加密字符串
#define ESHAPISystemGetAppKey getAPI(@"api/System/GetAppKey")
#define ESHAPITelCode getAPI(@"api/Member/SendTelCodeNew")
#define ESHAPIEmailCode getAPI(@"api/Tools/SendEmailCode")
#define ESHAPIVetifyCode getAPI(@"api/Pwd/SendCode")
#define ESHAPIFetchVoiceVetifiedCode getAPI(@"api/Member/GetVoiceCode")

//首页轮播图
#define ESHAPIGetCarousel getAPI(@"api/System/GetCarousel")
//拍卖会状态
#define ESHAPIGetAuctionHallStatus getAPI(@"api/Auction/GetAuctionHallStatus")
#define ESHAPIGetAuctionHallStatusMsg getAPI(@"api/Auction/GetAuctionHallStatusMsg")
//最新成交
#define  ESHAPIGetRecentDeal getAPI(@"api/Home/GetSaledList")
//累计发布和成交
#define  ESHAPIGetMechineCount getAPI(@"api/Home/GetCountOfPro")
//今日发布数量
#define ESHAPIHomeGetProductNum getAPI(@"api/Home/GetProductNum")

/******NewConfig******/
/**
 积分、账户
 */
//  获取银行列表
#define ESHAPIIntegralGetBankList getAPI(@"api/Integral/GetBankList")
//  积分历史纪录
#define ESHAPIGetDetailsByPager getAPI(@"api/Integral/GetDetailsByPager")
//  兑换历史纪录
#define ESHAPIGetChangeRecordsByPager getAPI(@"api/Integral/GetChangeRecordsByPager")
//  积分兑换请求
#define ESHAPIGetSaveChange getAPI(@"api/Integral/SaveChange")
//  获取积分兑换比率
#define ESHAPIGetChangeRate getAPI(@"api/Integral/GetChangeRate")
//  保存账户
#define ESHAPISaveAccount getAPI(@"api/Integral/SaveAccount")
//  获取账户信息
#define ESHAPIGetIntegralAccount getAPI(@"api/Integral/GetIntegralAccount")
//  获取积分信息
#define ESHAPIGetMemberById getAPI(@"api/Member/GetMemberById")
//  获取积分信息
#define ESHIntegralGetThisMonthChange getAPI(@"api/Integral/GetThisMonthChange")

/**
 卖设备
 */
//  上传图片（上传成功后会返回路径）
#define ESHAPIAshxPutObjectBatchHandler getAPI(@"Ashx/PutObjectBatchHandler.ashx")
//  发布卖品
#define ESHAPIBusinessAddSell getAPI(@"api/Business/AddSell")
// 检测卖设备信息
#define ESHAPIBusinessUpdateApply getAPI(@"api/Business/UpdateApply")
//  获取产品类型获取品牌
#define ESHAPIProductGetBrandByTypeAndFLetter getAPI(@"api/Product/GetBrandFroLetterAndHot")
//  提交卖设备申请
#define ESHAPIBusinessSellReservation getAPI(@"api/Business/SellReservation")
//  获取400电话
#define ESHAPISystemGetTel400 getAPI(@"api/System/GetTel400")

/**
 报名
 */
//  提交报名信息
#define ESHAPIMemberEnterAddMemberEnter getAPI(@"api/MemberEnter/AddMemberEnter")
//  获取报名状态
#define ESHAPIMemberEnterGetMemberEnterSet getAPI(@"api/MemberEnter/GetMemberEnterSet")
//  人员报名H5页面
#define ESHAPPAPPMemberMemberEnter getHtml5(@"/Member/MemberEnterWebApp?entertype=2")
//  设备报名H5页面
#define ESHAPPAPPMemberMemberEnterpro getHtml5(@"/Member/MemberEnterpro")

//  更新和启动图
#define ESHAPPUpdataXml getAPI(@"app/update.xml")
//  新用户推广（验证是否新用户）
#define ESHAPIAppSpreadisNewAppSpread getAPI(@"api/AppSpread/isNewAppSpread")
//  新用户推广（提交邀请码）
#define ESHAPIAppSpreadAddAppSpread getAPI(@"api/AppSpread/AddAppSpread")

/**
 品牌店铺
 */
//  店铺列表
#define ESHAPIShopsGetShopsByPagerAll getAPI(@"api/Shops/GetShopsByPagerAll")
//  店铺设备列表
#define ESHAPIShopsGetShopsGetShopsEquPageInfo getAPI(@"api/Shops/GetShopsEquPageInfo")
//  店铺详情页头部视图信息
#define ESHAPIShopsGetShopsGetShopsInfo getAPI(@"api/Shops/GetShopsInfo")

/**
 资讯
 */
//  获取资讯分类
//#define ESHAPIYingfengColumnColumnList @"http://60.205.140.180:84/yingfeng/Column/ColumnList"
#define ESHAPIYingfengColumnColumnList getYingFengAPI(@"yingfeng/Column/ColumnList")
#define ESHAPIArticleGetCategoryList getAPI(@"api/Article/GetCategoryList")
//  二手汇首页头条
#define ESHAPIHomeGetArticleTop getAPI(@"api/Home/GetArticleTop")
//  二手汇头条列表
#define ESHAPIHomeGetArticlePageInfo getAPI(@"api/Home/GetArticlePageInfo")
//  二手汇资讯列表（首页）
//#define ESHAPIYingfengArticleArticleList @"http://60.205.140.180:84/yingfeng/Article/ArticleList"
#define ESHAPIYingfengArticleArticleList getYingFengAPI(@"yingfeng/Article/ArticleList")
//  原资讯列表&工程信息
#define ESHAPIArticleGetArticleList getAPI(@"api/Article/GetArticleList")
//  资讯-发布或修改工程和设备
#define ESHAPIArticleArticleProject getAPI(@"api/Article/ArticleProject")
//  资讯-发布或修改求职和招聘
#define ESHAPIArticleArticleHire getAPI(@"api/Article/ArticleHire")
//  资讯-发布或修改配件
#define ESHAPIArticleArticleAccessory getAPI(@"api/Article/ArticleAccessory")
//  资讯-发布或修改故障咨询
#define ESHAPIArticleArticleFault getAPI(@"api/Article/ArticleFault")
//  资讯-获取发布下拉（枚举）数据
#define ESHAPIArticleGetEnumType getAPI(@"api/Article/GetEnumType")
//  资讯-获取发布设备类型下拉数据
#define ESHAPIArticleGetEquipmentType getAPI(@"api/Article/GetEquipmentType")
//  我的资讯-列表
#define ESHAPIArticleGetMyReleased getAPI(@"api/Article/GetMyReleased")
//  资讯-图片上传
#define ESHAPIAshxPutObjectBatchHandlerForArticle getAPI(@"Ashx/PutObjectBatchHandlerForArticle.ashx")
//  资讯-获取工程设备实体
#define ESHAPIArticleGetArticleProject getAPI(@"api/Article/GetArticleProject")
//  资讯-获取求职招聘实体
#define ESHAPIArticleGetArticleHire getAPI(@"api/Article/GetArticleHire")
//  资讯-获取配件实体
#define ESHAPIArticleGetArticleAccessory getAPI(@"api/Article/GetArticleAccessory")
//  资讯-获取故障咨询实体
#define ESHAPIArticleGetArticleFault getAPI(@"api/Article/GetArticleFault")
//  资讯-删除资讯
#define ESHAPIArticleGetDelMyReleased getAPI(@"api/Article/DelMyReleased")

//Notification
#define ESHConnect_error @"connect_error"   //网络引起的错误
#define ESHLogin_success @"login_success"   //服务器返回 登录成功
#define ESHLogin_fail @"login_fail"         //服务器返回 登录失败
#define ESHSignOUt_success @"signOut_success" //注销成功
#define ESHOpenCellAndStartConnection @"openCellAndStartConnection" //开启长连接
#define ESHCloseCellAndEndConnection @"closeCellAndEndConnection" //关闭T UI长连接
//  点击查看所有图片按钮
#define goodsDetailAllPicture @"ESHGoodsDetailViewControllerAllPictureButtonClick"
//  点击普通选择器中的item
#define ESHNormalSelectedViewItemClick @"ESHNormalSelectedViewItemClick"
//  关注设备成功
#define ESHAttention_success @"attention_success"
//  取消关注设备成功
#define ESHCancelAttention_success @"cancelAttention_success"
//  获取设备详情评估价格（金箍棒）
#define ESHAPIAuctionGetManualPriceByProductId getAPI(@"api/Auction/GetManualPriceByProductId")
//   预约拍卖添加设备成功
#define ESHAddApplyDailyAuctionEquipmentSuccess @"addApplyDailyAuctionEquipmentSuccess"
//   天天拍未关注设备详情页点击我要出价
#define ESHDailyAuctionInfoPageWantBidButtonClick @"DailyAuctionInfoPageWantBidButtonClick"
//   天天拍未关注设备详情页点击我要出价且关注成功
#define ESHDailyAuctionInfoPageWantBidButtonClickAndAttentSuccess @"dailyAuctionInfoPageWantBidButtonClickAndAttentSuccess"
/**
 字符常量（通知）
 */
//  网络连接失败
#define ESHNetError @"网络异常..."
#define ESHBackRefreash @"backRefreash"

/**
 发帖成功(通知)
 */
#define YFPostUpdate_success  @"updatePostInvitationSuccess"
/**
 删除成功(通知)
 **/
#define YFDeletePostInvitation_success @"DeletePostInvitationSuccess"

//  友盟分享
#define ESHUmengAppKey @"566ed58be0f55a45460024bf"
//  友盟统计的AppKey·
#define ESHUmengStatisticalAppKey @"569b030067e58ed1a3002ec4"
//  间距
#define MARGIN 5
//  导航栏高度
#define ESHTabBarHeight 49
//  轮播图的高度占屏幕的比例
#define HeightProportion 306 / 750
//  买设备列表cell高度
#define ROWHEIGHT_BUYLIST 94
//  正常的录入cell高度
#define ROWHEIGHT_POST 49
//  今日上传view高度
#define TODAY_UPLOAD_COUNTH 25

#define buttomViewHeight 55
//  父子控制器标签栏的高度
#define titleButtonHeight 40
//  导航栏＋状态栏高度
#define statusbarAndNavigationBarH 64
#define defultMargin 10
#define defultHalfMargin 5.5

#define KWidth_Scale [UIScreen mainScreen].bounds.size.width/375.0f
// 屏幕尺寸
#define ESHScreenH [UIScreen mainScreen].bounds.size.height
#define ESHScreenW [UIScreen mainScreen].bounds.size.width

#define iPhone6Previous ESHScreenH <= 568
#define iPhoneX ESHScreenH == 812

//  iphoneX底部适配
#define iPhoneXBottomSafeHeight (iPhoneX ? 45 : 0)

//  适配（根据iPhone6适配）
#define ESHRealValue(value) ((value)/375.0f*[UIScreen mainScreen].bounds.size.width)

// 日志输出
#if DEBUG // 开发阶段-DEBUG阶段:使用Log
#define ESHLog(...) NSLog(__VA_ARGS__)
#else // 发布阶段-上线阶段:移除Log
#define ESHLog(...)
#endif

// ENUM
typedef NS_ENUM(NSInteger, ESHMachineTypeId) {
    ESHMachineTypeIdExcavator = 27, //  挖掘机
    ESHMachineTypeIdLoader = 28,    //  装载机
    ESHMachineTypeIdBulldozer = 34, //  推土机
    ESHMachineTypeIdRoadRoller = 29,//  压路机
    ESHMachineTypeIdCrane = 35,     //  吊车
    ESHMachineTypeIdPumper = 36,    //  泵车
    ESHMachineTypeIdAgitatingLorry = 37,//  搅拌运输车
    ESHMachineTypeIdGrader = 38,        //  平地机
    ESHMachineTypeIdDumper = 39,        //  自卸车
    ESHMachineTypeIdQuarteringHammer = 30   //  破碎锤
};

//  程序主窗口
#define ESHKeyWindow [UIApplication sharedApplication].keyWindow

//  AFN配置
#ifndef TARGET_OS_IOS

#define TARGET_OS_IOS TARGET_OS_IPHONE

#endif

#ifndef TARGET_OS_WATCH

#define TARGET_OS_WATCH 0

#endif /* config_h */







#endif /* publicMacro_h */
