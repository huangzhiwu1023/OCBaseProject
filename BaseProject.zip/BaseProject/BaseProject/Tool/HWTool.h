//
//  HWTool.h
//  BaseProject
//
//  Created by 黄志武 on 2019/1/10.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWTool : NSObject
/**
 改变文字匹配到文字的颜色，大小
 color 颜色
 size 尺寸
 */
+(NSMutableAttributedString *)LabelAttributedstr:(NSString *)superStr colorString:(NSString *)colorString color:(UIColor *)color size:(CGFloat)size;

@end

NS_ASSUME_NONNULL_END
