//
//  HWTool.m
//  BaseProject
//
//  Created by 黄志武 on 2019/1/10.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import "HWTool.h"

@implementation HWTool

/**
 改变文字匹配到文字的颜色，大小
 color 颜色
 size 尺寸
 */
+(NSMutableAttributedString *)LabelAttributedstr:(NSString *)superStr colorString:(NSString *)colorString color:(UIColor *)color size:(CGFloat)size{
    
    //1.特定文字用法
    NSString *result = superStr;
    NSMutableAttributedString *attributeStr = [[NSMutableAttributedString alloc] initWithString:result];
    NSRange redRange = NSMakeRange([[attributeStr string] rangeOfString:colorString].location, [[attributeStr string] rangeOfString:colorString].length);
    
    [attributeStr addAttribute:NSForegroundColorAttributeName value:color range:redRange]; // 关键步骤，设置指定位置文字的颜色
    [attributeStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:size] range:redRange]; //关键步骤，设置指定位置文字的字号大小
    
    return attributeStr;
}

@end
