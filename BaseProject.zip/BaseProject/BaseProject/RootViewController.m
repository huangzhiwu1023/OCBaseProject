//
//  RootViewController.m
//  BaseProject
//
//  Created by 黄志武 on 2019/1/7.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import "RootViewController.h"
#import "HomeViewController.h"
#import "ClassViewController.h"
#import "FindViewController.h"
#import "ShopCartViewController.h"
#import "MineViewController.h"
#import "ZWTabBar.h"

@interface RootViewController ()<ZWTabBarDelegate>
@property (nonatomic, strong) HomeViewController *firstVC;
@property (nonatomic, strong) ClassViewController *secondVC;
@property (nonatomic, strong) FindViewController *thirdVC;
@property (nonatomic, strong) ShopCartViewController *fourthVC;
@property (nonatomic, strong) MineViewController *fifthVC;
@property (nonatomic, strong) ZWTabBar *ZWTabBar;
@property (nonatomic, strong) NSMutableArray *viewControllerCountArray;
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatChildVC];
    [self.tabBar showBadge:@"99" badgeColor:[UIColor purpleColor] badgeBackgroundColor:[UIColor greenColor] atIndex:2];
}

#pragma mark - 创建子控制器
- (void)creatChildVC {
    self.firstVC = [[HomeViewController alloc] init];
    self.secondVC = [[ClassViewController alloc] init];
    self.thirdVC = [[FindViewController alloc] init];
    self.fourthVC = [[ShopCartViewController alloc] init];
    self.fifthVC = [[MineViewController alloc] init];
    [self creatTagbBarWithChildVCArray:@[self.firstVC,self.secondVC,self.thirdVC,self.fourthVC,self.fifthVC] titleArray:@[@"首页",@"分类",@"发现",@"购物车",@"我的"] imageArray:@[@"home-normal",@"near-normal",@"fenlei-normal",@"shopping-normal",@"Personalcenter-normal"] selectedImageArray:@[@"home-Selected",@"near-selected",@"fenlei-Selected",@"shopping-selected",@"Personalcenter-selected"]];
}

//添加子模块
- (void)creatTagbBarWithChildVCArray:(NSArray <UIViewController *>*)childVCArray titleArray:(NSArray <NSString *> *)titleArray imageArray:(NSArray <NSString *>*)imageArray selectedImageArray:(NSArray <NSString *> *)selectedImageArray {
    for (UIViewController *viewController in childVCArray) {
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:viewController];
        [self.viewControllerCountArray addObject:navigationController];
    }
    self.ZWTabBar = [ZWTabBar tabBarWithFrame:self.tabBar.bounds titleArray:titleArray imageArray:imageArray selectedImageArray:selectedImageArray];
    self.ZWTabBar.ZWTabBarDelegate = self;
    [self setValue:self.ZWTabBar forKeyPath:@"tabBar"];
    self.viewControllers = self.viewControllerCountArray;
    self.selectedIndex = 0;
}


#pragma mark - cansTabBarDelegate
- (void)selectedZWTabBarItemAtIndex:(NSInteger)index {
    self.selectedIndex = index;
}


#pragma mark - 重写selectedIndex的set方法
- (void)setSelectedIndex:(NSUInteger)selectedIndex {
    [super setSelectedIndex:selectedIndex];
    self.ZWTabBar.selectedIndex = selectedIndex;
}





- (NSMutableArray *)viewControllerCountArray {
    if (!_viewControllerCountArray) {
        _viewControllerCountArray = [[NSMutableArray alloc] init];
    }
    return _viewControllerCountArray;
}

@end
