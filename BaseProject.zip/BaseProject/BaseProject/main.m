//
//  main.m
//  BaseProject
//
//  Created by 黄志武 on 2019/1/7.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
