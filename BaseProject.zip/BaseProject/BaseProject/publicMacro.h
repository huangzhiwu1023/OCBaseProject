//
//  publicMacro.h
//  BaseProject
//
//  Created by 黄志武 on 2019/1/10.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#ifndef publicMacro_h
#define publicMacro_h

//高、宽
#define mScreenWidth          ([UIScreen mainScreen].bounds.size.width)
#define mScreenHeight         ([UIScreen mainScreen].bounds.size.height)

//颜色
#define mRGB(r, g, b)     [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define mRGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define mHexColor(hex) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:1.0]
#define mHexColorAlpha(hex,a) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:a]

//字体
#define kFont_PF_Ultralight(fontSize) [UIFont fontWithName:@"PingFangSC-Ultralight" size:fontSize]
#define kFont_PF_Regular(fontSize) [UIFont fontWithName:@"PingFangSC-Regular" size:fontSize]
#define kFont_PF_Semibold(fontSize) [UIFont fontWithName:@"PingFangSC-Semibold" size:fontSize]
#define kFont_PF_Thin(fontSize) [UIFont fontWithName:@"PingFangSC-Thin" size:fontSize]
#define kFont_PF_Light(fontSize) [UIFont fontWithName:@"PingFangSC-Light" size:fontSize]
#define kFont_PF_Medium(fontSize) [UIFont fontWithName:@"PingFangSC-Medium" size:fontSize]

// 占位图片
#define kPlaceholderImage     [UIImage imageNamed:@"占位图"]

//字符串是否为空
#define IsStrEmpty(_ref)    (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]) ||([(_ref)isEqualToString:@""]))
//数组是否为空
#define IsArrEmpty(_ref)    (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]) ||([(_ref) count] == 0))

// block self
#define mWeakSelf  __weak typeof (self)weakSelf = self;
#define mStrongSelf typeof(weakSelf) __strong strongSelf = weakSelf;

//调试模式下输入NSLog，发布后不再输入。
#ifdef DEBUG
#define NSLog(...) NSLog(@"%s 第%d行 \n %@\n\n",__func__,__LINE__,[NSString stringWithFormat:__VA_ARGS__])
#else
#define NSLog(...)
#endif

/* 封装归档keyedArchiver操作 */
#define mWZLSERIALIZE_ARCHIVE(__objToBeArchived__, __key__, __filePath__)    \
\
NSMutableData *data = [NSMutableData data]; \
NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];   \
[archiver encodeObject:__objToBeArchived__ forKey:__key__];    \
[archiver finishEncoding];  \
[data writeToFile:__filePath__ atomically:YES]


/* 封装反归档keyedUnarchiver操作 */
#define mWZLSERIALIZE_UNARCHIVE(__objToStoreData__, __key__, __filePath__)   \
NSMutableData *dedata = [NSMutableData dataWithContentsOfFile:__filePath__]; \
NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:dedata];  \
__objToStoreData__ = [unarchiver decodeObjectForKey:__key__];  \
[unarchiver finishDecoding]


#endif /* publicMacro_h */

