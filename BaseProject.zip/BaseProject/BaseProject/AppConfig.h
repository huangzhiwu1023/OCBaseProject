//
//  AppConfig.h
//  BaseProject
//
//  Created by 黄志武 on 2019/1/10.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#ifndef AppConfig_h
#define AppConfig_h

#if DEBUG

#define N_HostSiteMain @"https://www.ershouhui.com/"

#else

#define N_HostSiteMain @"https://www.ershouhui.com/"

#endif

#endif /* AppConfig_h */
