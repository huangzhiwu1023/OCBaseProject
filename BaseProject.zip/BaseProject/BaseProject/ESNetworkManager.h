//
//  ESNetworkManager.h
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifndef ESNetworkManager_h
#define ESNetworkManager_h

typedef void (^ESNetWordSuccess)(NSURLSessionDataTask * task, id responseObject);

typedef void (^ESNetWordFailure)(NSURLSessionDataTask * task, NSError * error);

typedef void (^ESNetWordResult)(id data, NSError *error);

typedef void (^ESUploadProgress)(float progress);

typedef void (^ESDownloadProgress)(float progress);

#endif

@class RACSignal;
@interface ESNetworkManager : NSObject

+ (NSURLSessionDataTask *)GET:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure;

+ (NSURLSessionDataTask *)POST:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure;

+ (void)uploadImages:(NSArray *)imageArray
           urlString:(NSString *)urlString
              params:(NSDictionary *)params
         targetWidth:(float)width
        successBlock:(ESNetWordSuccess)successBlock
         failurBlock:(ESNetWordFailure)failureBlock
            progress:(ESUploadProgress)progress;

+ (void)downloadFileWithSavaPath:(NSString *)savePath
                       urlString:(NSString *)urlString
                          result:(ESNetWordResult)resultBlock
                        progress:(ESDownloadProgress)progress;

/**
 *  取消所有的网络请求
 */
+ (void)cancelAllRequest;

/**
 *  取消指定的url请求
 *
 *  @param requestType 该请求的请求类型
 *  @param string      该请求的完整url
 */

+ (void)cancelHttpRequestWithRequestType:(NSString *)requestType requestUrlString:(NSString *)string;

/**
    上传文件接口
    @param url 服务器地址
    @param parameters 字典 token
    @param fileData 要上传的数据
    @param name 服务器参数名称 @"file"
    @param fileName 文件名称 图片:xxx.jpg,xxx.png 视频:video.mp4
    @param mimeType 文件类型 图片:image/jpeg,image/png 视频:mp4->video/mpeg4  可参考网上对照表
    @param progress 上传进度
    @param success 成功回调
    @param failure 失败回调
 */
+ (void)upLoadToUrlString:(NSString *)url parameters:(NSDictionary *)parameters fileData:(NSData *)fileData name:(NSString *)name fileName:(NSString *)fileName mimeType:(NSString *)mimeType progress:(void (^)(NSProgress *progress))progress success:(void (^)(NSURLSessionDataTask *task, id responseObject))success failure:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;


@end

@interface ESNetworkManager (RAC)

/// RAC Post请求
+ (RACSignal *)rac_POST:(NSString *)hostString params:(NSDictionary *)params;

/// RAC Get请求
+ (RACSignal *)rac_GET:(NSString *)hostString params:(NSDictionary *)params;

+ (RACSignal *)rac_uploadImages:(NSArray *)uploadImages urlString:(NSString *)urlString params:(NSDictionary *)params targetWidth:(float)targetWidth;

#pragma ============================================================================



#pragma mark- ---------------------------实例--------------------------------
////登录
//+ (RACSignal *)requestWithUserName:(NSString *)username Withpwd:(NSString *)pwd;
////获取权限
//+ (RACSignal *)requestWithUserId:(NSString *)userId;
////获取销售下属ID
//+ (RACSignal *)getSellerIDs:(NSString *)userID;

#pragma mark- ---------------------------新机模块--------------------------------
//获取设备类型接口(挖掘机,装载机), 获取吨位(大中小挖)
+ (RACSignal *)getStoreEquipmentParam:(NSDictionary *)dic;
//获取品牌列表 新机主页
+ (RACSignal *)getBrandListParam:(NSDictionary *)dic;
//所有新机接口
+ (RACSignal *)getAllNewMachineWithParam:(NSDictionary *)dic;
//获取设备品牌接口
+ (RACSignal *)getBrandFilterParam:(NSDictionary *)dic;
//获取设备品牌头部详情
+ (RACSignal *)getBrandHeadDetail:(NSDictionary *)dic;
//所有经销商接口
+ (RACSignal *)getCompanyListData:(NSDictionary *)dic;
//请求店铺头部详情
+ (RACSignal *)getCompanyHeadDetail:(NSDictionary *)dic;
//获取所有省份
+ (RACSignal *)getProvinceList:(NSDictionary *)dic;
//获取所以市
+ (RACSignal *)getCityList:(NSDictionary *)dic;
//请求店铺详情下的新机列表接口
+ (RACSignal *)getCompanyNewMachineList:(NSDictionary *)dic;
//请求店铺下资讯&详情列表接口
+ (RACSignal *)getCompanyNewsList:(NSDictionary *)dic;
//获取机型的同时获取吨位信息
+ (RACSignal *)getStyleAndTonList:(NSDictionary *)dic;
//请求设备详情
+ (RACSignal *)getEquipmentHeadDetail:(NSDictionary *)dic;
//请求设备概述
+ (RACSignal *)getEquipmentDesc:(NSDictionary *)dic;
//请求设备参数
+ (RACSignal *)getEquipmentParam:(NSDictionary *)dic;
//请求设备照片
+ (RACSignal *)getEquipmentPhotos:(NSDictionary *)dic;
//请求商品照片
+ (RACSignal *)getGoodsPhotos:(NSDictionary *)dic;
//请求询价管理
+ (RACSignal *)getAskPrice:(NSDictionary *)dic;
//参数对比获取所有品牌
+ (RACSignal *)getComparisonBrand:(NSDictionary *)dic;
//参数对比获取所以有型号
+ (RACSignal *)getComparisonModel:(NSDictionary *)dic;
//参数对比参数
+ (RACSignal *)getCompareParam:(NSDictionary *)dic;
//获取所有的省市区
+ (RACSignal *)getAllProvinceAndCity:(NSDictionary *)dic;
//询价页面获取经销商
+ (RACSignal *)getPriceShop:(NSDictionary *)dic;
//对店铺,商品发表评论接口
+ (RACSignal *)sendComment:(NSDictionary *)dic;
//请求评论列表
+ (RACSignal *)getCommentList:(NSDictionary *)dic;
//请求文章详情
+ (RACSignal *)getArticleDetail:(NSDictionary *)dic;
//新的新机首页接口(带索引)
+ (RACSignal *)getNewBrandList:(NSDictionary *)dic;
//店铺下新机商品头部详情接口
+ (RACSignal *)getGoodsHeadDetail:(NSDictionary *)dic;
#pragma mark- ---------------New - 新机----------------
///** 设备类型-挖掘机/装载机.... */
//+ (RACSignal *)getBaseParam:(NSDictionary *)dic;
/** 新机首页品牌列表 */
+ (RACSignal *)getBrandListAndHot:(NSDictionary *)dic;
/** 选机筛选条件 */
+ (RACSignal *)getSelectMachineFilter:(NSDictionary *)dic;
/** 设备列表接口(选机) */
+ (RACSignal *)getSelectMchineList:(NSDictionary *)dic;
/** 设备详情头部 */
+ (RACSignal *)getEquipmentHead:(NSDictionary *)dic;

///判断收藏
+ (RACSignal *)judgeCommonCollection:(NSDictionary*)dic;

/** 获取设备设备分类(机型对比) */
+ (RACSignal *)getEquipSencondList:(NSDictionary *)dic;
/** 查询设备类型 */
+ (RACSignal *)getEquipType:(NSDictionary *)dic;
/** 请求机型对比参数 */
+ (RACSignal *)getNewCompareParam:(NSDictionary *)dic;
/** 根据省份和市名称获取Code */
+ (RACSignal *)getProvinceCodeWithName:(NSDictionary *)dic;


/** 店铺下的设备类型筛选 */
+ (RACSignal *)getCompanyType:(NSDictionary *)dic;
/** 店铺下的品牌筛选 */
+ (RACSignal *)getCompanyBrand:(NSDictionary *)dic;

/** 商品详情接口,调此接口是为了让商品浏览数+1 */
+ (RACSignal *)getShopGoodsDetailToAddOne:(NSDictionary *)dic;

#pragma mark- ---------------------------个人中心模块--------------------------------
//用户密码登录
+ (RACSignal *)userLoginwithParam:(NSDictionary *)dic;
//获取短信验证码
+ (RACSignal *)getCodeWithParam:(NSDictionary *)dic;
//修改用户头像
+ (RACSignal *)updateCustomImgWithParam:(NSDictionary *)dic;
//图片上传
+ (RACSignal *)uploadingImagWithParam:(NSDictionary *)dic;
//验证手机验证码
+ (RACSignal *)checkPhoneCodeWithParam:(NSDictionary *)dic;
//用户注册
+ (RACSignal *)userregisterWithParam:(NSDictionary *)dic;
//意见反馈
+ (RACSignal *)feedBackWithParam:(NSDictionary *)dic;
//短信登录
+ (RACSignal *)codeLoginWithParam:(NSDictionary *)dic;
//验证手机号是否注册
+ (RACSignal *)checkPhoneisRegisterWithParam:(NSDictionary *)dic;
//修改昵称
+ (RACSignal *)updateNickNameWithParam:(NSDictionary *)dic;
//忘记密码
+ (RACSignal *)updateCustomerPasswordWithParam:(NSDictionary *)dic;
//密钥登录
+ (RACSignal *)validateLoginKeyWithParam:(NSDictionary *)dic;

//微信登录
+ (RACSignal *)wechatLoginWithParam:(NSDictionary *)dic;
///短信验证+微信绑定
+ (RACSignal *)validatePhoneCodeAndWechatBindingParam:(NSDictionary*)dic;

///微信注册
+ (RACSignal *)wechatSignUpWithParam:(NSDictionary *)dic;
///解绑微信
+ (RACSignal *)wechatRemoveBindParam:(NSDictionary *)dic;
///微信绑定
+ (RACSignal *)wechatBingingParam:(NSDictionary *)dic;
///验证个人用户昵称是否可用
+ (RACSignal *)distinctNickNamePara:(NSDictionary *)dic;

#pragma mark- ---------------------------首页与资讯模块--------------------------------
//获取读秒广告图片
+(RACSignal *)getADImageWithParam:(NSDictionary *)dic;


#pragma mark -------- 个人中心-拍卖 --------
//我的资金
+ (RACSignal *)getMyMoneyWithMemberId:(NSString *)memberId;
//资金流水
+ (RACSignal *)getMoneyListWithMemberId:(NSString *)memberId PageIndex:(NSString *)pageIndex pageSize:(NSString *)pageSize;
//充值记录状态枚举
+ (RACSignal *)getEnumState;
//充值记录列表
+ (RACSignal *)getRechargeListWithMemberId:(NSString *)memberId State:(NSString *)state PageIndex:(NSString *)pageIndex pageSize:(NSString *)pageSize;;
//解冻、冻结记录
+ (RACSignal *)getFrozenlistWithMemberId:(NSString *)memberId PageIndex:(NSString *)pageIndex pageSize:(NSString *)pageSize Type:(NSString *)type;
//实名认证接口
+ (RACSignal *)getrealNameCertifyMemberId:(NSString *)memberId MemberName:(NSString *)memberName MemberIdcard:(NSString *)memberIdcard IdCardImgPositive:(NSString *)idCardImgPositive IdCardImgNegative:(NSString *)idCardImgNegative AreaPCC:(NSString *)areaPCC;
//获取返还记录接口
+ (RACSignal *)getRefundListWithDic:(NSDictionary *)dic;

#pragma mark -------- 小视频 --------
//视频Url上传接口
+ (RACSignal *)postVideoAndCoverPicWithDic:(NSDictionary *)dic;

+ (RACSignal *)getVideoMenu;
+ (RACSignal *)getVideoList:(NSDictionary *)dic;
//点赞视频
+ (RACSignal *)zanVideoWithDic:(NSDictionary *)dic;
//视频评论列表
+ (RACSignal *)getVideoCommentList:(NSDictionary *)dic;
//视频发表评论
+ (RACSignal *)sendVideoComment:(NSDictionary *)dic;
//播放数加1
+ (RACSignal *)addVideoPlayNum:(NSString *)videoId;
//删除视频
+ (RACSignal *)deleteVideo:(NSDictionary *)dic;

///小视频列表
+ (RACSignal *)shortVideosListWithParam:(NSDictionary*)dic;
///通用接口:获取分享数,1:浏览量，2:播放量"
+ (RACSignal *)videoRecordCommonParam:(NSDictionary *)dic;

#pragma mark -------- 二找相关 --------
//招聘信息列表
+ (RACSignal *)getJobInfoList:(NSDictionary *)dic;
//请求过滤条件
+ (RACSignal *)getJobFilter:(NSDictionary *)dic;
//招聘详情
+ (RACSignal *)getPublishJobDetail:(NSDictionary *)dic;
//求职详情
+ (RACSignal *)getApplyJobDetail:(NSDictionary *)dic;
//撤销发布
+ (RACSignal *)backPublish:(NSDictionary *)dic;
//删除二找
+ (RACSignal *)deleteJob:(NSDictionary *)dic;

#pragma mark -------- 二手机接口 --------
//二手机列表搜索筛选接口
+ (RACSignal *)getESJList:(NSDictionary *)dic;
//一级分类筛选
+ (RACSignal *)getESJFirstType:(NSDictionary *)dic;
//品牌筛选
+ (RACSignal *)getESJBrandList:(NSDictionary *)dic;
//二手机详情
+ (RACSignal *)getESJDetail:(NSDictionary *)dic;
//收藏和取消收藏
+ (RACSignal *)doCollectAction:(NSDictionary *)dic;
//请求个人主页
+ (RACSignal *)getESJPersonalHomeData:(NSDictionary *)dic;
//店铺二手机筛选条件
+ (RACSignal *)getShopESJFilterData:(NSDictionary *)dic;
//获取询价数量
+ (RACSignal *)getNumeber;
//删除我发布的二手机
+ (RACSignal *)deleteMyESJ:(NSDictionary *)dic;
//二手机上架和下架
+ (RACSignal *)upAndDwonESJ:(NSDictionary *)dic;
//我发布的二手机列表分组接口
+ (RACSignal *)getMyESJGroupList:(NSDictionary *)dic;
//我发布的二手机详情接口
+ (RACSignal *)getMyESJDetail:(NSDictionary *)dic;

//实名认证接口
+ (RACSignal *)realNameCertify:(NSDictionary *)dic;
//开通二手机业务
+ (RACSignal *)openESJBusiness:(NSDictionary *)dic;
//实名认证回显
+ (RACSignal *)getBackShowInfo:(NSDictionary *)dic;
//收藏用户列表
+ (RACSignal *)findCollectionCustomerList:(NSDictionary *)dic;
//询价用户列表
+ (RACSignal *)findEnquiryCustomerList:(NSDictionary *)dic;
//浏览人数列表
+ (RACSignal *)listCustomerViewVisitor:(NSDictionary *)dic;
//保存浏览信息
+ (RACSignal *)saveBrowseEquipDetail:(NSDictionary *)dic;

#pragma mark ------------------- 论坛-------------------------
//获取用户标签列表
+ (RACSignal *)getUserLabelList:(NSDictionary *)dic;
//获取可以添加的标签列表
+ (RACSignal *)getLabelListToAdd:(NSDictionary *)dic;
//设置用户标签 
+ (RACSignal *)setUserLabelList:(NSDictionary *)dic;
//论坛列表
+ (RACSignal *)findPostArticleControllerList:(NSDictionary *)dic;
//标题敏感词过滤
+ (RACSignal *)judgeArticlePostTitle:(NSDictionary *)dic;
//发布图文贴
+ (RACSignal *)saveArticlePostImageText:(NSDictionary *)dic;
//查询关注数，粉丝数和帖子数
+ (RACSignal *)findFocusCountAndFansCount;
//点赞和取消点赞
+ (RACSignal *)praiseInvitationArticlePost:(NSDictionary *)dic;

///直播点赞和取消点赞
+ (RACSignal *)praiseLiveWithParam:(NSDictionary*)dic;
//转发数自增
+ (RACSignal *)updateArticlePostForwardNumber:(NSDictionary *)dic;
//删除帖子
+ (RACSignal *)removeArticlePostInvitation:(NSDictionary *)dic;
//阅读量自增
+ (RACSignal *)updateArticleReadNumber:(NSDictionary *)dic;
//个人主页获取头部信息
+ (RACSignal *)personalCustomerPageHomeHeader:(NSDictionary *)dic;
//关注和取消关注
+ (RACSignal *)focusPersonArticleOn:(NSDictionary *)dic;
//获取视频上传Key
+ (RACSignal *)getAliyunSecretKey:(NSDictionary *)dic;

//论坛视频评论接口
+ (RACSignal *)sendForumVideoComment:(NSDictionary *)dic;
//论坛视频播放数+1
+ (RACSignal *)addForumVideoNum:(NSDictionary *)dic;
//论坛视频评论列表
+ (RACSignal *)getForumVideoCommentList:(NSDictionary *)dic;
//论坛视频点赞
+ (RACSignal *)zanForumVideo:(NSDictionary *)dic;
//修改用户访问时间/customer/updateVisitTime.json
+ (RACSignal *)customerUpdateVisitTime:(NSDictionary *)dic;
//删除评论接口
+ (RACSignal *)deleteForumComment:(NSDictionary *)dic;
//帖子详情界面 /articlePostController/findPostDetailByIdOrSequenceId.json
+ (RACSignal *)findPostDetailByIdSequence:(NSDictionary *)dic;


#pragma mark  --------消息中心-------
//获取系统消息接口
+ (RACSignal *)getTipsList:(NSDictionary *)dic;
//系统消息已读  设置全部已读不需要传tipsId
+ (RACSignal *)readTips:(NSDictionary *)dic;
//获取用户信息
+ (RACSignal *)getCustomerInfo:(NSDictionary *)dic;
//获取公告列表
+ (RACSignal *)getNoticeList:(NSDictionary *)dic;
//获取消息中心第一条消息和未读数
+ (RACSignal *)getNewsCenterFirstInfo:(NSDictionary *)dic;
//删除系统消息
+ (RACSignal *)deleteSystemNews:(NSDictionary *)dic;

#pragma mark  --------二手汇-------
+ (RACSignal *)ESHUpPic:(NSString *)str;
+ (RACSignal *)getESHDD ;

#pragma mark  --------直播-------
//获取直播列表接口
+ (RACSignal *)getLiveList:(NSDictionary *)dic;

#pragma mark ---------服务预约--------
//店铺预约服务管理编辑
+ (RACSignal *)storeBookingEditStoreBooking:(NSDictionary *)dic;
//经销商首页头部轮播
+ (RACSignal *)shopFrontPageFindStoreHeadByStoreSequence:(NSDictionary *)dic;
//经销商简介
+ (RACSignal *)getStoredDes:(NSDictionary *)dic;
//经销商图册
+ (RACSignal *)getStoredpPic:(NSDictionary *)dic;
//经销商视频
+ (RACSignal *)getStoredVideo:(NSDictionary *)dic;
//经销商直播列表
+ (RACSignal *)getStoreLiveList:(NSDictionary *)dic;

#pragma mark ------------ 小游戏---
//获取游戏密钥/storeGame/listSecretKey.json
+ (RACSignal *)storeGameListSecrrtKey:(NSDictionary *)dic;

#pragma mark ---------- 厂商旗舰店 ------
//厂商旗舰店头部接口
+ (RACSignal *)getFlagShopHeadData:(NSDictionary *)dic;
//厂商旗舰店首页接口
+ (RACSignal *)getFlagShophHomeData:(NSDictionary *)dic;
//厂商旗舰店产品接口
+ (RACSignal *)getFlagShopProductData:(NSDictionary *)dic;
//产品筛选条件接口
+ (RACSignal *)getFlagShopProductFilter:(NSDictionary *)dic;
//厂商旗舰店经销商列表接口
+ (RACSignal *)getFlagShopAgencyData:(NSDictionary *)dic;
//详情新闻列表接口
+ (RACSignal *)getFlagShopNewsList:(NSDictionary *)dic;
//厂商旗舰店联系我们接口
+ (RACSignal *)getFlagShopContactData:(NSDictionary *)dic;
//获取头像库数组
+ (RACSignal *)getHeadImages;
@end


