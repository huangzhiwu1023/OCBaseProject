//
//  ClassViewController.m
//  BaseProject
//
//  Created by 黄志武 on 2019/1/7.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import "ClassViewController.h"

@interface ClassViewController ()

@end

@implementation ClassViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =  [UIColor colorWithRed:((float)arc4random_uniform(256) / 255.0) green:((float)arc4random_uniform(256) / 255.0) blue:((float)arc4random_uniform(256) / 255.0) alpha:1.0];
    self.navigationItem.title = @"分类";
    [self.tabBarController.tabBar showBadge:@"10" badgeColor:[UIColor grayColor] badgeBackgroundColor:[UIColor orangeColor] atIndex:1];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
