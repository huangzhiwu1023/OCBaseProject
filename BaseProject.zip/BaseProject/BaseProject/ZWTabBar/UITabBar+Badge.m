//
//  UITabBar+Badge.m
//  BaseProject
//
//  Created by 黄志武 on 2019/1/7.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import "UITabBar+Badge.h"

@implementation UITabBar (Badge)
- (void)showBadge:(NSString *)badge atIndex:(NSInteger)index {
    
}

- (void)showBadge:(NSString *)badge badgeColor:(UIColor *)badgeColor badgeBackgroundColor:(UIColor *)backgroundColor atIndex:(NSInteger)index{
}

- (void)clearBadgeAtIndex:(NSInteger)index {
    
}
@end
