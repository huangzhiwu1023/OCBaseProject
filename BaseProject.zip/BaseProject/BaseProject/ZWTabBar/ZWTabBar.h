//
//  ZWTabBar.h
//  BaseProject
//
//  Created by 黄志武 on 2019/1/7.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITabBar+Badge.h"

@protocol ZWTabBarDelegate <NSObject>

/** 选中tabbar */
- (void)selectedZWTabBarItemAtIndex:(NSInteger)index;
@end

NS_ASSUME_NONNULL_BEGIN

@interface ZWTabBar : UITabBar
@property (nonatomic, strong) NSMutableArray *itemArray;
@property (nonatomic, assign) NSInteger selectedIndex;
@property (nonatomic, strong) NSArray *titleArray;
@property (nonatomic, strong) NSArray *imageArray;
@property (nonatomic, strong) NSArray *selectedImageArray;
@property (nonatomic, weak) id<ZWTabBarDelegate> ZWTabBarDelegate;
/** 实例化 */
+ (instancetype)tabBarWithFrame:(CGRect)frame titleArray:(NSArray <NSString *> *)titleArray imageArray:(NSArray <NSString *>*)imageArray selectedImageArray:(NSArray <NSString *> *)selectedImageArray;
@end

NS_ASSUME_NONNULL_END
