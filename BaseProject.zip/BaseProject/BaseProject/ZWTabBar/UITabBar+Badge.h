//
//  UITabBar+Badge.h
//  BaseProject
//
//  Created by 黄志武 on 2019/1/7.
//  Copyright © 2019年 zhiwu.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITabBar (Badge)

/**
 设置角标
 
 @param badge 角标值
 @param index tabbar的位置
 */
- (void)showBadge:(NSString *)badge atIndex:(NSInteger)index;

/**
 自定义角标背景,字体颜色
 
 @param badge 角标值
 @param badgeColor 角标字体颜色
 @param backgroundColor 角标背景颜色
 @param index tabbar位置
 */
- (void)showBadge:(NSString *)badge badgeColor:(UIColor *)badgeColor badgeBackgroundColor:(UIColor *)backgroundColor atIndex:(NSInteger)index;

/**
 清除角标
 
 @param index tabbar位置
 */
- (void)clearBadgeAtIndex:(NSInteger)index;

@end

NS_ASSUME_NONNULL_END
