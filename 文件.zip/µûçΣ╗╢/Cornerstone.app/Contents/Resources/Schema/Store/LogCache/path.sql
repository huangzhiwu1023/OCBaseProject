CREATE TABLE path
(
	id integer primary key autoincrement,
	text varchar(256) unique not null
);
