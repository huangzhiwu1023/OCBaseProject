//
//  YFNewHomeVC.swift
//  jsyf_user
//
//  Created by 黄志武 on 2018/8/22.
//  Copyright © 2018年 YF. All rights reserved.
//

import UIKit
import FTPopOverMenu_Swift
import SwiftyImage
import RxSwift
import RxCocoa
import SwiftyJSON
import Alamofire
//import Toast_Swift
import CoreTelephony

class YFNewHomeVC: UIViewController {

    fileprivate lazy var tableView : UITableView = { [weak self] in
        let tableview = UITableView(frame:CGRect.zero,style:.grouped)
        tableview.delegate = self
        tableview.dataSource = self
        tableview.bounces = false
        tableview.tableFooterView = UIView.init()
        tableview.backgroundColor = kBottomBgColor
        tableview.showsHorizontalScrollIndicator = false
        tableview.showsVerticalScrollIndicator = false
        tableview.separatorColor = UIColor(hex:"dfdfdf")
        tableview.separatorStyle = .none
        tableview.register(YFHomeNewsCell.self, forCellReuseIdentifier:YFHomeNewsCell.cellIdentifier)
        tableview.register(YFHomeVideoCell.self, forCellReuseIdentifier:YFHomeVideoCell.cellIdentifier)
        tableview.register(YFESJListModifyCell.self, forCellReuseIdentifier: "YFESJListModifyCell")
        return tableview
        }()
    var rightItem: UIBarButtonItem?
    var leftItem:  UIBarButtonItem?
    var NewestList = [NewestListSendData]()
  
    var arrNews = [HeadLineArr]()
    var forumArr = [ForumArr]()
    var videoArr = [VideoArr]()
    var esjList = [ESJListSenddata]()
    var esjArr = [EsjArr]()
    var esjArrProvice = [ESJListSenddata]()
    var esjArrAll = [ESJListSenddata]()
    var naviOne : YFHomeNaviView?
    var naviTwo : YFHomeNaviViewTwo?
    var isCountry : Bool = true
    var provice : String = "江苏省"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.setInsetNoneWith(self.tableView)
        self.title = "主页"
        self.navigationItem.titleView = UIView()
        getCacheData()
        setUI()
        addGameActionBtn()
        
    }

    /**
     * 获取游戏密钥
     **/
    func addGameActionBtn() {
        let addBtn = UIButton(type: .custom)
        addBtn.isHidden = true
        addBtn.setImage(UIImage(named: "game_n"), for: .normal)
        addBtn.contentHorizontalAlignment = .center
        addBtn.contentMode = .scaleAspectFit;
        addBtn.clipsToBounds = true
        self.view.addSubview(addBtn)
        self.view.bringSubview(toFront: addBtn)
        addBtn.snp.makeConstraints { (make) in
            make.right.equalTo(-16);
            make.bottom.equalTo(-30);
            make.height.equalTo(76);
            make.width.equalTo(80);
        }
        addBtn.addTarget(self, action: #selector(self.gameBtnClick(_:)), for: .touchUpInside)
    }
    
    @objc func gameBtnClick(_:UIButton) {
        let model = YFFlieTool.getUserModel()
        if (model != nil) {
            let vc = YFGameKeyListVC()
            self.navigationController?.pushViewController(vc
                , animated: true)
        } else {
            let vc = YFLoginVC()
            self.navigationController?.pushViewController(vc
                , animated: true)
        }
    }
    

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.edgesForExtendedLayout = []
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        //页面出现刷新头部定位
        naviOne?.locationLB?.text = getCurrentProvince()
        naviTwo?.locationLB?.text = getCurrentProvince()
        self.provice = getCurrentProvince()
        
        if self.provice == "全国" {
           self.isCountry = true
        }
        self.tableView.reloadData()
        
        getData()
        //是否展示小红点
        let naviV:YFHomeNaviView = (self.view.viewWithTag(8888) as? YFHomeNaviView) ?? YFHomeNaviView()
        if YFFlieTool.getUserModel() == nil {
            naviV.redPoint?.isHidden = true
        }
        else {
            YFFlieTool().getRedPointNum { (redNum) in
                if redNum > 0 {
                    naviV.redPoint?.isHidden = false
                }
                else {
                    naviV.redPoint?.isHidden = true
                }
            }
        }
        
        let navTwo:YFHomeNaviViewTwo = (self.view.viewWithTag(9999) as? YFHomeNaviViewTwo) ?? YFHomeNaviViewTwo()
        if YFFlieTool.getUserModel() == nil {
            navTwo.redPoint?.isHidden = true
        }
        else {
            YFFlieTool().getRedPointNum { (redNum) in
                if redNum > 0 {
                    navTwo.redPoint?.isHidden = false
                }
                else {
                    navTwo.redPoint?.isHidden = true
                }
            }
        }
 
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        if naviTwo?.alpha == 1 {
            return .default
        }
        return .lightContent
    }

    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}


extension YFNewHomeVC {
    //缓存
    func getCacheData() {
      let dic = ESToolAPI.BtnAPI.mSERIALIZE_UNARCHIVE(__filePath__: "YFHomeVCthr") as? [String :Any]
        if  dic != nil {
            self.esjList = YFFlieTool.dic(toEsjModel: dic!["secondEquListForAll"]  as? [Any] ??  [Any]()) as? [ESJListSenddata] ?? [ESJListSenddata]()
            _ = ESNetwork.shared.getDicToModel(dic: dic!).mapObject(type: YFNewHomeModel.self)
                .subscribe(onNext: { [weak self](model) in
                    self?.arrNews = model.newsArr
                    self?.forumArr = model.forumArr
                    self?.videoArr = model.videoArr
                    self?.esjArr = model.esjArrAll
                 
                    if let headerView = self?.tableView.tableHeaderView as? YFHomeHeadView {
                        headerView.configViewData(array: model.bannerArr, headNews: model.headLineArr, arr: model.navArr, secondNum: model.secondNum!,liveP: model.livePrompt!)
                    }
                    self?.tableView.reloadData()
                    }, onError: { [weak self] (error) in
                      //  self?.view.showWarning(error.localizedDescription)
                    }, onCompleted: {

                })

        }
        
    }
}

extension YFNewHomeVC{
    
    func getData() {
//        let provice: String = UserDefaults.standard.object(forKey: "provice") as? String ?? "全国"
        let provice: String = self.getCurrentProvince()
        let code = ESToolAPI.BtnAPI.getProvinceCode(provincename: provice, cityname: "").first ?? ""
        
        ESNetwork.shared.getHomeData(province: provice,provinceCode: code)
            .map() {json in
                guard let value = json["data"] as? [String : Any] else {
                    throw WSError(code: -1, localizedDescription: "数据格式不正确")
                }
                guard let value1 = value["sendData"] as? [String : Any] else {
                    throw WSError(code: -1, localizedDescription: "数据格式不正确")
                }
                print("===\(value1)==")
                ESToolAPI.BtnAPI.mSERIALIZE_ARCHIVE(__objToBeArchived__: value1, __filePath__: "YFHomeVCthr")
                self.NewestList = YFFlieTool.dic(toModel: value1["forumArr"] as? [Any] ??  [Any]()) as? [NewestListSendData] ?? [NewestListSendData]()
                  self.esjList = YFFlieTool.dic(toEsjModel: value1["secondEquListForAll"]  as? [Any] ??  [Any]()) as? [ESJListSenddata] ?? [ESJListSenddata]()
                self.esjArrProvice =  YFFlieTool.dic(toEsjModel: value1["secondEquList"]  as? [Any] ??  [Any]()) as? [ESJListSenddata] ?? [ESJListSenddata]()
                self.esjArrAll =  YFFlieTool.dic(toEsjModel: value1["secondEquListForAll"]  as? [Any] ??  [Any]()) as? [ESJListSenddata] ?? [ESJListSenddata]()
                if self.isCountry {
                    self.esjList = self.esjArrAll
                }else {
                    self.esjList = self.esjArrProvice
                }
                return value1
        }
           .mapObject(type: YFNewHomeModel.self)
            .subscribe(onNext: {[weak self] (model) in
                self?.arrNews = model.newsArr
                self?.forumArr = model.forumArr
                self?.videoArr = model.videoArr
                self?.esjArr = model.esjArr
                if let headerView = self?.tableView.tableHeaderView as? YFHomeHeadView {
                    headerView.configViewData(array: model.bannerArr, headNews: model.headLineArr, arr: model.navArr,secondNum:model.secondNum!,liveP:model.livePrompt!)
                    headerView.cycle?.scroll(toIndexNOAnimated: 0)
                    headerView.pageControl.currentPage = 0;
                }
             self?.tableView.reloadData()
            }, onError: { (error) in
                
            })
    }
}


extension YFNewHomeVC {
    
    func setUI() {
        let headerView = YFHomeHeadView.createView(vc:self)
        headerView.backgroundColor = UIColor.white
        view.addSubview(tableView)
        tableView.tableHeaderView = headerView
        tableView.snp.updateConstraints { (make) in
            make.top.equalTo(self.view).offset(0)
            make.right.equalTo(self.view).offset(0*m6Scale)
            make.left.equalTo(self.view).offset(0*m6Scale)
            make.bottom.equalTo(self.view).offset(0)
        }
        
        naviOne = YFHomeNaviView.init(frame: CGRect(x: 0, y: 0, width: mScreenWidth, height: mNavHeight))
        naviOne?.rootvc = self;
        self.view.addSubview(naviOne ?? UIView())
        naviOne?.tag = 8888
        naviOne?.locationLB?.text = getCurrentProvince();
        
        naviTwo = YFHomeNaviViewTwo.init(frame: CGRect(x: 0, y: 0, width: mScreenWidth, height: mNavHeight))
        naviTwo?.rootvc = self;
        self.view.addSubview(naviTwo ?? UIView())
        naviTwo?.tag = 9999
        naviTwo?.alpha = 0;
        naviTwo?.locationLB?.text = getCurrentProvince();
    }
    
    //获取省名
    func getCurrentProvince() -> String {
        var locationStr = YFUserDefaultTool.sharedInstance()?.getStringValue("centerProvince") ?? ""
        if locationStr.isEmpty {
            locationStr = YFUserDefaultTool.sharedInstance()?.getStringValue("provice") ?? ""
        }
        if locationStr.isEmpty {
            locationStr = "北京市"
        }
        return locationStr
    }
    
    
}


extension YFNewHomeVC : UIPopoverPresentationControllerDelegate {
    func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) -> Bool {
        return true
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
}

extension YFNewHomeVC :PYSearchViewControllerDelegate {
    func  searchViewController(_ searchViewController: PYSearchViewController!, searchTextDidChange searchBar: UISearchBar!, searchText: String!) {
        if(searchText.count>0)
        {
            var searchSuggestionsM:Array<String> = []
            let str1 = String(format:"搜索新机“%@”",searchText)
            let str2 = String(format:"搜索品牌“%@”",searchText)
            let  str3 = String(format:"搜索资讯“%@”",searchText)
            let  str4 = String(format:"搜索二手机“%@”",searchText)
            searchSuggestionsM.append(str1)
            searchSuggestionsM.append(str2)
            searchSuggestionsM.append(str3)
            searchSuggestionsM.append(str4)
            searchViewController.searchSuggestions = searchSuggestionsM;
        }
        
    }
}

extension YFNewHomeVC : PYSearchViewControllerDataSource {
    
    func searchViewController(_ searchViewController: PYSearchViewController!, didSearchWith searchBar: UISearchBar!, searchText: String!) {
        let vc = YFEquipmentSearchVC()
        vc.searchStr = searchBar.text ?? ""
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //热点搜索
    func searchViewController(_ searchViewController: PYSearchViewController!, didSelectHotSearchAt index: Int, searchText: String!) {
        //返回两个数组：关键字 、 对应的类型
        if(searchText.count>0)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                var searchSuggestionsM:Array<String> = []
                let str1 = String(format:"搜索新机“%@”",searchText)
                let str2 = String(format:"搜索品牌“%@”",searchText)
                let  str3 = String(format:"搜索资讯“%@”",searchText)
                let  str4 = String(format:"搜索二手机“%@”",searchText)
                searchSuggestionsM.append(str1)
                searchSuggestionsM.append(str2)
                searchSuggestionsM.append(str3)
                searchSuggestionsM.append(str4)
                searchViewController.searchSuggestions = searchSuggestionsM;
            }
            
        }
    }
    
    //历史搜索
    func searchViewController(_ searchViewController: PYSearchViewController!, didSelectSearchHistoryAt index: Int, searchText: String!) {
        
        if(searchText.count>0)
        {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                var searchSuggestionsM:Array<String> = []
                let str1 = String(format:"搜索新机“%@”",searchText)
                let str2 = String(format:"搜索品牌“%@”",searchText)
                let  str3 = String(format:"搜索资讯“%@”",searchText)
                let  str4 = String(format:"搜索二手机“%@”",searchText)
                searchSuggestionsM.append(str1)
                searchSuggestionsM.append(str2)
                searchSuggestionsM.append(str3)
                searchSuggestionsM.append(str4)
                searchViewController.searchSuggestions = searchSuggestionsM;
            }
            
        }
        
    }
    
    //点击栏搜索
    func searchViewController(_ searchViewController: PYSearchViewController!, didSelectSearchSuggestionAt indexPath: IndexPath!, searchBar: UISearchBar!) {
        if indexPath.row == 3 {
            let vc = YFESJSearchListVC()
            vc.searchStr = searchBar.text ?? ""
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 2 {
            let vc = YFNewsSearchVC()
            vc.searchStr = searchBar.text ?? ""
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }else  if indexPath.row == 1 {
            let vc = YFBrandSearchVC()
            vc.searchStr = searchBar.text ?? ""
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }else  if indexPath.row == 0 {
            let vc = YFEquipmentSearchVC()
            vc.searchStr = searchBar.text ?? ""
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func searchViewController(_ searchViewController: PYSearchViewController!,didSearchWithSearchBar searchBar: UISearchBar!,searchText: String!)
    {
        let vc = YFEquipmentSearchVC()
        vc.searchStr = searchBar.text ?? ""
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension YFNewHomeVC: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return self.esjList.count
        }else if section == 1 {
          return self.forumArr.count > 4 ? 4 : self.forumArr.count
        }else  {
             return 1
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 124
        }
        else if indexPath.section == 2 {
            return 301
        }else {
            return 98 
        }
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0{
            let esjCell = tableView.dequeueReusableCell(withIdentifier: "YFESJListModifyCell", for: indexPath) as! YFESJListModifyCell
            let model = self.esjList[indexPath.row]
            esjCell.model = model;
            return esjCell
        } else if indexPath.section == 1 {
            let deCell = tableView.dequeueReusableCell(withIdentifier: YFHomeNewsCell.cellIdentifier) as! YFHomeNewsCell
            let model = self.forumArr[indexPath.row]
            print("model=\(model)")
             deCell.configForumModelData(model:model )
            return deCell
        }else {
            let cell = tableView.dequeueReusableCell(withIdentifier: YFHomeVideoCell.cellIdentifier) as! YFHomeVideoCell
            cell.confitData(model: self.videoArr)
            cell.vc = self
            return cell
        }
        
      
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
      
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let view = UILabel()
        view.text = "查看更多"
        view.textColor = kNewYColor
        view.textAlignment = .center
        view.font = kAppFont(fontName: .regular, fontSize: 13)
        view.backgroundColor = kBottomBgColor
        view.frame = CGRect(x: 0, y: 0, width: mScreenWidth, height: 40)
        view.tapHandle { () -> String? in
            let vc = YFESJListVC()
            self.navigationController?.pushViewController(vc, animated: true)
            return ""
        }
        return view
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        
        let view = YFHomeHeaderFooterView()
    
        //view.moreLabel.isHidden = true
        if section == 0 {
            view.titleImage.image = UIImage.init(named: "home_esj_title")
            if self.provice == "全国" {
             view.moreLabel.isHidden = true
            view.lineLabel.isHidden = true
            }else{
                view.moreLabel.isHidden = false
                view.lineLabel.isHidden = false
            }
            
            if self.isCountry {
                view.allLabel.textColor = UIColor(hex: "F48F4A")
                view.moreLabel.textColor = UIColor(hex: "3E4A59")
                view.moreLabel.text = self.provice
            }else{
                view.moreLabel.textColor = UIColor(hex: "F48F4A")
                view.allLabel.textColor = UIColor(hex: "3E4A59")
                view.moreLabel.text = self.provice
            }
            
            view.allLabel.tapHandle { () -> String? in
                view.allLabel.textColor = UIColor(hex: "F48F4A")
                view.moreLabel.textColor = UIColor(hex: "3E4A59")
                self.isCountry = true
                self.esjList = self.esjArrAll
                self.tableView.reloadData();
                return ""
            }
      
            view.moreLabel.tapHandle { () -> String? in
                view.moreLabel.textColor = UIColor(hex: "F48F4A")
                view.allLabel.textColor = UIColor(hex: "3E4A59")
                 self.isCountry = false
                self.esjList = self.esjArrProvice
                self.tableView.reloadData();
                return ""
            }
   
        }else if  section == 1 {
            view.titleImage.image = UIImage.init(named: "home_forum_title")
        }else {
            view.titleImage.image = UIImage.init(named: "home_video_title")
        }
        view.titleImage.tapHandle { [weak self]() -> String? in
            if section == 0 {
            let vc = YFESJListVC()
                vc.isCountry = (self?.isCountry)!
                //vc.homeProvinceCode = ""
                self?.navigationController?.pushViewController(vc, animated: true)
            }else if  section == 1 {
                 YFTabBarControllerConfig.yf_tabBarController().selectedIndex = 2;
            }else {
                 NotificationCenter.default.post(name: NSNotification.Name(rawValue: "videoHome"), object: nil)
                 YFTabBarControllerConfig.yf_tabBarController().selectedIndex = 2;
            }
            let str = section == 0 ? "更多二手机":"更多视频"
            return str
        }
        return view
    }
    
}

extension YFNewHomeVC:UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.section == 0 {
            let vc = YFGoodsDetailVC()
            let sku = self.esjList[indexPath.row].equipmentSku;
            vc.parameterStr = String(format: "%zi", sku)
           self.esjList[indexPath.row].viewNumber += 1
            vc.listModel = self.esjList[indexPath.row];
            self.navigationController?.pushViewController(vc, animated: true)
        }else if indexPath.section == 1 {
            let model = self.forumArr[indexPath.row]
               let sendModel = self.NewestList[indexPath.row]
            if model.forumTypeFlag == "1" {//视频
                let vc = YFForumFullScrollPlayerVC()
                vc.dataList = [sendModel]
                vc.showIndex = 0
                 self.navigationController?.pushViewController(vc, animated: true)
            }else{
                let sendModel = self.NewestList[indexPath.row]
                let vc = YFInvitationDetailVC()
                print("\(sendModel.praisNumber)")
                vc.sendData = sendModel
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
         
        }else{
            
        }
        
        
     
    }
    
}


extension YFNewHomeVC : UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if self.tableView.contentOffset.y > 320 {
           self.tableView.bounces = true
        }else {
           self.tableView.bounces = false
        }
        //计算偏移,改变导航
        let minAlphaOffset = 0.0;
        let maxAlphaOffset = mScreenWidth  / 1.7 - mNavHeight;
        let offset = scrollView.contentOffset.y;
        let alpha = (offset - CGFloat(minAlphaOffset)) / (maxAlphaOffset - CGFloat(minAlphaOffset));
        var alpha2 = 1.0 - alpha
        if (alpha2 <= 0.2) {
            alpha2 = 0;
        }
        naviOne?.alpha = alpha2;
        if alpha2 == 0.0 {
            naviTwo?.alpha = 1;
            self.setNeedsStatusBarAppearanceUpdate()
        }
        else {
            naviTwo?.alpha = 0;
            self.setNeedsStatusBarAppearanceUpdate()
        }
    }
}



